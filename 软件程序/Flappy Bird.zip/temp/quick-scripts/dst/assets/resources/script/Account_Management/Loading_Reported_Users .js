
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Loading_Reported_Users .js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'cc8ca7SnsNONIRq0fD+GC6m', 'Loading_Reported_Users ');
// resources/script/Account_Management/Loading_Reported_Users .js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //账号管理预制体
    Account_Managent_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    Report_Information_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    Account_Management_Local_Variable.Reported_Users_Information = null;
    this._Is_Loading = true;
    WeChat.Loading_Reporterd_User();
    console.log("被举报人信息个数", Account_Management_Local_Variable.Reported_Users_Information.length);
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Account_Management_Local_Variable.Reported_Users_Information != null) {
      this.Loading_Reported_Users();
      this._Is_Loading = false;
    }
  },
  Loading_Reported_Users: function Loading_Reported_Users() {
    for (var i = 0; i < Account_Management_Local_Variable.Reported_Users_Information.length; i++) {
      console.log("1");
      var New_Account_Label = cc.instantiate(this.Account_Label);
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Reported_Users_Information[i].openid;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Reported_Users_Information[i].User_state;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].Reported_Count;
      var openidlist = Account_Management_Local_Variable.Reported_Users_Information[i].openidlist;
      New_Account_Label.height = 500 + openidlist.length * 200;
      this.Account_Managent_View.addChild(New_Account_Label);

      for (var j = 0; j < openidlist.length; j++) {
        console.log("查看openidlist", openidlist[j]);
        var New_Report_Information_Label = cc.instantiate(this.Report_Information_Label);
        New_Account_Label.addChild(New_Report_Information_Label);
        New_Report_Information_Label.getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + openidlist[j].Reported_Openid;
        New_Report_Information_Label.getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + openidlist[j].Report_Time.toString();
        New_Report_Information_Label.getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + openidlist[j].Report_Reason;
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcTG9hZGluZ19SZXBvcnRlZF9Vc2VycyAuanMiXSwibmFtZXMiOlsiQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQWNjb3VudF9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkFjY291bnRfTWFuYWdlbnRfVmlldyIsIk5vZGUiLCJSZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwiLCJfSXNfTG9hZGluZyIsIm9uTG9hZCIsIlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uIiwiV2VDaGF0IiwiTG9hZGluZ19SZXBvcnRlcmRfVXNlciIsImNvbnNvbGUiLCJsb2ciLCJsZW5ndGgiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiTG9hZGluZ19SZXBvcnRlZF9Vc2VycyIsImkiLCJOZXdfQWNjb3VudF9MYWJlbCIsImluc3RhbnRpYXRlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIm9wZW5pZCIsIlVzZXJfc3RhdGUiLCJBbGxfVXNlcnNfSW5mb3JtYXRpb24iLCJSZXBvcnRlZF9Db3VudCIsIm9wZW5pZGxpc3QiLCJoZWlnaHQiLCJhZGRDaGlsZCIsImoiLCJOZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsIiwiUmVwb3J0ZWRfT3BlbmlkIiwiUmVwb3J0X1RpbWUiLCJ0b1N0cmluZyIsIlJlcG9ydF9SZWFzb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsaUNBQWlDLEdBQUdDLE9BQU8sQ0FBQyxtQ0FBRCxDQUEvQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLGFBQWEsRUFBRTtBQUNkLGlCQUFTLElBREs7QUFFZEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRks7QUFHZEMsTUFBQUEsV0FBVyxFQUFFO0FBSEMsS0FESjtBQUtSO0FBQ0hDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3RCLGlCQUFTLElBRGE7QUFFdEJILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxJQUZhO0FBR3RCRixNQUFBQSxXQUFXLEVBQUU7QUFIUyxLQU5aO0FBVVI7QUFDSEcsSUFBQUEsd0JBQXdCLEVBQUU7QUFDekIsaUJBQVMsSUFEZ0I7QUFFekJMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZnQjtBQUd6QkMsTUFBQUEsV0FBVyxFQUFFO0FBSFksS0FYZjtBQWdCWEksSUFBQUEsV0FBVyxFQUFFO0FBaEJGLEdBSEo7QUFzQlI7QUFFQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCZCxJQUFBQSxpQ0FBaUMsQ0FBQ2UsMEJBQWxDLEdBQStELElBQS9EO0FBQ0EsU0FBS0YsV0FBTCxHQUFtQixJQUFuQjtBQUNBRyxJQUFBQSxNQUFNLENBQUNDLHNCQUFQO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JuQixpQ0FBaUMsQ0FBQ2UsMEJBQWxDLENBQTZESyxNQUFyRjtBQUVBLEdBOUJPO0FBZ0NSQyxFQUFBQSxLQWhDUSxtQkFnQ0EsQ0FFUCxDQWxDTztBQW9DUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEIsUUFBSSxLQUFLVixXQUFMLElBQW9CYixpQ0FBaUMsQ0FBQ2UsMEJBQWxDLElBQWdFLElBQXhGLEVBQThGO0FBQzdGLFdBQUtTLHNCQUFMO0FBQ0EsV0FBS1gsV0FBTCxHQUFtQixLQUFuQjtBQUNBO0FBQ0QsR0F6Q087QUEwQ1JXLEVBQUFBLHNCQTFDUSxvQ0EwQ2lCO0FBQ3hCLFNBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR3pCLGlDQUFpQyxDQUFDZSwwQkFBbEMsQ0FBNkRLLE1BQWpGLEVBQXlGSyxDQUFDLEVBQTFGLEVBQThGO0FBQzdGUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxHQUFaO0FBQ0EsVUFBSU8saUJBQWlCLEdBQUd4QixFQUFFLENBQUN5QixXQUFILENBQWUsS0FBS3JCLGFBQXBCLENBQXhCO0FBQ0FvQixNQUFBQSxpQkFBaUIsQ0FBQ0UsY0FBbEIsQ0FBaUMsMEJBQWpDLEVBQTZEQSxjQUE3RCxDQUE0RSxlQUE1RSxFQUE2RkEsY0FBN0YsQ0FDQyxjQURELEVBQ2lCQyxZQURqQixDQUM4QjNCLEVBQUUsQ0FBQzRCLEtBRGpDLEVBQ3dDQyxNQUR4QyxHQUNpRCxLQUFLL0IsaUNBQWlDLENBQUNlLDBCQUFsQyxDQUNyRFUsQ0FEcUQsRUFDbERPLE1BRko7QUFHQU4sTUFBQUEsaUJBQWlCLENBQUNFLGNBQWxCLENBQWlDLDBCQUFqQyxFQUE2REEsY0FBN0QsQ0FBNEUsc0JBQTVFLEVBQW9HQSxjQUFwRyxDQUNDLHFCQURELEVBQ3dCQyxZQUR4QixDQUNxQzNCLEVBQUUsQ0FBQzRCLEtBRHhDLEVBQytDQyxNQUQvQyxHQUN3RCxLQUFLL0IsaUNBQWlDLENBQUNlLDBCQUFsQyxDQUM1RFUsQ0FENEQsRUFDekRRLFVBRko7QUFHQVAsTUFBQUEsaUJBQWlCLENBQUNFLGNBQWxCLENBQWlDLDBCQUFqQyxFQUE2REEsY0FBN0QsQ0FDQywyQ0FERCxFQUM4Q0EsY0FEOUMsQ0FDNkQsMENBRDdELEVBQ3lHQyxZQUR6RyxDQUVDM0IsRUFBRSxDQUFDNEIsS0FGSixFQUVXQyxNQUZYLEdBRW9CLEtBQUsvQixpQ0FBaUMsQ0FBQ2tDLHFCQUFsQyxDQUF3RFQsQ0FBeEQsRUFBMkRVLGNBRnBGO0FBR0EsVUFBSUMsVUFBVSxHQUFHcEMsaUNBQWlDLENBQUNlLDBCQUFsQyxDQUE2RFUsQ0FBN0QsRUFBZ0VXLFVBQWpGO0FBQ0FWLE1BQUFBLGlCQUFpQixDQUFDVyxNQUFsQixHQUEyQixNQUFNRCxVQUFVLENBQUNoQixNQUFYLEdBQW9CLEdBQXJEO0FBQ0EsV0FBS1YscUJBQUwsQ0FBMkI0QixRQUEzQixDQUFvQ1osaUJBQXBDOztBQUNBLFdBQUssSUFBSWEsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsVUFBVSxDQUFDaEIsTUFBL0IsRUFBdUNtQixDQUFDLEVBQXhDLEVBQTRDO0FBQzNDckIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QmlCLFVBQVUsQ0FBQ0csQ0FBRCxDQUF0QztBQUNBLFlBQUlDLDRCQUE0QixHQUFHdEMsRUFBRSxDQUFDeUIsV0FBSCxDQUFlLEtBQUtmLHdCQUFwQixDQUFuQztBQUNBYyxRQUFBQSxpQkFBaUIsQ0FBQ1ksUUFBbEIsQ0FBMkJFLDRCQUEzQjtBQUNBQSxRQUFBQSw0QkFBNEIsQ0FBQ1osY0FBN0IsQ0FBNEMsZUFBNUMsRUFBNkRBLGNBQTdELENBQTRFLGNBQTVFLEVBQTRGQyxZQUE1RixDQUF5RzNCLEVBQUUsQ0FBQzRCLEtBQTVHLEVBQ0VDLE1BREYsR0FDVyxLQUFLSyxVQUFVLENBQUNHLENBQUQsQ0FBVixDQUFjRSxlQUQ5QjtBQUVBRCxRQUFBQSw0QkFBNEIsQ0FBQ1osY0FBN0IsQ0FBNEMsc0JBQTVDLEVBQW9FQSxjQUFwRSxDQUFtRixxQkFBbkYsRUFBMEdDLFlBQTFHLENBQ0MzQixFQUFFLENBQUM0QixLQURKLEVBQ1dDLE1BRFgsR0FDb0IsS0FBS0ssVUFBVSxDQUFDRyxDQUFELENBQVYsQ0FBY0csV0FBZCxDQUEwQkMsUUFBMUIsRUFEekI7QUFFQUgsUUFBQUEsNEJBQTRCLENBQUNaLGNBQTdCLENBQTRDLDJDQUE1QyxFQUF5RkEsY0FBekYsQ0FDQywwQ0FERCxFQUM2Q0MsWUFEN0MsQ0FDMEQzQixFQUFFLENBQUM0QixLQUQ3RCxFQUNvRUMsTUFEcEUsR0FDNkUsS0FBS0ssVUFBVSxDQUFDRyxDQUFELENBQVYsQ0FBY0ssYUFEaEc7QUFFQTtBQUVEO0FBQ0Q7QUF2RU8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJ0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRBY2NvdW50X0xhYmVsOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i0puWPt+euoeeQhumihOWItuS9k1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VudF9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/mjpLlkI3moYZcclxuXHRcdFJlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uID0gbnVsbDtcclxuXHRcdHRoaXMuX0lzX0xvYWRpbmcgPSB0cnVlO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfUmVwb3J0ZXJkX1VzZXIoKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi6KKr5Li+5oql5Lq65L+h5oGv5Liq5pWwXCIsIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5SZXBvcnRlZF9Vc2Vyc19JbmZvcm1hdGlvbi5sZW5ndGgpO1xyXG5cclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0aWYgKHRoaXMuX0lzX0xvYWRpbmcgJiYgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uICE9IG51bGwpIHtcclxuXHRcdFx0dGhpcy5Mb2FkaW5nX1JlcG9ydGVkX1VzZXJzKCk7XHJcblx0XHRcdHRoaXMuX0lzX0xvYWRpbmcgPSBmYWxzZTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdExvYWRpbmdfUmVwb3J0ZWRfVXNlcnMoKSB7XHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5SZXBvcnRlZF9Vc2Vyc19JbmZvcm1hdGlvbi5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIjFcIik7XHJcblx0XHRcdHZhciBOZXdfQWNjb3VudF9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQWNjb3VudF9MYWJlbCk7XHJcblx0XHRcdE5ld19BY2NvdW50X0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9NYW5hZ2VtZW50X0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiVXNlcl9JZF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcclxuXHRcdFx0XHRcIlVzZXJfSWRfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb25bXHJcblx0XHRcdFx0aV0ub3BlbmlkO1xyXG5cdFx0XHROZXdfQWNjb3VudF9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfTWFuYWdlbWVudF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfU3RhdHVzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFxyXG5cdFx0XHRcdFwiQWNjb3VudF9TdGF0dXNfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb25bXHJcblx0XHRcdFx0aV0uVXNlcl9zdGF0ZTtcclxuXHRcdFx0TmV3X0FjY291bnRfTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X01hbmFnZW1lbnRfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXHJcblx0XHRcdFx0XCJDdW11bGF0aXZlX051bWJlcl9PZl9SZXBvcnRlZF9DYXNlc19MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX1Nob3dcIikuZ2V0Q29tcG9uZW50KFxyXG5cdFx0XHRcdGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbltpXS5SZXBvcnRlZF9Db3VudDtcclxuXHRcdFx0dmFyIG9wZW5pZGxpc3QgPSBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb25baV0ub3BlbmlkbGlzdDtcclxuXHRcdFx0TmV3X0FjY291bnRfTGFiZWwuaGVpZ2h0ID0gNTAwICsgb3BlbmlkbGlzdC5sZW5ndGggKiAyMDA7XHJcblx0XHRcdHRoaXMuQWNjb3VudF9NYW5hZ2VudF9WaWV3LmFkZENoaWxkKE5ld19BY2NvdW50X0xhYmVsKTtcclxuXHRcdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBvcGVuaWRsaXN0Lmxlbmd0aDsgaisrKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLmn6XnnItvcGVuaWRsaXN0XCIsIG9wZW5pZGxpc3Rbal0pO1xyXG5cdFx0XHRcdHZhciBOZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5SZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwpO1xyXG5cdFx0XHRcdE5ld19BY2NvdW50X0xhYmVsLmFkZENoaWxkKE5ld19SZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwpO1xyXG5cdFx0XHRcdE5ld19SZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJVc2VyX0lkX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiVXNlcl9JZF9TaG93XCIpLmdldENvbXBvbmVudChjYy5MYWJlbClcclxuXHRcdFx0XHRcdC5zdHJpbmcgPSBcIlwiICsgb3BlbmlkbGlzdFtqXS5SZXBvcnRlZF9PcGVuaWQ7XHJcblx0XHRcdFx0TmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfU3RhdHVzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9TdGF0dXNfU2hvd1wiKS5nZXRDb21wb25lbnQoXHJcblx0XHRcdFx0XHRjYy5MYWJlbCkuc3RyaW5nID0gXCJcIiArIG9wZW5pZGxpc3Rbal0uUmVwb3J0X1RpbWUudG9TdHJpbmcoKTtcclxuXHRcdFx0XHROZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQ3VtdWxhdGl2ZV9OdW1iZXJfT2ZfUmVwb3J0ZWRfQ2FzZXNfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXHJcblx0XHRcdFx0XHRcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgb3BlbmlkbGlzdFtqXS5SZXBvcnRfUmVhc29uO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cdH1cclxufSk7XHJcbiJdfQ==