
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Change_Map.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '734952mXWpNIbJ+BxxqrbWv', 'Change_Map');
// resources/script/Game_Start/Change_Map.js

"use strict";

//改变地图难度
var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  // onLoad () {},
  onLoad: function onLoad() {},
  update: function update(dt) {},
  on_btn_click: function on_btn_click() {
    //改变背景
    var frame = this.node.getComponent(cc.Sprite).spriteFrame; //改变地图变量

    Game_Local_Varible.Current_Map = frame;

    if (Game_Local_Varible.Current_Map != null) {
      this.BGSprite.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
    } else {
      cc.loader.load({
        url: "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Map/Map_Desert.jpg?sign=1ff843bf81f16ee3d008efbd49344610&t=1608450857",
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        this.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
      });
    }

    console.log("Current_Map.typeof=" + Game_Local_Varible.Current_Map);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXENoYW5nZV9NYXAuanMiXSwibmFtZXMiOlsiR2FtZV9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQkdTcHJpdGUiLCJ0eXBlIiwiU3ByaXRlIiwic2VyaWFsemFibGUiLCJvbkxvYWQiLCJ1cGRhdGUiLCJkdCIsIm9uX2J0bl9jbGljayIsImZyYW1lIiwibm9kZSIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwiQ3VycmVudF9NYXAiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJTcHJpdGVGcmFtZSIsImNvbnNvbGUiLCJsb2ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxrQkFBa0IsR0FBR0MsT0FBTyxDQUFDLG9CQUFELENBQWhDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsUUFBUSxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGQTtBQUdUQyxNQUFBQSxXQUFXLEVBQUU7QUFISjtBQURDLEdBSEo7QUFZUjtBQUVBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVcsQ0FBRSxDQWRiO0FBZVJDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhLENBQUUsQ0FmZjtBQWtCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0EsUUFBSUMsS0FBSyxHQUFHLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QmQsRUFBRSxDQUFDTSxNQUExQixFQUFrQ1MsV0FBOUMsQ0FGd0IsQ0FHeEI7O0FBQ0FqQixJQUFBQSxrQkFBa0IsQ0FBQ2tCLFdBQW5CLEdBQWlDSixLQUFqQzs7QUFDQSxRQUFHZCxrQkFBa0IsQ0FBQ2tCLFdBQW5CLElBQWdDLElBQW5DLEVBQXdDO0FBQ3ZDLFdBQUtaLFFBQUwsQ0FBY1UsWUFBZCxDQUEyQmQsRUFBRSxDQUFDTSxNQUE5QixFQUFzQ1MsV0FBdEMsR0FBb0RqQixrQkFBa0IsQ0FBQ2tCLFdBQXZFO0FBQ0EsS0FGRCxNQUVLO0FBQ0poQixNQUFBQSxFQUFFLENBQUNpQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxRQUFBQSxHQUFHLEVBQUUsd0lBRFM7QUFFZGQsUUFBQUEsSUFBSSxFQUFFO0FBRlEsT0FBZixFQUdHLFVBQVNlLEdBQVQsRUFBY0MsT0FBZCxFQUF1QkMsSUFBdkIsRUFBNkI7QUFDL0IsWUFBSVYsS0FBSyxHQUFHLElBQUlaLEVBQUUsQ0FBQ3VCLFdBQVAsQ0FBbUJGLE9BQW5CLENBQVo7O0FBQ0EsWUFBSUQsR0FBSixFQUFTO0FBQ1JJLFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JMLEdBQXBCO0FBQ0E7O0FBQ0QsYUFBS2hCLFFBQUwsQ0FBY1UsWUFBZCxDQUEyQmQsRUFBRSxDQUFDTSxNQUE5QixFQUFzQ1MsV0FBdEMsR0FBb0RILEtBQXBEO0FBQ0EsT0FURDtBQVVBOztBQUVEWSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBd0IzQixrQkFBa0IsQ0FBQ2tCLFdBQXZEO0FBQ0E7QUF2Q08sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/mlLnlj5jlnLDlm77pmr7luqZcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRCR1Nwcml0ZToge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5TcHJpdGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHR9LFxyXG5cclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge30sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge30sXHJcblxyXG5cclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Ly/mlLnlj5jog4zmma9cclxuXHRcdHZhciBmcmFtZSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZTtcclxuXHRcdC8v5pS55Y+Y5Zyw5Zu+5Y+Y6YePXHJcblx0XHRHYW1lX0xvY2FsX1ZhcmlibGUuQ3VycmVudF9NYXAgPSBmcmFtZTtcclxuXHRcdGlmKEdhbWVfTG9jYWxfVmFyaWJsZS5DdXJyZW50X01hcCE9bnVsbCl7XHJcblx0XHRcdHRoaXMuQkdTcHJpdGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSBHYW1lX0xvY2FsX1ZhcmlibGUuQ3VycmVudF9NYXA7XHJcblx0XHR9ZWxzZXtcclxuXHRcdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHRcdHVybDogXCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL2ltYWdlL01hcC9NYXBfRGVzZXJ0LmpwZz9zaWduPTFmZjg0M2JmODFmMTZlZTNkMDA4ZWZiZDQ5MzQ0NjEwJnQ9MTYwODQ1MDg1N1wiLFxyXG5cdFx0XHRcdHR5cGU6ICdqcGcnXHJcblx0XHRcdH0sIGZ1bmN0aW9uKGVyciwgdGV4dHVyZSwgdGVzdCkge1xyXG5cdFx0XHRcdHZhciBmcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0XHRpZiAoZXJyKSB7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLCBlcnIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR0aGlzLkJHU3ByaXRlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gZnJhbWU7XHJcblx0XHRcdH0pXHJcblx0XHR9XHJcblx0XHRcclxuXHRcdGNvbnNvbGUubG9nKFwiQ3VycmVudF9NYXAudHlwZW9mPVwiICsgR2FtZV9Mb2NhbF9WYXJpYmxlLkN1cnJlbnRfTWFwKTtcclxuXHR9XHJcbn0pO1xyXG4iXX0=