
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Email_Waring.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f95f53B521Flo6ICudvtupm', 'Email_Waring');
// resources/script/Email/Email_Waring.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    OPENID_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  Warning: function Warning() {
    var open_id = this.OPENID_Label.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "账号异常警告";
    var Content = "您的账号可能存在异常，如核实有违规行为，系统将对您作出惩罚";
    WeChat.Email_Warning(Time, Title, Content, open_id);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxFbWFpbF9XYXJpbmcuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJPUEVOSURfTGFiZWwiLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsIldhcm5pbmciLCJvcGVuX2lkIiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiVGltZSIsInBhcnNlSW50IiwiRGF0ZSIsImdldFRpbWUiLCJUaXRsZSIsIkNvbnRlbnQiLCJXZUNoYXQiLCJFbWFpbF9XYXJuaW5nIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNUQyxJQUFBQSxZQUFZLEVBQUM7QUFDUixpQkFBUyxJQUREO0FBRVJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZEO0FBR1JDLE1BQUFBLFdBQVcsRUFBRTtBQUhMO0FBREosR0FIUDtBQVdMQyxFQUFBQSxPQUFPLEVBQUMsbUJBQVU7QUFDZCxRQUFJQyxPQUFPLEdBQUMsS0FBS0wsWUFBTCxDQUFrQk0sWUFBbEIsQ0FBK0JWLEVBQUUsQ0FBQ00sS0FBbEMsRUFBeUNLLE1BQXJELENBRGMsQ0FFZDs7QUFDTixRQUFJQyxJQUFJLEdBQUdDLFFBQVEsQ0FBQyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBRCxDQUFuQjtBQUNBLFFBQUlDLEtBQUssR0FBRyxRQUFaO0FBQ0EsUUFBSUMsT0FBTyxHQUFFLCtCQUFiO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0MsYUFBUCxDQUFxQlAsSUFBckIsRUFBMEJJLEtBQTFCLEVBQWdDQyxPQUFoQyxFQUF3Q1IsT0FBeEM7QUFDRyxHQWxCSTtBQW9CTFcsRUFBQUEsS0FwQkssbUJBb0JJLENBRVIsQ0F0QkksQ0F3Qkw7O0FBeEJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgT1BFTklEX0xhYmVsOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWwsXHJcbiAgICAgICAgICAgIHNlcmlhbHphYmxlOiB0cnVlLFxyXG4gICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBXYXJuaW5nOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIG9wZW5faWQ9dGhpcy5PUEVOSURfTGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgLy/ojrflj5bml7bpl7TmiLNcclxuXHRcdGxldCBUaW1lID0gcGFyc2VJbnQobmV3IERhdGUoKS5nZXRUaW1lKCkpO1xyXG5cdFx0dmFyIFRpdGxlID0gXCLotKblj7flvILluLjorablkYpcIjtcclxuXHRcdHZhciBDb250ZW50ID1cIuaCqOeahOi0puWPt+WPr+iDveWtmOWcqOW8guW4uO+8jOWmguaguOWunuaciei/neinhOihjOS4uu+8jOezu+e7n+WwhuWvueaCqOS9nOWHuuaDqee9mlwiO1xyXG5cdFx0V2VDaGF0LkVtYWlsX1dhcm5pbmcoVGltZSxUaXRsZSxDb250ZW50LG9wZW5faWQpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==