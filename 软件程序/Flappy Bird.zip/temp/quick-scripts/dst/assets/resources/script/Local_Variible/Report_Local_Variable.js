
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Report_Local_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7185fkTCFtDqJAe6Gxt7FSE', 'Report_Local_Variable');
// resources/script/Local_Variible/Report_Local_Variable.js

"use strict";

//举报         
module.exports = {
  //举报列表
  openid: "",
  User_Name: ""
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxSZXBvcnRfTG9jYWxfVmFyaWFibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIm9wZW5pZCIsIlVzZXJfTmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDaEI7QUFDQUMsRUFBQUEsTUFBTSxFQUFDLEVBRlM7QUFHaEJDLEVBQUFBLFNBQVMsRUFBQztBQUhNLENBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4vuaKpSAgICAgICAgIFxubW9kdWxlLmV4cG9ydHMgPSB7XG5cdC8v5Li+5oql5YiX6KGoXG5cdG9wZW5pZDpcIlwiLFxuXHRVc2VyX05hbWU6XCJcIlxufTsiXX0=