
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Change_Bird_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'aaa92aSi/ZKjb7X8Ef7fnO9', 'Change_Bird_Image');
// resources/script/Global_Function/Change_Bird_Image.js

"use strict";

//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    condition: false,
    Character_Image_Array: [],
    i: 0
  },
  start: function start() {},
  update: function update(dt) {
    this.node.getComponent(cc.Sprite).spriteFrame = Global_Variable.Character_Image1; // if (!this.condition) {
    // 	//想要执行的方法   
    // 	this.Character_Image_Array = new Array();
    // 	if (Global_Variable.Character_Image1 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image1);
    // 	if (Global_Variable.Character_Image2 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image2);
    // 	if (Global_Variable.Character_Image3 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image3);
    // 	if (Global_Variable.Character_Image4 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image4);
    // 	if(this.Character_Image_Array.length==4){
    // 		this.condition = true;	
    // 	}
    // };
    // if(this.condition) {
    // 	this.schedule(function() { // 计时器将每隔 1s 执行一次。
    // 		if (this.Character_Image_Array[this.i] != null) {
    // 			this.node.getComponent(cc.Sprite).spriteFrame = this.Character_Image_Array[this.i];
    // 			this.i+=1;
    // 			if (this.i == 3) {
    // 				this.i = 0;
    // 			}
    // 		}
    // 	},3);
    // };
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcQ2hhbmdlX0JpcmRfSW1hZ2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJjb25kaXRpb24iLCJDaGFyYWN0ZXJfSW1hZ2VfQXJyYXkiLCJpIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsIkdsb2JhbF9WYXJpYWJsZSIsIkNoYXJhY3Rlcl9JbWFnZTEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsU0FBUyxFQUFFLEtBREE7QUFFWEMsSUFBQUEscUJBQXFCLEVBQUMsRUFGWDtBQUdYQyxJQUFBQSxDQUFDLEVBQUc7QUFITyxHQUhKO0FBU1JDLEVBQUFBLEtBVFEsbUJBU0EsQ0FFUCxDQVhPO0FBYVJDLEVBQUFBLE1BYlEsa0JBYURDLEVBYkMsRUFhRztBQUNWLFNBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QlgsRUFBRSxDQUFDWSxNQUExQixFQUFrQ0MsV0FBbEMsR0FBZ0RDLGVBQWUsQ0FBQ0MsZ0JBQWhFLENBRFUsQ0FFVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0M7QUF6Q00sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdGNvbmRpdGlvbjogZmFsc2UsXHJcblx0XHRDaGFyYWN0ZXJfSW1hZ2VfQXJyYXk6W10sXHJcblx0XHRpIDogMCxcclxuXHRcdFxyXG5cdH0sXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZShkdCkge1xyXG5cdFx0dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTE7XHJcblx0XHQvLyBpZiAoIXRoaXMuY29uZGl0aW9uKSB7XHJcblx0XHQvLyBcdC8v5oOz6KaB5omn6KGM55qE5pa55rOVICAgXHJcblx0XHQvLyBcdHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5ID0gbmV3IEFycmF5KCk7XHJcblx0XHQvLyBcdGlmIChHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlMSAhPSBudWxsKVxyXG5cdFx0Ly8gXHRcdHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5LnB1c2goR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTEpO1xyXG5cdFx0Ly8gXHRpZiAoR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTIgIT0gbnVsbClcclxuXHRcdC8vIFx0XHR0aGlzLkNoYXJhY3Rlcl9JbWFnZV9BcnJheS5wdXNoKEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2UyKTtcclxuXHRcdC8vIFx0aWYgKEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2UzICE9IG51bGwpXHJcblx0XHQvLyBcdFx0dGhpcy5DaGFyYWN0ZXJfSW1hZ2VfQXJyYXkucHVzaChHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlMyk7XHJcblx0XHQvLyBcdGlmIChHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlNCAhPSBudWxsKVxyXG5cdFx0Ly8gXHRcdHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5LnB1c2goR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTQpO1xyXG5cdFx0Ly8gXHRpZih0aGlzLkNoYXJhY3Rlcl9JbWFnZV9BcnJheS5sZW5ndGg9PTQpe1xyXG5cdFx0Ly8gXHRcdHRoaXMuY29uZGl0aW9uID0gdHJ1ZTtcdFxyXG5cdFx0Ly8gXHR9XHJcblx0XHQvLyB9O1xyXG5cdFx0Ly8gaWYodGhpcy5jb25kaXRpb24pIHtcclxuXHRcdC8vIFx0dGhpcy5zY2hlZHVsZShmdW5jdGlvbigpIHsgLy8g6K6h5pe25Zmo5bCG5q+P6ZqUIDFzIOaJp+ihjOS4gOasoeOAglxyXG5cdFx0Ly8gXHRcdGlmICh0aGlzLkNoYXJhY3Rlcl9JbWFnZV9BcnJheVt0aGlzLmldICE9IG51bGwpIHtcclxuXHRcdC8vIFx0XHRcdHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5W3RoaXMuaV07XHJcblx0XHQvLyBcdFx0XHR0aGlzLmkrPTE7XHJcblx0XHQvLyBcdFx0XHRpZiAodGhpcy5pID09IDMpIHtcclxuXHRcdC8vIFx0XHRcdFx0dGhpcy5pID0gMDtcclxuXHRcdC8vIFx0XHRcdH1cclxuXHRcdC8vIFx0XHR9XHJcblx0XHQvLyBcdH0sMyk7XHJcblx0XHQvLyB9O1xyXG5cdFx0fSxcclxuXHRcdFxyXG5cdH0pOyJdfQ==