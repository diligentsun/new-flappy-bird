
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Cloud_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd8c801US0ZKWIP4fZ/YWxXG', 'Cloud_Image');
// resources/script/Global_Function/Cloud_Image.js

"use strict";

//改变图片
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    //图片所在路径
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //图片要加载的组件

  },
  // onLoad () {},
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge; //下载图片

    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcQ2xvdWRfSW1hZ2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJJYW1nZSIsIkJHU3ByaXRlIiwidHlwZSIsIlNwcml0ZSIsInNlcmlhbHphYmxlIiwib25Mb2FkIiwic2VsZiIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLEtBQUssRUFBRSxFQURJO0FBQ0Q7QUFDVkMsSUFBQUEsUUFBUSxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUQyxNQUFBQSxJQUFJLEVBQUVOLEVBQUUsQ0FBQ08sTUFGQTtBQUdUQyxNQUFBQSxXQUFXLEVBQUU7QUFISixLQUZDLENBTVI7O0FBTlEsR0FISjtBQVlSO0FBRUFDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVztBQUNsQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBLFFBQUlDLElBQUksR0FBR0QsSUFBSSxDQUFDTixLQUFoQixDQUZrQixDQUdsQjs7QUFDQUosSUFBQUEsRUFBRSxDQUFDWSxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUVILElBRFM7QUFFZEwsTUFBQUEsSUFBSSxFQUFFO0FBRlEsS0FBZixFQUdHLFVBQVNTLEdBQVQsRUFBY0MsT0FBZCxFQUF1QkMsSUFBdkIsRUFBNkI7QUFDL0IsVUFBSUMsS0FBSyxHQUFHLElBQUlsQixFQUFFLENBQUNtQixXQUFQLENBQW1CSCxPQUFuQixDQUFaOztBQUNBLFVBQUlELEdBQUosRUFBUztBQUNSSyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW9CTixHQUFwQjtBQUNBOztBQUNETCxNQUFBQSxJQUFJLENBQUNMLFFBQUwsQ0FBY2lCLFlBQWQsQ0FBMkJ0QixFQUFFLENBQUNPLE1BQTlCLEVBQXNDZ0IsV0FBdEMsR0FBb0RMLEtBQXBEO0FBQ0EsS0FURDtBQVVBLEdBNUJPO0FBOEJSTSxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYSxDQUFFO0FBOUJmLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5pS55Y+Y5Zu+54mHXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdElhbWdlOiBcIlwiLC8v5Zu+54mH5omA5Zyo6Lev5b6EXHJcblx0XHRCR1Nwcml0ZToge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5TcHJpdGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/lm77niYfopoHliqDovb3nmoTnu4Tku7ZcclxuXHR9LFxyXG5cclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0XHRsZXQgX3VybCA9IHNlbGYuSWFtZ2U7XHJcblx0XHQvL+S4i+i9veWbvueJh1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6IF91cmwsXHJcblx0XHRcdHR5cGU6ICdqcGcnXHJcblx0XHR9LCBmdW5jdGlvbihlcnIsIHRleHR1cmUsIHRlc3QpIHtcclxuXHRcdFx0dmFyIGZyYW1lID0gbmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRpZiAoZXJyKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIiwgZXJyKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRzZWxmLkJHU3ByaXRlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gZnJhbWU7XHJcblx0XHR9KVxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHt9LFxyXG59KTtcclxuIl19