
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Global_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ca194AYdxJFRJI8ZInLl158', 'Global_Variable');
// resources/script/Global_Function/Global_Variable.js

"use strict";

window.Global_Variable = {
  User_Information: null,
  openid: null,
  Gold: 0,
  Diamond: 0,
  Compassion: 0,
  User_Head_Image: null,
  User_Name: null,
  Best_Score: 0,
  Is_Admin: false,
  Is_Closured: null,
  Restores_Compassion_Time: new Date(),
  Character_Image1: null,
  Character_Image2: null,
  Character_Image3: null,
  Character_Image4: null,
  Unsealing_Time: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcR2xvYmFsX1ZhcmlhYmxlLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsIkdsb2JhbF9WYXJpYWJsZSIsIlVzZXJfSW5mb3JtYXRpb24iLCJvcGVuaWQiLCJHb2xkIiwiRGlhbW9uZCIsIkNvbXBhc3Npb24iLCJVc2VyX0hlYWRfSW1hZ2UiLCJVc2VyX05hbWUiLCJCZXN0X1Njb3JlIiwiSXNfQWRtaW4iLCJJc19DbG9zdXJlZCIsIlJlc3RvcmVzX0NvbXBhc3Npb25fVGltZSIsIkRhdGUiLCJDaGFyYWN0ZXJfSW1hZ2UxIiwiQ2hhcmFjdGVyX0ltYWdlMiIsIkNoYXJhY3Rlcl9JbWFnZTMiLCJDaGFyYWN0ZXJfSW1hZ2U0IiwiVW5zZWFsaW5nX1RpbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsZUFBUCxHQUF5QjtBQUN4QkMsRUFBQUEsZ0JBQWdCLEVBQUUsSUFETTtBQUV4QkMsRUFBQUEsTUFBTSxFQUFFLElBRmdCO0FBR3hCQyxFQUFBQSxJQUFJLEVBQUUsQ0FIa0I7QUFJeEJDLEVBQUFBLE9BQU8sRUFBRSxDQUplO0FBS3hCQyxFQUFBQSxVQUFVLEVBQUUsQ0FMWTtBQU14QkMsRUFBQUEsZUFBZSxFQUFFLElBTk87QUFPeEJDLEVBQUFBLFNBQVMsRUFBRSxJQVBhO0FBUXhCQyxFQUFBQSxVQUFVLEVBQUUsQ0FSWTtBQVN4QkMsRUFBQUEsUUFBUSxFQUFDLEtBVGU7QUFVeEJDLEVBQUFBLFdBQVcsRUFBQyxJQVZZO0FBV3hCQyxFQUFBQSx3QkFBd0IsRUFBRSxJQUFJQyxJQUFKLEVBWEY7QUFZeEJDLEVBQUFBLGdCQUFnQixFQUFFLElBWk07QUFheEJDLEVBQUFBLGdCQUFnQixFQUFFLElBYk07QUFjeEJDLEVBQUFBLGdCQUFnQixFQUFFLElBZE07QUFleEJDLEVBQUFBLGdCQUFnQixFQUFFLElBZk07QUFnQnhCQyxFQUFBQSxjQUFjLEVBQUU7QUFoQlEsQ0FBekIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIndpbmRvdy5HbG9iYWxfVmFyaWFibGUgPSB7XHJcblx0VXNlcl9JbmZvcm1hdGlvbjogbnVsbCxcclxuXHRvcGVuaWQ6IG51bGwsXHJcblx0R29sZDogMCxcclxuXHREaWFtb25kOiAwLFxyXG5cdENvbXBhc3Npb246IDAsXHJcblx0VXNlcl9IZWFkX0ltYWdlOiBudWxsLFxyXG5cdFVzZXJfTmFtZTogbnVsbCxcclxuXHRCZXN0X1Njb3JlOiAwLFxyXG5cdElzX0FkbWluOmZhbHNlLFxyXG5cdElzX0Nsb3N1cmVkOm51bGwsXHJcblx0UmVzdG9yZXNfQ29tcGFzc2lvbl9UaW1lOiBuZXcgRGF0ZSgpLFxyXG5cdENoYXJhY3Rlcl9JbWFnZTE6IG51bGwsXHJcblx0Q2hhcmFjdGVyX0ltYWdlMjogbnVsbCxcclxuXHRDaGFyYWN0ZXJfSW1hZ2UzOiBudWxsLFxyXG5cdENoYXJhY3Rlcl9JbWFnZTQ6IG51bGwsXHJcblx0VW5zZWFsaW5nX1RpbWU6IG51bGwsXHJcbn07XG4iXX0=