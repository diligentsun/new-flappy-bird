
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Over/Grade_Show.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a7b33r7cXNCMYXNoW8XFev8', 'Grade_Show');
// resources/script/Game_Over/Grade_Show.js

"use strict";

//进行游戏结束后的结算
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Grade_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //调入金币显示的Label
    Fraction_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //调入分数显示的Label
    Background: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //调入分数显示的Lab

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    WeChat.Game_Settlement(Math.floor(Game_Local_Varible.Fraction / 4 * Game_Difficulty_Local_Varible.Difficulty_Ratio + Game_Local_Varible.Gold), Game_Local_Varible.Fraction / 2); //将分数传入云数据库中

    this.Grade_Show.string = "一共通过了" + Game_Local_Varible.Fraction / 2 + "根水管\n收获了" + Math.floor(Game_Local_Varible.Fraction / 4 * Game_Difficulty_Local_Varible.Difficulty_Ratio + Game_Local_Varible.Gold) + "枚金币"; //将Label更新

    this.Fraction_Show.string = Game_Local_Varible.Fraction / 2 * Game_Difficulty_Local_Varible.Difficulty_Ratio; //更新前端Label

    this.Background.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfT3ZlclxcR3JhZGVfU2hvdy5qcyJdLCJuYW1lcyI6WyJHYW1lX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkdyYWRlX1Nob3ciLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsIkZyYWN0aW9uX1Nob3ciLCJCYWNrZ3JvdW5kIiwiU3ByaXRlIiwib25Mb2FkIiwiV2VDaGF0IiwiR2FtZV9TZXR0bGVtZW50IiwiTWF0aCIsImZsb29yIiwiRnJhY3Rpb24iLCJEaWZmaWN1bHR5X1JhdGlvIiwiR29sZCIsInN0cmluZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwiQ3VycmVudF9NYXAiLCJzdGFydCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxvQkFBRCxDQUFoQzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBR0QsT0FBTyxDQUFDLCtCQUFELENBQTNDOztBQUVBRSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGRTtBQUdYQyxNQUFBQSxXQUFXLEVBQUU7QUFIRixLQUREO0FBS1I7QUFDSEMsSUFBQUEsYUFBYSxFQUFFO0FBQ2QsaUJBQVMsSUFESztBQUVkSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGSztBQUdkQyxNQUFBQSxXQUFXLEVBQUU7QUFIQyxLQU5KO0FBVVI7QUFDSEUsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1UsTUFGRTtBQUdYSCxNQUFBQSxXQUFXLEVBQUU7QUFIRixLQVhELENBZVI7O0FBZlEsR0FISjtBQXFCUjtBQUVBSSxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFFbEJDLElBQUFBLE1BQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsSUFBSSxDQUFDQyxLQUFMLENBQVdsQixrQkFBa0IsQ0FBQ21CLFFBQW5CLEdBQThCLENBQTlCLEdBQWtDakIsNkJBQTZCLENBQUNrQixnQkFBaEUsR0FDakNwQixrQkFBa0IsQ0FBQ3FCLElBREcsQ0FBdkIsRUFDMkJyQixrQkFBa0IsQ0FBQ21CLFFBQW5CLEdBQThCLENBRHpELEVBRmtCLENBRzJDOztBQUM3RCxTQUFLWixVQUFMLENBQWdCZSxNQUFoQixHQUF5QixVQUFXdEIsa0JBQWtCLENBQUNtQixRQUFuQixHQUE4QixDQUF6QyxHQUE4QyxVQUE5QyxHQUE0REYsSUFBSSxDQUFDQyxLQUFMLENBQVdsQixrQkFBa0IsQ0FDaEhtQixRQUQ4RixHQUNuRixDQURtRixHQUMvRWpCLDZCQUE2QixDQUFDa0IsZ0JBRGlELEdBQzlCcEIsa0JBQWtCLENBQUNxQixJQURBLENBQTVELEdBQ3FFLEtBRDlGLENBSmtCLENBS21GOztBQUNyRyxTQUFLVixhQUFMLENBQW1CVyxNQUFuQixHQUE2QnRCLGtCQUFrQixDQUFDbUIsUUFBbkIsR0FBOEIsQ0FBL0IsR0FBb0NqQiw2QkFBNkIsQ0FBQ2tCLGdCQUE5RixDQU5rQixDQU04Rjs7QUFDaEgsU0FBS1IsVUFBTCxDQUFnQlcsWUFBaEIsQ0FBNkJwQixFQUFFLENBQUNVLE1BQWhDLEVBQXdDVyxXQUF4QyxHQUFzRHhCLGtCQUFrQixDQUFDeUIsV0FBekU7QUFDQSxHQS9CTztBQWlDUkMsRUFBQUEsS0FqQ1EsbUJBaUNBLENBQUUsQ0FqQ0Y7QUFtQ1JDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhLENBQUU7QUFuQ2YsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/ov5vooYzmuLjmiI/nu5PmnZ/lkI7nmoTnu5PnrpdcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0R3JhZGVfU2hvdzoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+iwg+WFpemHkeW4geaYvuekuueahExhYmVsXHJcblx0XHRGcmFjdGlvbl9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6LCD5YWl5YiG5pWw5pi+56S655qETGFiZWxcclxuXHRcdEJhY2tncm91bmQ6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuU3ByaXRlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6LCD5YWl5YiG5pWw5pi+56S655qETGFiXHJcblx0fSxcclxuXHJcblx0Ly8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblxyXG5cdFx0V2VDaGF0LkdhbWVfU2V0dGxlbWVudChNYXRoLmZsb29yKEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiAvIDQgKiBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICtcclxuXHRcdFx0R2FtZV9Mb2NhbF9WYXJpYmxlLkdvbGQpLCBHYW1lX0xvY2FsX1ZhcmlibGUuRnJhY3Rpb24gLyAyKTsgLy/lsIbliIbmlbDkvKDlhaXkupHmlbDmja7lupPkuK1cclxuXHRcdHRoaXMuR3JhZGVfU2hvdy5zdHJpbmcgPSBcIuS4gOWFsemAmui/h+S6hlwiICsgKEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiAvIDIpICsgXCLmoLnmsLTnrqFcXG7mlLbojrfkuoZcIiArIChNYXRoLmZsb29yKEdhbWVfTG9jYWxfVmFyaWJsZVxyXG5cdFx0XHQuRnJhY3Rpb24gLyA0ICogR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbyArIEdhbWVfTG9jYWxfVmFyaWJsZS5Hb2xkKSkgKyBcIuaemumHkeW4gVwiOyAvL+WwhkxhYmVs5pu05pawXHJcblx0XHR0aGlzLkZyYWN0aW9uX1Nob3cuc3RyaW5nID0gKEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiAvIDIpICogR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbzsgLy/mm7TmlrDliY3nq69MYWJlbFxyXG5cdFx0dGhpcy5CYWNrZ3JvdW5kLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gR2FtZV9Mb2NhbF9WYXJpYmxlLkN1cnJlbnRfTWFwO1xyXG5cdH0sXHJcblxyXG5cdHN0YXJ0KCkge30sXHJcblxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHt9LFxyXG59KTtcbiJdfQ==