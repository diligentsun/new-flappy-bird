
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Appeal_Confirm.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'de10cJbjlJPIq8tcs3hqSTQ', 'Appeal_Confirm');
// resources/script/Account_Management/Appeal_Confirm.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    Appeal_Content: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //举报框

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //载入申诉人的信息
    console.log("点到了吗??");
    var Appeal_Text = this.Appeal_Content.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "关于对账号的申诉";
    var Content = "系统已收到您的申诉，请等待处理			申诉原因：" + Appeal_Text;
    WeChat.Email_Report_And_Appeal(Time, Title, Content);
    console.log("申诉内容为", Appeal_Text); //上传举报信息

    WeChat.Uploading_Reported_Information(Global_Variable.openid, Appeal_Text);
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQXBwZWFsX0NvbmZpcm0uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJBcHBlYWxfQ29udGVudCIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJjb25zb2xlIiwibG9nIiwiQXBwZWFsX1RleHQiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJUaW1lIiwicGFyc2VJbnQiLCJEYXRlIiwiZ2V0VGltZSIsIlRpdGxlIiwiQ29udGVudCIsIldlQ2hhdCIsIkVtYWlsX1JlcG9ydF9BbmRfQXBwZWFsIiwiVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uIiwiR2xvYmFsX1ZhcmlhYmxlIiwib3BlbmlkIiwibm9kZSIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUVYQyxJQUFBQSxjQUFjLEVBQUU7QUFDZixpQkFBUyxJQURNO0FBRWZDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZNO0FBR2ZDLE1BQUFBLFdBQVcsRUFBRTtBQUhFLEtBRkwsQ0FNVDs7QUFOUyxHQUhKO0FBWVI7QUFFQTtBQUNBQyxFQUFBQSxLQWZRLG1CQWVBLENBRVAsQ0FqQk87QUFrQlJDLEVBQUFBLFlBQVksRUFBRSx3QkFBVztBQUN4QjtBQUNBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0EsUUFBSUMsV0FBVyxHQUFHLEtBQUtSLGNBQUwsQ0FBb0JTLFlBQXBCLENBQWlDYixFQUFFLENBQUNNLEtBQXBDLEVBQTJDUSxNQUE3RCxDQUh3QixDQUt0Qjs7QUFDRixRQUFJQyxJQUFJLEdBQUdDLFFBQVEsQ0FBQyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBRCxDQUFuQjtBQUNBLFFBQUlDLEtBQUssR0FBRyxVQUFaO0FBQ0EsUUFBSUMsT0FBTyxHQUFFLDRCQUEwQlIsV0FBdkM7QUFDQVMsSUFBQUEsTUFBTSxDQUFDQyx1QkFBUCxDQUErQlAsSUFBL0IsRUFBb0NJLEtBQXBDLEVBQTBDQyxPQUExQztBQUNBVixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCQyxXQUFyQixFQVZ3QixDQVd4Qjs7QUFDQVMsSUFBQUEsTUFBTSxDQUFDRSw4QkFBUCxDQUFzQ0MsZUFBZSxDQUFDQyxNQUF0RCxFQUE2RGIsV0FBN0Q7QUFDQSxTQUFLYyxJQUFMLENBQVVDLE9BQVY7QUFDQSxHQWhDTyxDQWlDUjs7QUFqQ1EsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cclxuXHRcdEFwcGVhbF9Db250ZW50OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sLy/kuL7miqXmoYZcclxuXHR9LFxyXG5cclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cdG9uX2J0bl9jbGljazogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+i9veWFpeeUs+ivieS6uueahOS/oeaBr1xyXG5cdFx0Y29uc29sZS5sb2coXCLngrnliLDkuoblkJc/P1wiKTtcclxuXHRcdHZhciBBcHBlYWxfVGV4dCA9IHRoaXMuQXBwZWFsX0NvbnRlbnQuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcblxyXG5cdFx0ICAvL+iOt+WPluaXtumXtOaIs1xyXG5cdFx0bGV0IFRpbWUgPSBwYXJzZUludChuZXcgRGF0ZSgpLmdldFRpbWUoKSk7XHJcblx0XHR2YXIgVGl0bGUgPSBcIuWFs+S6juWvuei0puWPt+eahOeUs+iviVwiO1xyXG5cdFx0dmFyIENvbnRlbnQgPVwi57O757uf5bey5pS25Yiw5oKo55qE55Sz6K+J77yM6K+3562J5b6F5aSE55CGXHRcdFx055Sz6K+J5Y6f5Zug77yaXCIrQXBwZWFsX1RleHQ7XHJcblx0XHRXZUNoYXQuRW1haWxfUmVwb3J0X0FuZF9BcHBlYWwoVGltZSxUaXRsZSxDb250ZW50KTtcclxuXHRcdGNvbnNvbGUubG9nKFwi55Sz6K+J5YaF5a655Li6XCIsIEFwcGVhbF9UZXh0KTtcclxuXHRcdC8v5LiK5Lyg5Li+5oql5L+h5oGvXHJcblx0XHRXZUNoYXQuVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uKEdsb2JhbF9WYXJpYWJsZS5vcGVuaWQsQXBwZWFsX1RleHQpO1xyXG5cdFx0dGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=