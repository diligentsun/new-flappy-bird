
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Jump_DIfficulty.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c82b5K7GGNOQZ4B65REBXaa', 'Jump_DIfficulty');
// resources/script/Local_Variible/Jump_DIfficulty.js

"use strict";

//跳转难度界面
cc.Class({
  "extends": cc.Component,
  properties: {
    Choose_Difficulty: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //难度框		
    Jump_Jump: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //点击图片

  },
  onLoad: function onLoad() {
    this.Choose_Difficulty.node.active = false; // 初始化跳跃动作  

    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchMove, this);
  },
  onDestroy: function onDestroy() {// 取消键盘输入监听
  },
  start: function start() {},
  update: function update(dt) {},
  onTouchMove: function onTouchMove(event) {
    //管理Jump图片
    this.Jump_Jump.node.active = false; //打开难度选择框

    this.Choose_Difficulty.node.active = true;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxKdW1wX0RJZmZpY3VsdHkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJDaG9vc2VfRGlmZmljdWx0eSIsInR5cGUiLCJTcHJpdGUiLCJzZXJpYWx6YWJsZSIsIkp1bXBfSnVtcCIsIm9uTG9hZCIsIm5vZGUiLCJhY3RpdmUiLCJvbiIsIk5vZGUiLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsIm9uVG91Y2hNb3ZlIiwib25EZXN0cm95Iiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImV2ZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBRVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxpQkFBaUIsRUFBRTtBQUNsQixpQkFBUyxJQURTO0FBRWxCQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGUztBQUdsQkMsTUFBQUEsV0FBVyxFQUFFO0FBSEssS0FEUjtBQUtSO0FBQ0hDLElBQUFBLFNBQVMsRUFBRTtBQUNWLGlCQUFTLElBREM7QUFFVkgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRkM7QUFHVkMsTUFBQUEsV0FBVyxFQUFFO0FBSEgsS0FOQSxDQVVSOztBQVZRLEdBRko7QUFlUkUsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCLFNBQUtMLGlCQUFMLENBQXVCTSxJQUF2QixDQUE0QkMsTUFBNUIsR0FBcUMsS0FBckMsQ0FEa0IsQ0FFbEI7O0FBQ0EsU0FBS0QsSUFBTCxDQUFVRSxFQUFWLENBQWFaLEVBQUUsQ0FBQ2EsSUFBSCxDQUFRQyxTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxLQUFLQyxXQUFqRCxFQUE4RCxJQUE5RDtBQUNBLEdBbkJPO0FBcUJSQyxFQUFBQSxTQXJCUSx1QkFxQkksQ0FDWDtBQUVBLEdBeEJPO0FBMEJSQyxFQUFBQSxLQTFCUSxtQkEwQkEsQ0FFUCxDQTVCTztBQThCUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWEsQ0FFcEIsQ0FoQ087QUFpQ1JKLEVBQUFBLFdBakNRLHVCQWlDSUssS0FqQ0osRUFpQ1c7QUFDbEI7QUFDQSxTQUFLYixTQUFMLENBQWVFLElBQWYsQ0FBb0JDLE1BQXBCLEdBQTZCLEtBQTdCLENBRmtCLENBR2xCOztBQUNBLFNBQUtQLGlCQUFMLENBQXVCTSxJQUF2QixDQUE0QkMsTUFBNUIsR0FBcUMsSUFBckM7QUFDQTtBQXRDTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+i3s+i9rOmavuW6pueVjOmdolxyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdENob29zZV9EaWZmaWN1bHR5OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlNwcml0ZSxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+mavuW6puahhlx0XHRcclxuXHRcdEp1bXBfSnVtcDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5TcHJpdGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ngrnlh7vlm77niYdcclxuXHR9LFxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dGhpcy5DaG9vc2VfRGlmZmljdWx0eS5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG5cdFx0Ly8g5Yid5aeL5YyW6Lez6LeD5Yqo5L2cICBcclxuXHRcdHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoTW92ZSwgdGhpcyk7XHJcblx0fSxcclxuXHJcblx0b25EZXN0cm95KCkge1xyXG5cdFx0Ly8g5Y+W5raI6ZSu55uY6L6T5YWl55uR5ZCsXHJcblxyXG5cdH0sXHJcblxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cclxuXHR1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblxyXG5cdH0sXHJcblx0b25Ub3VjaE1vdmUoZXZlbnQpIHtcclxuXHRcdC8v566h55CGSnVtcOWbvueJh1xyXG5cdFx0dGhpcy5KdW1wX0p1bXAubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuXHRcdC8v5omT5byA6Zq+5bqm6YCJ5oup5qGGXHJcblx0XHR0aGlzLkNob29zZV9EaWZmaWN1bHR5Lm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuXHR9LFxyXG59KTtcbiJdfQ==