
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Global_WeChat.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3ae40Cuxy1MB6W58a3Vhe8+', 'Global_WeChat');
// resources/script/Global_Function/Global_WeChat.js

"use strict";

//全局变量
var Rank_Local_Varible = require('Rank_Local_Variable');

var Shop_Character_Local_Variable = require('Shop_Character_Local_Varible');

var User_Have_Character_Local_Varible = require('User_Have_Character_Local_Varible');

var Email_Local_Variable = require('Email_Local_Variable');

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

window.WeChat = {}; //微信登录注册调用

WeChat.onRegisterUser = function (_userinfo) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  console.log(_userinfo);
  wx.cloud.callFunction({
    //调用云函数
    name: "login",
    //传入的参数，玩家信息
    data: {
      userinfo: _userinfo
    },
    success: function success(res) {
      console.log("登录注册成功回调", res);
      Global_Variable.Is_Closured = res.result.Is_Closured;
      Global_Variable.Unsealing_Time = res.result.data[0].Unsealing_Time;
      Global_Variable.openid = res.result.data[0].openid;
      console.log("!res.result.Is_Closured的值为", !res.result.Is_Closured);
      console.log("Global_Variable.Unsealing_Time", Global_Variable.Unsealing_Time);

      if (!res.result.Is_Closured) {
        cc.director.loadScene("Game_Start");
      } else {
        cc.director.loadScene("Closure");
      }
    },
    fail: function fail() {
      Global_Variable.Is_Closured = true;
      console.log("程序出错", console.error);
    }
  });
}; //加载资源


WeChat.Loading_Resources = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    name: "Loading_Resources",
    success: function success(res) {
      //将值赋给全局变量
      console.log("获取成功回调", res);
      Global_Variable.openid = res.result.openid;
      Global_Variable.Gold = res.result.Gold;
      Global_Variable.Diamond = res.result.Diamond;
      Global_Variable.Compassion = res.result.Compassion;
      Global_Variable.User_Head_Image = res.result.User_Head_Image;
      Global_Variable.Best_Score = res.result.Best_Score;
      Global_Variable.User_Name = res.result.User_Name;
      Global_Variable.Current_Character_Id = res.result.Current_Character_Id;
      Global_Variable.Is_Admin = res.result.Is_Admin;
      WeChat.Loading_Bird_Image(Global_Variable.Current_Character_Id);
    },
    fail: function fail() {
      console.log("获取基础物资出错", console.error); //失败了重新赋值

      WeChat.Loading_Resources();
    }
  });
}; //游戏结算


WeChat.Game_Settlement = function (_Add_Gold, _Score) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    name: "Game_Settlement",
    //传入参数，包括增加的金币数量，分数
    data: {
      Add_Gold: _Add_Gold,
      Score: _Score
    },
    success: function success(res) {
      console.log("获取成功回调", res);
      Global_Variable.Gold = res.result.Gold;
      Global_Variable.Diamond = res.result.Diamond;
      Global_Variable.Compassion = res.result.Compassion;
    },
    fail: function fail() {
      console.log("获取基础物资出错", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //加载世界排名


WeChat.Loading_World_Rank = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数		
    name: "Loading_World_Rank",
    success: function success(res) {
      console.log("下载世界排名成功回调", res);
      Rank_Local_Varible.Word_Rank_User = res.result.User_Information.data;
      console.log("Rank_Local_Varible为", Rank_Local_Varible.Word_Rank_User[0].openid);
    },
    fail: function fail() {
      console.log("下载世界排名出错", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //上传举报、申诉列表


WeChat.Uploading_Reported_Information = function (_Openid, _Report_Content) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    name: "Uploading_Reported_Information",
    data: {
      Reported_Openid: _Openid,
      Report_Content: _Report_Content
    },
    success: function success(res) {
      console.log("举报成功回调", res);
    },
    fail: function fail() {
      console.log("举报出错回调", console.error);
    }
  });
};

WeChat.Loading_Character = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Character",
    success: function success(res) {
      console.log("获取角色信息成功", res);
      Shop_Character_Local_Variable.Shop_Character_User = res.result.Character_Information.data;
      User_Have_Character_Local_Varible.User_Have_Character = res.result.User_Have_Character_Information.data;
    },
    fail: function fail() {
      console.log("获取角色信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
};

WeChat.Loading_Shop_Character = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Shop",
    success: function success(res) {
      console.log("获取商店信息成功", res);
      Shop_Character_Local_Variable.Shop_Character_User = res.result.Character_Information.data;
      User_Have_Character_Local_Varible.User_Have_Character = res.result.User_Have_Character_Information.data;
    },
    fail: function fail() {
      console.log("获取商店信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //商店购买跟新


WeChat.Buy_Character_Update = function (_Update_Gold, _Update_Character) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Shop_Buy",
    data: {
      Update_Gold: _Update_Gold,
      Update_Character: _Update_Character
    },
    success: function success(res) {
      console.log("商店获取成功回调", res);
    },
    fail: function fail() {
      console.log("商店获回调出错", console.error);
      WeChat.Loading_Resources();
    }
  });
};

WeChat.Loading_Bird_Image = function (Character_Id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_Bird_Image",
    data: {
      Character_Id: Character_Id
    },
    success: function success(res) {
      console.log("角色图像获取成功回调", res);
      cc.loader.load({
        url: res.result.Character_Image1,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image1 = frame;
      });
      cc.loader.load({
        url: res.result.Character_Image2,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image2 = frame;
      });
      cc.loader.load({
        url: res.result.Character_Image3,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image3 = frame;
      });
      cc.loader.load({
        url: res.result.Character_Image4,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image4 = frame;
      });
    },
    fail: function fail() {
      console.log("角色图像回调出错", console.error);
    }
  });
};

WeChat.Updating_Current_Character_id = function (Character_Id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Updating_Current_Character_id",
    data: {
      Character_Id: Character_Id
    },
    success: function success(res) {
      console.log("修改当前角色成功回调", res);
      WeChat.Loading_Bird_Image(Character_Id);
    },
    fail: function fail() {
      console.log("修改当前角色失败", console.error);
      WeChat.Loading_Bird_Image(Character_Id);
    }
  });
}; //加载个人邮箱


WeChat.Loading_Email = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_Email",
    success: function success(res) {
      Email_Local_Variable.Email = res.result.User_Email_Information.data;
      console.log("获取邮件信息成功", res);
      console.log("邮件信息表", Email_Local_Variable.Email);
    },
    fail: function fail() {
      console.log("获取邮件信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //加载全部邮箱


WeChat.Loading_All_Email = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_All_Email",
    success: function success(res) {
      Email_Local_Variable.Email = res.result.User_Email_Information.data;
      console.log("获取邮件信息成功", res);
      console.log("邮件信息表", Email_Local_Variable.Email);
    },
    fail: function fail() {
      console.log("获取邮件信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //已读全部邮件


WeChat.Read_All = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Read_All",
    success: function success(res) {
      console.log("已读邮件成功回调", res);
    },
    fail: function fail() {
      console.log("已读邮件失败", console.error);
    }
  });
}; //删除已读邮件


WeChat.Delete_Read = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Delete_Read",
    success: function success(res) {
      console.log("删除已读邮件成功回调", res);
    },
    fail: function fail() {
      console.log("删除已读邮件失败", console.error);
    }
  });
}; //已读单个邮件


WeChat.Read = function (_id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Read",
    data: {
      _id: _id
    },
    success: function success(res) {
      console.log("已读邮件成功回调", res);
    },
    fail: function fail() {
      console.log("已读邮件失败", console.error);
    }
  });
}; //接受奖励


WeChat.Accept = function (_id, _Add_Gold, _Add_Diamond, _Add_Compassion) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Accept",
    data: {
      _id: _id,
      Add_Gold: _Add_Gold,
      Add_Diamond: _Add_Diamond,
      Add_Compassion: _Add_Compassion
    },
    success: function success(res) {
      console.log("接受奖励成功回调", res);
      Global_Variable.Gold = res.result.Gold;
      Global_Variable.Diamond = res.result.Diamond;
      Global_Variable.Compassion = res.result.Compassion;
    },
    fail: function fail() {
      console.log("获取基础物资出错", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //发放奖励


WeChat.Awards_Email = function (Time, Title, Content, Gold, Diamond, Compassion, Enclosure) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Awards",
    data: {
      Time: Time,
      Email_Title: Title,
      Email_Content: Content,
      Email_Gold: Gold,
      Email_Diamond: Diamond,
      Email_Compassion: Compassion,
      Enclosure: Enclosure
    },
    success: function success(res) {
      console.log("发放奖励成功回调", res);
    },
    fail: function fail() {
      console.log("发放奖励失败", console.error);
    }
  });
};

WeChat.Loading_All_User = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_All_User",
    success: function success(res) {
      console.log("下载全部账号信息成功回调", res);
      Account_Management_Local_Variable.All_Users_Information = res.result.All_Users_Information.data;
      console.log("查看全部账号", Account_Management_Local_Variable.All_Users_Information);
    },
    fail: function fail() {
      console.log("下载全部账号信息失败", console.error);
      WeChat.Loading_All_User();
    }
  });
};

WeChat.Loading_Report_User = function (_openid) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_Report_User",
    data: {
      openid: _openid
    },
    success: function success(res) {
      console.log("下载举报人信息成功回调", res);
      Account_Management_Local_Variable.Report_User_List = res.result.Report_User_List.data;
      console.log("查看所有举报人信息", Account_Management_Local_Variable.Report_User_List);
    },
    fail: function fail() {
      console.log("下载所有举报人信息失败", console.error);
      WeChat.Loading_Report_User(_openid);
    }
  });
};

WeChat.Loading_Reporterd_User = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_All_Reported_Users",
    success: function success(res) {
      console.log("下载被举报人信息成功回调", res);
      Account_Management_Local_Variable.Reported_Users_Information = res.result.Reported_Information.list;
      console.log("查看被举报人信息", Account_Management_Local_Variable.Reported_Users_Information);
    },
    fail: function fail() {
      console.log("下载所有被举报人信息失败", console.error);
      WeChat.Loading_Reporterd_User();
    }
  });
};

WeChat.Email_Report_And_Appeal = function (Time, Title, Content) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Email_Report",
    data: {
      Time: Time,
      Email_Title: Title,
      Email_Content: Content
    },
    success: function success(res) {
      console.log("举报邮件成功回调", res);
    },
    fail: function fail() {
      console.log("举报邮件发送失败", console.error);
      ;
    }
  });
};

WeChat.Email_Warning = function (Time, Title, Content, open_id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Email_Warning",
    data: {
      Time: Time,
      Email_Title: Title,
      Email_Content: Content,
      open_id: open_id
    },
    success: function success(res) {
      console.log("警告邮件成功回调", res);
    },
    fail: function fail() {
      console.log("警告邮件发送失败", console.error);
      ;
    }
  });
};

WeChat.Handle_Reported_User = function (_openid) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Handle_Reported_User",
    data: {
      openid: _openid
    },
    success: function success(res) {
      console.log("处理被举报人成功回调", res);
    },
    fail: function fail() {
      console.log("处理被举报人失败", console.error);
    }
  });
};

WeChat.Closure_Account = function (Openid, Input) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Closure_Account",
    data: {
      Reported_Openid: Openid,
      Closure_Time: Input
    },
    success: function success(res) {
      console.log("封停账号成功回调", res);
    },
    fail: function fail() {
      console.log("封停账号失败", console.error);
    }
  });
};

WeChat.Cancel_Closure = function (Openid) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Cancel_Closure",
    data: {
      Reported_Openid: Openid
    },
    success: function success(res) {
      console.log("解除封停账号成功回调", res);
    },
    fail: function fail() {
      console.log("解除封停账号失败", console.error);
    }
  });
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcR2xvYmFsX1dlQ2hhdC5qcyJdLCJuYW1lcyI6WyJSYW5rX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWFibGUiLCJVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsIkFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZSIsIndpbmRvdyIsIldlQ2hhdCIsIm9uUmVnaXN0ZXJVc2VyIiwiX3VzZXJpbmZvIiwid3giLCJjbG91ZCIsImluaXQiLCJlbnYiLCJjb25zb2xlIiwibG9nIiwiY2FsbEZ1bmN0aW9uIiwibmFtZSIsImRhdGEiLCJ1c2VyaW5mbyIsInN1Y2Nlc3MiLCJyZXMiLCJHbG9iYWxfVmFyaWFibGUiLCJJc19DbG9zdXJlZCIsInJlc3VsdCIsIlVuc2VhbGluZ19UaW1lIiwib3BlbmlkIiwiY2MiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsImZhaWwiLCJlcnJvciIsIkxvYWRpbmdfUmVzb3VyY2VzIiwiR29sZCIsIkRpYW1vbmQiLCJDb21wYXNzaW9uIiwiVXNlcl9IZWFkX0ltYWdlIiwiQmVzdF9TY29yZSIsIlVzZXJfTmFtZSIsIkN1cnJlbnRfQ2hhcmFjdGVyX0lkIiwiSXNfQWRtaW4iLCJMb2FkaW5nX0JpcmRfSW1hZ2UiLCJHYW1lX1NldHRsZW1lbnQiLCJfQWRkX0dvbGQiLCJfU2NvcmUiLCJBZGRfR29sZCIsIlNjb3JlIiwiTG9hZGluZ19Xb3JsZF9SYW5rIiwiV29yZF9SYW5rX1VzZXIiLCJVc2VyX0luZm9ybWF0aW9uIiwiVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uIiwiX09wZW5pZCIsIl9SZXBvcnRfQ29udGVudCIsIlJlcG9ydGVkX09wZW5pZCIsIlJlcG9ydF9Db250ZW50IiwiTG9hZGluZ19DaGFyYWN0ZXIiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIiwiQ2hhcmFjdGVyX0luZm9ybWF0aW9uIiwiVXNlcl9IYXZlX0NoYXJhY3RlciIsIlVzZXJfSGF2ZV9DaGFyYWN0ZXJfSW5mb3JtYXRpb24iLCJMb2FkaW5nX1Nob3BfQ2hhcmFjdGVyIiwiQnV5X0NoYXJhY3Rlcl9VcGRhdGUiLCJfVXBkYXRlX0dvbGQiLCJfVXBkYXRlX0NoYXJhY3RlciIsIlVwZGF0ZV9Hb2xkIiwiVXBkYXRlX0NoYXJhY3RlciIsIkNoYXJhY3Rlcl9JZCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJDaGFyYWN0ZXJfSW1hZ2UxIiwidHlwZSIsImVyciIsInRleHR1cmUiLCJ0ZXN0IiwiZnJhbWUiLCJTcHJpdGVGcmFtZSIsIkNoYXJhY3Rlcl9JbWFnZTIiLCJDaGFyYWN0ZXJfSW1hZ2UzIiwiQ2hhcmFjdGVyX0ltYWdlNCIsIlVwZGF0aW5nX0N1cnJlbnRfQ2hhcmFjdGVyX2lkIiwiTG9hZGluZ19FbWFpbCIsIkVtYWlsIiwiVXNlcl9FbWFpbF9JbmZvcm1hdGlvbiIsIkxvYWRpbmdfQWxsX0VtYWlsIiwiUmVhZF9BbGwiLCJEZWxldGVfUmVhZCIsIlJlYWQiLCJfaWQiLCJBY2NlcHQiLCJfQWRkX0RpYW1vbmQiLCJfQWRkX0NvbXBhc3Npb24iLCJBZGRfRGlhbW9uZCIsIkFkZF9Db21wYXNzaW9uIiwiQXdhcmRzX0VtYWlsIiwiVGltZSIsIlRpdGxlIiwiQ29udGVudCIsIkVuY2xvc3VyZSIsIkVtYWlsX1RpdGxlIiwiRW1haWxfQ29udGVudCIsIkVtYWlsX0dvbGQiLCJFbWFpbF9EaWFtb25kIiwiRW1haWxfQ29tcGFzc2lvbiIsIkxvYWRpbmdfQWxsX1VzZXIiLCJBbGxfVXNlcnNfSW5mb3JtYXRpb24iLCJMb2FkaW5nX1JlcG9ydF9Vc2VyIiwiX29wZW5pZCIsIlJlcG9ydF9Vc2VyX0xpc3QiLCJMb2FkaW5nX1JlcG9ydGVyZF9Vc2VyIiwiUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb24iLCJSZXBvcnRlZF9JbmZvcm1hdGlvbiIsImxpc3QiLCJFbWFpbF9SZXBvcnRfQW5kX0FwcGVhbCIsIkVtYWlsX1dhcm5pbmciLCJvcGVuX2lkIiwiSGFuZGxlX1JlcG9ydGVkX1VzZXIiLCJDbG9zdXJlX0FjY291bnQiLCJPcGVuaWQiLCJJbnB1dCIsIkNsb3N1cmVfVGltZSIsIkNhbmNlbF9DbG9zdXJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxxQkFBRCxDQUFoQzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBQ0QsT0FBTyxDQUFDLDhCQUFELENBQXpDOztBQUNBLElBQUlFLGlDQUFpQyxHQUFDRixPQUFPLENBQUMsbUNBQUQsQ0FBN0M7O0FBQ0EsSUFBSUcsb0JBQW9CLEdBQUdILE9BQU8sQ0FBQyxzQkFBRCxDQUFsQzs7QUFDQSxJQUFJSSxpQ0FBaUMsR0FBQ0osT0FBTyxDQUFDLG1DQUFELENBQTdDOztBQUNBSyxNQUFNLENBQUNDLE1BQVAsR0FBZ0IsRUFBaEIsRUFDQTs7QUFDQUEsTUFBTSxDQUFDQyxjQUFQLEdBQXdCLFVBQVNDLFNBQVQsRUFBb0I7QUFDM0NDLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFDYkMsSUFBQUEsR0FBRyxFQUFFO0FBRFEsR0FBZDtBQUdBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWU4sU0FBWjtBQUNBQyxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUUsT0FGZTtBQUdyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUU7QUFDTEMsTUFBQUEsUUFBUSxFQUFFVjtBQURMLEtBSmU7QUFPckJXLElBQUFBLE9BUHFCLG1CQU9iQyxHQVBhLEVBT1I7QUFDWlAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF3Qk0sR0FBeEI7QUFDQUMsTUFBQUEsZUFBZSxDQUFDQyxXQUFoQixHQUE4QkYsR0FBRyxDQUFDRyxNQUFKLENBQVdELFdBQXpDO0FBQ0FELE1BQUFBLGVBQWUsQ0FBQ0csY0FBaEIsR0FBaUNKLEdBQUcsQ0FBQ0csTUFBSixDQUFXTixJQUFYLENBQWdCLENBQWhCLEVBQW1CTyxjQUFwRDtBQUNBSCxNQUFBQSxlQUFlLENBQUNJLE1BQWhCLEdBQXlCTCxHQUFHLENBQUNHLE1BQUosQ0FBV04sSUFBWCxDQUFnQixDQUFoQixFQUFtQlEsTUFBNUM7QUFDQVosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBeUMsQ0FBQ00sR0FBRyxDQUFDRyxNQUFKLENBQVdELFdBQXJEO0FBQ0FULE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdDQUFaLEVBQTZDTyxlQUFlLENBQUNHLGNBQTdEOztBQUNBLFVBQUcsQ0FBQ0osR0FBRyxDQUFDRyxNQUFKLENBQVdELFdBQWYsRUFBMkI7QUFDMUJJLFFBQUFBLEVBQUUsQ0FBQ0MsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFlBQXRCO0FBQ0EsT0FGRCxNQUVLO0FBQ0pGLFFBQUFBLEVBQUUsQ0FBQ0MsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFNBQXRCO0FBQ0E7QUFFRCxLQXBCb0I7QUFxQnJCQyxJQUFBQSxJQXJCcUIsa0JBcUJkO0FBQ05SLE1BQUFBLGVBQWUsQ0FBQ0MsV0FBaEIsR0FBOEIsSUFBOUI7QUFDQVQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFvQkQsT0FBTyxDQUFDaUIsS0FBNUI7QUFDQTtBQXhCb0IsR0FBdEI7QUEwQkEsQ0EvQkQsRUFnQ0E7OztBQUNBeEIsTUFBTSxDQUFDeUIsaUJBQVAsR0FBMkIsWUFBVztBQUNyQ3RCLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFDYkMsSUFBQUEsR0FBRyxFQUFFO0FBRFEsR0FBZDtBQUdBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUUsbUJBRmU7QUFHckJHLElBQUFBLE9BSHFCLG1CQUdiQyxHQUhhLEVBR1I7QUFDWjtBQUNBUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCTSxHQUF0QjtBQUNBQyxNQUFBQSxlQUFlLENBQUNJLE1BQWhCLEdBQXlCTCxHQUFHLENBQUNHLE1BQUosQ0FBV0UsTUFBcEM7QUFDQUosTUFBQUEsZUFBZSxDQUFDVyxJQUFoQixHQUF1QlosR0FBRyxDQUFDRyxNQUFKLENBQVdTLElBQWxDO0FBQ0FYLE1BQUFBLGVBQWUsQ0FBQ1ksT0FBaEIsR0FBMEJiLEdBQUcsQ0FBQ0csTUFBSixDQUFXVSxPQUFyQztBQUNBWixNQUFBQSxlQUFlLENBQUNhLFVBQWhCLEdBQTZCZCxHQUFHLENBQUNHLE1BQUosQ0FBV1csVUFBeEM7QUFDQWIsTUFBQUEsZUFBZSxDQUFDYyxlQUFoQixHQUFrQ2YsR0FBRyxDQUFDRyxNQUFKLENBQVdZLGVBQTdDO0FBQ0FkLE1BQUFBLGVBQWUsQ0FBQ2UsVUFBaEIsR0FBNkJoQixHQUFHLENBQUNHLE1BQUosQ0FBV2EsVUFBeEM7QUFDQWYsTUFBQUEsZUFBZSxDQUFDZ0IsU0FBaEIsR0FBNEJqQixHQUFHLENBQUNHLE1BQUosQ0FBV2MsU0FBdkM7QUFDQWhCLE1BQUFBLGVBQWUsQ0FBQ2lCLG9CQUFoQixHQUFxQ2xCLEdBQUcsQ0FBQ0csTUFBSixDQUFXZSxvQkFBaEQ7QUFDQWpCLE1BQUFBLGVBQWUsQ0FBQ2tCLFFBQWhCLEdBQXlCbkIsR0FBRyxDQUFDRyxNQUFKLENBQVdnQixRQUFwQztBQUNBakMsTUFBQUEsTUFBTSxDQUFDa0Msa0JBQVAsQ0FBMEJuQixlQUFlLENBQUNpQixvQkFBMUM7QUFDQSxLQWhCb0I7QUFpQnJCVCxJQUFBQSxJQWpCcUIsa0JBaUJkO0FBQ05oQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCRCxPQUFPLENBQUNpQixLQUFoQyxFQURNLENBRU47O0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBckJvQixHQUF0QjtBQXVCQSxDQTNCRCxFQTRCQTs7O0FBQ0F6QixNQUFNLENBQUNtQyxlQUFQLEdBQXlCLFVBQVNDLFNBQVQsRUFBb0JDLE1BQXBCLEVBQTRCO0FBQ3BEbEMsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUNiQyxJQUFBQSxHQUFHLEVBQUU7QUFEUSxHQUFkO0FBR0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0FDLElBQUFBLElBQUksRUFBRSxpQkFGZTtBQUdyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUU7QUFDTDJCLE1BQUFBLFFBQVEsRUFBRUYsU0FETDtBQUVMRyxNQUFBQSxLQUFLLEVBQUVGO0FBRkYsS0FKZTtBQVNyQnhCLElBQUFBLE9BVHFCLG1CQVNiQyxHQVRhLEVBU1I7QUFFWlAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFzQk0sR0FBdEI7QUFDQUMsTUFBQUEsZUFBZSxDQUFDVyxJQUFoQixHQUF1QlosR0FBRyxDQUFDRyxNQUFKLENBQVdTLElBQWxDO0FBQ0FYLE1BQUFBLGVBQWUsQ0FBQ1ksT0FBaEIsR0FBMEJiLEdBQUcsQ0FBQ0csTUFBSixDQUFXVSxPQUFyQztBQUNBWixNQUFBQSxlQUFlLENBQUNhLFVBQWhCLEdBQTZCZCxHQUFHLENBQUNHLE1BQUosQ0FBV1csVUFBeEM7QUFDQSxLQWZvQjtBQWdCckJMLElBQUFBLElBaEJxQixrQkFnQmQ7QUFDTmhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JELE9BQU8sQ0FBQ2lCLEtBQWhDO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBbkJvQixHQUF0QjtBQXFCQSxDQXpCRCxFQTBCQTs7O0FBQ0F6QixNQUFNLENBQUN3QyxrQkFBUCxHQUE0QixZQUFXO0FBQ3RDckMsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUNiQyxJQUFBQSxHQUFHLEVBQUU7QUFEUSxHQUFkO0FBR0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0FDLElBQUFBLElBQUksRUFBRSxvQkFGZTtBQUlyQkcsSUFBQUEsT0FKcUIsbUJBSWJDLEdBSmEsRUFJUjtBQUVaUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQTBCTSxHQUExQjtBQUNBckIsTUFBQUEsa0JBQWtCLENBQUNnRCxjQUFuQixHQUFvQzNCLEdBQUcsQ0FBQ0csTUFBSixDQUFXeUIsZ0JBQVgsQ0FBNEIvQixJQUFoRTtBQUNBSixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWixFQUFtQ2Ysa0JBQWtCLENBQUNnRCxjQUFuQixDQUFrQyxDQUFsQyxFQUFxQ3RCLE1BQXhFO0FBQ0EsS0FUb0I7QUFVckJJLElBQUFBLElBVnFCLGtCQVVkO0FBQ05oQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCRCxPQUFPLENBQUNpQixLQUFoQztBQUNBeEIsTUFBQUEsTUFBTSxDQUFDeUIsaUJBQVA7QUFDQTtBQWJvQixHQUF0QjtBQWVBLENBbkJELEVBcUJBOzs7QUFDQXpCLE1BQU0sQ0FBQzJDLDhCQUFQLEdBQXdDLFVBQVNDLE9BQVQsRUFBa0JDLGVBQWxCLEVBQW1DO0FBRTFFMUMsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUNiQyxJQUFBQSxHQUFHLEVBQUU7QUFEUSxHQUFkO0FBR0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0FDLElBQUFBLElBQUksRUFBRSxnQ0FGZTtBQUdyQkMsSUFBQUEsSUFBSSxFQUFFO0FBQ0xtQyxNQUFBQSxlQUFlLEVBQUVGLE9BRFo7QUFFTEcsTUFBQUEsY0FBYyxFQUFFRjtBQUZYLEtBSGU7QUFRckJoQyxJQUFBQSxPQVJxQixtQkFRYkMsR0FSYSxFQVFSO0FBQ1pQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JNLEdBQXRCO0FBQ0EsS0FWb0I7QUFXckJTLElBQUFBLElBWHFCLGtCQVdkO0FBQ05oQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCRCxPQUFPLENBQUNpQixLQUE5QjtBQUNBO0FBYm9CLEdBQXRCO0FBZUEsQ0FwQkQ7O0FBc0JBeEIsTUFBTSxDQUFDZ0QsaUJBQVAsR0FBeUIsWUFBWTtBQUNwQzdDLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxXQUhnQjtBQU1yQkcsSUFBQUEsT0FOcUIsbUJBTWJDLEdBTmEsRUFNVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBbkIsTUFBQUEsNkJBQTZCLENBQUNzRCxtQkFBOUIsR0FBa0RuQyxHQUFHLENBQUNHLE1BQUosQ0FBV2lDLHFCQUFYLENBQWlDdkMsSUFBbkY7QUFDQWYsTUFBQUEsaUNBQWlDLENBQUN1RCxtQkFBbEMsR0FBc0RyQyxHQUFHLENBQUNHLE1BQUosQ0FBV21DLCtCQUFYLENBQTJDekMsSUFBakc7QUFDQSxLQVZvQjtBQVdyQlksSUFBQUEsSUFYcUIsa0JBV2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBZG9CLEdBQXRCO0FBZ0JBLENBbEJEOztBQW9CQXpCLE1BQU0sQ0FBQ3FELHNCQUFQLEdBQThCLFlBQVU7QUFDdkNsRCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsTUFIZ0I7QUFNckJHLElBQUFBLE9BTnFCLG1CQU1iQyxHQU5hLEVBTVQ7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQW5CLE1BQUFBLDZCQUE2QixDQUFDc0QsbUJBQTlCLEdBQWtEbkMsR0FBRyxDQUFDRyxNQUFKLENBQVdpQyxxQkFBWCxDQUFpQ3ZDLElBQW5GO0FBQ0FmLE1BQUFBLGlDQUFpQyxDQUFDdUQsbUJBQWxDLEdBQXNEckMsR0FBRyxDQUFDRyxNQUFKLENBQVdtQywrQkFBWCxDQUEyQ3pDLElBQWpHO0FBQ0EsS0FWb0I7QUFXckJZLElBQUFBLElBWHFCLGtCQVdmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCRCxPQUFPLENBQUNpQixLQUEvQjtBQUNBeEIsTUFBQUEsTUFBTSxDQUFDeUIsaUJBQVA7QUFDQTtBQWRvQixHQUF0QjtBQWdCQSxDQWxCRCxFQXFCQTs7O0FBQ0F6QixNQUFNLENBQUNzRCxvQkFBUCxHQUE0QixVQUFVQyxZQUFWLEVBQXVCQyxpQkFBdkIsRUFBMEM7QUFDckVyRCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsVUFIZ0I7QUFLckJDLElBQUFBLElBQUksRUFBQztBQUNKOEMsTUFBQUEsV0FBVyxFQUFDRixZQURSO0FBRUpHLE1BQUFBLGdCQUFnQixFQUFDRjtBQUZiLEtBTGdCO0FBVXJCM0MsSUFBQUEsT0FWcUIsbUJBVWJDLEdBVmEsRUFVVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBLEtBWm9CO0FBYXJCUyxJQUFBQSxJQWJxQixrQkFhZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUFzQkQsT0FBTyxDQUFDaUIsS0FBOUI7QUFDQXhCLE1BQUFBLE1BQU0sQ0FBQ3lCLGlCQUFQO0FBQ0E7QUFoQm9CLEdBQXRCO0FBa0JBLENBcEJEOztBQXNCQXpCLE1BQU0sQ0FBQ2tDLGtCQUFQLEdBQTBCLFVBQVV5QixZQUFWLEVBQXdCO0FBQ2pEeEQsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLG9CQUhnQjtBQUtyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pnRCxNQUFBQSxZQUFZLEVBQUNBO0FBRFQsS0FMZ0I7QUFTckI5QyxJQUFBQSxPQVRxQixtQkFTYkMsR0FUYSxFQVNUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBeUJNLEdBQXpCO0FBRUFNLE1BQUFBLEVBQUUsQ0FBQ3dDLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLFFBQUFBLEdBQUcsRUFBQ2hELEdBQUcsQ0FBQ0csTUFBSixDQUFXOEMsZ0JBREQ7QUFFZEMsUUFBQUEsSUFBSSxFQUFDO0FBRlMsT0FBZixFQUdFLFVBQVNDLEdBQVQsRUFBYUMsT0FBYixFQUFxQkMsSUFBckIsRUFBMEI7QUFDM0IsWUFBSUMsS0FBSyxHQUFDLElBQUloRCxFQUFFLENBQUNpRCxXQUFQLENBQW1CSCxPQUFuQixDQUFWOztBQUNBLFlBQUdELEdBQUgsRUFBTztBQUNOMUQsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQnlELEdBQW5CO0FBQ0E7O0FBQ0RsRCxRQUFBQSxlQUFlLENBQUNnRCxnQkFBaEIsR0FBaUNLLEtBQWpDO0FBQ0EsT0FURDtBQVVBaEQsTUFBQUEsRUFBRSxDQUFDd0MsTUFBSCxDQUFVQyxJQUFWLENBQWU7QUFDZEMsUUFBQUEsR0FBRyxFQUFDaEQsR0FBRyxDQUFDRyxNQUFKLENBQVdxRCxnQkFERDtBQUVkTixRQUFBQSxJQUFJLEVBQUM7QUFGUyxPQUFmLEVBR0UsVUFBU0MsR0FBVCxFQUFhQyxPQUFiLEVBQXFCQyxJQUFyQixFQUEwQjtBQUMzQixZQUFJQyxLQUFLLEdBQUMsSUFBSWhELEVBQUUsQ0FBQ2lELFdBQVAsQ0FBbUJILE9BQW5CLENBQVY7O0FBQ0EsWUFBR0QsR0FBSCxFQUFPO0FBQ04xRCxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CeUQsR0FBbkI7QUFDQTs7QUFDRGxELFFBQUFBLGVBQWUsQ0FBQ3VELGdCQUFoQixHQUFpQ0YsS0FBakM7QUFDQSxPQVREO0FBVUFoRCxNQUFBQSxFQUFFLENBQUN3QyxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxRQUFBQSxHQUFHLEVBQUNoRCxHQUFHLENBQUNHLE1BQUosQ0FBV3NELGdCQUREO0FBRWRQLFFBQUFBLElBQUksRUFBQztBQUZTLE9BQWYsRUFHRSxVQUFTQyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFlBQUlDLEtBQUssR0FBQyxJQUFJaEQsRUFBRSxDQUFDaUQsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxZQUFHRCxHQUFILEVBQU87QUFDTjFELFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJ5RCxHQUFuQjtBQUNBOztBQUNEbEQsUUFBQUEsZUFBZSxDQUFDd0QsZ0JBQWhCLEdBQWlDSCxLQUFqQztBQUNBLE9BVEQ7QUFVQWhELE1BQUFBLEVBQUUsQ0FBQ3dDLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLFFBQUFBLEdBQUcsRUFBQ2hELEdBQUcsQ0FBQ0csTUFBSixDQUFXdUQsZ0JBREQ7QUFFZFIsUUFBQUEsSUFBSSxFQUFDO0FBRlMsT0FBZixFQUdFLFVBQVNDLEdBQVQsRUFBYUMsT0FBYixFQUFxQkMsSUFBckIsRUFBMEI7QUFDM0IsWUFBSUMsS0FBSyxHQUFDLElBQUloRCxFQUFFLENBQUNpRCxXQUFQLENBQW1CSCxPQUFuQixDQUFWOztBQUNBLFlBQUdELEdBQUgsRUFBTztBQUNOMUQsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQnlELEdBQW5CO0FBQ0E7O0FBQ0RsRCxRQUFBQSxlQUFlLENBQUN5RCxnQkFBaEIsR0FBaUNKLEtBQWpDO0FBQ0EsT0FURDtBQVVBLEtBcERvQjtBQXNEckI3QyxJQUFBQSxJQXREcUIsa0JBc0RmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCRCxPQUFPLENBQUNpQixLQUEvQjtBQUNBO0FBeERvQixHQUF0QjtBQTBEQSxDQTVERDs7QUE4REF4QixNQUFNLENBQUN5RSw2QkFBUCxHQUFxQyxVQUFVZCxZQUFWLEVBQXdCO0FBQzVEeEQsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLCtCQUhnQjtBQUtyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pnRCxNQUFBQSxZQUFZLEVBQUNBO0FBRFQsS0FMZ0I7QUFTckI5QyxJQUFBQSxPQVRxQixtQkFTYkMsR0FUYSxFQVNUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBeUJNLEdBQXpCO0FBQ0FkLE1BQUFBLE1BQU0sQ0FBQ2tDLGtCQUFQLENBQTBCeUIsWUFBMUI7QUFDQSxLQVpvQjtBQWNyQnBDLElBQUFBLElBZHFCLGtCQWNmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCRCxPQUFPLENBQUNpQixLQUEvQjtBQUNBeEIsTUFBQUEsTUFBTSxDQUFDa0Msa0JBQVAsQ0FBMEJ5QixZQUExQjtBQUNBO0FBakJvQixHQUF0QjtBQW1CQSxDQXJCRCxFQXVCQTs7O0FBQ0EzRCxNQUFNLENBQUMwRSxhQUFQLEdBQXFCLFlBQVU7QUFDOUJ2RSxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsZUFIZ0I7QUFJckJHLElBQUFBLE9BSnFCLG1CQUliQyxHQUphLEVBSVQ7QUFDWGpCLE1BQUFBLG9CQUFvQixDQUFDOEUsS0FBckIsR0FBMkI3RCxHQUFHLENBQUNHLE1BQUosQ0FBVzJELHNCQUFYLENBQWtDakUsSUFBN0Q7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQVAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQlgsb0JBQW9CLENBQUM4RSxLQUF6QztBQUNBLEtBUm9CO0FBU3JCcEQsSUFBQUEsSUFUcUIsa0JBU2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBWm9CLEdBQXRCO0FBZUEsQ0FqQkQsRUFrQkE7OztBQUNBekIsTUFBTSxDQUFDNkUsaUJBQVAsR0FBeUIsWUFBVTtBQUNsQzFFLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxtQkFIZ0I7QUFJckJHLElBQUFBLE9BSnFCLG1CQUliQyxHQUphLEVBSVQ7QUFDWGpCLE1BQUFBLG9CQUFvQixDQUFDOEUsS0FBckIsR0FBMkI3RCxHQUFHLENBQUNHLE1BQUosQ0FBVzJELHNCQUFYLENBQWtDakUsSUFBN0Q7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQVAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQlgsb0JBQW9CLENBQUM4RSxLQUF6QztBQUNBLEtBUm9CO0FBU3JCcEQsSUFBQUEsSUFUcUIsa0JBU2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBWm9CLEdBQXRCO0FBZUEsQ0FqQkQsRUFrQkE7OztBQUNBekIsTUFBTSxDQUFDOEUsUUFBUCxHQUFnQixZQUFZO0FBQzNCM0UsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLFVBSGdCO0FBSXJCRyxJQUFBQSxPQUpxQixtQkFJYkMsR0FKYSxFQUlUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJNLEdBQXZCO0FBQ0EsS0FOb0I7QUFRckJTLElBQUFBLElBUnFCLGtCQVFmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCRCxPQUFPLENBQUNpQixLQUE3QjtBQUNBO0FBVm9CLEdBQXRCO0FBWUEsQ0FkRCxFQWVBOzs7QUFDQXhCLE1BQU0sQ0FBQytFLFdBQVAsR0FBbUIsWUFBWTtBQUM5QjVFLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxhQUhnQjtBQUlyQkcsSUFBQUEsT0FKcUIsbUJBSWJDLEdBSmEsRUFJVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQXlCTSxHQUF6QjtBQUNBLEtBTm9CO0FBUXJCUyxJQUFBQSxJQVJxQixrQkFRZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1QkQsT0FBTyxDQUFDaUIsS0FBL0I7QUFDQTtBQVZvQixHQUF0QjtBQVlBLENBZEQsRUFlQTs7O0FBQ0F4QixNQUFNLENBQUNnRixJQUFQLEdBQVksVUFBU0MsR0FBVCxFQUFhO0FBQ3hCOUUsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLE1BSGdCO0FBSXJCQyxJQUFBQSxJQUFJLEVBQUM7QUFDSnNFLE1BQUFBLEdBQUcsRUFBQ0E7QUFEQSxLQUpnQjtBQU9yQnBFLElBQUFBLE9BUHFCLG1CQU9iQyxHQVBhLEVBT1Q7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQSxLQVRvQjtBQVdyQlMsSUFBQUEsSUFYcUIsa0JBV2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBcUJELE9BQU8sQ0FBQ2lCLEtBQTdCO0FBQ0E7QUFib0IsR0FBdEI7QUFlQSxDQWpCRCxFQWtCQTs7O0FBQ0F4QixNQUFNLENBQUNrRixNQUFQLEdBQWMsVUFBU0QsR0FBVCxFQUFhN0MsU0FBYixFQUF1QitDLFlBQXZCLEVBQW9DQyxlQUFwQyxFQUFvRDtBQUNqRWpGLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxRQUhnQjtBQUlyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pzRSxNQUFBQSxHQUFHLEVBQUNBLEdBREE7QUFFSjNDLE1BQUFBLFFBQVEsRUFBQ0YsU0FGTDtBQUdKaUQsTUFBQUEsV0FBVyxFQUFDRixZQUhSO0FBSUpHLE1BQUFBLGNBQWMsRUFBQ0Y7QUFKWCxLQUpnQjtBQVVyQnZFLElBQUFBLE9BVnFCLG1CQVViQyxHQVZhLEVBVVQ7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQUMsTUFBQUEsZUFBZSxDQUFDVyxJQUFoQixHQUF1QlosR0FBRyxDQUFDRyxNQUFKLENBQVdTLElBQWxDO0FBQ0FYLE1BQUFBLGVBQWUsQ0FBQ1ksT0FBaEIsR0FBMEJiLEdBQUcsQ0FBQ0csTUFBSixDQUFXVSxPQUFyQztBQUNBWixNQUFBQSxlQUFlLENBQUNhLFVBQWhCLEdBQTZCZCxHQUFHLENBQUNHLE1BQUosQ0FBV1csVUFBeEM7QUFDQSxLQWZvQjtBQWlCckJMLElBQUFBLElBakJxQixrQkFpQmY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JELE9BQU8sQ0FBQ2lCLEtBQWhDO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBcEJvQixHQUF0QjtBQXNCQSxDQXhCRCxFQXlCQTs7O0FBQ0F6QixNQUFNLENBQUN1RixZQUFQLEdBQW9CLFVBQVNDLElBQVQsRUFBY0MsS0FBZCxFQUFvQkMsT0FBcEIsRUFBNEJoRSxJQUE1QixFQUFpQ0MsT0FBakMsRUFBeUNDLFVBQXpDLEVBQW9EK0QsU0FBcEQsRUFBOEQ7QUFDakZ4RixFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsUUFIZ0I7QUFJckJDLElBQUFBLElBQUksRUFBQztBQUNKNkUsTUFBQUEsSUFBSSxFQUFDQSxJQUREO0FBRUpJLE1BQUFBLFdBQVcsRUFBQ0gsS0FGUjtBQUdKSSxNQUFBQSxhQUFhLEVBQUNILE9BSFY7QUFJSkksTUFBQUEsVUFBVSxFQUFDcEUsSUFKUDtBQUtKcUUsTUFBQUEsYUFBYSxFQUFDcEUsT0FMVjtBQU1KcUUsTUFBQUEsZ0JBQWdCLEVBQUNwRSxVQU5iO0FBT0orRCxNQUFBQSxTQUFTLEVBQUNBO0FBUE4sS0FKZ0I7QUFhckI5RSxJQUFBQSxPQWJxQixtQkFhYkMsR0FiYSxFQWFUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJNLEdBQXZCO0FBQ0EsS0Fmb0I7QUFpQnJCUyxJQUFBQSxJQWpCcUIsa0JBaUJmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCRCxPQUFPLENBQUNpQixLQUE5QjtBQUNBO0FBbkJvQixHQUF0QjtBQXFCQSxDQXZCRDs7QUF5QkF4QixNQUFNLENBQUNpRyxnQkFBUCxHQUF3QixZQUFZO0FBQ25DOUYsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLGtCQUhnQjtBQUtyQkcsSUFBQUEsT0FMcUIsbUJBS2JDLEdBTGEsRUFLVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTJCTSxHQUEzQjtBQUNBaEIsTUFBQUEsaUNBQWlDLENBQUNvRyxxQkFBbEMsR0FBd0RwRixHQUFHLENBQUNHLE1BQUosQ0FBV2lGLHFCQUFYLENBQWlDdkYsSUFBekY7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQlYsaUNBQWlDLENBQUNvRyxxQkFBdkQ7QUFDQSxLQVRvQjtBQVdyQjNFLElBQUFBLElBWHFCLGtCQVdmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQXlCRCxPQUFPLENBQUNpQixLQUFqQztBQUNBeEIsTUFBQUEsTUFBTSxDQUFDaUcsZ0JBQVA7QUFDQTtBQWRvQixHQUF0QjtBQWdCQSxDQWxCRDs7QUFvQkFqRyxNQUFNLENBQUNtRyxtQkFBUCxHQUEyQixVQUFVQyxPQUFWLEVBQW1CO0FBQzdDakcsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLHFCQUhnQjtBQUtyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pRLE1BQUFBLE1BQU0sRUFBQ2lGO0FBREgsS0FMZ0I7QUFTckJ2RixJQUFBQSxPQVRxQixtQkFTYkMsR0FUYSxFQVNUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVosRUFBMEJNLEdBQTFCO0FBQ0FoQixNQUFBQSxpQ0FBaUMsQ0FBQ3VHLGdCQUFsQyxHQUFtRHZGLEdBQUcsQ0FBQ0csTUFBSixDQUFXb0YsZ0JBQVgsQ0FBNEIxRixJQUEvRTtBQUNBSixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCVixpQ0FBaUMsQ0FBQ3VHLGdCQUExRDtBQUNBLEtBYm9CO0FBZXJCOUUsSUFBQUEsSUFmcUIsa0JBZWY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVosRUFBMEJELE9BQU8sQ0FBQ2lCLEtBQWxDO0FBQ0F4QixNQUFBQSxNQUFNLENBQUNtRyxtQkFBUCxDQUEyQkMsT0FBM0I7QUFDQTtBQWxCb0IsR0FBdEI7QUFvQkEsQ0F0QkQ7O0FBd0JBcEcsTUFBTSxDQUFDc0csc0JBQVAsR0FBOEIsWUFBWTtBQUN6Q25HLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyw0QkFIZ0I7QUFJckJHLElBQUFBLE9BSnFCLG1CQUliQyxHQUphLEVBSVQ7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQk0sR0FBM0I7QUFDQWhCLE1BQUFBLGlDQUFpQyxDQUFDeUcsMEJBQWxDLEdBQTZEekYsR0FBRyxDQUFDRyxNQUFKLENBQVd1RixvQkFBWCxDQUFnQ0MsSUFBN0Y7QUFDQWxHLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJWLGlDQUFpQyxDQUFDeUcsMEJBQXpEO0FBQ0EsS0FSb0I7QUFTckJoRixJQUFBQSxJQVRxQixrQkFTZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQkQsT0FBTyxDQUFDaUIsS0FBbkM7QUFDQXhCLE1BQUFBLE1BQU0sQ0FBQ3NHLHNCQUFQO0FBQ0E7QUFab0IsR0FBdEI7QUFjQSxDQWhCRDs7QUFrQkF0RyxNQUFNLENBQUMwRyx1QkFBUCxHQUErQixVQUFVbEIsSUFBVixFQUFlQyxLQUFmLEVBQXFCQyxPQUFyQixFQUE4QjtBQUM1RHZGLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxjQUhnQjtBQUlyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0o2RSxNQUFBQSxJQUFJLEVBQUNBLElBREQ7QUFFSkksTUFBQUEsV0FBVyxFQUFDSCxLQUZSO0FBR0pJLE1BQUFBLGFBQWEsRUFBQ0g7QUFIVixLQUpnQjtBQVNyQjdFLElBQUFBLE9BVHFCLG1CQVNiQyxHQVRhLEVBU1Q7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQSxLQVhvQjtBQVlyQlMsSUFBQUEsSUFacUIsa0JBWWY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQXNDO0FBQ3RDO0FBZG9CLEdBQXRCO0FBZ0JBLENBbEJEOztBQW9CQXhCLE1BQU0sQ0FBQzJHLGFBQVAsR0FBcUIsVUFBVW5CLElBQVYsRUFBZUMsS0FBZixFQUFxQkMsT0FBckIsRUFBNkJrQixPQUE3QixFQUFzQztBQUMxRHpHLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxlQUhnQjtBQUlyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0o2RSxNQUFBQSxJQUFJLEVBQUNBLElBREQ7QUFFSkksTUFBQUEsV0FBVyxFQUFDSCxLQUZSO0FBR0pJLE1BQUFBLGFBQWEsRUFBQ0gsT0FIVjtBQUlKa0IsTUFBQUEsT0FBTyxFQUFDQTtBQUpKLEtBSmdCO0FBVXJCL0YsSUFBQUEsT0FWcUIsbUJBVWJDLEdBVmEsRUFVVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBLEtBWm9CO0FBYXJCUyxJQUFBQSxJQWJxQixrQkFhZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1QkQsT0FBTyxDQUFDaUIsS0FBL0I7QUFBc0M7QUFDdEM7QUFmb0IsR0FBdEI7QUFpQkEsQ0FuQkQ7O0FBcUJBeEIsTUFBTSxDQUFDNkcsb0JBQVAsR0FBNEIsVUFBU1QsT0FBVCxFQUFpQjtBQUM1Q2pHLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxzQkFIZ0I7QUFJckJDLElBQUFBLElBQUksRUFBQztBQUNKUSxNQUFBQSxNQUFNLEVBQUNpRjtBQURILEtBSmdCO0FBT3JCdkYsSUFBQUEsT0FQcUIsbUJBT2JDLEdBUGEsRUFPVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQXlCTSxHQUF6QjtBQUNBLEtBVG9CO0FBVXJCUyxJQUFBQSxJQVZxQixrQkFVZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1QkQsT0FBTyxDQUFDaUIsS0FBL0I7QUFDQTtBQVpvQixHQUF0QjtBQWNBLENBaEJEOztBQWtCQXhCLE1BQU0sQ0FBQzhHLGVBQVAsR0FBeUIsVUFBU0MsTUFBVCxFQUFnQkMsS0FBaEIsRUFBc0I7QUFDOUM3RyxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsaUJBSGdCO0FBSXJCQyxJQUFBQSxJQUFJLEVBQUM7QUFDSm1DLE1BQUFBLGVBQWUsRUFBQ2lFLE1BRFo7QUFFSkUsTUFBQUEsWUFBWSxFQUFDRDtBQUZULEtBSmdCO0FBUXJCbkcsSUFBQUEsT0FScUIsbUJBUWJDLEdBUmEsRUFRVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBLEtBVm9CO0FBV3JCUyxJQUFBQSxJQVhxQixrQkFXZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQkQsT0FBTyxDQUFDaUIsS0FBN0I7QUFDQTtBQWJvQixHQUF0QjtBQWVBLENBakJEOztBQW1CQXhCLE1BQU0sQ0FBQ2tILGNBQVAsR0FBd0IsVUFBU0gsTUFBVCxFQUFnQjtBQUN2QzVHLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxnQkFIZ0I7QUFJckJDLElBQUFBLElBQUksRUFBQztBQUNKbUMsTUFBQUEsZUFBZSxFQUFDaUU7QUFEWixLQUpnQjtBQU9yQmxHLElBQUFBLE9BUHFCLG1CQU9iQyxHQVBhLEVBT1Q7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWixFQUF5Qk0sR0FBekI7QUFDQSxLQVRvQjtBQVVyQlMsSUFBQUEsSUFWcUIsa0JBVWY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0E7QUFab0IsR0FBdEI7QUFjQSxDQWhCRCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lhajlsYDlj5jph49cclxudmFyIFJhbmtfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ1JhbmtfTG9jYWxfVmFyaWFibGUnKTtcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlhYmxlPXJlcXVpcmUoJ1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxudmFyIFVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZT1yZXF1aXJlKCdVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxudmFyIEVtYWlsX0xvY2FsX1ZhcmlhYmxlID0gcmVxdWlyZSgnRW1haWxfTG9jYWxfVmFyaWFibGUnKTtcclxudmFyIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZT1yZXF1aXJlKCdBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUnKTtcclxud2luZG93LldlQ2hhdCA9IHt9O1xyXG4vL+W+ruS/oeeZu+W9leazqOWGjOiwg+eUqFxyXG5XZUNoYXQub25SZWdpc3RlclVzZXIgPSBmdW5jdGlvbihfdXNlcmluZm8pIHtcclxuXHR3eC5jbG91ZC5pbml0KHtcclxuXHRcdGVudjogXCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwiXHJcblx0fSlcclxuXHRjb25zb2xlLmxvZyhfdXNlcmluZm8pO1xyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0bmFtZTogXCJsb2dpblwiLFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbDvvIznjqnlrrbkv6Hmga9cclxuXHRcdGRhdGE6IHtcclxuXHRcdFx0dXNlcmluZm86IF91c2VyaW5mbyxcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcykge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIueZu+W9leazqOWGjOaIkOWKn+Wbnuiwg1wiLCByZXMpO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuSXNfQ2xvc3VyZWQgPSByZXMucmVzdWx0LklzX0Nsb3N1cmVkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuVW5zZWFsaW5nX1RpbWUgPSByZXMucmVzdWx0LmRhdGFbMF0uVW5zZWFsaW5nX1RpbWU7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5vcGVuaWQgPSByZXMucmVzdWx0LmRhdGFbMF0ub3BlbmlkO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIiFyZXMucmVzdWx0LklzX0Nsb3N1cmVk55qE5YC85Li6XCIsIXJlcy5yZXN1bHQuSXNfQ2xvc3VyZWQpO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIkdsb2JhbF9WYXJpYWJsZS5VbnNlYWxpbmdfVGltZVwiLEdsb2JhbF9WYXJpYWJsZS5VbnNlYWxpbmdfVGltZSk7XHJcblx0XHRcdGlmKCFyZXMucmVzdWx0LklzX0Nsb3N1cmVkKXtcclxuXHRcdFx0XHRjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lX1N0YXJ0XCIpO1xyXG5cdFx0XHR9ZWxzZXtcclxuXHRcdFx0XHRjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJDbG9zdXJlXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0fSxcclxuXHRcdGZhaWwoKSB7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Jc19DbG9zdXJlZCA9IHRydWU7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi56iL5bqP5Ye66ZSZXCIsIGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/liqDovb3otYTmupBcclxuV2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzID0gZnVuY3Rpb24oKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7XHJcblx0XHRlbnY6IFwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIlxyXG5cdH0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHRuYW1lOiBcIkxvYWRpbmdfUmVzb3VyY2VzXCIsXHJcblx0XHRzdWNjZXNzKHJlcykge1xyXG5cdFx0XHQvL+WwhuWAvOi1i+e7meWFqOWxgOWPmOmHj1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuiOt+WPluaIkOWKn+Wbnuiwg1wiLCByZXMpO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUub3BlbmlkID0gcmVzLnJlc3VsdC5vcGVuaWQ7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Hb2xkID0gcmVzLnJlc3VsdC5Hb2xkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuRGlhbW9uZCA9IHJlcy5yZXN1bHQuRGlhbW9uZDtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb24gPSByZXMucmVzdWx0LkNvbXBhc3Npb247XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Vc2VyX0hlYWRfSW1hZ2UgPSByZXMucmVzdWx0LlVzZXJfSGVhZF9JbWFnZTtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkJlc3RfU2NvcmUgPSByZXMucmVzdWx0LkJlc3RfU2NvcmU7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Vc2VyX05hbWUgPSByZXMucmVzdWx0LlVzZXJfTmFtZTtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkN1cnJlbnRfQ2hhcmFjdGVyX0lkPXJlcy5yZXN1bHQuQ3VycmVudF9DaGFyYWN0ZXJfSWQ7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Jc19BZG1pbj1yZXMucmVzdWx0LklzX0FkbWluO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19CaXJkX0ltYWdlKEdsb2JhbF9WYXJpYWJsZS5DdXJyZW50X0NoYXJhY3Rlcl9JZCk7XHJcblx0XHR9LFxyXG5cdFx0ZmFpbCgpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bln7rnoYDnianotYTlh7rplJlcIiwgY29uc29sZS5lcnJvcik7XHJcblx0XHRcdC8v5aSx6LSl5LqG6YeN5paw6LWL5YC8XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/muLjmiI/nu5PnrpdcclxuV2VDaGF0LkdhbWVfU2V0dGxlbWVudCA9IGZ1bmN0aW9uKF9BZGRfR29sZCwgX1Njb3JlKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7XHJcblx0XHRlbnY6IFwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIlxyXG5cdH0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHRuYW1lOiBcIkdhbWVfU2V0dGxlbWVudFwiLFxyXG5cdFx0Ly/kvKDlhaXlj4LmlbDvvIzljIXmi6zlop7liqDnmoTph5HluIHmlbDph4/vvIzliIbmlbBcclxuXHRcdGRhdGE6IHtcclxuXHRcdFx0QWRkX0dvbGQ6IF9BZGRfR29sZCxcclxuXHRcdFx0U2NvcmU6IF9TY29yZSxcclxuXHRcdH0sXHJcblxyXG5cdFx0c3VjY2VzcyhyZXMpIHtcclxuXHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5oiQ5Yqf5Zue6LCDXCIsIHJlcyk7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Hb2xkID0gcmVzLnJlc3VsdC5Hb2xkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuRGlhbW9uZCA9IHJlcy5yZXN1bHQuRGlhbW9uZDtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb24gPSByZXMucmVzdWx0LkNvbXBhc3Npb247XHJcblx0XHR9LFxyXG5cdFx0ZmFpbCgpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bln7rnoYDnianotYTlh7rplJlcIiwgY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/liqDovb3kuJbnlYzmjpLlkI1cclxuV2VDaGF0LkxvYWRpbmdfV29ybGRfUmFuayA9IGZ1bmN0aW9uKCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe1xyXG5cdFx0ZW52OiBcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJcclxuXHR9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFx0XHRcclxuXHRcdG5hbWU6IFwiTG9hZGluZ19Xb3JsZF9SYW5rXCIsXHJcblxyXG5cdFx0c3VjY2VzcyhyZXMpIHtcclxuXHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5LiL6L295LiW55WM5o6S5ZCN5oiQ5Yqf5Zue6LCDXCIsIHJlcyk7XHJcblx0XHRcdFJhbmtfTG9jYWxfVmFyaWJsZS5Xb3JkX1JhbmtfVXNlciA9IHJlcy5yZXN1bHQuVXNlcl9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIlJhbmtfTG9jYWxfVmFyaWJsZeS4ulwiLCBSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXJbMF0ub3BlbmlkKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4i+i9veS4lueVjOaOkuWQjeWHuumUmVwiLCBjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHR9XHJcblx0fSlcclxufVxyXG5cclxuLy/kuIrkvKDkuL7miqXjgIHnlLPor4nliJfooahcclxuV2VDaGF0LlVwbG9hZGluZ19SZXBvcnRlZF9JbmZvcm1hdGlvbiA9IGZ1bmN0aW9uKF9PcGVuaWQsIF9SZXBvcnRfQ29udGVudCkge1xyXG5cclxuXHR3eC5jbG91ZC5pbml0KHtcclxuXHRcdGVudjogXCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwiXHJcblx0fSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdG5hbWU6IFwiVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uXCIsXHJcblx0XHRkYXRhOiB7XHJcblx0XHRcdFJlcG9ydGVkX09wZW5pZDogX09wZW5pZCxcclxuXHRcdFx0UmVwb3J0X0NvbnRlbnQ6IF9SZXBvcnRfQ29udGVudCxcclxuXHRcdH0sXHJcblxyXG5cdFx0c3VjY2VzcyhyZXMpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkuL7miqXmiJDlip/lm57osINcIiwgcmVzKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4vuaKpeWHuumUmeWbnuiwg1wiLCBjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuTG9hZGluZ19DaGFyYWN0ZXI9ZnVuY3Rpb24gKCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJDaGFyYWN0ZXJcIixcclxuXHRcdFxyXG5cclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W6KeS6Imy5L+h5oGv5oiQ5YqfXCIscmVzKTtcclxuXHRcdFx0U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWFibGUuU2hvcF9DaGFyYWN0ZXJfVXNlcj1yZXMucmVzdWx0LkNoYXJhY3Rlcl9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3Rlcj1yZXMucmVzdWx0LlVzZXJfSGF2ZV9DaGFyYWN0ZXJfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W6KeS6Imy5L+h5oGv5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5Mb2FkaW5nX1Nob3BfQ2hhcmFjdGVyPWZ1bmN0aW9uKCl7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIlNob3BcIixcclxuXHRcdFxyXG5cclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5ZWG5bqX5L+h5oGv5oiQ5YqfXCIscmVzKTtcclxuXHRcdFx0U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWFibGUuU2hvcF9DaGFyYWN0ZXJfVXNlcj1yZXMucmVzdWx0LkNoYXJhY3Rlcl9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3Rlcj1yZXMucmVzdWx0LlVzZXJfSGF2ZV9DaGFyYWN0ZXJfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5ZWG5bqX5L+h5oGv5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcblxyXG4vL+WVhuW6l+i0reS5sOi3n+aWsFxyXG5XZUNoYXQuQnV5X0NoYXJhY3Rlcl9VcGRhdGU9ZnVuY3Rpb24gKF9VcGRhdGVfR29sZCxfVXBkYXRlX0NoYXJhY3Rlcikge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJTaG9wX0J1eVwiLFxyXG5cdFx0XHJcblx0XHRkYXRhOntcclxuXHRcdFx0VXBkYXRlX0dvbGQ6X1VwZGF0ZV9Hb2xkLFxyXG5cdFx0XHRVcGRhdGVfQ2hhcmFjdGVyOl9VcGRhdGVfQ2hhcmFjdGVyLFxyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0c3VjY2VzcyhyZXMpe1x0XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCLllYblupfojrflj5bmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLllYblupfojrflm57osIPlh7rplJlcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHR9XHJcblx0fSlcclxufVxyXG5cclxuV2VDaGF0LkxvYWRpbmdfQmlyZF9JbWFnZT1mdW5jdGlvbiAoQ2hhcmFjdGVyX0lkKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIkxvYWRpbmdfQmlyZF9JbWFnZVwiLFxyXG5cdFx0XHJcblx0XHRkYXRhOntcclxuXHRcdFx0Q2hhcmFjdGVyX0lkOkNoYXJhY3Rlcl9JZCxcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6KeS6Imy5Zu+5YOP6I635Y+W5oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdFx0XHJcblx0XHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0XHR1cmw6cmVzLnJlc3VsdC5DaGFyYWN0ZXJfSW1hZ2UxLFxyXG5cdFx0XHRcdHR5cGU6J2pwZydcclxuXHRcdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2UxPWZyYW1lO1xyXG5cdFx0XHR9KTtcclxuXHRcdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHRcdHVybDpyZXMucmVzdWx0LkNoYXJhY3Rlcl9JbWFnZTIsXHJcblx0XHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0XHR9LGZ1bmN0aW9uKGVycix0ZXh0dXJlLHRlc3Qpe1xyXG5cdFx0XHRcdHZhciBmcmFtZT1uZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XHJcblx0XHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi5Zu+54mH6ZSZ6K+vXCIsZXJyKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTI9ZnJhbWU7XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRjYy5sb2FkZXIubG9hZCh7XHJcblx0XHRcdFx0dXJsOnJlcy5yZXN1bHQuQ2hhcmFjdGVyX0ltYWdlMyxcclxuXHRcdFx0XHR0eXBlOidqcGcnXHJcblx0XHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XHJcblx0XHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0XHRpZihlcnIpe1xyXG5cdFx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlMz1mcmFtZTtcclxuXHRcdFx0fSk7XHJcblx0XHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0XHR1cmw6cmVzLnJlc3VsdC5DaGFyYWN0ZXJfSW1hZ2U0LFxyXG5cdFx0XHRcdHR5cGU6J2pwZydcclxuXHRcdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2U0PWZyYW1lO1xyXG5cdFx0XHR9KVxyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuinkuiJsuWbvuWDj+Wbnuiwg+WHuumUmVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5VcGRhdGluZ19DdXJyZW50X0NoYXJhY3Rlcl9pZD1mdW5jdGlvbiAoQ2hhcmFjdGVyX0lkKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIlVwZGF0aW5nX0N1cnJlbnRfQ2hhcmFjdGVyX2lkXCIsXHJcblx0XHRcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRDaGFyYWN0ZXJfSWQ6Q2hhcmFjdGVyX0lkLFxyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0c3VjY2VzcyhyZXMpe1x0XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkv67mlLnlvZPliY3op5LoibLmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19CaXJkX0ltYWdlKENoYXJhY3Rlcl9JZCk7XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5L+u5pS55b2T5YmN6KeS6Imy5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX0JpcmRfSW1hZ2UoQ2hhcmFjdGVyX0lkKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG4vL+WKoOi9veS4quS6uumCrueusVxyXG5XZUNoYXQuTG9hZGluZ19FbWFpbD1mdW5jdGlvbigpe1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJMb2FkaW5nX0VtYWlsXCIsXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsPXJlcy5yZXN1bHQuVXNlcl9FbWFpbF9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuiOt+WPlumCruS7tuS/oeaBr+aIkOWKn1wiLHJlcyk7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6YKu5Lu25L+h5oGv6KGoXCIsRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bpgq7ku7bkv6Hmga/lpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHR9XHJcblx0XHRcclxuXHR9KVxyXG59XHJcbi8v5Yqg6L295YWo6YOo6YKu566xXHJcbldlQ2hhdC5Mb2FkaW5nX0FsbF9FbWFpbD1mdW5jdGlvbigpe1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJMb2FkaW5nX0FsbF9FbWFpbFwiLFxyXG5cdFx0c3VjY2VzcyhyZXMpe1xyXG5cdFx0XHRFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbD1yZXMucmVzdWx0LlVzZXJfRW1haWxfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bpgq7ku7bkv6Hmga/miJDlip9cIixyZXMpO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIumCruS7tuS/oeaBr+ihqFwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W6YKu5Lu25L+h5oGv5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdFx0XHJcblx0fSlcclxufVxyXG4vL+W3suivu+WFqOmDqOmCruS7tlxyXG5XZUNoYXQuUmVhZF9BbGw9ZnVuY3Rpb24gKCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJSZWFkX0FsbFwiLFxyXG5cdFx0c3VjY2VzcyhyZXMpe1x0XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlt7Lor7vpgq7ku7bmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuW3suivu+mCruS7tuWksei0pVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/liKDpmaTlt7Lor7vpgq7ku7ZcclxuV2VDaGF0LkRlbGV0ZV9SZWFkPWZ1bmN0aW9uICgpIHtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiRGVsZXRlX1JlYWRcIixcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Yig6Zmk5bey6K+76YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLliKDpmaTlt7Lor7vpgq7ku7blpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcbi8v5bey6K+75Y2V5Liq6YKu5Lu2XHJcbldlQ2hhdC5SZWFkPWZ1bmN0aW9uKF9pZCl7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIlJlYWRcIixcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRfaWQ6X2lkLFxyXG5cdFx0fSxcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5bey6K+76YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlt7Lor7vpgq7ku7blpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcbi8v5o6l5Y+X5aWW5YqxXHJcbldlQ2hhdC5BY2NlcHQ9ZnVuY3Rpb24oX2lkLF9BZGRfR29sZCxfQWRkX0RpYW1vbmQsX0FkZF9Db21wYXNzaW9uKXtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiQWNjZXB0XCIsXHJcblx0XHRkYXRhOntcclxuXHRcdFx0X2lkOl9pZCxcclxuXHRcdFx0QWRkX0dvbGQ6X0FkZF9Hb2xkLFxyXG5cdFx0XHRBZGRfRGlhbW9uZDpfQWRkX0RpYW1vbmQsXHJcblx0XHRcdEFkZF9Db21wYXNzaW9uOl9BZGRfQ29tcGFzc2lvbixcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHRcdFxyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuaOpeWPl+WlluWKseaIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Hb2xkID0gcmVzLnJlc3VsdC5Hb2xkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuRGlhbW9uZCA9IHJlcy5yZXN1bHQuRGlhbW9uZDtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb24gPSByZXMucmVzdWx0LkNvbXBhc3Npb247XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5Z+656GA54mp6LWE5Ye66ZSZXCIsIGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19SZXNvdXJjZXMoKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcbi8v5Y+R5pS+5aWW5YqxXHJcbldlQ2hhdC5Bd2FyZHNfRW1haWw9ZnVuY3Rpb24oVGltZSxUaXRsZSxDb250ZW50LEdvbGQsRGlhbW9uZCxDb21wYXNzaW9uLEVuY2xvc3VyZSl7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIkF3YXJkc1wiLFxyXG5cdFx0ZGF0YTp7XHJcblx0XHRcdFRpbWU6VGltZSxcclxuXHRcdFx0RW1haWxfVGl0bGU6VGl0bGUsXHJcblx0XHRcdEVtYWlsX0NvbnRlbnQ6Q29udGVudCxcclxuXHRcdFx0RW1haWxfR29sZDpHb2xkLFxyXG5cdFx0XHRFbWFpbF9EaWFtb25kOkRpYW1vbmQsXHJcblx0XHRcdEVtYWlsX0NvbXBhc3Npb246Q29tcGFzc2lvbixcclxuXHRcdFx0RW5jbG9zdXJlOkVuY2xvc3VyZSxcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHRcdFxyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuWPkeaUvuWlluWKseaIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Y+R5pS+5aWW5Yqx5aSx6LSlXCIsIGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5Mb2FkaW5nX0FsbF9Vc2VyPWZ1bmN0aW9uICgpIHtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiTG9hZGluZ19BbGxfVXNlclwiLFxyXG5cdFx0XHJcblx0XHRzdWNjZXNzKHJlcyl7XHRcdFxyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4i+i9veWFqOmDqOi0puWPt+S/oeaBr+aIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHRcdEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5BbGxfVXNlcnNfSW5mb3JtYXRpb249cmVzLnJlc3VsdC5BbGxfVXNlcnNfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLmn6XnnIvlhajpg6jotKblj7dcIixBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuQWxsX1VzZXJzX0luZm9ybWF0aW9uKTtcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkuIvovb3lhajpg6jotKblj7fkv6Hmga/lpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfQWxsX1VzZXIoKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuTG9hZGluZ19SZXBvcnRfVXNlcj1mdW5jdGlvbiAoX29wZW5pZCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJMb2FkaW5nX1JlcG9ydF9Vc2VyXCIsXHJcblx0XHRcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRvcGVuaWQ6X29wZW5pZCxcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5LiL6L295Li+5oql5Lq65L+h5oGv5oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3Q9cmVzLnJlc3VsdC5SZXBvcnRfVXNlcl9MaXN0LmRhdGE7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5p+l55yL5omA5pyJ5Li+5oql5Lq65L+h5oGvXCIsQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3QpO1xyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4i+i9veaJgOacieS4vuaKpeS6uuS/oeaBr+Wksei0pVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19SZXBvcnRfVXNlcihfb3BlbmlkKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuTG9hZGluZ19SZXBvcnRlcmRfVXNlcj1mdW5jdGlvbiAoKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIkxvYWRpbmdfQWxsX1JlcG9ydGVkX1VzZXJzXCIsXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5LiL6L296KKr5Li+5oql5Lq65L+h5oGv5oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uPXJlcy5yZXN1bHQuUmVwb3J0ZWRfSW5mb3JtYXRpb24ubGlzdDtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLmn6XnnIvooqvkuL7miqXkurrkv6Hmga9cIixBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb24pO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkuIvovb3miYDmnInooqvkuL7miqXkurrkv6Hmga/lpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVwb3J0ZXJkX1VzZXIoKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuRW1haWxfUmVwb3J0X0FuZF9BcHBlYWw9ZnVuY3Rpb24gKFRpbWUsVGl0bGUsQ29udGVudCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJFbWFpbF9SZXBvcnRcIixcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRUaW1lOlRpbWUsXHJcblx0XHRcdEVtYWlsX1RpdGxlOlRpdGxlLFxyXG5cdFx0XHRFbWFpbF9Db250ZW50OkNvbnRlbnRcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Li+5oql6YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Li+5oql6YKu5Lu25Y+R6YCB5aSx6LSlXCIsY29uc29sZS5lcnJvcik7O1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5FbWFpbF9XYXJuaW5nPWZ1bmN0aW9uIChUaW1lLFRpdGxlLENvbnRlbnQsb3Blbl9pZCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJFbWFpbF9XYXJuaW5nXCIsXHJcblx0XHRkYXRhOntcclxuXHRcdFx0VGltZTpUaW1lLFxyXG5cdFx0XHRFbWFpbF9UaXRsZTpUaXRsZSxcclxuXHRcdFx0RW1haWxfQ29udGVudDpDb250ZW50LFxyXG5cdFx0XHRvcGVuX2lkOm9wZW5faWRcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6K2m5ZGK6YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6K2m5ZGK6YKu5Lu25Y+R6YCB5aSx6LSlXCIsY29uc29sZS5lcnJvcik7O1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5IYW5kbGVfUmVwb3J0ZWRfVXNlcj1mdW5jdGlvbihfb3BlbmlkKXtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiSGFuZGxlX1JlcG9ydGVkX1VzZXJcIixcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRvcGVuaWQ6X29wZW5pZFxyXG5cdFx0fSxcclxuXHRcdHN1Y2Nlc3MocmVzKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlpITnkIbooqvkuL7miqXkurrmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlpITnkIbooqvkuL7miqXkurrlpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuQ2xvc3VyZV9BY2NvdW50ID0gZnVuY3Rpb24oT3BlbmlkLElucHV0KXtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiQ2xvc3VyZV9BY2NvdW50XCIsXHJcblx0XHRkYXRhOntcclxuXHRcdFx0UmVwb3J0ZWRfT3BlbmlkOk9wZW5pZCxcclxuXHRcdFx0Q2xvc3VyZV9UaW1lOklucHV0LFxyXG5cdFx0fSxcclxuXHRcdHN1Y2Nlc3MocmVzKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlsIHlgZzotKblj7fmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlsIHlgZzotKblj7flpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuQ2FuY2VsX0Nsb3N1cmUgPSBmdW5jdGlvbihPcGVuaWQpe1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJDYW5jZWxfQ2xvc3VyZVwiLFxyXG5cdFx0ZGF0YTp7XHJcblx0XHRcdFJlcG9ydGVkX09wZW5pZDpPcGVuaWQsXHJcblx0XHR9LFxyXG5cdFx0c3VjY2VzcyhyZXMpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuino+mZpOWwgeWBnOi0puWPt+aIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHR9LFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuino+mZpOWwgeWBnOi0puWPt+Wksei0pVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn0iXX0=