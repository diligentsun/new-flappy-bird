
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Role/Have_Character_Information.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4ab376ZptJEGo98hDU3KGrZ', 'Have_Character_Information');
// resources/script/Role/Have_Character_Information.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Buy_Character_Background: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    var self = this;
    var This_Name = this.Character_Name.getComponent(cc.Label).string;
    WeChat.Loading_Shop_Character();

    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var List_Name = Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;

      if (This_Name === List_Name) {
        //当前点击的角色
        var This_information = Shop_Character_Local_Varible.Shop_Character_User[i];
        var New_Buy_Character_Background = cc.instantiate(this.Buy_Character_Background);
        this.Canvas.parent.parent.parent.addChild(New_Buy_Character_Background);
        New_Buy_Character_Background.setPosition(0, -210);
        console.log("图片地址为", This_information);
        this.Loading_Image(New_Buy_Character_Background, This_information.Character_Head_Image);
        New_Buy_Character_Background.getChildByName("Character_Name").getComponent(cc.Label).string = "" + This_information.Character_Name;
        New_Buy_Character_Background.getChildByName("Character_Synopsis").getComponent(cc.Label).string = "" + This_information.Character_Synopsis;
        New_Buy_Character_Background.getChildByName("Bounce_Power_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Jump_Speed;
        New_Buy_Character_Background.getChildByName("Weight_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fall_Speed;
        New_Buy_Character_Background.getChildByName("Speed_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fly_Speed;
        New_Buy_Character_Background.getChildByName("Skill_Name_Label").getComponent(cc.Label).string = "" + This_information.Skill_Name;
        New_Buy_Character_Background.getChildByName("Skill_Effect_Label").getComponent(cc.Label).string = "" + This_information.Skill_Synopsis;
        New_Buy_Character_Background.getChildByName("Character_Id").getComponent(cc.Label).string = "" + This_information.Character_Id;
        New_Buy_Character_Background.getChildByName("Background1").getComponent(cc.Sprite).fillRange = This_information.Character_Jump_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background2").getComponent(cc.Sprite).fillRange = This_information.Character_Fall_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background3").getComponent(cc.Sprite).fillRange = This_information.Character_Fly_Speed / 100;
        break;
      }
    }
  },
  update: function update(dt) {},
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Character_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJvbGVcXEhhdmVfQ2hhcmFjdGVyX0luZm9ybWF0aW9uLmpzIl0sIm5hbWVzIjpbIlNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJCdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQiLCJ0eXBlIiwiUHJlZmFiIiwic2VyaWFsemFibGUiLCJDaGFyYWN0ZXJfTmFtZSIsIkxhYmVsIiwiQ2FudmFzIiwiTm9kZSIsIm9uX2J0bl9jbGljayIsInNlbGYiLCJUaGlzX05hbWUiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJXZUNoYXQiLCJMb2FkaW5nX1Nob3BfQ2hhcmFjdGVyIiwiaSIsIlNob3BfQ2hhcmFjdGVyX1VzZXIiLCJsZW5ndGgiLCJMaXN0X05hbWUiLCJUaGlzX2luZm9ybWF0aW9uIiwiTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZCIsImluc3RhbnRpYXRlIiwicGFyZW50IiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiIsImNvbnNvbGUiLCJsb2ciLCJMb2FkaW5nX0ltYWdlIiwiQ2hhcmFjdGVyX0hlYWRfSW1hZ2UiLCJnZXRDaGlsZEJ5TmFtZSIsIkNoYXJhY3Rlcl9TeW5vcHNpcyIsIkNoYXJhY3Rlcl9KdW1wX1NwZWVkIiwiQ2hhcmFjdGVyX0ZhbGxfU3BlZWQiLCJDaGFyYWN0ZXJfRmx5X1NwZWVkIiwiU2tpbGxfTmFtZSIsIlNraWxsX1N5bm9wc2lzIiwiQ2hhcmFjdGVyX0lkIiwiU3ByaXRlIiwiZmlsbFJhbmdlIiwidXBkYXRlIiwiZHQiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJzcHJpdGVGcmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJQSw0QkFBNEIsR0FBR0MsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsd0JBQXdCLEVBQUM7QUFDckIsaUJBQVEsSUFEYTtBQUU5QkMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRnNCO0FBRzlCQyxNQUFBQSxXQUFXLEVBQUM7QUFIa0IsS0FEakI7QUFNUkMsSUFBQUEsY0FBYyxFQUFDO0FBQ1gsaUJBQVEsSUFERztBQUVwQkgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRlk7QUFHcEJGLE1BQUFBLFdBQVcsRUFBQztBQUhRLEtBTlA7QUFXUkcsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csSUFGTDtBQUdaSixNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQVhDLEdBSFA7QUFxQkw7QUFFQUssRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3JCLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsU0FBUyxHQUFDLEtBQUtOLGNBQUwsQ0FBb0JPLFlBQXBCLENBQWlDZixFQUFFLENBQUNTLEtBQXBDLEVBQTJDTyxNQUF6RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLHNCQUFQOztBQUdBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDckIsNEJBQTRCLENBQUNzQixtQkFBN0IsQ0FBaURDLE1BQS9ELEVBQXNFRixDQUFDLEVBQXZFLEVBQTBFO0FBQ3RFLFVBQUlHLFNBQVMsR0FBQ3hCLDRCQUE0QixDQUFDc0IsbUJBQTdCLENBQWlERCxDQUFqRCxFQUFvRFgsY0FBbEU7O0FBRUEsVUFBR00sU0FBUyxLQUFHUSxTQUFmLEVBQXlCO0FBQ3JCO0FBQ0EsWUFBSUMsZ0JBQWdCLEdBQUN6Qiw0QkFBNEIsQ0FBQ3NCLG1CQUE3QixDQUFpREQsQ0FBakQsQ0FBckI7QUFFQSxZQUFJSyw0QkFBNEIsR0FBR3hCLEVBQUUsQ0FBQ3lCLFdBQUgsQ0FBZSxLQUFLckIsd0JBQXBCLENBQW5DO0FBQ0EsYUFBS00sTUFBTCxDQUFZZ0IsTUFBWixDQUFtQkEsTUFBbkIsQ0FBMEJBLE1BQTFCLENBQWlDQyxRQUFqQyxDQUEwQ0gsNEJBQTFDO0FBQ0FBLFFBQUFBLDRCQUE0QixDQUFDSSxXQUE3QixDQUF5QyxDQUF6QyxFQUEyQyxDQUFDLEdBQTVDO0FBQ0FDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBb0JQLGdCQUFwQjtBQUVBLGFBQUtRLGFBQUwsQ0FBbUJQLDRCQUFuQixFQUFnREQsZ0JBQWdCLENBQUNTLG9CQUFqRTtBQUNBUixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsZ0JBQTVDLEVBQThEbEIsWUFBOUQsQ0FBMkVmLEVBQUUsQ0FBQ1MsS0FBOUUsRUFBcUZPLE1BQXJGLEdBQTRGLEtBQUdPLGdCQUFnQixDQUFDZixjQUFoSDtBQUNBZ0IsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ1csa0JBQXBIO0FBQ0FWLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QywyQkFBNUMsRUFBeUVsQixZQUF6RSxDQUFzRmYsRUFBRSxDQUFDUyxLQUF6RixFQUFnR08sTUFBaEcsR0FBdUcsS0FBR08sZ0JBQWdCLENBQUNZLG9CQUEzSDtBQUNBWCxRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMscUJBQTVDLEVBQW1FbEIsWUFBbkUsQ0FBZ0ZmLEVBQUUsQ0FBQ1MsS0FBbkYsRUFBMEZPLE1BQTFGLEdBQWlHLEtBQUdPLGdCQUFnQixDQUFDYSxvQkFBckg7QUFDQVosUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ2MsbUJBQXBIO0FBQ0FiLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxrQkFBNUMsRUFBZ0VsQixZQUFoRSxDQUE2RWYsRUFBRSxDQUFDUyxLQUFoRixFQUF1Rk8sTUFBdkYsR0FBOEYsS0FBR08sZ0JBQWdCLENBQUNlLFVBQWxIO0FBQ0FkLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxvQkFBNUMsRUFBa0VsQixZQUFsRSxDQUErRWYsRUFBRSxDQUFDUyxLQUFsRixFQUF5Rk8sTUFBekYsR0FBZ0csS0FBR08sZ0JBQWdCLENBQUNnQixjQUFwSDtBQUNBZixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsY0FBNUMsRUFBNERsQixZQUE1RCxDQUF5RWYsRUFBRSxDQUFDUyxLQUE1RSxFQUFtRk8sTUFBbkYsR0FBMEYsS0FBR08sZ0JBQWdCLENBQUNpQixZQUE5RztBQUNBaEIsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGFBQTVDLEVBQTJEbEIsWUFBM0QsQ0FBd0VmLEVBQUUsQ0FBQ3lDLE1BQTNFLEVBQW1GQyxTQUFuRixHQUE2Rm5CLGdCQUFnQixDQUFDWSxvQkFBakIsR0FBc0MsR0FBbkk7QUFDQVgsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGFBQTVDLEVBQTJEbEIsWUFBM0QsQ0FBd0VmLEVBQUUsQ0FBQ3lDLE1BQTNFLEVBQW1GQyxTQUFuRixHQUE2Rm5CLGdCQUFnQixDQUFDYSxvQkFBakIsR0FBc0MsR0FBbkk7QUFDQVosUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGFBQTVDLEVBQTJEbEIsWUFBM0QsQ0FBd0VmLEVBQUUsQ0FBQ3lDLE1BQTNFLEVBQW1GQyxTQUFuRixHQUE2Rm5CLGdCQUFnQixDQUFDYyxtQkFBakIsR0FBcUMsR0FBbEk7QUFDQTtBQUNIO0FBQ0o7QUFDSixHQXhESTtBQXlETE0sRUFBQUEsTUF6REssa0JBeURHQyxFQXpESCxFQXlETyxDQUFFLENBekRUO0FBMEROYixFQUFBQSxhQTFETSx5QkEwRFFsQixJQTFEUixFQTBEYWdDLFVBMURiLEVBMER3QjtBQUMvQixRQUFJQyxJQUFJLEdBQUNELFVBQVQ7QUFDQTdDLElBQUFBLEVBQUUsQ0FBQytDLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBQ0gsSUFEVTtBQUVkekMsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVM2QyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJckQsRUFBRSxDQUFDc0QsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTnJCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJvQixHQUFuQjtBQUNBOztBQUNEckMsTUFBQUEsSUFBSSxDQUFDb0IsY0FBTCxDQUFvQixpQkFBcEIsRUFBdUNsQixZQUF2QyxDQUFvRGYsRUFBRSxDQUFDeUMsTUFBdkQsRUFBK0RjLFdBQS9ELEdBQTJFRixLQUEzRTtBQUVBLEtBVkQ7QUFXRDtBQXZFUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDaGFyYWN0ZXJfTmFtZTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgVGhpc19OYW1lPXRoaXMuQ2hhcmFjdGVyX05hbWUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIoKTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXIubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBMaXN0X05hbWU9U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2ldLkNoYXJhY3Rlcl9OYW1lO1xyXG5cclxuICAgICAgICAgICAgaWYoVGhpc19OYW1lPT09TGlzdF9OYW1lKXtcclxuICAgICAgICAgICAgICAgIC8v5b2T5YmN54K55Ye755qE6KeS6ImyXHJcbiAgICAgICAgICAgICAgICB2YXIgVGhpc19pbmZvcm1hdGlvbj1TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXJbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkJ1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LnBhcmVudC5hZGRDaGlsZChOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kKTtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuc2V0UG9zaXRpb24oMCwtMjEwKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Zu+54mH5Zyw5Z2A5Li6XCIsVGhpc19pbmZvcm1hdGlvbik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQsVGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSGVhZF9JbWFnZSk7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9TeW5vcHNpc1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX1N5bm9wc2lzO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJvdW5jZV9Qb3dlcl9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9KdW1wX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIldlaWdodF9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GYWxsX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNwZWVkX051bWJlcl9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0ZseV9TcGVlZDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJTa2lsbF9OYW1lX0xhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGhpc19pbmZvcm1hdGlvbi5Ta2lsbF9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNraWxsX0VmZmVjdF9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uU2tpbGxfU3lub3BzaXM7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX0lkXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSWQ7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZDFcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuZmlsbFJhbmdlPVRoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0p1bXBfU3BlZWQvMTAwO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmQyXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLmZpbGxSYW5nZT1UaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GYWxsX1NwZWVkLzEwMDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJCYWNrZ3JvdW5kM1wiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5maWxsUmFuZ2U9VGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfRmx5X1NwZWVkLzEwMDtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHVwZGF0ZSAoZHQpIHt9LFxyXG4gIFx0TG9hZGluZ19JbWFnZShzZWxmLEltYWdlX1BhdGgpe1xyXG5cdFx0bGV0IF91cmw9SW1hZ2VfUGF0aDtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0dXJsOl91cmwsXHJcblx0XHRcdHR5cGU6J2pwZydcclxuXHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XHJcblx0XHRcdHZhciBmcmFtZT1uZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XHJcblx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdHNlbGYuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfSW1hZ2VcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9ZnJhbWU7XHJcblx0XHRcdFxyXG5cdFx0fSlcclxufVxyXG5cclxufSk7XHJcbiJdfQ==