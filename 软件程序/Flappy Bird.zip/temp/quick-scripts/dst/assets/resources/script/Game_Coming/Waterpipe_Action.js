
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Waterpipe_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '85c4fRDZ2lP6YFLrKdOCnzk', 'Waterpipe_Action');
// resources/script/Game_Coming/Waterpipe_Action.js

"use strict";

//水管移动逻辑
var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Move_Speed: 0,
    //水平移动速度
    x: 0,
    //x坐标
    y: 0,
    //y坐标
    Move_Distance: 0,
    //移动的距离
    Is_Move: false,
    //是否垂直移动
    Is_Up: true //是否向上移动 ，如果为否，就会向下移动

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager(); //改变碰撞体积

    manager.enabled = true; //manager.enabledDebugDraw = true;

    this.Is_Move = Game_Difficulty_Local_Varible.Is_Difficulty; //如果游戏难度为最难，则则不能上下移动

    if (Math.random() > 0.5) {
      this.Is_Up = false; //决定上下移动还是左右移动
    }
  },
  start: function start() {},
  update: function update(dt) {
    this.node.x -= 5 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 2; //水平移动水管

    if (this.node.x < -600) {
      //如果水管已出屏幕，分数加一，毁灭掉水管
      Game_Local_Varible.Fraction += 1;
      this.node.destroy();
    }

    if (this.Is_Move == true && this.node.x < 0) {
      //如果水管能够上下移动，添加水管的上下移动距离
      this.Move_Distance = 50;
      this.Is_Move = false;
    }

    if (this.Move_Distance > 0 && this.Is_Up == true) {
      //使水管上下移动
      this.node.y += 5;
      this.Move_Distance -= 5;
    } else if (this.Move_Distance > 0 && this.Is_Up == false) {
      this.node.y -= 5;
      this.Move_Distance -= 5;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxXYXRlcnBpcGVfQWN0aW9uLmpzIl0sIm5hbWVzIjpbIkdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsIkdhbWVfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiTW92ZV9TcGVlZCIsIngiLCJ5IiwiTW92ZV9EaXN0YW5jZSIsIklzX01vdmUiLCJJc19VcCIsIm9uTG9hZCIsIm1hbmFnZXIiLCJkaXJlY3RvciIsImdldENvbGxpc2lvbk1hbmFnZXIiLCJlbmFibGVkIiwiSXNfRGlmZmljdWx0eSIsIk1hdGgiLCJyYW5kb20iLCJzdGFydCIsInVwZGF0ZSIsImR0Iiwibm9kZSIsIkRpZmZpY3VsdHlfUmF0aW8iLCJGcmFjdGlvbiIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSw2QkFBNkIsR0FBR0MsT0FBTyxDQUFDLCtCQUFELENBQTNDOztBQUNBLElBQUlDLGtCQUFrQixHQUFHRCxPQUFPLENBQUMsb0JBQUQsQ0FBaEM7O0FBRUFFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxVQUFVLEVBQUUsQ0FERDtBQUNJO0FBQ2ZDLElBQUFBLENBQUMsRUFBRSxDQUZRO0FBRUw7QUFDTkMsSUFBQUEsQ0FBQyxFQUFFLENBSFE7QUFHTDtBQUNOQyxJQUFBQSxhQUFhLEVBQUUsQ0FKSjtBQUlPO0FBQ2xCQyxJQUFBQSxPQUFPLEVBQUUsS0FMRTtBQUtLO0FBQ2hCQyxJQUFBQSxLQUFLLEVBQUUsSUFOSSxDQU1FOztBQU5GLEdBSEo7QUFZUjtBQUNBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEIsUUFBSUMsT0FBTyxHQUFHWCxFQUFFLENBQUNZLFFBQUgsQ0FBWUMsbUJBQVosRUFBZCxDQURrQixDQUMrQjs7QUFDakRGLElBQUFBLE9BQU8sQ0FBQ0csT0FBUixHQUFrQixJQUFsQixDQUZrQixDQUdsQjs7QUFDQSxTQUFLTixPQUFMLEdBQWVYLDZCQUE2QixDQUFDa0IsYUFBN0MsQ0FKa0IsQ0FJMEM7O0FBQzVELFFBQUlDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFwQixFQUF5QjtBQUN4QixXQUFLUixLQUFMLEdBQWEsS0FBYixDQUR3QixDQUNKO0FBQ3BCO0FBQ0QsR0FyQk87QUF3QlJTLEVBQUFBLEtBQUssRUFBRSxpQkFBVyxDQUFFLENBeEJaO0FBeUJSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQixTQUFLQyxJQUFMLENBQVVoQixDQUFWLElBQWdCLElBQUlSLDZCQUE2QixDQUFDeUIsZ0JBQTlCLEdBQWlELENBQXJFLENBRG9CLENBQ3FEOztBQUN6RSxRQUFJLEtBQUtELElBQUwsQ0FBVWhCLENBQVYsR0FBYyxDQUFDLEdBQW5CLEVBQXdCO0FBQUU7QUFDekJOLE1BQUFBLGtCQUFrQixDQUFDd0IsUUFBbkIsSUFBK0IsQ0FBL0I7QUFDQSxXQUFLRixJQUFMLENBQVVHLE9BQVY7QUFDQTs7QUFDRCxRQUFJLEtBQUtoQixPQUFMLElBQWdCLElBQWhCLElBQXdCLEtBQUthLElBQUwsQ0FBVWhCLENBQVYsR0FBYyxDQUExQyxFQUE2QztBQUFFO0FBQzlDLFdBQUtFLGFBQUwsR0FBcUIsRUFBckI7QUFDQSxXQUFLQyxPQUFMLEdBQWUsS0FBZjtBQUNBOztBQUNELFFBQUksS0FBS0QsYUFBTCxHQUFxQixDQUFyQixJQUEwQixLQUFLRSxLQUFMLElBQWMsSUFBNUMsRUFBa0Q7QUFBRTtBQUNuRCxXQUFLWSxJQUFMLENBQVVmLENBQVYsSUFBZSxDQUFmO0FBQ0EsV0FBS0MsYUFBTCxJQUFzQixDQUF0QjtBQUNBLEtBSEQsTUFHTyxJQUFJLEtBQUtBLGFBQUwsR0FBcUIsQ0FBckIsSUFBMEIsS0FBS0UsS0FBTCxJQUFjLEtBQTVDLEVBQW1EO0FBQ3pELFdBQUtZLElBQUwsQ0FBVWYsQ0FBVixJQUFlLENBQWY7QUFDQSxXQUFLQyxhQUFMLElBQXNCLENBQXRCO0FBQ0E7QUFDRDtBQTFDTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+awtOeuoeenu+WKqOmAu+i+kVxyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnR2FtZV9Mb2NhbF9WYXJpYmxlJyk7XHJcblxyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRNb3ZlX1NwZWVkOiAwLCAvL+awtOW5s+enu+WKqOmAn+W6plxyXG5cdFx0eDogMCwgLy945Z2Q5qCHXHJcblx0XHR5OiAwLCAvL3nlnZDmoIdcclxuXHRcdE1vdmVfRGlzdGFuY2U6IDAsIC8v56e75Yqo55qE6Led56a7XHJcblx0XHRJc19Nb3ZlOiBmYWxzZSwgLy/mmK/lkKblnoLnm7Tnp7vliqhcclxuXHRcdElzX1VwOiB0cnVlLCAvL+aYr+WQpuWQkeS4iuenu+WKqCDvvIzlpoLmnpzkuLrlkKbvvIzlsLHkvJrlkJHkuIvnp7vliqhcclxuXHR9LFxyXG5cclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIG1hbmFnZXIgPSBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCk7IC8v5pS55Y+Y56Kw5pKe5L2T56evXHJcblx0XHRtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0Ly9tYW5hZ2VyLmVuYWJsZWREZWJ1Z0RyYXcgPSB0cnVlO1xyXG5cdFx0dGhpcy5Jc19Nb3ZlID0gR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuSXNfRGlmZmljdWx0eTsgLy/lpoLmnpzmuLjmiI/pmr7luqbkuLrmnIDpmr7vvIzliJnliJnkuI3og73kuIrkuIvnp7vliqhcclxuXHRcdGlmIChNYXRoLnJhbmRvbSgpID4gMC41KSB7XHJcblx0XHRcdHRoaXMuSXNfVXAgPSBmYWxzZTsgLy/lhrPlrprkuIrkuIvnp7vliqjov5jmmK/lt6blj7Pnp7vliqhcclxuXHRcdH1cclxuXHR9LFxyXG5cclxuXHJcblx0c3RhcnQ6IGZ1bmN0aW9uKCkge30sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0dGhpcy5ub2RlLnggLT0gKDUgKyBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICogMik7IC8v5rC05bmz56e75Yqo5rC0566hXHJcblx0XHRpZiAodGhpcy5ub2RlLnggPCAtNjAwKSB7IC8v5aaC5p6c5rC0566h5bey5Ye65bGP5bmV77yM5YiG5pWw5Yqg5LiA77yM5q+B54Gt5o6J5rC0566hXHJcblx0XHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiArPSAxO1xyXG5cdFx0XHR0aGlzLm5vZGUuZGVzdHJveSgpO1xyXG5cdFx0fVxyXG5cdFx0aWYgKHRoaXMuSXNfTW92ZSA9PSB0cnVlICYmIHRoaXMubm9kZS54IDwgMCkgeyAvL+WmguaenOawtOeuoeiDveWkn+S4iuS4i+enu+WKqO+8jOa3u+WKoOawtOeuoeeahOS4iuS4i+enu+WKqOi3neemu1xyXG5cdFx0XHR0aGlzLk1vdmVfRGlzdGFuY2UgPSA1MDtcclxuXHRcdFx0dGhpcy5Jc19Nb3ZlID0gZmFsc2U7XHJcblx0XHR9XHJcblx0XHRpZiAodGhpcy5Nb3ZlX0Rpc3RhbmNlID4gMCAmJiB0aGlzLklzX1VwID09IHRydWUpIHsgLy/kvb/msLTnrqHkuIrkuIvnp7vliqhcclxuXHRcdFx0dGhpcy5ub2RlLnkgKz0gNTtcclxuXHRcdFx0dGhpcy5Nb3ZlX0Rpc3RhbmNlIC09IDU7XHJcblx0XHR9IGVsc2UgaWYgKHRoaXMuTW92ZV9EaXN0YW5jZSA+IDAgJiYgdGhpcy5Jc19VcCA9PSBmYWxzZSkge1xyXG5cdFx0XHR0aGlzLm5vZGUueSAtPSA1O1xyXG5cdFx0XHR0aGlzLk1vdmVfRGlzdGFuY2UgLT0gNTtcclxuXHRcdH1cclxuXHR9LFxyXG59KTtcbiJdfQ==