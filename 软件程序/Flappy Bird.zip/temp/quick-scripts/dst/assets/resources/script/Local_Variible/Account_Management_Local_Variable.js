
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Account_Management_Local_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fcaa05Eja5EDING8XS/HnT8', 'Account_Management_Local_Variable');
// resources/script/Local_Variible/Account_Management_Local_Variable.js

"use strict";

//游戏难度系数的局部变量
module.exports = {
  //全部玩家角色表
  All_Users_Information: null,
  Report_User_List: null,
  Reported_Users_Information: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIkFsbF9Vc2Vyc19JbmZvcm1hdGlvbiIsIlJlcG9ydF9Vc2VyX0xpc3QiLCJSZXBvcnRlZF9Vc2Vyc19JbmZvcm1hdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDaEI7QUFDQUMsRUFBQUEscUJBQXFCLEVBQUUsSUFGUDtBQUdoQkMsRUFBQUEsZ0JBQWdCLEVBQUMsSUFIRDtBQUloQkMsRUFBQUEsMEJBQTBCLEVBQUM7QUFKWCxDQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/muLjmiI/pmr7luqbns7vmlbDnmoTlsYDpg6jlj5jph49cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcblx0Ly/lhajpg6jnjqnlrrbop5LoibLooahcclxuXHRBbGxfVXNlcnNfSW5mb3JtYXRpb246IG51bGwsXHJcblx0UmVwb3J0X1VzZXJfTGlzdDpudWxsLFxyXG5cdFJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uOm51bGwsXHJcblxyXG5cdFxyXG59O1xyXG4iXX0=