
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Gold_Show_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8b8b2T/IZ1FAabnNpC4GbPK', 'Gold_Show_Action');
// resources/script/Game_Coming/Gold_Show_Action.js

"use strict";

//金币显示框运动逻辑
var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Gold_Show: {
      //金币显示框
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    console.log("Game_Local_Varible.Gold=" + Game_Local_Varible.Gold);
    this.Gold_Show.string = Game_Local_Varible.Gold; //改变金币显示数
  },
  start: function start() {},
  update: function update(dt) {
    this.Gold_Show.string = Game_Local_Varible.Gold; //改变金币显示数
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxHb2xkX1Nob3dfQWN0aW9uLmpzIl0sIm5hbWVzIjpbIkdhbWVfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkdvbGRfU2hvdyIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwib25Mb2FkIiwiY29uc29sZSIsImxvZyIsIkdvbGQiLCJzdHJpbmciLCJzdGFydCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxvQkFBRCxDQUFoQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ2RDLElBQUFBLFNBQVMsRUFBQztBQUFHO0FBQ1osaUJBQVEsSUFEQztBQUVUQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sS0FGQztBQUdUQyxNQUFBQSxXQUFXLEVBQUM7QUFISDtBQURJLEdBSFA7QUFZTDtBQUVBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDckJDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDZCQUEyQlosa0JBQWtCLENBQUNhLElBQTFEO0FBQ0EsU0FBS1AsU0FBTCxDQUFlUSxNQUFmLEdBQXlCZCxrQkFBa0IsQ0FBQ2EsSUFBNUMsQ0FGcUIsQ0FFK0I7QUFDcEQsR0FqQk87QUFtQkxFLEVBQUFBLEtBbkJLLG1CQW1CSSxDQUNSLENBcEJJO0FBc0JMQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUN2QixTQUFLWCxTQUFMLENBQWVRLE1BQWYsR0FBeUJkLGtCQUFrQixDQUFDYSxJQUE1QyxDQUR1QixDQUMyQjtBQUNsRDtBQXhCTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+mHkeW4geaYvuekuuahhui/kOWKqOmAu+i+kVxyXG52YXIgR2FtZV9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnR2FtZV9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblx0XHRHb2xkX1Nob3c6eyAgLy/ph5HluIHmmL7npLrmoYZcclxuXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbigpIHsgIFxyXG5cdFx0Y29uc29sZS5sb2coXCJHYW1lX0xvY2FsX1ZhcmlibGUuR29sZD1cIitHYW1lX0xvY2FsX1ZhcmlibGUuR29sZClcclxuXHRcdHRoaXMuR29sZF9TaG93LnN0cmluZyA9IChHYW1lX0xvY2FsX1ZhcmlibGUuR29sZCk7ICAvL+aUueWPmOmHkeW4geaYvuekuuaVsFxyXG5cdH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblx0XHR0aGlzLkdvbGRfU2hvdy5zdHJpbmcgPSAoR2FtZV9Mb2NhbF9WYXJpYmxlLkdvbGQpOy8v5pS55Y+Y6YeR5biB5pi+56S65pWwXHJcblx0fSxcclxufSk7XHJcbiJdfQ==