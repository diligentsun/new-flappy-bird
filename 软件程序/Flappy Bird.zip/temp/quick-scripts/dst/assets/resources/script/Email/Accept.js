
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Accept.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'be864f5ltdAVaIxUzh5vevO', 'Accept');
// resources/script/Email/Accept.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Accept_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //成功接受提示信息
    Already_Accepted_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已接受过提示信息
    No_Awards_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //没有奖励提示信息
    Email_Title: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //邮件标题
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  Accept: function Accept() {
    var self = this;
    var This_Title = this.Email_Title.getComponent(cc.Label).string;
    WeChat.Loading_Email();

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var Title = Email_Local_Variable.Email[i].Email_Title;

      if (This_Title === Title) {
        //当前点击的邮件
        console.log("当前邮件内容为2：", Email_Local_Variable.Email[i]);

        if (Email_Local_Variable.Email[i].Enclosure === false) {
          var Tip = cc.instantiate(this.No_Awards_Box);
          this.Canvas.addChild(Tip); //设置提示框位置

          Tip.setPosition(0, 0);
        } //是否已经接受过奖励
        else {
            if (Email_Local_Variable.Email[i].Accept === false) {
              //未曾接受奖励
              console.log("接受奖励");
              var Tip = cc.instantiate(this.Accept_Box);
              this.Canvas.addChild(Tip); //设置提示框位置

              Tip.setPosition(0, 0); //奖励参数设置

              var id = Email_Local_Variable.Email[i]._id;
              var Gold = Number(Email_Local_Variable.Email[i].Email_Gold);
              var Diamond = Number(Email_Local_Variable.Email[i].Email_Diamond);
              var Compassion = Number(Email_Local_Variable.Email[i].Email_Compassion); //接受奖励

              console.log("已经接受奖励", "金币：", Gold, "钻石：", Diamond, "体力：", Compassion);
              WeChat.Accept(id, Gold, Diamond, Compassion);
            } //已接受过奖励
            else {
                //弹出提示框
                var Tip = cc.instantiate(this.Already_Accepted_Box);
                this.Canvas.addChild(Tip); //设置提示框位置

                Tip.setPosition(0, 0);
              }
          }

        break;
      }
    }
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxBY2NlcHQuanMiXSwibmFtZXMiOlsiRW1haWxfTG9jYWxfVmFyaWFibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJBY2NlcHRfQm94IiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQWxyZWFkeV9BY2NlcHRlZF9Cb3giLCJOb19Bd2FyZHNfQm94IiwiRW1haWxfVGl0bGUiLCJMYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJBY2NlcHQiLCJzZWxmIiwiVGhpc19UaXRsZSIsImdldENvbXBvbmVudCIsInN0cmluZyIsIldlQ2hhdCIsIkxvYWRpbmdfRW1haWwiLCJpIiwiRW1haWwiLCJsZW5ndGgiLCJUaXRsZSIsImNvbnNvbGUiLCJsb2ciLCJFbmNsb3N1cmUiLCJUaXAiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJpZCIsIl9pZCIsIkdvbGQiLCJOdW1iZXIiLCJFbWFpbF9Hb2xkIiwiRGlhbW9uZCIsIkVtYWlsX0RpYW1vbmQiLCJDb21wYXNzaW9uIiwiRW1haWxfQ29tcGFzc2lvbiIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBTUEsb0JBQW9CLEdBQUdDLE9BQU8sQ0FBQyx3Q0FBRCxDQUFwQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBQztBQUNQLGlCQUFRLElBREQ7QUFFUEMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRkQ7QUFHUEMsTUFBQUEsV0FBVyxFQUFDO0FBSEwsS0FESDtBQUtOO0FBQ0ZDLElBQUFBLG9CQUFvQixFQUFDO0FBQ2pCLGlCQUFRLElBRFM7QUFFakJILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxNQUZTO0FBR2pCQyxNQUFBQSxXQUFXLEVBQUM7QUFISyxLQU5iO0FBVU47QUFDRkUsSUFBQUEsYUFBYSxFQUFDO0FBQ1YsaUJBQVEsSUFERTtBQUVWSixNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGRTtBQUdWQyxNQUFBQSxXQUFXLEVBQUM7QUFIRixLQVhOO0FBZU47QUFDRkcsSUFBQUEsV0FBVyxFQUFDO0FBQ1IsaUJBQVEsSUFEQTtBQUVSTCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csS0FGQTtBQUdSSixNQUFBQSxXQUFXLEVBQUM7QUFISixLQWhCSjtBQW9CTjtBQUNGSyxJQUFBQSxNQUFNLEVBQUM7QUFDSCxpQkFBUSxJQURMO0FBRUhQLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDYSxJQUZMO0FBR1pOLE1BQUFBLFdBQVcsRUFBQztBQUhBO0FBckJDLEdBSFA7QUErQkw7QUFFQTtBQUNBTyxFQUFBQSxNQUFNLEVBQUUsa0JBQVU7QUFDZCxRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBLFFBQUlDLFVBQVUsR0FBQyxLQUFLTixXQUFMLENBQWlCTyxZQUFqQixDQUE4QmpCLEVBQUUsQ0FBQ1csS0FBakMsRUFBd0NPLE1BQXZEO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0MsYUFBUDs7QUFHQSxTQUFJLElBQUlDLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQ3ZCLG9CQUFvQixDQUFDd0IsS0FBckIsQ0FBMkJDLE1BQXpDLEVBQWdERixDQUFDLEVBQWpELEVBQW9EO0FBQ2hELFVBQUlHLEtBQUssR0FBQzFCLG9CQUFvQixDQUFDd0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCWCxXQUF4Qzs7QUFDQSxVQUFHTSxVQUFVLEtBQUdRLEtBQWhCLEVBQXNCO0FBQ2xCO0FBQ0FDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBd0I1QixvQkFBb0IsQ0FBQ3dCLEtBQXJCLENBQTJCRCxDQUEzQixDQUF4Qjs7QUFFQSxZQUFHdkIsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJNLFNBQTlCLEtBQTBDLEtBQTdDLEVBQW1EO0FBQy9DLGNBQUlDLEdBQUcsR0FBRzVCLEVBQUUsQ0FBQzZCLFdBQUgsQ0FBZSxLQUFLcEIsYUFBcEIsQ0FBVjtBQUNJLGVBQUtHLE1BQUwsQ0FBWWtCLFFBQVosQ0FBcUJGLEdBQXJCLEVBRjJDLENBRzNDOztBQUNBQSxVQUFBQSxHQUFHLENBQUNHLFdBQUosQ0FBZ0IsQ0FBaEIsRUFBa0IsQ0FBbEI7QUFDUCxTQUxELENBTUE7QUFOQSxhQU9HO0FBQ0MsZ0JBQUdqQyxvQkFBb0IsQ0FBQ3dCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QlAsTUFBOUIsS0FBdUMsS0FBMUMsRUFBZ0Q7QUFDNUM7QUFDQVcsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBLGtCQUFJRSxHQUFHLEdBQUc1QixFQUFFLENBQUM2QixXQUFILENBQWUsS0FBS3pCLFVBQXBCLENBQVY7QUFDQSxtQkFBS1EsTUFBTCxDQUFZa0IsUUFBWixDQUFxQkYsR0FBckIsRUFKNEMsQ0FLNUM7O0FBQ0FBLGNBQUFBLEdBQUcsQ0FBQ0csV0FBSixDQUFnQixDQUFoQixFQUFrQixDQUFsQixFQU40QyxDQU81Qzs7QUFDQSxrQkFBSUMsRUFBRSxHQUFHbEMsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJZLEdBQXZDO0FBQ0Esa0JBQUlDLElBQUksR0FBR0MsTUFBTSxDQUFDckMsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJlLFVBQS9CLENBQWpCO0FBQ0Esa0JBQUlDLE9BQU8sR0FBR0YsTUFBTSxDQUFDckMsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJpQixhQUEvQixDQUFwQjtBQUNBLGtCQUFJQyxVQUFVLEdBQUdKLE1BQU0sQ0FBQ3JDLG9CQUFvQixDQUFDd0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCbUIsZ0JBQS9CLENBQXZCLENBWDRDLENBWTVDOztBQUNBZixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCLEtBQXJCLEVBQTJCUSxJQUEzQixFQUFnQyxLQUFoQyxFQUFzQ0csT0FBdEMsRUFBOEMsS0FBOUMsRUFBb0RFLFVBQXBEO0FBQ0FwQixjQUFBQSxNQUFNLENBQUNMLE1BQVAsQ0FBY2tCLEVBQWQsRUFBaUJFLElBQWpCLEVBQXNCRyxPQUF0QixFQUE4QkUsVUFBOUI7QUFHSCxhQWpCRCxDQWtCQTtBQWxCQSxpQkFtQk07QUFDRjtBQUNBLG9CQUFJWCxHQUFHLEdBQUc1QixFQUFFLENBQUM2QixXQUFILENBQWUsS0FBS3JCLG9CQUFwQixDQUFWO0FBQ0EscUJBQUtJLE1BQUwsQ0FBWWtCLFFBQVosQ0FBcUJGLEdBQXJCLEVBSEUsQ0FJRjs7QUFDQUEsZ0JBQUFBLEdBQUcsQ0FBQ0csV0FBSixDQUFnQixDQUFoQixFQUFrQixDQUFsQjtBQUNIO0FBQ0w7O0FBQ0Q7QUFDRjtBQUNKO0FBQ0osR0FwRkk7QUFxRkxVLEVBQUFBLEtBckZLLG1CQXFGSSxDQUVSLENBdkZJLENBeUZMOztBQXpGSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9vemCrueuseWIl+ihqFxyXG5jb25zdCBFbWFpbF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL0VtYWlsX0xvY2FsX1ZhcmlhYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgQWNjZXB0X0JveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5QcmVmYWIsXHJcbiAgICAgICAgICAgIHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSwvL+aIkOWKn+aOpeWPl+aPkOekuuS/oeaBr1xyXG4gICAgICAgIEFscmVhZHlfQWNjZXB0ZWRfQm94OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLlByZWZhYixcclxuICAgICAgICAgICAgc2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICB9LC8v5bey5o6l5Y+X6L+H5o+Q56S65L+h5oGvXHJcbiAgICAgICAgTm9fQXdhcmRzX0JveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5QcmVmYWIsXHJcbiAgICAgICAgICAgIHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSwvL+ayoeacieWlluWKseaPkOekuuS/oeaBr1xyXG4gICAgICAgIEVtYWlsX1RpdGxlOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgICAgICBzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sLy/pgq7ku7bmoIfpophcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcbiAgICBBY2NlcHQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHZhciBUaGlzX1RpdGxlPXRoaXMuRW1haWxfVGl0bGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfRW1haWwoKTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbC5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdmFyIFRpdGxlPUVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlO1xyXG4gICAgICAgICAgICBpZihUaGlzX1RpdGxlPT09VGl0bGUpe1xyXG4gICAgICAgICAgICAgICAgLy/lvZPliY3ngrnlh7vnmoTpgq7ku7ZcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN6YKu5Lu25YaF5a655Li6Mu+8mlwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW5jbG9zdXJlPT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBUaXAgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLk5vX0F3YXJkc19Cb3gpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5hZGRDaGlsZChUaXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+iuvue9ruaPkOekuuahhuS9jee9rlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXAuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8v5piv5ZCm5bey57uP5o6l5Y+X6L+H5aWW5YqxXHJcbiAgICAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uQWNjZXB0PT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+acquabvuaOpeWPl+WlluWKsVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaOpeWPl+WlluWKsVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFRpcCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQWNjZXB0X0JveCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQ2FudmFzLmFkZENoaWxkKFRpcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v6K6+572u5o+Q56S65qGG5L2N572uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRpcC5zZXRQb3NpdGlvbigwLDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+WlluWKseWPguaVsOiuvue9rlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaWQgPSBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5faWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBHb2xkID0gTnVtYmVyKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX0dvbGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgRGlhbW9uZCA9IE51bWJlcihFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9EaWFtb25kKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIENvbXBhc3Npb24gPSBOdW1iZXIoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfQ29tcGFzc2lvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v5o6l5Y+X5aWW5YqxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5bey57uP5o6l5Y+X5aWW5YqxXCIsXCLph5HluIHvvJpcIixHb2xkLFwi6ZK755+z77yaXCIsRGlhbW9uZCxcIuS9k+WKm++8mlwiLENvbXBhc3Npb24pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBXZUNoYXQuQWNjZXB0KGlkLEdvbGQsRGlhbW9uZCxDb21wYXNzaW9uKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvL+W3suaOpeWPl+i/h+WlluWKsVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy/lvLnlh7rmj5DnpLrmoYZcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFRpcCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQWxyZWFkeV9BY2NlcHRlZF9Cb3gpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5hZGRDaGlsZChUaXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+iuvue9ruaPkOekuuahhuS9jee9rlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXAuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19