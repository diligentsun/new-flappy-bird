
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Change_Difficult.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3313dWvxnZAQ4hjAepWc3E+', 'Change_Difficult');
// resources/script/Game_Start/Change_Difficult.js

"use strict";

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible'); //改变游戏难度


cc.Class({
  "extends": cc.Component,
  properties: {
    Difficulty: "" //声明游戏难度

  },
  start: function start() {},
  // update (dt) {},
  on_btn_click: function on_btn_click() {
    //根据不同的游戏难度，调整难度系数
    if (this.Difficulty == 'Easy') {
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 0.5;
      Game_Difficulty_Local_Varible.Is_Difficulty = false;
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 1;
    } else if (this.Difficulty == 'Mid') {
      Game_Difficulty_Local_Varible.Is_Difficulty = false;
    } else if (this.Difficulty == 'Difficulty') {
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 1;
      Game_Difficulty_Local_Varible.Is_Difficulty = true;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXENoYW5nZV9EaWZmaWN1bHQuanMiXSwibmFtZXMiOlsiR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJEaWZmaWN1bHR5Iiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJEaWZmaWN1bHR5X1JhdGlvIiwiSXNfRGlmZmljdWx0eSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSw2QkFBNkIsR0FBR0MsT0FBTyxDQUFDLCtCQUFELENBQTNDLEVBQ0E7OztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsVUFBVSxFQUFFLEVBREQsQ0FDSzs7QUFETCxHQUhKO0FBT1JDLEVBQUFBLEtBUFEsbUJBT0EsQ0FHUCxDQVZPO0FBWVI7QUFDQUMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQUU7QUFDMUIsUUFBSSxLQUFLRixVQUFMLElBQW1CLE1BQXZCLEVBQStCO0FBQzlCTixNQUFBQSw2QkFBNkIsQ0FBQ1MsZ0JBQTlCLEdBQWlELEdBQWpEO0FBRUFULE1BQUFBLDZCQUE2QixDQUFDVSxhQUE5QixHQUE4QyxLQUE5QztBQUNBVixNQUFBQSw2QkFBNkIsQ0FBQ1MsZ0JBQTlCLEdBQWlELENBQWpEO0FBQ0EsS0FMRCxNQUtPLElBQUksS0FBS0gsVUFBTCxJQUFtQixLQUF2QixFQUE4QjtBQUVwQ04sTUFBQUEsNkJBQTZCLENBQUNVLGFBQTlCLEdBQThDLEtBQTlDO0FBQ0EsS0FITSxNQUdBLElBQUksS0FBS0osVUFBTCxJQUFtQixZQUF2QixFQUFxQztBQUMzQ04sTUFBQUEsNkJBQTZCLENBQUNTLGdCQUE5QixHQUFpRCxDQUFqRDtBQUVBVCxNQUFBQSw2QkFBNkIsQ0FBQ1UsYUFBOUIsR0FBOEMsSUFBOUM7QUFDQTtBQUNEO0FBM0JPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbInZhciBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlJyk7XHJcbi8v5pS55Y+Y5ri45oiP6Zq+5bqmXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdERpZmZpY3VsdHk6IFwiXCIsIC8v5aOw5piO5ri45oiP6Zq+5bqmXHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cclxuXHR9LFxyXG5cclxuXHQvLyB1cGRhdGUgKGR0KSB7fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkgeyAvL+agueaNruS4jeWQjOeahOa4uOaIj+mavuW6pu+8jOiwg+aVtOmavuW6puezu+aVsFxyXG5cdFx0aWYgKHRoaXMuRGlmZmljdWx0eSA9PSAnRWFzeScpIHtcclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbyA9IDAuNTtcclxuXHJcblx0XHRcdEdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlLklzX0RpZmZpY3VsdHkgPSBmYWxzZTtcclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbyA9IDE7XHJcblx0XHR9IGVsc2UgaWYgKHRoaXMuRGlmZmljdWx0eSA9PSAnTWlkJykge1xyXG5cclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuSXNfRGlmZmljdWx0eSA9IGZhbHNlO1xyXG5cdFx0fSBlbHNlIGlmICh0aGlzLkRpZmZpY3VsdHkgPT0gJ0RpZmZpY3VsdHknKSB7XHJcblx0XHRcdEdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlLkRpZmZpY3VsdHlfUmF0aW8gPSAxO1xyXG5cclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuSXNfRGlmZmljdWx0eSA9IHRydWU7XHJcblx0XHR9XHJcblx0fVxyXG59KTtcbiJdfQ==