
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Gold_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '85f41MkxtRAJbqu2YeY3nrd', 'Gold_Action');
// resources/script/Game_Coming/Gold_Action.js

"use strict";

//金币运动函数
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    coinAudio: {
      "default": null,
      type: cc.AudioClip
    },
    Move_Speed: 0,
    //金币的移动速度
    x: 0,
    //金币x坐标
    y: 0,
    //金币y坐标
    Gold_Show: {
      //金币的预制体
      "default": null,
      type: cc.Prefab,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    //打开碰撞属性
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; //manager.enabledDebugDraw = true;
  },
  start: function start() {},
  update: function update(dt) {
    //通过更新金币的x坐标，让金币前进
    this.node.x -= 5 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 2; //如果金币超出界面，毁灭掉金币

    if (this.node.x < -600) {
      this.node.destroy();
    }
  },
  //碰撞判断	
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log("other.name = ", other.node.name, other.node.group, other.node.groupIndex);

    if (other.node.groupIndex === 0) {
      //如果和小鸟碰撞
      var Gold_Show_Label = cc.instantiate(this.Gold_Show); //加入金币显示框

      Game_Local_Varible.Gold += 1;
      this.node.destroy(); //移除该金币

      this.node.parent.addChild(Gold_Show_Label);
      Gold_Show_Label.setPosition(400, 750);
      cc.audioEngine.playEffect(this.coinAudio, false, 0.6);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxHb2xkX0FjdGlvbi5qcyJdLCJuYW1lcyI6WyJHYW1lX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNvaW5BdWRpbyIsInR5cGUiLCJBdWRpb0NsaXAiLCJNb3ZlX1NwZWVkIiwieCIsInkiLCJHb2xkX1Nob3ciLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIm9uTG9hZCIsIm1hbmFnZXIiLCJkaXJlY3RvciIsImdldENvbGxpc2lvbk1hbmFnZXIiLCJlbmFibGVkIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm5vZGUiLCJEaWZmaWN1bHR5X1JhdGlvIiwiZGVzdHJveSIsIm9uQ29sbGlzaW9uRW50ZXIiLCJvdGhlciIsInNlbGYiLCJjb25zb2xlIiwibG9nIiwibmFtZSIsImdyb3VwIiwiZ3JvdXBJbmRleCIsIkdvbGRfU2hvd19MYWJlbCIsImluc3RhbnRpYXRlIiwiR29sZCIsInBhcmVudCIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJhdWRpb0VuZ2luZSIsInBsYXlFZmZlY3QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxrQkFBa0IsR0FBR0MsT0FBTyxDQUFDLG9CQUFELENBQWhDOztBQUNBLElBQUlDLDZCQUE2QixHQUFHRCxPQUFPLENBQUMsK0JBQUQsQ0FBM0M7O0FBRUFFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUVYQyxJQUFBQSxTQUFTLEVBQUU7QUFDRCxpQkFBUyxJQURSO0FBRURDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZSLEtBRkE7QUFPWEMsSUFBQUEsVUFBVSxFQUFFLENBUEQ7QUFPSTtBQUNmQyxJQUFBQSxDQUFDLEVBQUUsQ0FSUTtBQVFMO0FBQ05DLElBQUFBLENBQUMsRUFBRSxDQVRRO0FBU0w7QUFDTkMsSUFBQUEsU0FBUyxFQUFFO0FBQUU7QUFDWixpQkFBUyxJQURDO0FBRVZMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVyxNQUZDO0FBR1ZDLE1BQUFBLFdBQVcsRUFBRTtBQUhIO0FBVkEsR0FISjtBQXFCUjtBQUNBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQSxRQUFJQyxPQUFPLEdBQUdkLEVBQUUsQ0FBQ2UsUUFBSCxDQUFZQyxtQkFBWixFQUFkO0FBQ0FGLElBQUFBLE9BQU8sQ0FBQ0csT0FBUixHQUFrQixJQUFsQixDQUhrQixDQUlsQjtBQUNBLEdBM0JPO0FBNkJSQyxFQUFBQSxLQUFLLEVBQUUsaUJBQVcsQ0FBRSxDQTdCWjtBQThCUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEI7QUFDQSxTQUFLQyxJQUFMLENBQVViLENBQVYsSUFBZ0IsSUFBSVQsNkJBQTZCLENBQUN1QixnQkFBOUIsR0FBaUQsQ0FBckUsQ0FGb0IsQ0FHcEI7O0FBQ0EsUUFBSSxLQUFLRCxJQUFMLENBQVViLENBQVYsR0FBYyxDQUFDLEdBQW5CLEVBQXdCO0FBQ3ZCLFdBQUthLElBQUwsQ0FBVUUsT0FBVjtBQUVBO0FBQ0QsR0F0Q087QUF1Q1I7QUFDQUMsRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVNDLEtBQVQsRUFBZ0JDLElBQWhCLEVBQXNCO0FBRXZDQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCSCxLQUFLLENBQUNKLElBQU4sQ0FBV1EsSUFBeEMsRUFBOENKLEtBQUssQ0FBQ0osSUFBTixDQUFXUyxLQUF6RCxFQUFnRUwsS0FBSyxDQUFDSixJQUFOLENBQVdVLFVBQTNFOztBQUNBLFFBQUlOLEtBQUssQ0FBQ0osSUFBTixDQUFXVSxVQUFYLEtBQTBCLENBQTlCLEVBQWlDO0FBQUU7QUFDbEMsVUFBSUMsZUFBZSxHQUFHaEMsRUFBRSxDQUFDaUMsV0FBSCxDQUFlLEtBQUt2QixTQUFwQixDQUF0QixDQURnQyxDQUNzQjs7QUFDdERiLE1BQUFBLGtCQUFrQixDQUFDcUMsSUFBbkIsSUFBMkIsQ0FBM0I7QUFDQSxXQUFLYixJQUFMLENBQVVFLE9BQVYsR0FIZ0MsQ0FHWDs7QUFDckIsV0FBS0YsSUFBTCxDQUFVYyxNQUFWLENBQWlCQyxRQUFqQixDQUEwQkosZUFBMUI7QUFDQUEsTUFBQUEsZUFBZSxDQUFDSyxXQUFoQixDQUE0QixHQUE1QixFQUFpQyxHQUFqQztBQUNBckMsTUFBQUEsRUFBRSxDQUFDc0MsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtuQyxTQUEvQixFQUEwQyxLQUExQyxFQUFnRCxHQUFoRDtBQUVBO0FBQ0Q7QUFwRE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/ph5HluIHov5Dliqjlh73mlbBcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG4gIFxyXG5cdFx0Y29pbkF1ZGlvOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcFxyXG4gICAgICAgIH0sXHJcblxyXG5cdFx0TW92ZV9TcGVlZDogMCwgLy/ph5HluIHnmoTnp7vliqjpgJ/luqZcclxuXHRcdHg6IDAsIC8v6YeR5biBeOWdkOagh1xyXG5cdFx0eTogMCwgLy/ph5HluIF55Z2Q5qCHXHJcblx0XHRHb2xkX1Nob3c6IHsgLy/ph5HluIHnmoTpooTliLbkvZNcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0fSxcclxuXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+aJk+W8gOeisOaSnuWxnuaAp1xyXG5cdFx0dmFyIG1hbmFnZXIgPSBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCk7XHJcblx0XHRtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0Ly9tYW5hZ2VyLmVuYWJsZWREZWJ1Z0RyYXcgPSB0cnVlO1xyXG5cdH0sXHJcblxyXG5cdHN0YXJ0OiBmdW5jdGlvbigpIHt9LFxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHtcclxuXHRcdC8v6YCa6L+H5pu05paw6YeR5biB55qEeOWdkOagh++8jOiuqemHkeW4geWJjei/m1xyXG5cdFx0dGhpcy5ub2RlLnggLT0gKDUgKyBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICogMik7XHJcblx0XHQvL+WmguaenOmHkeW4gei2heWHuueVjOmdou+8jOavgeeBreaOiemHkeW4gVxyXG5cdFx0aWYgKHRoaXMubm9kZS54IDwgLTYwMCkge1xyXG5cdFx0XHR0aGlzLm5vZGUuZGVzdHJveSgpO1xyXG5cclxuXHRcdH1cclxuXHR9LFxyXG5cdC8v56Kw5pKe5Yik5patXHRcclxuXHRvbkNvbGxpc2lvbkVudGVyOiBmdW5jdGlvbihvdGhlciwgc2VsZikge1xyXG5cclxuXHRcdGNvbnNvbGUubG9nKFwib3RoZXIubmFtZSA9IFwiLCBvdGhlci5ub2RlLm5hbWUsIG90aGVyLm5vZGUuZ3JvdXAsIG90aGVyLm5vZGUuZ3JvdXBJbmRleCk7XHJcblx0XHRpZiAob3RoZXIubm9kZS5ncm91cEluZGV4ID09PSAwKSB7IC8v5aaC5p6c5ZKM5bCP6bif56Kw5pKeXHJcblx0XHRcdHZhciBHb2xkX1Nob3dfTGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkdvbGRfU2hvdyk7IC8v5Yqg5YWl6YeR5biB5pi+56S65qGGXHJcblx0XHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5Hb2xkICs9IDE7XHJcblx0XHRcdHRoaXMubm9kZS5kZXN0cm95KCk7IC8v56e76Zmk6K+l6YeR5biBXHJcblx0XHRcdHRoaXMubm9kZS5wYXJlbnQuYWRkQ2hpbGQoR29sZF9TaG93X0xhYmVsKTtcclxuXHRcdFx0R29sZF9TaG93X0xhYmVsLnNldFBvc2l0aW9uKDQwMCwgNzUwKTtcclxuXHRcdFx0Y2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmNvaW5BdWRpbywgZmFsc2UsMC42KTtcclxuXHRcclxuXHRcdH1cclxuXHR9LFxyXG59KTtcclxuIl19