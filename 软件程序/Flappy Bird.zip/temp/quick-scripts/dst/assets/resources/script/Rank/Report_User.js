
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Report_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3150aaPeV1AHaJmpWEz0VCd', 'Report_User');
// resources/script/Rank/Report_User.js

"use strict";

//弹出举报框
var Report_Local_Variable = require('Report_Local_Variable');

var Rank_Local_Varible = require('Rank_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Report_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //举报框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //玩家框节点
    Report_Rank: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //被举报玩家

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建举报信息框
    var New_Report_Label = cc.instantiate(this.Report_Label);
    this.Canvas.parent.parent.parent.addChild(New_Report_Label);
    New_Report_Label.setPosition(0, 0); //载入信息

    console.log("被举报人的名次", this.Report_Rank.getComponent(cc.Label).string);
    var Rank_Number = Number(this.Report_Rank.getComponent(cc.Label).string) - 1;
    console.log("被举报人的openid", Report_Local_Variable.openid);
    Report_Local_Variable.openid = Rank_Local_Varible.Word_Rank_User[Rank_Number].openid;
    Report_Local_Variable.User_Name = Rank_Local_Varible.Word_Rank_User[Rank_Number].User_Name;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXFJlcG9ydF9Vc2VyLmpzIl0sIm5hbWVzIjpbIlJlcG9ydF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJSYW5rX0xvY2FsX1ZhcmlibGUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIlJlcG9ydF9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkNhbnZhcyIsIk5vZGUiLCJSZXBvcnRfUmFuayIsIkxhYmVsIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJOZXdfUmVwb3J0X0xhYmVsIiwiaW5zdGFudGlhdGUiLCJwYXJlbnQiLCJhZGRDaGlsZCIsInNldFBvc2l0aW9uIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInN0cmluZyIsIlJhbmtfTnVtYmVyIiwiTnVtYmVyIiwib3BlbmlkIiwiV29yZF9SYW5rX1VzZXIiLCJVc2VyX05hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxxQkFBcUIsR0FBR0MsT0FBTyxDQUFDLHVCQUFELENBQW5DOztBQUNBLElBQUlDLGtCQUFrQixHQUFHRCxPQUFPLENBQUMscUJBQUQsQ0FBaEM7O0FBRUFFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZJO0FBR2JDLE1BQUFBLFdBQVcsRUFBRTtBQUhBLEtBREg7QUFLUjtBQUNIQyxJQUFBQSxNQUFNLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxJQUZGO0FBR1BGLE1BQUFBLFdBQVcsRUFBRTtBQUhOLEtBTkc7QUFVUjtBQUNIRyxJQUFBQSxXQUFXLEVBQUU7QUFDWixpQkFBUyxJQURHO0FBRVpMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVyxLQUZHO0FBR1pKLE1BQUFBLFdBQVcsRUFBRTtBQUhELEtBWEYsQ0FlUjs7QUFmUSxHQUhKO0FBcUJSSyxFQUFBQSxLQXJCUSxtQkFxQkEsQ0FFUCxDQXZCTztBQXdCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUdkLEVBQUUsQ0FBQ2UsV0FBSCxDQUFlLEtBQUtYLFlBQXBCLENBQXZCO0FBQ0EsU0FBS0ksTUFBTCxDQUFZUSxNQUFaLENBQW1CQSxNQUFuQixDQUEwQkEsTUFBMUIsQ0FBaUNDLFFBQWpDLENBQTBDSCxnQkFBMUM7QUFDQUEsSUFBQUEsZ0JBQWdCLENBQUNJLFdBQWpCLENBQTZCLENBQTdCLEVBQWdDLENBQWhDLEVBSndCLENBS3hCOztBQUNBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaLEVBQXVCLEtBQUtWLFdBQUwsQ0FBaUJXLFlBQWpCLENBQThCckIsRUFBRSxDQUFDVyxLQUFqQyxFQUF3Q1csTUFBL0Q7QUFDQSxRQUFJQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQyxLQUFLZCxXQUFMLENBQWlCVyxZQUFqQixDQUE4QnJCLEVBQUUsQ0FBQ1csS0FBakMsRUFBd0NXLE1BQXpDLENBQU4sR0FBeUQsQ0FBM0U7QUFDQUgsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksYUFBWixFQUEyQnZCLHFCQUFxQixDQUFDNEIsTUFBakQ7QUFDQTVCLElBQUFBLHFCQUFxQixDQUFDNEIsTUFBdEIsR0FBK0IxQixrQkFBa0IsQ0FBQzJCLGNBQW5CLENBQWtDSCxXQUFsQyxFQUErQ0UsTUFBOUU7QUFDQTVCLElBQUFBLHFCQUFxQixDQUFDOEIsU0FBdEIsR0FBa0M1QixrQkFBa0IsQ0FBQzJCLGNBQW5CLENBQWtDSCxXQUFsQyxFQUErQ0ksU0FBakY7QUFDQSxHQW5DTyxDQW9DUjs7QUFwQ1EsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lvLnlh7rkuL7miqXmoYZcclxudmFyIFJlcG9ydF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJ1JlcG9ydF9Mb2NhbF9WYXJpYWJsZScpO1xyXG52YXIgUmFua19Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnUmFua19Mb2NhbF9WYXJpYWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0UmVwb3J0X0xhYmVsOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+S4vuaKpeahhlxyXG5cdFx0Q2FudmFzOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/njqnlrrbmoYboioLngrlcclxuXHRcdFJlcG9ydF9SYW5rOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6KKr5Li+5oql546p5a62XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v5Yib5bu65Li+5oql5L+h5oGv5qGGXHJcblx0XHR2YXIgTmV3X1JlcG9ydF9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuUmVwb3J0X0xhYmVsKTtcclxuXHRcdHRoaXMuQ2FudmFzLnBhcmVudC5wYXJlbnQucGFyZW50LmFkZENoaWxkKE5ld19SZXBvcnRfTGFiZWwpO1xyXG5cdFx0TmV3X1JlcG9ydF9MYWJlbC5zZXRQb3NpdGlvbigwLCAwKTtcclxuXHRcdC8v6L295YWl5L+h5oGvXHJcblx0XHRjb25zb2xlLmxvZyhcIuiiq+S4vuaKpeS6uueahOWQjeasoVwiLCB0aGlzLlJlcG9ydF9SYW5rLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKTtcclxuXHRcdHZhciBSYW5rX051bWJlciA9IE51bWJlcih0aGlzLlJlcG9ydF9SYW5rLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKSAtIDE7XHJcblx0XHRjb25zb2xlLmxvZyhcIuiiq+S4vuaKpeS6uueahG9wZW5pZFwiLCBSZXBvcnRfTG9jYWxfVmFyaWFibGUub3BlbmlkKTtcclxuXHRcdFJlcG9ydF9Mb2NhbF9WYXJpYWJsZS5vcGVuaWQgPSBSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXJbUmFua19OdW1iZXJdLm9wZW5pZDtcclxuXHRcdFJlcG9ydF9Mb2NhbF9WYXJpYWJsZS5Vc2VyX05hbWUgPSBSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXJbUmFua19OdW1iZXJdLlVzZXJfTmFtZTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=