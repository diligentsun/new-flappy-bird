
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Buy_Character_Sure.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'aac19v+FeVMJLHchDHDMilr', 'Buy_Character_Sure');
// resources/script/Shop/Buy_Character_Sure.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

var User_Have_Character_Local_Varible = require('../Local_Variible/User_Have_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Reminder_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Id: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Price_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    WeChat.Loading_Shop_Character(); //读取当前点击的角色金币

    var This_Information_Price = this.Price_Label.getComponent(cc.Label).string; //读取当前点击的角色信息

    var This_Information = this.Character_Id.getComponent(cc.Label).string; //读取用户拥有的金币

    var User_Gold = Global_Variable.Gold;
    var New_Reminder_Box = cc.instantiate(this.Reminder_Box);
    this.Canvas.parent.parent.addChild(New_Reminder_Box);
    New_Reminder_Box.setPosition(0, -400);
    var flag = 0;

    for (var i = 0; i < User_Have_Character_Local_Varible.User_Have_Character.length; i++) {
      //读取用户拥有的角色信息
      var User_Character_Information = User_Have_Character_Local_Varible.User_Have_Character[i]; //判断已经拥有角色
      //判断是否是本机用户

      if (This_Information == User_Character_Information.Character_Id && Global_Variable.openid == User_Character_Information.openid) {
        New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "您已拥有该商品";
        flag = 1;
        break; //输出已经拥有
      }
    }

    console.log("小鸟价格", This_Information_Price);
    console.log("用户金币数", User_Gold); //判断用户金币是否购买的起当前小鸟       

    if (User_Gold < This_Information_Price && flag == 0) {
      New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "金币不足购买商品";
    }

    if (User_Gold >= This_Information_Price && flag == 0) {
      New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "购买成功该商品";
      User_Gold = User_Gold - This_Information_Price;
      WeChat.Buy_Character_Update(User_Gold, This_Information);
    }
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXEJ1eV9DaGFyYWN0ZXJfU3VyZS5qcyJdLCJuYW1lcyI6WyJTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsIlVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiUmVtaW5kZXJfQm94IiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQ2hhcmFjdGVyX0lkIiwiTGFiZWwiLCJQcmljZV9MYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJvbl9idG5fY2xpY2siLCJXZUNoYXQiLCJMb2FkaW5nX1Nob3BfQ2hhcmFjdGVyIiwiVGhpc19JbmZvcm1hdGlvbl9QcmljZSIsImdldENvbXBvbmVudCIsInN0cmluZyIsIlRoaXNfSW5mb3JtYXRpb24iLCJVc2VyX0dvbGQiLCJHbG9iYWxfVmFyaWFibGUiLCJHb2xkIiwiTmV3X1JlbWluZGVyX0JveCIsImluc3RhbnRpYXRlIiwicGFyZW50IiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiIsImZsYWciLCJpIiwiVXNlcl9IYXZlX0NoYXJhY3RlciIsImxlbmd0aCIsIlVzZXJfQ2hhcmFjdGVyX0luZm9ybWF0aW9uIiwib3BlbmlkIiwiZ2V0Q2hpbGRCeU5hbWUiLCJjb25zb2xlIiwibG9nIiwiQnV5X0NoYXJhY3Rlcl9VcGRhdGUiLCJ1cGRhdGUiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJQSw0QkFBNEIsR0FBR0MsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBLElBQU1DLGlDQUFpQyxHQUFHRCxPQUFPLENBQUMscURBQUQsQ0FBakQ7O0FBQ0FFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxZQUFZLEVBQUM7QUFDVCxpQkFBUSxJQURDO0FBRWxCQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGVTtBQUdsQkMsTUFBQUEsV0FBVyxFQUFDO0FBSE0sS0FETDtBQU1SQyxJQUFBQSxZQUFZLEVBQUM7QUFDVCxpQkFBUSxJQURDO0FBRWxCSCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1MsS0FGVTtBQUdsQkYsTUFBQUEsV0FBVyxFQUFDO0FBSE0sS0FOTDtBQVdSRyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUSxJQURBO0FBRWpCTCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1MsS0FGUztBQUdqQkYsTUFBQUEsV0FBVyxFQUFDO0FBSEssS0FYSjtBQWdCUkksSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITixNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1ksSUFGTDtBQUdaTCxNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQWhCQyxHQUhQO0FBMEJMO0FBQ0FNLEVBQUFBLFlBQVksRUFBQyx3QkFBWTtBQUVyQkMsSUFBQUEsTUFBTSxDQUFDQyxzQkFBUCxHQUZxQixDQU9yQjs7QUFDQSxRQUFJQyxzQkFBc0IsR0FBQyxLQUFLTixXQUFMLENBQWlCTyxZQUFqQixDQUE4QmpCLEVBQUUsQ0FBQ1MsS0FBakMsRUFBd0NTLE1BQW5FLENBUnFCLENBU3JCOztBQUNBLFFBQUlDLGdCQUFnQixHQUFDLEtBQUtYLFlBQUwsQ0FBa0JTLFlBQWxCLENBQStCakIsRUFBRSxDQUFDUyxLQUFsQyxFQUF5Q1MsTUFBOUQsQ0FWcUIsQ0FXckI7O0FBQ0EsUUFBSUUsU0FBUyxHQUFDQyxlQUFlLENBQUNDLElBQTlCO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUd2QixFQUFFLENBQUN3QixXQUFILENBQWUsS0FBS3BCLFlBQXBCLENBQXZCO0FBQ0EsU0FBS08sTUFBTCxDQUFZYyxNQUFaLENBQW1CQSxNQUFuQixDQUEwQkMsUUFBMUIsQ0FBbUNILGdCQUFuQztBQUNBQSxJQUFBQSxnQkFBZ0IsQ0FBQ0ksV0FBakIsQ0FBNkIsQ0FBN0IsRUFBK0IsQ0FBQyxHQUFoQztBQUNBLFFBQUlDLElBQUksR0FBQyxDQUFUOztBQUdBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDOUIsaUNBQWlDLENBQUMrQixtQkFBbEMsQ0FBc0RDLE1BQXBFLEVBQTJFRixDQUFDLEVBQTVFLEVBQStFO0FBQy9FO0FBQ0EsVUFBSUcsMEJBQTBCLEdBQUNqQyxpQ0FBaUMsQ0FBQytCLG1CQUFsQyxDQUFzREQsQ0FBdEQsQ0FBL0IsQ0FGK0UsQ0FHM0U7QUFDQTs7QUFDSSxVQUFJVixnQkFBZ0IsSUFBRWEsMEJBQTBCLENBQUN4QixZQUE5QyxJQUE4RGEsZUFBZSxDQUFDWSxNQUFoQixJQUF3QkQsMEJBQTBCLENBQUNDLE1BQXBILEVBQTRIO0FBQ3hIVixRQUFBQSxnQkFBZ0IsQ0FBQ1csY0FBakIsQ0FBZ0MsZUFBaEMsRUFBaURqQixZQUFqRCxDQUE4RGpCLEVBQUUsQ0FBQ1MsS0FBakUsRUFBd0VTLE1BQXhFLEdBQStFLFNBQS9FO0FBQ0FVLFFBQUFBLElBQUksR0FBQyxDQUFMO0FBQ0EsY0FId0gsQ0FJeEg7QUFDWDtBQUNBOztBQUNETyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CcEIsc0JBQW5CO0FBQ0FtQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CaEIsU0FBcEIsRUFoQ3FCLENBaUNyQjs7QUFDQSxRQUFJQSxTQUFTLEdBQUNKLHNCQUFYLElBQXFDWSxJQUFJLElBQUUsQ0FBOUMsRUFBaUQ7QUFDN0NMLE1BQUFBLGdCQUFnQixDQUFDVyxjQUFqQixDQUFnQyxlQUFoQyxFQUFpRGpCLFlBQWpELENBQThEakIsRUFBRSxDQUFDUyxLQUFqRSxFQUF3RVMsTUFBeEUsR0FBK0UsVUFBL0U7QUFDSDs7QUFDRCxRQUFJRSxTQUFTLElBQUVKLHNCQUFaLElBQXNDWSxJQUFJLElBQUUsQ0FBL0MsRUFBa0Q7QUFDOUNMLE1BQUFBLGdCQUFnQixDQUFDVyxjQUFqQixDQUFnQyxlQUFoQyxFQUFpRGpCLFlBQWpELENBQThEakIsRUFBRSxDQUFDUyxLQUFqRSxFQUF3RVMsTUFBeEUsR0FBK0UsU0FBL0U7QUFDQUUsTUFBQUEsU0FBUyxHQUFDQSxTQUFTLEdBQUNKLHNCQUFwQjtBQUNBRixNQUFBQSxNQUFNLENBQUN1QixvQkFBUCxDQUE0QmpCLFNBQTVCLEVBQXNDRCxnQkFBdEM7QUFDSDtBQUtKLEdBekVJO0FBMkVEbUIsRUFBQUEsTUEzRUMsa0JBMkVPQyxFQTNFUCxFQTJFVyxDQUFFO0FBM0ViLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG52YXIgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxuY29uc3QgVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnLi4vTG9jYWxfVmFyaWlibGUvVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgUmVtaW5kZXJfQm94OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDaGFyYWN0ZXJfSWQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgUHJpY2VfTGFiZWw6eyAgXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuICAgIG9uX2J0bl9jbGljazpmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgIFdlQ2hhdC5Mb2FkaW5nX1Nob3BfQ2hhcmFjdGVyKCk7XHJcblxyXG4gICAgICBcclxuXHJcblxyXG4gICAgICAgIC8v6K+75Y+W5b2T5YmN54K55Ye755qE6KeS6Imy6YeR5biBXHJcbiAgICAgICAgdmFyIFRoaXNfSW5mb3JtYXRpb25fUHJpY2U9dGhpcy5QcmljZV9MYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICAvL+ivu+WPluW9k+WJjeeCueWHu+eahOinkuiJsuS/oeaBr1xyXG4gICAgICAgIHZhciBUaGlzX0luZm9ybWF0aW9uPXRoaXMuQ2hhcmFjdGVyX0lkLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgIC8v6K+75Y+W55So5oi35oul5pyJ55qE6YeR5biBXHJcbiAgICAgICAgdmFyIFVzZXJfR29sZD1HbG9iYWxfVmFyaWFibGUuR29sZDtcclxuICAgICAgICB2YXIgTmV3X1JlbWluZGVyX0JveCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuUmVtaW5kZXJfQm94KTtcclxuICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LmFkZENoaWxkKE5ld19SZW1pbmRlcl9Cb3gpO1xyXG4gICAgICAgIE5ld19SZW1pbmRlcl9Cb3guc2V0UG9zaXRpb24oMCwtNDAwKTtcclxuICAgICAgICB2YXIgZmxhZz0wO1xyXG5cclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3Rlci5sZW5ndGg7aSsrKXtcclxuICAgICAgICAvL+ivu+WPlueUqOaIt+aLpeacieeahOinkuiJsuS/oeaBr1xyXG4gICAgICAgIHZhciBVc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbj1Vc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3RlcltpXTtcclxuICAgICAgICAgICAgLy/liKTmlq3lt7Lnu4/mi6XmnInop5LoibJcclxuICAgICAgICAgICAgLy/liKTmlq3mmK/lkKbmmK/mnKzmnLrnlKjmiLdcclxuICAgICAgICAgICAgICAgIGlmKChUaGlzX0luZm9ybWF0aW9uPT1Vc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSWQpJiYoR2xvYmFsX1ZhcmlhYmxlLm9wZW5pZD09VXNlcl9DaGFyYWN0ZXJfSW5mb3JtYXRpb24ub3BlbmlkKSl7XHJcbiAgICAgICAgICAgICAgICAgICAgTmV3X1JlbWluZGVyX0JveC5nZXRDaGlsZEJ5TmFtZShcIlJlbWluZGVyX1RleHRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCLmgqjlt7Lmi6XmnInor6XllYblk4FcIjtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/ovpPlh7rlt7Lnu4/mi6XmnIlcclxuICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5bCP6bif5Lu35qC8XCIsVGhpc19JbmZvcm1hdGlvbl9QcmljZSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCLnlKjmiLfph5HluIHmlbBcIixVc2VyX0dvbGQpO1xyXG4gICAgICAgIC8v5Yik5pat55So5oi36YeR5biB5piv5ZCm6LSt5Lmw55qE6LW35b2T5YmN5bCP6bifICAgICAgIFxyXG4gICAgICAgIGlmKChVc2VyX0dvbGQ8VGhpc19JbmZvcm1hdGlvbl9QcmljZSkmJihmbGFnPT0wKSl7XHJcbiAgICAgICAgICAgIE5ld19SZW1pbmRlcl9Cb3guZ2V0Q2hpbGRCeU5hbWUoXCJSZW1pbmRlcl9UZXh0XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwi6YeR5biB5LiN6Laz6LSt5Lmw5ZWG5ZOBXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChVc2VyX0dvbGQ+PVRoaXNfSW5mb3JtYXRpb25fUHJpY2UpJiYoZmxhZz09MCkpe1xyXG4gICAgICAgICAgICBOZXdfUmVtaW5kZXJfQm94LmdldENoaWxkQnlOYW1lKFwiUmVtaW5kZXJfVGV4dFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIui0reS5sOaIkOWKn+ivpeWVhuWTgVwiO1xyXG4gICAgICAgICAgICBVc2VyX0dvbGQ9VXNlcl9Hb2xkLVRoaXNfSW5mb3JtYXRpb25fUHJpY2U7XHJcbiAgICAgICAgICAgIFdlQ2hhdC5CdXlfQ2hhcmFjdGVyX1VwZGF0ZShVc2VyX0dvbGQsVGhpc19JbmZvcm1hdGlvbik7XHJcbiAgICAgICAgfVxyXG4gXHJcblxyXG5cclxuXHJcbiAgICB9LFxyXG5cclxuICAgICAgICB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==