
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Game_Local_Varible.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0dac3D7735OkZ6XLHfugRmJ', 'Game_Local_Varible');
// resources/script/Local_Variible/Game_Local_Varible.js

"use strict";

//游戏界面的局部变量
module.exports = {
  //分数统计
  Fraction: 0,
  //获得金币
  Gold: 0,
  //当前地图
  Current_Map: {
    "default": null,
    type: cc.SpriteFrame,
    serialzable: true
  }
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxHYW1lX0xvY2FsX1ZhcmlibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIkZyYWN0aW9uIiwiR29sZCIsIkN1cnJlbnRfTWFwIiwidHlwZSIsImNjIiwiU3ByaXRlRnJhbWUiLCJzZXJpYWx6YWJsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDaEI7QUFDQUMsRUFBQUEsUUFBUSxFQUFFLENBRk07QUFHaEI7QUFDQUMsRUFBQUEsSUFBSSxFQUFFLENBSlU7QUFLaEI7QUFDQUMsRUFBQUEsV0FBVyxFQUFFO0FBQ1osZUFBUyxJQURHO0FBRVpDLElBQUFBLElBQUksRUFBRUMsRUFBRSxDQUFDQyxXQUZHO0FBR1pDLElBQUFBLFdBQVcsRUFBRTtBQUhEO0FBTkcsQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5ri45oiP55WM6Z2i55qE5bGA6YOo5Y+Y6YePXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG5cdC8v5YiG5pWw57uf6K6hXHJcblx0RnJhY3Rpb246IDAsXHJcblx0Ly/ojrflvpfph5HluIFcclxuXHRHb2xkOiAwLFxyXG5cdC8v5b2T5YmN5Zyw5Zu+XHJcblx0Q3VycmVudF9NYXA6IHtcclxuXHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHR0eXBlOiBjYy5TcHJpdGVGcmFtZSxcclxuXHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdH0sXHJcbn07XG4iXX0=