
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Email_Information.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1c8bc2GdkJAwamUQNO6/X0g', 'Email_Information');
// resources/script/Email/Email_Information.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Email_Information: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //邮件信息页面
    Email_Title: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //邮件标题
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  Open_Email: function Open_Email() {
    var self = this;
    var This_Title = this.Email_Title.getComponent(cc.Label).string;
    WeChat.Loading_Email();

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var Title = Email_Local_Variable.Email[i].Email_Title;

      if (This_Title === Title) {
        //当前点击的邮件
        console.log("当前邮件内容为1：", Email_Local_Variable.Email[i]); //为当前邮件新建节点

        var New_Email_Information = cc.instantiate(this.Email_Information);
        this.Canvas.parent.parent.parent.parent.addChild(New_Email_Information); //设置节点即邮件信息界面的位置

        New_Email_Information.setPosition(0, 0); // if(Email_Local_Variable.Email[i].Enclosure===false)New_Email_Information.Determine.Button.interactable = false;
        //载入邮件信息

        var Time = new Date(parseInt(Email_Local_Variable.Email[i].Time)).toLocaleString().replace(/:\d{1,2}$/, ' ');
        New_Email_Information.getChildByName("Email_Title").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Title;
        New_Email_Information.getChildByName("Email_Content").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Content;
        New_Email_Information.getChildByName("Diamond").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Diamond;
        New_Email_Information.getChildByName("Gold").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Gold;
        New_Email_Information.getChildByName("Compassion").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Compassion;
        New_Email_Information.getChildByName("Time").getComponent(cc.Label).string = "" + Time; //将邮件设为已读

        WeChat.Read(Email_Local_Variable.Email[i]._id);
        console.log("已将邮件设为已读");
        console.log("邮件id:", Email_Local_Variable.Email[i]._id);
        break;
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxFbWFpbF9JbmZvcm1hdGlvbi5qcyJdLCJuYW1lcyI6WyJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkVtYWlsX0luZm9ybWF0aW9uIiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiRW1haWxfVGl0bGUiLCJMYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJPcGVuX0VtYWlsIiwic2VsZiIsIlRoaXNfVGl0bGUiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJXZUNoYXQiLCJMb2FkaW5nX0VtYWlsIiwiaSIsIkVtYWlsIiwibGVuZ3RoIiwiVGl0bGUiLCJjb25zb2xlIiwibG9nIiwiTmV3X0VtYWlsX0luZm9ybWF0aW9uIiwiaW5zdGFudGlhdGUiLCJwYXJlbnQiLCJhZGRDaGlsZCIsInNldFBvc2l0aW9uIiwiVGltZSIsIkRhdGUiLCJwYXJzZUludCIsInRvTG9jYWxlU3RyaW5nIiwicmVwbGFjZSIsImdldENoaWxkQnlOYW1lIiwiRW1haWxfQ29udGVudCIsIkVtYWlsX0RpYW1vbmQiLCJFbWFpbF9Hb2xkIiwiRW1haWxfQ29tcGFzc2lvbiIsIlJlYWQiLCJfaWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFNQSxvQkFBb0IsR0FBR0MsT0FBTyxDQUFDLHdDQUFELENBQXBDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsaUJBQWlCLEVBQUM7QUFDZCxpQkFBUSxJQURNO0FBRXZCQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGZTtBQUd2QkMsTUFBQUEsV0FBVyxFQUFDO0FBSFcsS0FEVjtBQUtOO0FBQ0ZDLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFakJILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxLQUZTO0FBR2pCRixNQUFBQSxXQUFXLEVBQUM7QUFISyxLQU5KO0FBVU47QUFDRkcsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csSUFGTDtBQUdaSixNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQVhDLEdBSFA7QUFzQkw7QUFFQUssRUFBQUEsVUFBVSxFQUFFLHNCQUFXO0FBQ25CLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsVUFBVSxHQUFDLEtBQUtOLFdBQUwsQ0FBaUJPLFlBQWpCLENBQThCZixFQUFFLENBQUNTLEtBQWpDLEVBQXdDTyxNQUF2RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLGFBQVA7O0FBR0EsU0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUNyQixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCQyxNQUF6QyxFQUFnREYsQ0FBQyxFQUFqRCxFQUFvRDtBQUNoRCxVQUFJRyxLQUFLLEdBQUN4QixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QlgsV0FBeEM7O0FBRUEsVUFBR00sVUFBVSxLQUFHUSxLQUFoQixFQUFzQjtBQUNsQjtBQUNBQyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCMUIsb0JBQW9CLENBQUNzQixLQUFyQixDQUEyQkQsQ0FBM0IsQ0FBeEIsRUFGa0IsQ0FHbEI7O0FBQ0EsWUFBSU0scUJBQXFCLEdBQUd6QixFQUFFLENBQUMwQixXQUFILENBQWUsS0FBS3RCLGlCQUFwQixDQUE1QjtBQUNBLGFBQUtNLE1BQUwsQ0FBWWlCLE1BQVosQ0FBbUJBLE1BQW5CLENBQTBCQSxNQUExQixDQUFpQ0EsTUFBakMsQ0FBd0NDLFFBQXhDLENBQWlESCxxQkFBakQsRUFMa0IsQ0FNbEI7O0FBQ0FBLFFBQUFBLHFCQUFxQixDQUFDSSxXQUF0QixDQUFrQyxDQUFsQyxFQUFvQyxDQUFwQyxFQVBrQixDQVFsQjtBQUNBOztBQUNBLFlBQUlDLElBQUksR0FBQyxJQUFJQyxJQUFKLENBQVNDLFFBQVEsQ0FBQ2xDLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCVyxJQUEvQixDQUFqQixFQUF1REcsY0FBdkQsR0FBd0VDLE9BQXhFLENBQWdGLFdBQWhGLEVBQTRGLEdBQTVGLENBQVQ7QUFDQVQsUUFBQUEscUJBQXFCLENBQUNVLGNBQXRCLENBQXFDLGFBQXJDLEVBQW9EcEIsWUFBcEQsQ0FBaUVmLEVBQUUsQ0FBQ1MsS0FBcEUsRUFBMkVPLE1BQTNFLEdBQWtGLEtBQUdsQixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QlgsV0FBbkg7QUFDQWlCLFFBQUFBLHFCQUFxQixDQUFDVSxjQUF0QixDQUFxQyxlQUFyQyxFQUFzRHBCLFlBQXRELENBQW1FZixFQUFFLENBQUNTLEtBQXRFLEVBQTZFTyxNQUE3RSxHQUFvRixLQUFHbEIsb0JBQW9CLENBQUNzQixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJpQixhQUFySDtBQUNBWCxRQUFBQSxxQkFBcUIsQ0FBQ1UsY0FBdEIsQ0FBcUMsU0FBckMsRUFBZ0RwQixZQUFoRCxDQUE2RGYsRUFBRSxDQUFDUyxLQUFoRSxFQUF1RU8sTUFBdkUsR0FBOEUsS0FBR2xCLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCa0IsYUFBL0c7QUFDQVosUUFBQUEscUJBQXFCLENBQUNVLGNBQXRCLENBQXFDLE1BQXJDLEVBQTZDcEIsWUFBN0MsQ0FBMERmLEVBQUUsQ0FBQ1MsS0FBN0QsRUFBb0VPLE1BQXBFLEdBQTJFLEtBQUdsQixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4Qm1CLFVBQTVHO0FBQ0FiLFFBQUFBLHFCQUFxQixDQUFDVSxjQUF0QixDQUFxQyxZQUFyQyxFQUFtRHBCLFlBQW5ELENBQWdFZixFQUFFLENBQUNTLEtBQW5FLEVBQTBFTyxNQUExRSxHQUFpRixLQUFHbEIsb0JBQW9CLENBQUNzQixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJvQixnQkFBbEg7QUFDQWQsUUFBQUEscUJBQXFCLENBQUNVLGNBQXRCLENBQXFDLE1BQXJDLEVBQTZDcEIsWUFBN0MsQ0FBMERmLEVBQUUsQ0FBQ1MsS0FBN0QsRUFBb0VPLE1BQXBFLEdBQTJFLEtBQUdjLElBQTlFLENBaEJrQixDQWlCbEI7O0FBQ0FiLFFBQUFBLE1BQU0sQ0FBQ3VCLElBQVAsQ0FBWTFDLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCc0IsR0FBMUM7QUFDQWxCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVo7QUFDQUQsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQjFCLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCc0IsR0FBbEQ7QUFDQTtBQUNIO0FBQ0o7QUFDSjtBQXpESSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9vemCrueuseWIl+ihqFxyXG5jb25zdCBFbWFpbF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL0VtYWlsX0xvY2FsX1ZhcmlhYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgRW1haWxfSW5mb3JtYXRpb246e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICB9LC8v6YKu5Lu25L+h5oGv6aG16Z2iXHJcbiAgICAgICAgRW1haWxfVGl0bGU6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sLy/pgq7ku7bmoIfpophcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBPcGVuX0VtYWlsOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdmFyIFRoaXNfVGl0bGU9dGhpcy5FbWFpbF9UaXRsZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICBXZUNoYXQuTG9hZGluZ19FbWFpbCgpO1xyXG4gICAgICAgIFxyXG5cclxuICAgICAgICBmb3IodmFyIGk9MDtpPEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICB2YXIgVGl0bGU9RW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfVGl0bGU7XHJcblxyXG4gICAgICAgICAgICBpZihUaGlzX1RpdGxlPT09VGl0bGUpe1xyXG4gICAgICAgICAgICAgICAgLy/lvZPliY3ngrnlh7vnmoTpgq7ku7ZcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN6YKu5Lu25YaF5a655Li6Me+8mlwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldKTtcclxuICAgICAgICAgICAgICAgIC8v5Li65b2T5YmN6YKu5Lu25paw5bu66IqC54K5XHJcbiAgICAgICAgICAgICAgICB2YXIgTmV3X0VtYWlsX0luZm9ybWF0aW9uID0gY2MuaW5zdGFudGlhdGUodGhpcy5FbWFpbF9JbmZvcm1hdGlvbik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LnBhcmVudC5wYXJlbnQuYWRkQ2hpbGQoTmV3X0VtYWlsX0luZm9ybWF0aW9uKTtcclxuICAgICAgICAgICAgICAgIC8v6K6+572u6IqC54K55Y2z6YKu5Lu25L+h5oGv55WM6Z2i55qE5L2N572uXHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIC8vIGlmKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZT09PWZhbHNlKU5ld19FbWFpbF9JbmZvcm1hdGlvbi5EZXRlcm1pbmUuQnV0dG9uLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy/ovb3lhaXpgq7ku7bkv6Hmga9cclxuICAgICAgICAgICAgICAgIHZhciBUaW1lPW5ldyBEYXRlKHBhcnNlSW50KEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLlRpbWUpKS50b0xvY2FsZVN0cmluZygpLnJlcGxhY2UoLzpcXGR7MSwyfSQvLCcgJyk7XHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uZ2V0Q2hpbGRCeU5hbWUoXCJFbWFpbF9UaXRsZVwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0VtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlO1xyXG4gICAgICAgICAgICAgICAgTmV3X0VtYWlsX0luZm9ybWF0aW9uLmdldENoaWxkQnlOYW1lKFwiRW1haWxfQ29udGVudFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0VtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX0NvbnRlbnQ7XHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uZ2V0Q2hpbGRCeU5hbWUoXCJEaWFtb25kXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfRGlhbW9uZDtcclxuICAgICAgICAgICAgICAgIE5ld19FbWFpbF9JbmZvcm1hdGlvbi5nZXRDaGlsZEJ5TmFtZShcIkdvbGRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9Hb2xkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0VtYWlsX0luZm9ybWF0aW9uLmdldENoaWxkQnlOYW1lKFwiQ29tcGFzc2lvblwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0VtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX0NvbXBhc3Npb247XHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uZ2V0Q2hpbGRCeU5hbWUoXCJUaW1lXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGltZTtcclxuICAgICAgICAgICAgICAgIC8v5bCG6YKu5Lu26K6+5Li65bey6K+7XHJcbiAgICAgICAgICAgICAgICBXZUNoYXQuUmVhZChFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5faWQpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLlt7LlsIbpgq7ku7borr7kuLrlt7Lor7tcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIumCruS7tmlkOlwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLl9pZCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgXHJcblxyXG59KTtcclxuIl19