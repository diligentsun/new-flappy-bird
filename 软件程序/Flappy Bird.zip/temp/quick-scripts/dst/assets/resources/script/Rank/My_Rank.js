
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/My_Rank.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e4df5WVfNREMp/E8B3qtIDN', 'My_Rank');
// resources/script/Rank/My_Rank.js

"use strict";

//加载自己的成绩信息
cc.Class({
  "extends": cc.Component,
  properties: {
    User_Heading_Image: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //使用者头像
    User_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //使用者名字		
    Best_Scroe_Text: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  //加载自己的信息
  onLoad: function onLoad() {
    this.Loading_Image(this, Global_Variable.User_Head_Image);
    this.User_Name.string = Global_Variable.User_Name;
    this.Best_Scroe_Text.string = Global_Variable.Best_Score + "分";
  },
  start: function start() {},
  // update (dt) {},
  //加载图片
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.User_Heading_Image.getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXE15X1JhbmsuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJVc2VyX0hlYWRpbmdfSW1hZ2UiLCJ0eXBlIiwiU3ByaXRlIiwic2VyaWFsemFibGUiLCJVc2VyX05hbWUiLCJMYWJlbCIsIkJlc3RfU2Nyb2VfVGV4dCIsIm9uTG9hZCIsIkxvYWRpbmdfSW1hZ2UiLCJHbG9iYWxfVmFyaWFibGUiLCJVc2VyX0hlYWRfSW1hZ2UiLCJzdHJpbmciLCJCZXN0X1Njb3JlIiwic3RhcnQiLCJzZWxmIiwiSW1hZ2VfUGF0aCIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNkQyxJQUFBQSxrQkFBa0IsRUFBQztBQUVoQixpQkFBUSxJQUZRO0FBR2hCQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFIUTtBQUloQkMsTUFBQUEsV0FBVyxFQUFDO0FBSkksS0FETDtBQU1aO0FBQ0ZDLElBQUFBLFNBQVMsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFUEgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRkQ7QUFHUEYsTUFBQUEsV0FBVyxFQUFDO0FBSEwsS0FQSTtBQVdaO0FBQ0ZHLElBQUFBLGVBQWUsRUFBQztBQUNiLGlCQUFRLElBREs7QUFFYkwsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRks7QUFHYkYsTUFBQUEsV0FBVyxFQUFDO0FBSEM7QUFaRixHQUhQO0FBc0JSO0FBQ0lJLEVBQUFBLE1BQU0sRUFBRSxrQkFBVTtBQUNwQixTQUFLQyxhQUFMLENBQW1CLElBQW5CLEVBQXdCQyxlQUFlLENBQUNDLGVBQXhDO0FBQ0EsU0FBS04sU0FBTCxDQUFlTyxNQUFmLEdBQXNCRixlQUFlLENBQUNMLFNBQXRDO0FBQ0EsU0FBS0UsZUFBTCxDQUFxQkssTUFBckIsR0FBNEJGLGVBQWUsQ0FBQ0csVUFBaEIsR0FBMkIsR0FBdkQ7QUFFQSxHQTVCTTtBQThCTEMsRUFBQUEsS0E5QkssbUJBOEJJLENBRVIsQ0FoQ0k7QUFrQ0w7QUFDSDtBQUNBTCxFQUFBQSxhQXBDUSx5QkFvQ01NLElBcENOLEVBb0NXQyxVQXBDWCxFQW9Dc0I7QUFDM0IsUUFBSUMsSUFBSSxHQUFDRCxVQUFUO0FBQ0FuQixJQUFBQSxFQUFFLENBQUNxQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZGYsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVNtQixHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJM0IsRUFBRSxDQUFDNEIsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTkssUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQk4sR0FBbkI7QUFDQTs7QUFDRE4sTUFBQUEsSUFBSSxDQUFDZCxrQkFBTCxDQUF3QjJCLFlBQXhCLENBQXFDL0IsRUFBRSxDQUFDTSxNQUF4QyxFQUFnRDBCLFdBQWhELEdBQTRETCxLQUE1RDtBQUVBLEtBVkQ7QUFXRjtBQWpETyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+WKoOi9veiHquW3seeahOaIkOe7qeS/oeaBr1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cdFx0VXNlcl9IZWFkaW5nX0ltYWdlOntcclxuXHJcblx0XHRcdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHRcdFx0dHlwZTpjYy5TcHJpdGUsXHJcblx0XHRcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSwvL+S9v+eUqOiAheWktOWDj1xyXG5cdFx0VXNlcl9OYW1lOntcclxuXHRcdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHRcdFx0dHlwZTpjYy5MYWJlbCxcclxuXHRcdFx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcblx0XHR9LC8v5L2/55So6ICF5ZCN5a2XXHRcdFxyXG5cdFx0QmVzdF9TY3JvZV9UZXh0OntcclxuXHRcdFx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcbiAgICB9LFxyXG5cclxuXHQvL+WKoOi9veiHquW3seeahOS/oeaBr1xyXG4gICAgIG9uTG9hZDogZnVuY3Rpb24oKXtcclxuXHRcdCB0aGlzLkxvYWRpbmdfSW1hZ2UodGhpcyxHbG9iYWxfVmFyaWFibGUuVXNlcl9IZWFkX0ltYWdlKTtcclxuXHRcdCB0aGlzLlVzZXJfTmFtZS5zdHJpbmc9R2xvYmFsX1ZhcmlhYmxlLlVzZXJfTmFtZTtcclxuXHRcdCB0aGlzLkJlc3RfU2Nyb2VfVGV4dC5zdHJpbmc9R2xvYmFsX1ZhcmlhYmxlLkJlc3RfU2NvcmUrXCLliIZcIjtcclxuXHRcdCBcclxuXHQgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxuXHQvL+WKoOi9veWbvueJh1xyXG5cdExvYWRpbmdfSW1hZ2Uoc2VsZixJbWFnZV9QYXRoKXtcclxuXHRcdFx0XHRsZXQgX3VybD1JbWFnZV9QYXRoO1xyXG5cdFx0XHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0XHRcdHVybDpfdXJsLFxyXG5cdFx0XHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0XHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XHJcblx0XHRcdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0c2VsZi5Vc2VyX0hlYWRpbmdfSW1hZ2UuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9ZnJhbWU7XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHR9KVxyXG5cdH1cclxufSk7XHJcbiJdfQ==