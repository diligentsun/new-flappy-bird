
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Cancel_Closure.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c2475IN0ABFuY27U34UTn1M', 'Cancel_Closure');
// resources/script/Account_Management/Cancel_Closure.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    User_Id_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //Openid

  },
  start: function start() {
    WeChat.Cancel_Closure;
  },
  on_btn_click: function on_btn_click() {
    var Openid = this.User_Id_Show.getComponent(cc.Label).string;
    WeChat.Cancel_Closure(Openid);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQ2FuY2VsX0Nsb3N1cmUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJVc2VyX0lkX1Nob3ciLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsInN0YXJ0IiwiV2VDaGF0IiwiQ2FuY2VsX0Nsb3N1cmUiLCJvbl9idG5fY2xpY2siLCJPcGVuaWQiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNkQyxJQUFBQSxZQUFZLEVBQUM7QUFDWixpQkFBUSxJQURJO0FBRVpDLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxLQUZJO0FBR1pDLE1BQUFBLFdBQVcsRUFBQztBQUhBLEtBREMsQ0FLWjs7QUFMWSxHQUhQO0FBWUxDLEVBQUFBLEtBWkssbUJBWUk7QUFDYkMsSUFBQUEsTUFBTSxDQUFDQyxjQUFQO0FBQ0ssR0FkSTtBQWVSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEIsUUFBSUMsTUFBTSxHQUFDLEtBQUtSLFlBQUwsQ0FBa0JTLFlBQWxCLENBQStCYixFQUFFLENBQUNNLEtBQWxDLEVBQXlDUSxNQUFwRDtBQUNBTCxJQUFBQSxNQUFNLENBQUNDLGNBQVAsQ0FBc0JFLE1BQXRCO0FBQ0EsR0FsQk8sQ0FtQkw7O0FBbkJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHRcdFVzZXJfSWRfU2hvdzp7XHJcblx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcblx0XHR9LC8vT3BlbmlkXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbldlQ2hhdC5DYW5jZWxfQ2xvc3VyZVxyXG4gICAgfSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIE9wZW5pZD10aGlzLlVzZXJfSWRfU2hvdy5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuXHRcdFdlQ2hhdC5DYW5jZWxfQ2xvc3VyZShPcGVuaWQpO1xyXG5cdH1cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19