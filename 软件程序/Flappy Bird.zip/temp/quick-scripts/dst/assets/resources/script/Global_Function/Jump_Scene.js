
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Jump_Scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd2897L4SatGvI7ZZ+eiw+yr', 'Jump_Scene');
// resources/script/Global_Function/Jump_Scene.js

"use strict";

//界面跳转
cc.Class({
  "extends": cc.Component,
  properties: {
    scene: ""
  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    cc.director.loadScene(this.scene);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcSnVtcF9TY2VuZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNjZW5lIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJkaXJlY3RvciIsImxvYWRTY2VuZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsS0FBSyxFQUFFO0FBREksR0FISjtBQU9SQyxFQUFBQSxLQVBRLG1CQU9BLENBRVAsQ0FUTztBQVVSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEJOLElBQUFBLEVBQUUsQ0FBQ08sUUFBSCxDQUFZQyxTQUFaLENBQXNCLEtBQUtKLEtBQTNCO0FBQ0E7QUFaTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+eVjOmdoui3s+i9rFxyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRzY2VuZTogXCJcIixcclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Y2MuZGlyZWN0b3IubG9hZFNjZW5lKHRoaXMuc2NlbmUpO1xyXG5cdH1cclxufSk7XG4iXX0=