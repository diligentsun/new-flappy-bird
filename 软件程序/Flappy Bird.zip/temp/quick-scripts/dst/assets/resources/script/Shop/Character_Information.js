
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Character_Information.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2288aR73xZMqrncTej+w8ez', 'Character_Information');
// resources/script/Shop/Character_Information.js

"use strict";

//显示角色信息
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Buy_Character_Background: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    var self = this;
    var This_Name = this.Character_Name.getComponent(cc.Label).string;
    WeChat.Loading_Shop_Character();

    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var List_Name = Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;

      if (This_Name === List_Name) {
        //当前点击的角色
        var This_information = Shop_Character_Local_Varible.Shop_Character_User[i];
        var New_Buy_Character_Background = cc.instantiate(this.Buy_Character_Background);
        this.Canvas.parent.parent.parent.addChild(New_Buy_Character_Background);
        New_Buy_Character_Background.setPosition(0, -300);
        console.log("图片地址为", This_information);
        this.Loading_Image(New_Buy_Character_Background, This_information.Character_Head_Image);
        New_Buy_Character_Background.getChildByName("Character_Name").getComponent(cc.Label).string = "" + This_information.Character_Name;
        New_Buy_Character_Background.getChildByName("Character_Synopsis").getComponent(cc.Label).string = "" + This_information.Character_Synopsis;
        New_Buy_Character_Background.getChildByName("Bounce_Power_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Jump_Speed;
        New_Buy_Character_Background.getChildByName("Weight_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fall_Speed;
        New_Buy_Character_Background.getChildByName("Speed_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fly_Speed;
        New_Buy_Character_Background.getChildByName("Skill_Name_Label").getComponent(cc.Label).string = "" + This_information.Skill_Name;
        New_Buy_Character_Background.getChildByName("Skill_Effect_Label").getComponent(cc.Label).string = "" + This_information.Skill_Synopsis;
        New_Buy_Character_Background.getChildByName("Price_Label").getComponent(cc.Label).string = "" + This_information.Character_Price;
        New_Buy_Character_Background.getChildByName("Character_Id").getComponent(cc.Label).string = "" + This_information.Character_Id;
        New_Buy_Character_Background.getChildByName("Background1").getComponent(cc.Sprite).fillRange = This_information.Character_Jump_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background2").getComponent(cc.Sprite).fillRange = This_information.Character_Fall_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background3").getComponent(cc.Sprite).fillRange = This_information.Character_Fly_Speed / 100;
        break;
      }
    }
  },
  update: function update(dt) {},
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Character_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXENoYXJhY3Rlcl9JbmZvcm1hdGlvbi5qcyJdLCJuYW1lcyI6WyJTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kIiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQ2hhcmFjdGVyX05hbWUiLCJMYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJvbl9idG5fY2xpY2siLCJzZWxmIiwiVGhpc19OYW1lIiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiV2VDaGF0IiwiTG9hZGluZ19TaG9wX0NoYXJhY3RlciIsImkiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIiwibGVuZ3RoIiwiTGlzdF9OYW1lIiwiVGhpc19pbmZvcm1hdGlvbiIsIk5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQiLCJpbnN0YW50aWF0ZSIsInBhcmVudCIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJjb25zb2xlIiwibG9nIiwiTG9hZGluZ19JbWFnZSIsIkNoYXJhY3Rlcl9IZWFkX0ltYWdlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJDaGFyYWN0ZXJfU3lub3BzaXMiLCJDaGFyYWN0ZXJfSnVtcF9TcGVlZCIsIkNoYXJhY3Rlcl9GYWxsX1NwZWVkIiwiQ2hhcmFjdGVyX0ZseV9TcGVlZCIsIlNraWxsX05hbWUiLCJTa2lsbF9TeW5vcHNpcyIsIkNoYXJhY3Rlcl9QcmljZSIsIkNoYXJhY3Rlcl9JZCIsIlNwcml0ZSIsImZpbGxSYW5nZSIsInVwZGF0ZSIsImR0IiwiSW1hZ2VfUGF0aCIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwic3ByaXRlRnJhbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSw0QkFBNEIsR0FBR0MsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsd0JBQXdCLEVBQUM7QUFDckIsaUJBQVEsSUFEYTtBQUU5QkMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRnNCO0FBRzlCQyxNQUFBQSxXQUFXLEVBQUM7QUFIa0IsS0FEakI7QUFNUkMsSUFBQUEsY0FBYyxFQUFDO0FBQ1gsaUJBQVEsSUFERztBQUVwQkgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRlk7QUFHcEJGLE1BQUFBLFdBQVcsRUFBQztBQUhRLEtBTlA7QUFXUkcsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csSUFGTDtBQUdaSixNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQVhDLEdBSFA7QUFxQkw7QUFFQUssRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3JCLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsU0FBUyxHQUFDLEtBQUtOLGNBQUwsQ0FBb0JPLFlBQXBCLENBQWlDZixFQUFFLENBQUNTLEtBQXBDLEVBQTJDTyxNQUF6RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLHNCQUFQOztBQUdBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDckIsNEJBQTRCLENBQUNzQixtQkFBN0IsQ0FBaURDLE1BQS9ELEVBQXNFRixDQUFDLEVBQXZFLEVBQTBFO0FBQ3RFLFVBQUlHLFNBQVMsR0FBQ3hCLDRCQUE0QixDQUFDc0IsbUJBQTdCLENBQWlERCxDQUFqRCxFQUFvRFgsY0FBbEU7O0FBRUEsVUFBR00sU0FBUyxLQUFHUSxTQUFmLEVBQXlCO0FBQ3JCO0FBQ0EsWUFBSUMsZ0JBQWdCLEdBQUN6Qiw0QkFBNEIsQ0FBQ3NCLG1CQUE3QixDQUFpREQsQ0FBakQsQ0FBckI7QUFFQSxZQUFJSyw0QkFBNEIsR0FBR3hCLEVBQUUsQ0FBQ3lCLFdBQUgsQ0FBZSxLQUFLckIsd0JBQXBCLENBQW5DO0FBQ0EsYUFBS00sTUFBTCxDQUFZZ0IsTUFBWixDQUFtQkEsTUFBbkIsQ0FBMEJBLE1BQTFCLENBQWlDQyxRQUFqQyxDQUEwQ0gsNEJBQTFDO0FBQ0FBLFFBQUFBLDRCQUE0QixDQUFDSSxXQUE3QixDQUF5QyxDQUF6QyxFQUEyQyxDQUFDLEdBQTVDO0FBQ0FDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBb0JQLGdCQUFwQjtBQUVBLGFBQUtRLGFBQUwsQ0FBbUJQLDRCQUFuQixFQUFnREQsZ0JBQWdCLENBQUNTLG9CQUFqRTtBQUNBUixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsZ0JBQTVDLEVBQThEbEIsWUFBOUQsQ0FBMkVmLEVBQUUsQ0FBQ1MsS0FBOUUsRUFBcUZPLE1BQXJGLEdBQTRGLEtBQUdPLGdCQUFnQixDQUFDZixjQUFoSDtBQUNBZ0IsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ1csa0JBQXBIO0FBQ0FWLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QywyQkFBNUMsRUFBeUVsQixZQUF6RSxDQUFzRmYsRUFBRSxDQUFDUyxLQUF6RixFQUFnR08sTUFBaEcsR0FBdUcsS0FBR08sZ0JBQWdCLENBQUNZLG9CQUEzSDtBQUNBWCxRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMscUJBQTVDLEVBQW1FbEIsWUFBbkUsQ0FBZ0ZmLEVBQUUsQ0FBQ1MsS0FBbkYsRUFBMEZPLE1BQTFGLEdBQWlHLEtBQUdPLGdCQUFnQixDQUFDYSxvQkFBckg7QUFDQVosUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ2MsbUJBQXBIO0FBQ0FiLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxrQkFBNUMsRUFBZ0VsQixZQUFoRSxDQUE2RWYsRUFBRSxDQUFDUyxLQUFoRixFQUF1Rk8sTUFBdkYsR0FBOEYsS0FBR08sZ0JBQWdCLENBQUNlLFVBQWxIO0FBQ0FkLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxvQkFBNUMsRUFBa0VsQixZQUFsRSxDQUErRWYsRUFBRSxDQUFDUyxLQUFsRixFQUF5Rk8sTUFBekYsR0FBZ0csS0FBR08sZ0JBQWdCLENBQUNnQixjQUFwSDtBQUNBZixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsYUFBNUMsRUFBMkRsQixZQUEzRCxDQUF3RWYsRUFBRSxDQUFDUyxLQUEzRSxFQUFrRk8sTUFBbEYsR0FBeUYsS0FBR08sZ0JBQWdCLENBQUNpQixlQUE3RztBQUNBaEIsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGNBQTVDLEVBQTREbEIsWUFBNUQsQ0FBeUVmLEVBQUUsQ0FBQ1MsS0FBNUUsRUFBbUZPLE1BQW5GLEdBQTBGLEtBQUdPLGdCQUFnQixDQUFDa0IsWUFBOUc7QUFDQWpCLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxhQUE1QyxFQUEyRGxCLFlBQTNELENBQXdFZixFQUFFLENBQUMwQyxNQUEzRSxFQUFtRkMsU0FBbkYsR0FBNkZwQixnQkFBZ0IsQ0FBQ1ksb0JBQWpCLEdBQXNDLEdBQW5JO0FBQ0FYLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxhQUE1QyxFQUEyRGxCLFlBQTNELENBQXdFZixFQUFFLENBQUMwQyxNQUEzRSxFQUFtRkMsU0FBbkYsR0FBNkZwQixnQkFBZ0IsQ0FBQ2Esb0JBQWpCLEdBQXNDLEdBQW5JO0FBQ0FaLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxhQUE1QyxFQUEyRGxCLFlBQTNELENBQXdFZixFQUFFLENBQUMwQyxNQUEzRSxFQUFtRkMsU0FBbkYsR0FBNkZwQixnQkFBZ0IsQ0FBQ2MsbUJBQWpCLEdBQXFDLEdBQWxJO0FBQ0E7QUFDSDtBQUNKO0FBQ0osR0F6REk7QUEwRExPLEVBQUFBLE1BMURLLGtCQTBER0MsRUExREgsRUEwRE8sQ0FBRSxDQTFEVDtBQTJETmQsRUFBQUEsYUEzRE0seUJBMkRRbEIsSUEzRFIsRUEyRGFpQyxVQTNEYixFQTJEd0I7QUFDL0IsUUFBSUMsSUFBSSxHQUFDRCxVQUFUO0FBQ0E5QyxJQUFBQSxFQUFFLENBQUNnRCxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZDFDLE1BQUFBLElBQUksRUFBQztBQUZTLEtBQWYsRUFHRSxVQUFTOEMsR0FBVCxFQUFhQyxPQUFiLEVBQXFCQyxJQUFyQixFQUEwQjtBQUMzQixVQUFJQyxLQUFLLEdBQUMsSUFBSXRELEVBQUUsQ0FBQ3VELFdBQVAsQ0FBbUJILE9BQW5CLENBQVY7O0FBQ0EsVUFBR0QsR0FBSCxFQUFPO0FBQ050QixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CcUIsR0FBbkI7QUFDQTs7QUFDRHRDLE1BQUFBLElBQUksQ0FBQ29CLGNBQUwsQ0FBb0IsaUJBQXBCLEVBQXVDbEIsWUFBdkMsQ0FBb0RmLEVBQUUsQ0FBQzBDLE1BQXZELEVBQStEYyxXQUEvRCxHQUEyRUYsS0FBM0U7QUFFQSxLQVZEO0FBV0Q7QUF4RVEsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/mmL7npLrop5LoibLkv6Hmga9cclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDaGFyYWN0ZXJfTmFtZTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgVGhpc19OYW1lPXRoaXMuQ2hhcmFjdGVyX05hbWUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIoKTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXIubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBMaXN0X05hbWU9U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2ldLkNoYXJhY3Rlcl9OYW1lO1xyXG5cclxuICAgICAgICAgICAgaWYoVGhpc19OYW1lPT09TGlzdF9OYW1lKXtcclxuICAgICAgICAgICAgICAgIC8v5b2T5YmN54K55Ye755qE6KeS6ImyXHJcbiAgICAgICAgICAgICAgICB2YXIgVGhpc19pbmZvcm1hdGlvbj1TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXJbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkJ1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LnBhcmVudC5hZGRDaGlsZChOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kKTtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuc2V0UG9zaXRpb24oMCwtMzAwKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Zu+54mH5Zyw5Z2A5Li6XCIsVGhpc19pbmZvcm1hdGlvbik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQsVGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSGVhZF9JbWFnZSk7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9TeW5vcHNpc1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX1N5bm9wc2lzO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJvdW5jZV9Qb3dlcl9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9KdW1wX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIldlaWdodF9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GYWxsX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNwZWVkX051bWJlcl9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0ZseV9TcGVlZDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJTa2lsbF9OYW1lX0xhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGhpc19pbmZvcm1hdGlvbi5Ta2lsbF9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNraWxsX0VmZmVjdF9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uU2tpbGxfU3lub3BzaXM7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiUHJpY2VfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9QcmljZTtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfSWRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9JZDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJCYWNrZ3JvdW5kMVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5maWxsUmFuZ2U9VGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSnVtcF9TcGVlZC8xMDA7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZDJcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuZmlsbFJhbmdlPVRoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0ZhbGxfU3BlZWQvMTAwO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmQzXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLmZpbGxSYW5nZT1UaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GbHlfU3BlZWQvMTAwO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdXBkYXRlIChkdCkge30sXHJcbiAgXHRMb2FkaW5nX0ltYWdlKHNlbGYsSW1hZ2VfUGF0aCl7XHJcblx0XHRsZXQgX3VybD1JbWFnZV9QYXRoO1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6X3VybCxcclxuXHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdH1cclxuXHRcdFx0c2VsZi5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9JbWFnZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcclxuXHRcdFx0XHJcblx0XHR9KVxyXG59XHJcblxyXG59KTtcclxuIl19