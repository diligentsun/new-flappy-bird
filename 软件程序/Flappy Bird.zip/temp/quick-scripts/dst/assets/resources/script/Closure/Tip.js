
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Closure/Tip.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '92d67ihDSlIL5FHV3xxiZud', 'Tip');
// resources/script/Closure/Tip.js

"use strict";

//弹出提示框
cc.Class({
  "extends": cc.Component,
  properties: {
    Tip: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //提示框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    } //玩家框节点

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建申诉信息框
    var New_Tip = cc.instantiate(this.Tip);
    this.Canvas.parent.addChild(New_Tip);
    New_Tip.setPosition(0, 0);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXENsb3N1cmVcXFRpcC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIlRpcCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkNhbnZhcyIsIk5vZGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIk5ld19UaXAiLCJpbnN0YW50aWF0ZSIsInBhcmVudCIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLEdBQUcsRUFBRTtBQUNKLGlCQUFTLElBREw7QUFFSkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRkw7QUFHSkMsTUFBQUEsV0FBVyxFQUFFO0FBSFQsS0FETTtBQUtSO0FBQ0hDLElBQUFBLE1BQU0sRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUEgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNTLElBRkY7QUFHUEYsTUFBQUEsV0FBVyxFQUFFO0FBSE4sS0FORyxDQVVSOztBQVZRLEdBSEo7QUFnQlJHLEVBQUFBLEtBaEJRLG1CQWdCQSxDQUVQLENBbEJPO0FBbUJSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEI7QUFDQSxRQUFJQyxPQUFPLEdBQUdaLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlLEtBQUtULEdBQXBCLENBQWQ7QUFDQSxTQUFLSSxNQUFMLENBQVlNLE1BQVosQ0FBbUJDLFFBQW5CLENBQTRCSCxPQUE1QjtBQUNBQSxJQUFBQSxPQUFPLENBQUNJLFdBQVIsQ0FBb0IsQ0FBcEIsRUFBdUIsQ0FBdkI7QUFDQSxHQXhCTyxDQXlCUjs7QUF6QlEsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lvLnlh7rmj5DnpLrmoYZcclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0VGlwOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+aPkOekuuahhlxyXG5cdFx0Q2FudmFzOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/njqnlrrbmoYboioLngrlcclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Ly/liJvlu7rnlLPor4nkv6Hmga/moYZcclxuXHRcdHZhciBOZXdfVGlwID0gY2MuaW5zdGFudGlhdGUodGhpcy5UaXApO1xyXG5cdFx0dGhpcy5DYW52YXMucGFyZW50LmFkZENoaWxkKE5ld19UaXApO1xyXG5cdFx0TmV3X1RpcC5zZXRQb3NpdGlvbigwLCAwKTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=