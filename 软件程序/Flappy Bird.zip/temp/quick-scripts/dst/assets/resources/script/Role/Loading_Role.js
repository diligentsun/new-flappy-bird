
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Role/Loading_Role.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '70024YCCxVGfLoGElakA4f/', 'Loading_Role');
// resources/script/Role/Loading_Role.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var User_Have_Character_Local_Varible = require('../Local_Variible/User_Have_Character_Local_Varible');

var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Character_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var self = this;
    User_Have_Character_Local_Varible.User_Have_Character = null;
    WeChat.Loading_Character();
    this._Is_Loading == true;
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && User_Have_Character_Local_Varible.User_Have_Character != null) {
      this.Loading_Character();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("sprite").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Character: function Loading_Character() {
    //遍历User_Character_Information的表
    for (var i = 0; i < User_Have_Character_Local_Varible.User_Have_Character.length; i++) {
      //User_Character_Information放的是只有2个记录的小表(User_Have_Character)的信息
      var User_Character_Information = User_Have_Character_Local_Varible.User_Have_Character[i]; //User_Character_Number放的是Character的序号

      var User_Character_Number = User_Have_Character_Local_Varible.User_Have_Character[i].Character_Id; //判断用户是否有该小鸟
      //Global_Variable.openid是当前用户的openid

      if (Global_Variable.openid == User_Character_Information.openid) {
        // console.log("角色长度",User_Have_Character_Local_Varible.User_Have_Character.length);
        for (var j = 0; j < Shop_Character_Local_Varible.Shop_Character_User.length; j++) {
          if (User_Character_Number == Shop_Character_Local_Varible.Shop_Character_User[j].Character_Id) {
            var New_Character_Label = cc.instantiate(this.Character_Label);
            this.Character_View.addChild(New_Character_Label);
            this.Loading_Image(New_Character_Label, Shop_Character_Local_Varible.Shop_Character_User[j].Character_Head_Image);
            New_Character_Label.getChildByName("Character_Name").getComponent(cc.Label).string = "" + Shop_Character_Local_Varible.Shop_Character_User[j].Character_Name;
          }
        }
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJvbGVcXExvYWRpbmdfUm9sZS5qcyJdLCJuYW1lcyI6WyJVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQ2hhcmFjdGVyX0xhYmVsIiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQ2hhcmFjdGVyX1ZpZXciLCJOb2RlIiwiX0lzX0xvYWRpbmciLCJvbkxvYWQiLCJzZWxmIiwiVXNlcl9IYXZlX0NoYXJhY3RlciIsIldlQ2hhdCIsIkxvYWRpbmdfQ2hhcmFjdGVyIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIkxvYWRpbmdfSW1hZ2UiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJjb25zb2xlIiwibG9nIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsImkiLCJsZW5ndGgiLCJVc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbiIsIlVzZXJfQ2hhcmFjdGVyX051bWJlciIsIkNoYXJhY3Rlcl9JZCIsIkdsb2JhbF9WYXJpYWJsZSIsIm9wZW5pZCIsImoiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIiwiTmV3X0NoYXJhY3Rlcl9MYWJlbCIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJDaGFyYWN0ZXJfSGVhZF9JbWFnZSIsIkxhYmVsIiwic3RyaW5nIiwiQ2hhcmFjdGVyX05hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUEsaUNBQWlDLEdBQUdDLE9BQU8sQ0FBQyxxREFBRCxDQUFqRDs7QUFDQSxJQUFJQyw0QkFBNEIsR0FBR0QsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBRSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUVMQyxFQUFBQSxVQUFVLEVBQUU7QUFDZEMsSUFBQUEsZUFBZSxFQUFDO0FBQ2YsaUJBQVEsSUFETztBQUVmQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGTztBQUdmQyxNQUFBQSxXQUFXLEVBQUM7QUFIRyxLQURGO0FBTWRDLElBQUFBLGNBQWMsRUFBQztBQUNkLGlCQUFRLElBRE07QUFFZEgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLElBRk07QUFHZEYsTUFBQUEsV0FBVyxFQUFDO0FBSEUsS0FORDtBQVdmRyxJQUFBQSxXQUFXLEVBQUM7QUFYRyxHQUZQO0FBZ0JMO0FBRUNDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVTtBQUNyQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBZixJQUFBQSxpQ0FBaUMsQ0FBQ2dCLG1CQUFsQyxHQUFzRCxJQUF0RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLGlCQUFQO0FBQ0EsU0FBS0wsV0FBTCxJQUFrQixJQUFsQjtBQUNDLEdBdkJNO0FBeUJMTSxFQUFBQSxLQXpCSyxtQkF5QkksQ0FFUixDQTNCSTtBQTZCTEMsRUFBQUEsTUFBTSxFQUFDLGdCQUFVQyxFQUFWLEVBQWM7QUFDdkIsUUFBRyxLQUFLUixXQUFMLElBQWtCYixpQ0FBaUMsQ0FBQ2dCLG1CQUFsQyxJQUF1RCxJQUE1RSxFQUFpRjtBQUNoRixXQUFLRSxpQkFBTDtBQUNBLFdBQUtMLFdBQUwsR0FBaUIsS0FBakI7QUFDQTtBQUNELEdBbENPO0FBbUNSUyxFQUFBQSxhQW5DUSx5QkFtQ01QLElBbkNOLEVBbUNXUSxVQW5DWCxFQW1Dc0I7QUFDN0IsUUFBSUMsSUFBSSxHQUFDRCxVQUFUO0FBQ0FwQixJQUFBQSxFQUFFLENBQUNzQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZGhCLE1BQUFBLElBQUksRUFBQztBQUZTLEtBQWYsRUFHRSxVQUFTb0IsR0FBVCxFQUFhQyxPQUFiLEVBQXFCQyxJQUFyQixFQUEwQjtBQUMzQixVQUFJQyxLQUFLLEdBQUMsSUFBSTVCLEVBQUUsQ0FBQzZCLFdBQVAsQ0FBbUJILE9BQW5CLENBQVY7O0FBQ0EsVUFBR0QsR0FBSCxFQUFPO0FBQ05LLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJOLEdBQW5CO0FBQ0E7O0FBQ0RiLE1BQUFBLElBQUksQ0FBQ29CLGNBQUwsQ0FBb0IsUUFBcEIsRUFBOEJDLFlBQTlCLENBQTJDakMsRUFBRSxDQUFDa0MsTUFBOUMsRUFBc0RDLFdBQXRELEdBQWtFUCxLQUFsRTtBQUVBLEtBVkQ7QUFXRCxHQWhEUTtBQWlEUmIsRUFBQUEsaUJBakRRLCtCQWlEVztBQUNsQjtBQUNBLFNBQUksSUFBSXFCLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQ3ZDLGlDQUFpQyxDQUFDZ0IsbUJBQWxDLENBQXNEd0IsTUFBcEUsRUFBMkVELENBQUMsRUFBNUUsRUFBK0U7QUFDOUU7QUFDQSxVQUFJRSwwQkFBMEIsR0FBQ3pDLGlDQUFpQyxDQUFDZ0IsbUJBQWxDLENBQXNEdUIsQ0FBdEQsQ0FBL0IsQ0FGOEUsQ0FHOUU7O0FBQ0EsVUFBSUcscUJBQXFCLEdBQUMxQyxpQ0FBaUMsQ0FBQ2dCLG1CQUFsQyxDQUFzRHVCLENBQXRELEVBQXlESSxZQUFuRixDQUo4RSxDQUs5RTtBQUNHOztBQUNBLFVBQUdDLGVBQWUsQ0FBQ0MsTUFBaEIsSUFBd0JKLDBCQUEwQixDQUFDSSxNQUF0RCxFQUE2RDtBQUMvRDtBQUNBLGFBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDNUMsNEJBQTRCLENBQUM2QyxtQkFBN0IsQ0FBaURQLE1BQS9ELEVBQXNFTSxDQUFDLEVBQXZFLEVBQTBFO0FBQ3pFLGNBQUdKLHFCQUFxQixJQUFFeEMsNEJBQTRCLENBQUM2QyxtQkFBN0IsQ0FBaURELENBQWpELEVBQW9ESCxZQUE5RSxFQUEyRjtBQUMxRixnQkFBSUssbUJBQW1CLEdBQUM3QyxFQUFFLENBQUM4QyxXQUFILENBQWUsS0FBSzFDLGVBQXBCLENBQXhCO0FBQ0EsaUJBQUtJLGNBQUwsQ0FBb0J1QyxRQUFwQixDQUE2QkYsbUJBQTdCO0FBQ0EsaUJBQUsxQixhQUFMLENBQW1CMEIsbUJBQW5CLEVBQXVDOUMsNEJBQTRCLENBQUM2QyxtQkFBN0IsQ0FBaURELENBQWpELEVBQW9ESyxvQkFBM0Y7QUFDTUgsWUFBQUEsbUJBQW1CLENBQUNiLGNBQXBCLENBQW1DLGdCQUFuQyxFQUFxREMsWUFBckQsQ0FBa0VqQyxFQUFFLENBQUNpRCxLQUFyRSxFQUE0RUMsTUFBNUUsR0FBbUYsS0FBR25ELDRCQUE0QixDQUFDNkMsbUJBQTdCLENBQWlERCxDQUFqRCxFQUFvRFEsY0FBMUk7QUFDTjtBQUVEO0FBRUU7QUFFSjtBQUNEO0FBekVPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5jb25zdCBVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9Vc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHRcdENoYXJhY3Rlcl9MYWJlbDp7XHJcblx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSxcclxuXHRcdENoYXJhY3Rlcl9WaWV3OntcclxuXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSxcclxuXHRfSXNfTG9hZGluZzp0cnVlLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAgb25Mb2FkOiBmdW5jdGlvbigpe1xyXG5cdFx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdFx0VXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlVzZXJfSGF2ZV9DaGFyYWN0ZXI9bnVsbDtcclxuXHRcdFdlQ2hhdC5Mb2FkaW5nX0NoYXJhY3RlcigpO1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz09dHJ1ZTsgXHJcblx0IH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlOmZ1bmN0aW9uIChkdCkge1xyXG5cdFx0aWYodGhpcy5fSXNfTG9hZGluZyYmVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlVzZXJfSGF2ZV9DaGFyYWN0ZXIhPW51bGwpe1xyXG5cdFx0XHR0aGlzLkxvYWRpbmdfQ2hhcmFjdGVyKCk7XHJcblx0XHRcdHRoaXMuX0lzX0xvYWRpbmc9ZmFsc2U7XHJcblx0XHR9XHJcblx0fSxcclxuXHRMb2FkaW5nX0ltYWdlKHNlbGYsSW1hZ2VfUGF0aCl7XHJcblx0XHRsZXQgX3VybD1JbWFnZV9QYXRoO1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6X3VybCxcclxuXHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdH1cclxuXHRcdFx0c2VsZi5nZXRDaGlsZEJ5TmFtZShcInNwcml0ZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcclxuXHRcdFx0XHJcblx0XHR9KVxyXG59LFxyXG5cdExvYWRpbmdfQ2hhcmFjdGVyKCl7XHJcblx0XHQvL+mBjeWOhlVzZXJfQ2hhcmFjdGVyX0luZm9ybWF0aW9u55qE6KGoXHJcblx0XHRmb3IodmFyIGk9MDtpPFVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5Vc2VyX0hhdmVfQ2hhcmFjdGVyLmxlbmd0aDtpKyspe1x0XHRcclxuXHRcdFx0Ly9Vc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbuaUvueahOaYr+WPquaciTLkuKrorrDlvZXnmoTlsI/ooagoVXNlcl9IYXZlX0NoYXJhY3RlcinnmoTkv6Hmga9cclxuXHRcdFx0dmFyIFVzZXJfQ2hhcmFjdGVyX0luZm9ybWF0aW9uPVVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5Vc2VyX0hhdmVfQ2hhcmFjdGVyW2ldO1xyXG5cdFx0XHQvL1VzZXJfQ2hhcmFjdGVyX051bWJlcuaUvueahOaYr0NoYXJhY3RlcueahOW6j+WPt1xyXG5cdFx0XHR2YXIgVXNlcl9DaGFyYWN0ZXJfTnVtYmVyPVVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5Vc2VyX0hhdmVfQ2hhcmFjdGVyW2ldLkNoYXJhY3Rlcl9JZDtcclxuXHRcdFx0Ly/liKTmlq3nlKjmiLfmmK/lkKbmnInor6XlsI/puJ9cclxuXHRcdCAgICAvL0dsb2JhbF9WYXJpYWJsZS5vcGVuaWTmmK/lvZPliY3nlKjmiLfnmoRvcGVuaWRcclxuXHRcdCAgICBpZihHbG9iYWxfVmFyaWFibGUub3BlbmlkPT1Vc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbi5vcGVuaWQpe1xyXG5cdFx0XHRcdC8vIGNvbnNvbGUubG9nKFwi6KeS6Imy6ZW/5bqmXCIsVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlVzZXJfSGF2ZV9DaGFyYWN0ZXIubGVuZ3RoKTtcclxuXHRcdFx0XHRmb3IodmFyIGo9MDtqPFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuU2hvcF9DaGFyYWN0ZXJfVXNlci5sZW5ndGg7aisrKXtcclxuXHRcdFx0XHRcdGlmKFVzZXJfQ2hhcmFjdGVyX051bWJlcj09U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2pdLkNoYXJhY3Rlcl9JZCl7XHJcblx0XHRcdFx0XHRcdHZhciBOZXdfQ2hhcmFjdGVyX0xhYmVsPWNjLmluc3RhbnRpYXRlKHRoaXMuQ2hhcmFjdGVyX0xhYmVsKTtcclxuXHRcdFx0XHRcdFx0dGhpcy5DaGFyYWN0ZXJfVmlldy5hZGRDaGlsZChOZXdfQ2hhcmFjdGVyX0xhYmVsKTtcclxuXHRcdFx0XHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19DaGFyYWN0ZXJfTGFiZWwsU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2pdLkNoYXJhY3Rlcl9IZWFkX0ltYWdlKTtcclxuXHRcdCAgICAgICAgXHRcdE5ld19DaGFyYWN0ZXJfTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfTmFtZVwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuU2hvcF9DaGFyYWN0ZXJfVXNlcltqXS5DaGFyYWN0ZXJfTmFtZTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRcclxuXHRcdCAgICB9XHJcblx0XHQgICBcclxuXHRcdH1cclxuXHR9XHJcbn0pO1xyXG4iXX0=