
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Close_Box.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '15c871m3upP+ITBKtGQ2KX7', 'Close_Box');
// resources/script/Global_Function/Close_Box.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  Close: function Close() {
    this.Canvas.destroy();
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcQ2xvc2VfQm94LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQ2FudmFzIiwidHlwZSIsIk5vZGUiLCJzZXJpYWx6YWJsZSIsIkNsb3NlIiwiZGVzdHJveSIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVIQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sSUFGTDtBQUdaQyxNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQURDLEdBSFA7QUFXTDtBQUVBO0FBQ0FDLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUNaLFNBQUtKLE1BQUwsQ0FBWUssT0FBWjtBQUNILEdBaEJJO0FBaUJMQyxFQUFBQSxLQWpCSyxtQkFpQkksQ0FFUixDQW5CSSxDQXFCTDs7QUFyQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIENhbnZhczp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuICAgIENsb3NlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5DYW52YXMuZGVzdHJveSgpO1xyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19