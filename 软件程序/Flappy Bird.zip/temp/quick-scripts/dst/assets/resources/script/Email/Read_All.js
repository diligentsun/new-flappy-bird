
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Read_All.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bc8ddeepjtFgqAinaVbR+PX', 'Read_All');
// resources/script/Email/Read_All.js

"use strict";

//下载邮箱列表
var _require = require('../Local_Variible/Email_Local_Variable'),
    Email = _require.Email;

var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {},
  Read_All: function Read_All() {
    //获取邮件列表
    WeChat.Loading_Email(); //将未读修改为已读

    WeChat.Read_All();
    console.log("邮件信息表", Email_Local_Variable.Email);
    cc.director.loadScene("Email");
  },
  start: function start() {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxSZWFkX0FsbC5qcyJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiRW1haWwiLCJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiUmVhZF9BbGwiLCJXZUNoYXQiLCJMb2FkaW5nX0VtYWlsIiwiY29uc29sZSIsImxvZyIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7ZUFDa0JBLE9BQU8sQ0FBQyx3Q0FBRDtJQUFqQkMsaUJBQUFBOztBQUNSLElBQU1DLG9CQUFvQixHQUFHRixPQUFPLENBQUMsd0NBQUQsQ0FBcEM7O0FBQ0FHLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBS0xDLEVBQUFBLFFBQVEsRUFBQyxvQkFBVTtBQUNmO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0MsYUFBUCxHQUZlLENBR2Y7O0FBQ0FELElBQUFBLE1BQU0sQ0FBQ0QsUUFBUDtBQUVBRyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CVCxvQkFBb0IsQ0FBQ0QsS0FBekM7QUFDQUUsSUFBQUEsRUFBRSxDQUFDUyxRQUFILENBQVlDLFNBQVosQ0FBc0IsT0FBdEI7QUFDSCxHQWJJO0FBZUxDLEVBQUFBLEtBZkssbUJBZUksQ0FFUjtBQWpCSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9vemCrueuseWIl+ihqFxyXG5jb25zdCB7IEVtYWlsIH0gPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jb25zdCBFbWFpbF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL0VtYWlsX0xvY2FsX1ZhcmlhYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG4gICAgUmVhZF9BbGw6ZnVuY3Rpb24oKXtcclxuICAgICAgICAvL+iOt+WPlumCruS7tuWIl+ihqFxyXG4gICAgICAgIFdlQ2hhdC5Mb2FkaW5nX0VtYWlsKCk7XHJcbiAgICAgICAgLy/lsIbmnKror7vkv67mlLnkuLrlt7Lor7tcclxuICAgICAgICBXZUNoYXQuUmVhZF9BbGwoKTtcclxuICAgICAgICBcclxuICAgICAgICBjb25zb2xlLmxvZyhcIumCruS7tuS/oeaBr+ihqFwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsKTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJFbWFpbFwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=