
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Login/WX_Login.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '87438YORgpMZrY2yjMH+Zna', 'WX_Login');
// resources/script/Game_Login/WX_Login.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {
    //调用微信登录函数，登录游戏
    wx.login({
      success: function success(res) {
        if (res.code) {
          console.log("登录成功，获取到code", res.code);
        }

        var button = wx.createUserInfoButton({
          type: 'text',
          text: '开始游戏',
          style: {
            left: wx.getSystemInfoSync().screenWidth / 2 - 60,
            top: wx.getSystemInfoSync().screenHeight / 2 - 60,
            width: 120,
            height: 40,
            lineHeight: 40,
            backgroundColor: '#00aa00',
            color: '#ffffff',
            textAlign: 'center',
            fontSize: 16,
            borderRadius: 90
          }
        });
        button.hide();
        button.show();
        button.onTap(function (res) {
          console.log(res);

          if (res.errMsg === "getUserInfo:ok") {
            console.log("已经授权"); //获取注册信息

            console.log(res.userInfo);
            WeChat.onRegisterUser(res.userInfo);
            button.destroy(); //cc.director.loadScene("Game_Start");
          } else {
            console.log("没有授权");
          }
        });
      }
    });
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfTG9naW5cXFdYX0xvZ2luLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwid3giLCJsb2dpbiIsInN1Y2Nlc3MiLCJyZXMiLCJjb2RlIiwiY29uc29sZSIsImxvZyIsImJ1dHRvbiIsImNyZWF0ZVVzZXJJbmZvQnV0dG9uIiwidHlwZSIsInRleHQiLCJzdHlsZSIsImxlZnQiLCJnZXRTeXN0ZW1JbmZvU3luYyIsInNjcmVlbldpZHRoIiwidG9wIiwic2NyZWVuSGVpZ2h0Iiwid2lkdGgiLCJoZWlnaHQiLCJsaW5lSGVpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJ0ZXh0QWxpZ24iLCJmb250U2l6ZSIsImJvcmRlclJhZGl1cyIsImhpZGUiLCJzaG93Iiwib25UYXAiLCJlcnJNc2ciLCJ1c2VySW5mbyIsIldlQ2hhdCIsIm9uUmVnaXN0ZXJVc2VyIiwiZGVzdHJveSIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUUsRUFISjtBQU9SQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQUMsSUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUkMsTUFBQUEsT0FBTyxFQUFFLGlCQUFTQyxHQUFULEVBQWM7QUFDdEIsWUFBSUEsR0FBRyxDQUFDQyxJQUFSLEVBQWM7QUFDYkMsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QkgsR0FBRyxDQUFDQyxJQUFoQztBQUNBOztBQUNELFlBQUlHLE1BQU0sR0FBR1AsRUFBRSxDQUFDUSxvQkFBSCxDQUF3QjtBQUNwQ0MsVUFBQUEsSUFBSSxFQUFFLE1BRDhCO0FBRXBDQyxVQUFBQSxJQUFJLEVBQUUsTUFGOEI7QUFHcENDLFVBQUFBLEtBQUssRUFBRTtBQUNOQyxZQUFBQSxJQUFJLEVBQUVaLEVBQUUsQ0FBQ2EsaUJBQUgsR0FBdUJDLFdBQXZCLEdBQXFDLENBQXJDLEdBQXlDLEVBRHpDO0FBRU5DLFlBQUFBLEdBQUcsRUFBRWYsRUFBRSxDQUFDYSxpQkFBSCxHQUF1QkcsWUFBdkIsR0FBc0MsQ0FBdEMsR0FBMEMsRUFGekM7QUFHTkMsWUFBQUEsS0FBSyxFQUFFLEdBSEQ7QUFJTkMsWUFBQUEsTUFBTSxFQUFFLEVBSkY7QUFLTkMsWUFBQUEsVUFBVSxFQUFFLEVBTE47QUFNTkMsWUFBQUEsZUFBZSxFQUFFLFNBTlg7QUFPTkMsWUFBQUEsS0FBSyxFQUFFLFNBUEQ7QUFRTkMsWUFBQUEsU0FBUyxFQUFFLFFBUkw7QUFTTkMsWUFBQUEsUUFBUSxFQUFFLEVBVEo7QUFVTkMsWUFBQUEsWUFBWSxFQUFFO0FBVlI7QUFINkIsU0FBeEIsQ0FBYjtBQWdCQWpCLFFBQUFBLE1BQU0sQ0FBQ2tCLElBQVA7QUFDQWxCLFFBQUFBLE1BQU0sQ0FBQ21CLElBQVA7QUFDQW5CLFFBQUFBLE1BQU0sQ0FBQ29CLEtBQVAsQ0FBYSxVQUFDeEIsR0FBRCxFQUFTO0FBQ3JCRSxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUgsR0FBWjs7QUFFQSxjQUFJQSxHQUFHLENBQUN5QixNQUFKLEtBQWUsZ0JBQW5CLEVBQXFDO0FBQ3BDdkIsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQURvQyxDQUVwQzs7QUFDQUQsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlILEdBQUcsQ0FBQzBCLFFBQWhCO0FBQ0FDLFlBQUFBLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQjVCLEdBQUcsQ0FBQzBCLFFBQTFCO0FBQ0F0QixZQUFBQSxNQUFNLENBQUN5QixPQUFQLEdBTG9DLENBTXBDO0FBQ0EsV0FQRCxNQU9NO0FBQ0wzQixZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0E7QUFDRCxTQWJEO0FBY0E7QUFyQ08sS0FBVDtBQXVDQSxHQWhETztBQWtEUjJCLEVBQUFBLEtBbERRLG1CQWtEQSxDQUVQLENBcERPLENBd0RSOztBQXhEUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0fSxcclxuXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+iwg+eUqOW+ruS/oeeZu+W9leWHveaVsO+8jOeZu+W9lea4uOaIj1xyXG5cdFx0d3gubG9naW4oe1xyXG5cdFx0XHRzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuXHRcdFx0XHRpZiAocmVzLmNvZGUpIHtcclxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi55m75b2V5oiQ5Yqf77yM6I635Y+W5YiwY29kZVwiLCByZXMuY29kZSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHZhciBidXR0b24gPSB3eC5jcmVhdGVVc2VySW5mb0J1dHRvbih7XHJcblx0XHRcdFx0XHR0eXBlOiAndGV4dCcsXHJcblx0XHRcdFx0XHR0ZXh0OiAn5byA5aeL5ri45oiPJyxcclxuXHRcdFx0XHRcdHN0eWxlOiB7XHJcblx0XHRcdFx0XHRcdGxlZnQ6IHd4LmdldFN5c3RlbUluZm9TeW5jKCkuc2NyZWVuV2lkdGggLyAyIC0gNjAsXHJcblx0XHRcdFx0XHRcdHRvcDogd3guZ2V0U3lzdGVtSW5mb1N5bmMoKS5zY3JlZW5IZWlnaHQgLyAyIC0gNjAsXHJcblx0XHRcdFx0XHRcdHdpZHRoOiAxMjAsXHJcblx0XHRcdFx0XHRcdGhlaWdodDogNDAsXHJcblx0XHRcdFx0XHRcdGxpbmVIZWlnaHQ6IDQwLFxyXG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3I6ICcjMDBhYTAwJyxcclxuXHRcdFx0XHRcdFx0Y29sb3I6ICcjZmZmZmZmJyxcclxuXHRcdFx0XHRcdFx0dGV4dEFsaWduOiAnY2VudGVyJyxcclxuXHRcdFx0XHRcdFx0Zm9udFNpemU6IDE2LFxyXG5cdFx0XHRcdFx0XHRib3JkZXJSYWRpdXM6IDkwLFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHRcdGJ1dHRvbi5oaWRlKCk7XHJcblx0XHRcdFx0YnV0dG9uLnNob3coKTtcclxuXHRcdFx0XHRidXR0b24ub25UYXAoKHJlcykgPT4ge1xyXG5cdFx0XHRcdFx0Y29uc29sZS5sb2cocmVzKTtcclxuXHJcblx0XHRcdFx0XHRpZiAocmVzLmVyck1zZyA9PT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcblx0XHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi5bey57uP5o6I5p2DXCIpO1xyXG5cdFx0XHRcdFx0XHQvL+iOt+WPluazqOWGjOS/oeaBr1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhyZXMudXNlckluZm8pO1xyXG5cdFx0XHRcdFx0XHRXZUNoYXQub25SZWdpc3RlclVzZXIocmVzLnVzZXJJbmZvKTtcclxuXHRcdFx0XHRcdFx0YnV0dG9uLmRlc3Ryb3koKTtcclxuXHRcdFx0XHRcdFx0Ly9jYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lX1N0YXJ0XCIpO1xyXG5cdFx0XHRcdFx0fWVsc2Uge1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuayoeacieaOiOadg1wiKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblx0XHRcclxuXHR9LFxyXG5cdFxyXG5cdFxyXG5cclxuXHQvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XG4iXX0=