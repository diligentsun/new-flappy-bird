
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Game_Difficulty_Local_Varible.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '77c6fU8RvVPS5w1VUEQmtm9', 'Game_Difficulty_Local_Varible');
// resources/script/Local_Variible/Game_Difficulty_Local_Varible.js

"use strict";

//游戏难度系数的局部变量
module.exports = {
  //游戏难度系数
  Difficulty_Ratio: 1,
  //是否是困难模式
  Is_Difficulty: false
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiRGlmZmljdWx0eV9SYXRpbyIsIklzX0RpZmZpY3VsdHkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2hCO0FBQ0FDLEVBQUFBLGdCQUFnQixFQUFFLENBRkY7QUFHaEI7QUFDQUMsRUFBQUEsYUFBYSxFQUFFO0FBSkMsQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5ri45oiP6Zq+5bqm57O75pWw55qE5bGA6YOo5Y+Y6YePXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG5cdC8v5ri45oiP6Zq+5bqm57O75pWwXHJcblx0RGlmZmljdWx0eV9SYXRpbzogMSxcclxuXHQvL+aYr+WQpuaYr+WbsOmavuaooeW8j1xyXG5cdElzX0RpZmZpY3VsdHk6IGZhbHNlLFxyXG59O1xuIl19