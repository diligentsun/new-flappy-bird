
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Loading_All_Reported_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'afec0r3ZNlGZL+pBm6bChur', 'Loading_All_Reported_User');
// resources/script/Account_Management/Loading_All_Reported_User.js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Uid_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //Openid
    Report_Information_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  // update (dt) {},
  on_btn_click: function on_btn_click() {
    var Openid = this.Uid_Show.getComponent(cc.Label).string;
    WeChat.Loading_Report_User(Openid);
    console.log("下拉举报");
    WeChat.Loading_All_User();
    console.log("输出账号个数", Account_Management_Local_Variable.Report_User_List.length);

    for (var i = 0; i < Account_Management_Local_Variable.Report_User_List.length; i++) {
      console.log("1");
      var New_Report_Information_Label = cc.instantiate(this.Report_Information_Label);
      this.Account_Label.addChild(New_Report_Information_Label);
      New_Report_Information_Label.getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Report_User_List[i].Report_Openid;
      New_Report_Information_Label.getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Report_User_List[i].Report_Time.toString();
      New_Report_Information_Label.getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Report_User_List[i].Report_Reason;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcTG9hZGluZ19BbGxfUmVwb3J0ZWRfVXNlci5qcyJdLCJuYW1lcyI6WyJBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJVaWRfU2hvdyIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwiUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsIiwiUHJlZmFiIiwiQWNjb3VudF9MYWJlbCIsIk5vZGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIk9wZW5pZCIsImdldENvbXBvbmVudCIsInN0cmluZyIsIldlQ2hhdCIsIkxvYWRpbmdfUmVwb3J0X1VzZXIiLCJjb25zb2xlIiwibG9nIiwiTG9hZGluZ19BbGxfVXNlciIsIlJlcG9ydF9Vc2VyX0xpc3QiLCJsZW5ndGgiLCJpIiwiTmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbCIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJnZXRDaGlsZEJ5TmFtZSIsIlJlcG9ydF9PcGVuaWQiLCJSZXBvcnRfVGltZSIsInRvU3RyaW5nIiwiUmVwb3J0X1JlYXNvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxpQ0FBaUMsR0FBQ0MsT0FBTyxDQUFDLG1DQUFELENBQTdDOztBQUVBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsUUFBUSxFQUFDO0FBQ1IsaUJBQVEsSUFEQTtBQUVSQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sS0FGQTtBQUdSQyxNQUFBQSxXQUFXLEVBQUM7QUFISixLQURFO0FBS1Q7QUFDRkMsSUFBQUEsd0JBQXdCLEVBQUM7QUFDeEIsaUJBQVEsSUFEZ0I7QUFFeEJILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxNQUZnQjtBQUd4QkYsTUFBQUEsV0FBVyxFQUFDO0FBSFksS0FOZDtBQVdYRyxJQUFBQSxhQUFhLEVBQUM7QUFDYixpQkFBUSxJQURLO0FBRWJMLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDVyxJQUZLO0FBR2JKLE1BQUFBLFdBQVcsRUFBQztBQUhDO0FBWEgsR0FISjtBQXNCUjtBQUVBO0FBRUFLLEVBQUFBLEtBMUJRLG1CQTBCQSxDQUVQLENBNUJPO0FBOEJSO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBVztBQUN4QixRQUFJQyxNQUFNLEdBQUMsS0FBS1YsUUFBTCxDQUFjVyxZQUFkLENBQTJCZixFQUFFLENBQUNNLEtBQTlCLEVBQXFDVSxNQUFoRDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLG1CQUFQLENBQTJCSixNQUEzQjtBQUNBSyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FILElBQUFBLE1BQU0sQ0FBQ0ksZ0JBQVA7QUFDQUYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQnRCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1EQyxNQUF4RTs7QUFDQSxTQUFJLElBQUlDLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQzFCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1EQyxNQUFqRSxFQUF3RUMsQ0FBQyxFQUF6RSxFQUE0RTtBQUMzRUwsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksR0FBWjtBQUNBLFVBQUlLLDRCQUE0QixHQUFDekIsRUFBRSxDQUFDMEIsV0FBSCxDQUFlLEtBQUtsQix3QkFBcEIsQ0FBakM7QUFDQSxXQUFLRSxhQUFMLENBQW1CaUIsUUFBbkIsQ0FBNEJGLDRCQUE1QjtBQUNBQSxNQUFBQSw0QkFBNEIsQ0FBQ0csY0FBN0IsQ0FBNEMsZUFBNUMsRUFBNkRBLGNBQTdELENBQTRFLGNBQTVFLEVBQTRGYixZQUE1RixDQUF5R2YsRUFBRSxDQUFDTSxLQUE1RyxFQUFtSFUsTUFBbkgsR0FBMEgsS0FBR2xCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1ERSxDQUFuRCxFQUFzREssYUFBbkw7QUFDQUosTUFBQUEsNEJBQTRCLENBQUNHLGNBQTdCLENBQTRDLHNCQUE1QyxFQUFvRUEsY0FBcEUsQ0FBbUYscUJBQW5GLEVBQTBHYixZQUExRyxDQUF1SGYsRUFBRSxDQUFDTSxLQUExSCxFQUFpSVUsTUFBakksR0FBd0ksS0FBR2xCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1ERSxDQUFuRCxFQUFzRE0sV0FBdEQsQ0FBa0VDLFFBQWxFLEVBQTNJO0FBQ0FOLE1BQUFBLDRCQUE0QixDQUFDRyxjQUE3QixDQUE0QywyQ0FBNUMsRUFBeUZBLGNBQXpGLENBQXdHLDBDQUF4RyxFQUFvSmIsWUFBcEosQ0FBaUtmLEVBQUUsQ0FBQ00sS0FBcEssRUFBMktVLE1BQTNLLEdBQWtMLEtBQUdsQixpQ0FBaUMsQ0FBQ3dCLGdCQUFsQyxDQUFtREUsQ0FBbkQsRUFBc0RRLGFBQTNPO0FBQ0E7QUFDRDtBQTdDTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlPXJlcXVpcmUoJ0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0VWlkX1Nob3c6e1xyXG5cdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSwvL09wZW5pZFxyXG5cdFx0UmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsOntcclxuXHRcdFx0ZGVmYXVsdDpudWxsLFxyXG5cdFx0XHR0eXBlOmNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRBY2NvdW50X0xhYmVsOntcclxuXHRcdFx0ZGVmYXVsdDpudWxsLFxyXG5cdFx0XHR0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcblx0XHR9LFxyXG5cdFx0XG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cclxuXHQvLyB1cGRhdGUgKGR0KSB7fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIE9wZW5pZD10aGlzLlVpZF9TaG93LmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfUmVwb3J0X1VzZXIoT3BlbmlkKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi5LiL5ouJ5Li+5oqlXCIpO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfQWxsX1VzZXIoKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi6L6T5Ye66LSm5Y+35Liq5pWwXCIsQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3QubGVuZ3RoKTtcclxuXHRcdGZvcih2YXIgaT0wO2k8QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3QubGVuZ3RoO2krKyl7XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCIxXCIpO1xyXG5cdFx0XHR2YXIgTmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbD1jYy5pbnN0YW50aWF0ZSh0aGlzLlJlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbCk7XHJcblx0XHRcdHRoaXMuQWNjb3VudF9MYWJlbC5hZGRDaGlsZChOZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsKTtcclxuXHRcdFx0TmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIlVzZXJfSWRfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXCJVc2VyX0lkX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0X1VzZXJfTGlzdFtpXS5SZXBvcnRfT3BlbmlkO1xyXG5cdFx0XHROZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9TdGF0dXNfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X1N0YXR1c19TaG93XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3RbaV0uUmVwb3J0X1RpbWUudG9TdHJpbmcoKTtcclxuXHRcdFx0TmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiQ3VtdWxhdGl2ZV9OdW1iZXJfT2ZfUmVwb3J0ZWRfQ2FzZXNfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5SZXBvcnRfVXNlcl9MaXN0W2ldLlJlcG9ydF9SZWFzb247XHJcblx0XHR9XHJcblx0fVxyXG59KTtcbiJdfQ==