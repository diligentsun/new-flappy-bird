
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Loading_Base_Resouce.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bcc9eKPWABDFafMeuT5G5RM', 'Loading_Base_Resouce');
// resources/script/Global_Function/Loading_Base_Resouce.js

"use strict";

//加载基础资源
cc.Class({
  "extends": cc.Component,
  properties: {
    Diamond_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //导入钻石
    Gold_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //导入金币
    Compassion_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //导入爱心

  },
  onLoad: function onLoad() {
    WeChat.Loading_Resources();
  },
  start: function start() {},
  //
  update: function update(dt) {
    //加载基础资源
    // this.schedule(function() { // 计时器将每隔 1s 执行一次。
    // 	WeChat.Loading_Resources();
    // }, 1);
    //更新界面上的基础资源
    if (Global_Variable.Gold != null) {
      this.Gold_Show.string = Global_Variable.Gold;
      this.Diamond_Show.string = Global_Variable.Diamond;
      this.Compassion_Show.string = Global_Variable.Compassion;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcTG9hZGluZ19CYXNlX1Jlc291Y2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJEaWFtb25kX1Nob3ciLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsIkdvbGRfU2hvdyIsIkNvbXBhc3Npb25fU2hvdyIsIm9uTG9hZCIsIldlQ2hhdCIsIkxvYWRpbmdfUmVzb3VyY2VzIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIkdsb2JhbF9WYXJpYWJsZSIsIkdvbGQiLCJzdHJpbmciLCJEaWFtb25kIiwiQ29tcGFzc2lvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUVSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsWUFBWSxFQUFFO0FBQ2IsaUJBQVMsSUFESTtBQUViQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGSTtBQUdiQyxNQUFBQSxXQUFXLEVBQUU7QUFIQSxLQURIO0FBS1I7QUFDSEMsSUFBQUEsU0FBUyxFQUFFO0FBQ1YsaUJBQVMsSUFEQztBQUVWSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGQztBQUdWQyxNQUFBQSxXQUFXLEVBQUU7QUFISCxLQU5BO0FBVVI7QUFDSEUsSUFBQUEsZUFBZSxFQUFFO0FBQ2hCLGlCQUFTLElBRE87QUFFaEJKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZPO0FBR2hCQyxNQUFBQSxXQUFXLEVBQUU7QUFIRyxLQVhOLENBZVQ7O0FBZlMsR0FGSjtBQW9CUkcsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCQyxJQUFBQSxNQUFNLENBQUNDLGlCQUFQO0FBQ0EsR0F0Qk87QUF3QlJDLEVBQUFBLEtBQUssRUFBRSxpQkFBVyxDQUFFLENBeEJaO0FBeUJSO0FBQ0FDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFHQyxlQUFlLENBQUNDLElBQWhCLElBQXNCLElBQXpCLEVBQThCO0FBQzdCLFdBQUtULFNBQUwsQ0FBZVUsTUFBZixHQUF3QkYsZUFBZSxDQUFDQyxJQUF4QztBQUNBLFdBQUtiLFlBQUwsQ0FBa0JjLE1BQWxCLEdBQTJCRixlQUFlLENBQUNHLE9BQTNDO0FBQ0EsV0FBS1YsZUFBTCxDQUFxQlMsTUFBckIsR0FBOEJGLGVBQWUsQ0FBQ0ksVUFBOUM7QUFDQTtBQUNEO0FBckNPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5Yqg6L295Z+656GA6LWE5rqQXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0RGlhbW9uZF9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v5a+85YWl6ZK755+zXHJcblx0XHRHb2xkX1Nob3c6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/lr7zlhaXph5HluIFcclxuXHRcdENvbXBhc3Npb25fU2hvdzoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9IC8v5a+85YWl54ix5b+DXHJcblx0fSxcclxuXHJcblx0b25Mb2FkOiBmdW5jdGlvbigpIHtcclxuXHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdH0sXHJcblxyXG5cdHN0YXJ0OiBmdW5jdGlvbigpIHt9LFxyXG5cdC8vXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0Ly/liqDovb3ln7rnoYDotYTmupBcclxuXHRcdC8vIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7IC8vIOiuoeaXtuWZqOWwhuavj+malCAxcyDmiafooYzkuIDmrKHjgIJcclxuXHRcdC8vIFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHQvLyB9LCAxKTtcclxuXHRcdC8v5pu05paw55WM6Z2i5LiK55qE5Z+656GA6LWE5rqQXHJcblx0XHRpZihHbG9iYWxfVmFyaWFibGUuR29sZCE9bnVsbCl7XHJcblx0XHRcdHRoaXMuR29sZF9TaG93LnN0cmluZyA9IEdsb2JhbF9WYXJpYWJsZS5Hb2xkO1xyXG5cdFx0XHR0aGlzLkRpYW1vbmRfU2hvdy5zdHJpbmcgPSBHbG9iYWxfVmFyaWFibGUuRGlhbW9uZDtcclxuXHRcdFx0dGhpcy5Db21wYXNzaW9uX1Nob3cuc3RyaW5nID0gR2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb247XHJcblx0XHR9XHJcblx0fSxcclxufSk7XHJcblxyXG4iXX0=