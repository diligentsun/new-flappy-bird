
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e5a1fZvLqBJ2a3/lkwWzySk', 'Character');
// resources/script/Shop/Character.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    buy: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Canvas_Sprite: {
      "default": null,
      type: cc.Canvas,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  onClickAlert: function onClickAlert() {
    var anode = cc.instantiate(this.buy);
    this.Canvas_Sprite.node.addChild(anode);
    anode.setPosition(540, 0); //  node = node.getComponent('BuyCharacter');
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXENoYXJhY3Rlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImJ1eSIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkNhbnZhc19TcHJpdGUiLCJDYW52YXMiLCJzdGFydCIsIm9uQ2xpY2tBbGVydCIsImFub2RlIiwiaW5zdGFudGlhdGUiLCJub2RlIiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEdBQUcsRUFBQztBQUNBLGlCQUFRLElBRFI7QUFFQUMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRlI7QUFHQUMsTUFBQUEsV0FBVyxFQUFDO0FBSFosS0FESTtBQU1SQyxJQUFBQSxhQUFhLEVBQUM7QUFDVixpQkFBUSxJQURFO0FBRVZILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxNQUZFO0FBR1ZGLE1BQUFBLFdBQVcsRUFBQztBQUhGO0FBTk4sR0FIUDtBQWdCTDtBQUVBO0FBRUFHLEVBQUFBLEtBcEJLLG1CQW9CSSxDQUVSLENBdEJJO0FBdUJKQyxFQUFBQSxZQUFZLEVBQUMsd0JBQVU7QUFDbkIsUUFBSUMsS0FBSyxHQUFHWixFQUFFLENBQUNhLFdBQUgsQ0FBZSxLQUFLVCxHQUFwQixDQUFaO0FBQ0EsU0FBS0ksYUFBTCxDQUFtQk0sSUFBbkIsQ0FBd0JDLFFBQXhCLENBQWlDSCxLQUFqQztBQUNBQSxJQUFBQSxLQUFLLENBQUNJLFdBQU4sQ0FBa0IsR0FBbEIsRUFBc0IsQ0FBdEIsRUFIbUIsQ0FJcEI7QUFDRixHQTVCRyxDQTZCTDs7QUE3QkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7ICAgXHJcbiAgICAgICAgYnV5OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLlByZWZhYixcclxuICAgICAgICAgICAgc2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICAgfSxcclxuICAgICAgICBDYW52YXNfU3ByaXRlOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkNhbnZhcyxcclxuICAgICAgICAgICAgc2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LCBcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgIG9uQ2xpY2tBbGVydDpmdW5jdGlvbigpe1xyXG4gICAgICAgICB2YXIgYW5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJ1eSk7ICBcclxuICAgICAgICAgdGhpcy5DYW52YXNfU3ByaXRlLm5vZGUuYWRkQ2hpbGQoYW5vZGUpO1xyXG4gICAgICAgICBhbm9kZS5zZXRQb3NpdGlvbig1NDAsMCk7XHJcbiAgICAgICAgLy8gIG5vZGUgPSBub2RlLmdldENvbXBvbmVudCgnQnV5Q2hhcmFjdGVyJyk7XHJcbiAgICAgfVxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=