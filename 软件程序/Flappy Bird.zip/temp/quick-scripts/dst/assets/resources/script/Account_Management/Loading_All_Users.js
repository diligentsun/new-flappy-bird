
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Loading_All_Users.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f1ea21R/gtMBb5z8qlYax3s', 'Loading_All_Users');
// resources/script/Account_Management/Loading_All_Users.js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //账号管理预制体
    Account_Managent_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this._Is_Loading = true;
    Account_Management_Local_Variable.All_Users_Information = null;
    WeChat.Loading_All_User();
    console.log("输出账号个数", Account_Management_Local_Variable.All_Users_Information.length);
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Account_Management_Local_Variable.All_Users_Information != null) {
      this.Loading_All_User();
      this._Is_Loading = false;
    }
  },
  Loading_All_User: function Loading_All_User() {
    for (var i = 0; i < Account_Management_Local_Variable.All_Users_Information.length; i++) {
      console.log("1");
      var New_Account_Label = cc.instantiate(this.Account_Label);
      this.Account_Managent_View.addChild(New_Account_Label);
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].openid;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].User_state;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].Reported_Count;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcTG9hZGluZ19BbGxfVXNlcnMuanMiXSwibmFtZXMiOlsiQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQWNjb3VudF9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkFjY291bnRfTWFuYWdlbnRfVmlldyIsIk5vZGUiLCJfSXNfTG9hZGluZyIsIm9uTG9hZCIsIkFsbF9Vc2Vyc19JbmZvcm1hdGlvbiIsIldlQ2hhdCIsIkxvYWRpbmdfQWxsX1VzZXIiLCJjb25zb2xlIiwibG9nIiwibGVuZ3RoIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImkiLCJOZXdfQWNjb3VudF9MYWJlbCIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJnZXRDaGlsZEJ5TmFtZSIsImdldENvbXBvbmVudCIsIkxhYmVsIiwic3RyaW5nIiwib3BlbmlkIiwiVXNlcl9zdGF0ZSIsIlJlcG9ydGVkX0NvdW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLGlDQUFpQyxHQUFHQyxPQUFPLENBQUMsbUNBQUQsQ0FBL0M7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxhQUFhLEVBQUU7QUFDZCxpQkFBUyxJQURLO0FBRWRDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZLO0FBR2RDLE1BQUFBLFdBQVcsRUFBRTtBQUhDLEtBREo7QUFLUjtBQUNIQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUN0QixpQkFBUyxJQURhO0FBRXRCSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1MsSUFGYTtBQUd0QkYsTUFBQUEsV0FBVyxFQUFFO0FBSFMsS0FOWjtBQVVSO0FBQ0hHLElBQUFBLFdBQVcsRUFBRTtBQVhGLEdBSEo7QUFpQlI7QUFFQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCLFNBQUtELFdBQUwsR0FBaUIsSUFBakI7QUFDQVosSUFBQUEsaUNBQWlDLENBQUNjLHFCQUFsQyxHQUF3RCxJQUF4RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLGdCQUFQO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JsQixpQ0FBaUMsQ0FBQ2MscUJBQWxDLENBQXdESyxNQUE5RTtBQUNBLEdBeEJPO0FBMEJSQyxFQUFBQSxLQTFCUSxtQkEwQkEsQ0FFUCxDQTVCTztBQThCUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEIsUUFBRyxLQUFLVixXQUFMLElBQWtCWixpQ0FBaUMsQ0FBQ2MscUJBQWxDLElBQXlELElBQTlFLEVBQW1GO0FBQ2xGLFdBQUtFLGdCQUFMO0FBQ0EsV0FBS0osV0FBTCxHQUFpQixLQUFqQjtBQUNBO0FBQ0QsR0FuQ087QUFxQ1JJLEVBQUFBLGdCQXJDUSw4QkFxQ1c7QUFDbEIsU0FBSyxJQUFJTyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHdkIsaUNBQWlDLENBQUNjLHFCQUFsQyxDQUF3REssTUFBNUUsRUFBb0ZJLENBQUMsRUFBckYsRUFBeUY7QUFDeEZOLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEdBQVo7QUFDQSxVQUFJTSxpQkFBaUIsR0FBR3RCLEVBQUUsQ0FBQ3VCLFdBQUgsQ0FBZSxLQUFLbkIsYUFBcEIsQ0FBeEI7QUFDQSxXQUFLSSxxQkFBTCxDQUEyQmdCLFFBQTNCLENBQW9DRixpQkFBcEM7QUFDQUEsTUFBQUEsaUJBQWlCLENBQUNHLGNBQWxCLENBQWlDLDBCQUFqQyxFQUE2REEsY0FBN0QsQ0FBNEUsZUFBNUUsRUFBNkZBLGNBQTdGLENBQ0MsY0FERCxFQUNpQkMsWUFEakIsQ0FDOEIxQixFQUFFLENBQUMyQixLQURqQyxFQUN3Q0MsTUFEeEMsR0FDaUQsS0FBSzlCLGlDQUFpQyxDQUFDYyxxQkFBbEMsQ0FBd0RTLENBQXhELEVBQTJEUSxNQURqSDtBQUVBUCxNQUFBQSxpQkFBaUIsQ0FBQ0csY0FBbEIsQ0FBaUMsMEJBQWpDLEVBQTZEQSxjQUE3RCxDQUE0RSxzQkFBNUUsRUFBb0dBLGNBQXBHLENBQ0MscUJBREQsRUFDd0JDLFlBRHhCLENBQ3FDMUIsRUFBRSxDQUFDMkIsS0FEeEMsRUFDK0NDLE1BRC9DLEdBQ3dELEtBQUs5QixpQ0FBaUMsQ0FBQ2MscUJBQWxDLENBQzVEUyxDQUQ0RCxFQUN6RFMsVUFGSjtBQUdBUixNQUFBQSxpQkFBaUIsQ0FBQ0csY0FBbEIsQ0FBaUMsMEJBQWpDLEVBQTZEQSxjQUE3RCxDQUE0RSwyQ0FBNUUsRUFBeUhBLGNBQXpILENBQ0MsMENBREQsRUFDNkNDLFlBRDdDLENBQzBEMUIsRUFBRSxDQUFDMkIsS0FEN0QsRUFDb0VDLE1BRHBFLEdBQzZFLEtBQUs5QixpQ0FBaUMsQ0FBQ2MscUJBQWxDLENBQ2pGUyxDQURpRixFQUM5RVUsY0FGSjtBQUdBO0FBQ0Q7QUFuRE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJ0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRBY2NvdW50X0xhYmVsOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i0puWPt+euoeeQhumihOWItuS9k1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VudF9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/mjpLlkI3moYZcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz10cnVlO1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbj1udWxsO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfQWxsX1VzZXIoKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi6L6T5Ye66LSm5Y+35Liq5pWwXCIsIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5BbGxfVXNlcnNfSW5mb3JtYXRpb24ubGVuZ3RoKTtcclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0aWYodGhpcy5fSXNfTG9hZGluZyYmQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbiE9bnVsbCl7XHJcblx0XHRcdHRoaXMuTG9hZGluZ19BbGxfVXNlcigpO1xyXG5cdFx0XHR0aGlzLl9Jc19Mb2FkaW5nPWZhbHNlO1xyXG5cdFx0fVxyXG5cdH0sXHJcblxyXG5cdExvYWRpbmdfQWxsX1VzZXIoKSB7XHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5BbGxfVXNlcnNfSW5mb3JtYXRpb24ubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCIxXCIpO1xyXG5cdFx0XHR2YXIgTmV3X0FjY291bnRfTGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkFjY291bnRfTGFiZWwpO1xyXG5cdFx0XHR0aGlzLkFjY291bnRfTWFuYWdlbnRfVmlldy5hZGRDaGlsZChOZXdfQWNjb3VudF9MYWJlbCk7XHJcblx0XHRcdE5ld19BY2NvdW50X0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9NYW5hZ2VtZW50X0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiVXNlcl9JZF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcclxuXHRcdFx0XHRcIlVzZXJfSWRfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuQWxsX1VzZXJzX0luZm9ybWF0aW9uW2ldLm9wZW5pZDtcclxuXHRcdFx0TmV3X0FjY291bnRfTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X01hbmFnZW1lbnRfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X1N0YXR1c19MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcclxuXHRcdFx0XHRcIkFjY291bnRfU3RhdHVzX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbltcclxuXHRcdFx0XHRpXS5Vc2VyX3N0YXRlO1xyXG5cdFx0XHROZXdfQWNjb3VudF9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfTWFuYWdlbWVudF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFxyXG5cdFx0XHRcdFwiQ3VtdWxhdGl2ZV9OdW1iZXJfT2ZfUmVwb3J0ZWRfQ2FzZXNfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuQWxsX1VzZXJzX0luZm9ybWF0aW9uW1xyXG5cdFx0XHRcdGldLlJlcG9ydGVkX0NvdW50O1xyXG5cdFx0fVxyXG5cdH0sXHJcbn0pO1xuIl19