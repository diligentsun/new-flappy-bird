
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Closure_Account.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3ff96/E4BtH1onOg+sWVBCi', 'Closure_Account');
// resources/script/Account_Management/Closure_Account.js

"use strict";

//封停账号
cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    User_Id_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Input_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    var Openid = this.User_Id_Show.getComponent(cc.Label).string;
    var Input = Number(this.Input_Show.getComponent(cc.Label).string);

    if (!isNaN(Input)) {
      WeChat.Closure_Account(Openid, Input);
      WeChat.Handle_Reported_User(Openid);
      this.Account_Label.destroy();
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQ2xvc3VyZV9BY2NvdW50LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQWNjb3VudF9MYWJlbCIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJVc2VyX0lkX1Nob3ciLCJMYWJlbCIsIklucHV0X1Nob3ciLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIk9wZW5pZCIsImdldENvbXBvbmVudCIsInN0cmluZyIsIklucHV0IiwiTnVtYmVyIiwiaXNOYU4iLCJXZUNoYXQiLCJDbG9zdXJlX0FjY291bnQiLCJIYW5kbGVfUmVwb3J0ZWRfVXNlciIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLGFBQWEsRUFBQztBQUNiLGlCQUFTLElBREk7QUFFYkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBRkk7QUFHYkMsTUFBQUEsV0FBVyxFQUFFO0FBSEEsS0FESDtBQU1YQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxLQUZJO0FBR2JGLE1BQUFBLFdBQVcsRUFBRTtBQUhBLEtBTkg7QUFXWEcsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1MsS0FGRTtBQUdYRixNQUFBQSxXQUFXLEVBQUU7QUFIRjtBQVhELEdBSEo7QUFzQlI7QUFFQTtBQUVBSSxFQUFBQSxLQTFCUSxtQkEwQkEsQ0FFUCxDQTVCTztBQTZCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCLFFBQUlDLE1BQU0sR0FBQyxLQUFLTCxZQUFMLENBQWtCTSxZQUFsQixDQUErQmQsRUFBRSxDQUFDUyxLQUFsQyxFQUF5Q00sTUFBcEQ7QUFDQSxRQUFJQyxLQUFLLEdBQUNDLE1BQU0sQ0FBQyxLQUFLUCxVQUFMLENBQWdCSSxZQUFoQixDQUE2QmQsRUFBRSxDQUFDUyxLQUFoQyxFQUF1Q00sTUFBeEMsQ0FBaEI7O0FBQ0EsUUFBSSxDQUFDRyxLQUFLLENBQUNGLEtBQUQsQ0FBVixFQUFrQjtBQUNsQkcsTUFBQUEsTUFBTSxDQUFDQyxlQUFQLENBQXVCUCxNQUF2QixFQUE4QkcsS0FBOUI7QUFDQUcsTUFBQUEsTUFBTSxDQUFDRSxvQkFBUCxDQUE0QlIsTUFBNUI7QUFDQSxXQUFLVCxhQUFMLENBQW1Ca0IsT0FBbkI7QUFDQztBQUNELEdBckNPLENBdUNSOztBQXZDUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+WwgeWBnOi0puWPt1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRBY2NvdW50X0xhYmVsOntcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTm9kZSxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LFxyXG5cdFx0VXNlcl9JZF9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRJbnB1dF9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRcclxuXHR9LFxyXG5cclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIE9wZW5pZD10aGlzLlVzZXJfSWRfU2hvdy5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuXHRcdHZhciBJbnB1dD1OdW1iZXIodGhpcy5JbnB1dF9TaG93LmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKTtcclxuXHRcdGlmICghaXNOYU4oSW5wdXQpKXtcclxuXHRcdFdlQ2hhdC5DbG9zdXJlX0FjY291bnQoT3BlbmlkLElucHV0KTtcclxuXHRcdFdlQ2hhdC5IYW5kbGVfUmVwb3J0ZWRfVXNlcihPcGVuaWQpO1xyXG5cdFx0dGhpcy5BY2NvdW50X0xhYmVsLmRlc3Ryb3koKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcbiJdfQ==