
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Handle_Reported_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e02daNVnhVHjIYR/RnbYwcg', 'Handle_Reported_User');
// resources/script/Account_Management/Handle_Reported_User.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Openid_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    WeChat.Handle_Reported_User(this.Openid_Show.getComponent(cc.Label).string);
    this.Account_Label.destroy();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcSGFuZGxlX1JlcG9ydGVkX1VzZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJPcGVuaWRfU2hvdyIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwiQWNjb3VudF9MYWJlbCIsIk5vZGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIldlQ2hhdCIsIkhhbmRsZV9SZXBvcnRlZF9Vc2VyIiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiZGVzdHJveSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFdBQVcsRUFBQztBQUNULGlCQUFRLElBREM7QUFFVEMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLEtBRkM7QUFHVEMsTUFBQUEsV0FBVyxFQUFDO0FBSEgsS0FESjtBQU1mQyxJQUFBQSxhQUFhLEVBQUM7QUFDVixpQkFBUSxJQURFO0FBRVZILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxJQUZFO0FBR1ZGLE1BQUFBLFdBQVcsRUFBQztBQUhGO0FBTkMsR0FIUDtBQWlCTDtBQUVBO0FBRUFHLEVBQUFBLEtBckJLLG1CQXFCSSxDQUVSLENBdkJJO0FBeUJMQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDdkJDLElBQUFBLE1BQU0sQ0FBQ0Msb0JBQVAsQ0FBNEIsS0FBS1QsV0FBTCxDQUFpQlUsWUFBakIsQ0FBOEJkLEVBQUUsQ0FBQ00sS0FBakMsRUFBd0NTLE1BQXBFO0FBQ0gsU0FBS1AsYUFBTCxDQUFtQlEsT0FBbkI7QUFDRDtBQTVCTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgT3BlbmlkX1Nob3c6e1xyXG4gICAgICAgIFx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcbiAgICAgICAgXHRcdFx0dHlwZTpjYy5MYWJlbCxcclxuICAgICAgICBcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sXHJcblx0QWNjb3VudF9MYWJlbDp7XHJcblx0XHRcdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHRcdFx0dHlwZTpjYy5Ob2RlLFxyXG5cdFx0XHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uX2J0bl9jbGljazogZnVuY3Rpb24oKSB7XHJcbiAgICBcdFx0V2VDaGF0LkhhbmRsZV9SZXBvcnRlZF9Vc2VyKHRoaXMuT3BlbmlkX1Nob3cuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcpO1xyXG5cdFx0XHR0aGlzLkFjY291bnRfTGFiZWwuZGVzdHJveSgpO1xyXG5cdH1cclxufSk7XHJcbiJdfQ==