
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1f137N8wjtIf6TUMv85q+ne', 'Game');
// resources/script/Game_Coming/Game.js

"use strict";

//控制游戏进程的JS脚本
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Bird: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //载入小鸟
    Background: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //载入背景
    Fraction: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //载入分数统计
    Waterpipe_Up: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入上方水管的预制体
    Waterpipe_Down: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入下方水管的预制体
    Fall_Gold: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入金币的预制体
    Is_Start: false,
    //控制游戏是否进行
    time: 0,
    //载入时间
    Time_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //载入倒计的Label
    daojishi: 3 //设置倒计时时间

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onLoad: function onLoad() {
    Game_Local_Varible.Gold = 0;
    Game_Local_Varible.Fraction = 0;
    this.Bird.node.active = false;
    this.Background.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
    cc.loader.load({
      url: 'https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/music/Background_Music.mp3?sign=386a04ae0314e518d75477e111518b42&t=1610622832',
      type: 'mp3'
    }, function (err, data) {
      console.log(data);
      cc.audioEngine.playMusic(data);
    }); //cc.audioEngine.play("https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/music/Background_Music.mp3?sign=386a04ae0314e518d75477e111518b42&t=1610622832", false,0.1);
  },
  start: function start() {
    this.Time_Label.string = 3; //  场景文本框为 显示3

    this.daojishi = 3;

    if (this.daojishi >= 0) {
      this.schedule(function () {
        // 计时器将每隔 1s 执行一次。
        this.DoSomething();

        if (this.daojishi == 0) {
          this.Time_Label.enabled = false;
          this.Is_Start = true;
          this.Bird.node.active = true;
        }
      }, 1);
    }
  },
  update: function update(dt) {
    this.time += 1;
    this.gainScore(); //每隔一段时间生成一个水管

    if (this.time % 100 == 0 && this.Is_Start) {
      this.spawnNewWaterpipe();
    } //如果小鸟飞出了界面，游戏结束，进行跳转。


    if (this.Bird.node.y > 2000) {
      cc.director.loadScene("Game_Over");
    }
  },
  //随机生成新的水管
  spawnNewWaterpipe: function spawnNewWaterpipe() {
    var Waterpipe_Up_randY = Math.random() * 400 + 800 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 200; //随机生成上方水管的坐标

    var Waterpipe_Down_randY = Waterpipe_Up_randY - Math.random() * 200 - 2000 + 200 * Game_Difficulty_Local_Varible.Difficulty_Ratio; //随机生成下方水管的坐标

    var Gold_randY = (Waterpipe_Up_randY + Waterpipe_Down_randY) / 2; //再水管中间生成金币的坐标

    var randX = 700; //生成水管的X坐标
    //生成新的水管和进行，并且把他们加入到画布中

    var New_Waterpipe_Up = cc.instantiate(this.Waterpipe_Up);
    this.node.addChild(New_Waterpipe_Up);
    New_Waterpipe_Up.setPosition(randX, Waterpipe_Up_randY);
    var New_Waterpipe_Down = cc.instantiate(this.Waterpipe_Down);
    this.node.addChild(New_Waterpipe_Down);
    New_Waterpipe_Down.setPosition(randX, Waterpipe_Down_randY);
    var New_Fall_Gold = cc.instantiate(this.Fall_Gold);
    this.node.addChild(New_Fall_Gold);
    New_Fall_Gold.setPosition(randX, Gold_randY);
  },
  gainScore: function gainScore() {
    // 更新 scoreDisplay Label 的文字
    this.Fraction.string = 'Score: ' + Game_Local_Varible.Fraction / 2;
  },
  DoSomething: function DoSomething() {
    // 倒计时算法
    if (this.daojishi >= 1) {
      this.daojishi = this.daojishi - 1;
      this.Time_Label.string = this.daojishi; //场景中文本框显示 
      //cc.log("daojishi=" + this.daojishi);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxHYW1lLmpzIl0sIm5hbWVzIjpbIkdhbWVfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQmlyZCIsInR5cGUiLCJTcHJpdGUiLCJzZXJpYWx6YWJsZSIsIkJhY2tncm91bmQiLCJGcmFjdGlvbiIsIkxhYmVsIiwiV2F0ZXJwaXBlX1VwIiwiUHJlZmFiIiwiV2F0ZXJwaXBlX0Rvd24iLCJGYWxsX0dvbGQiLCJJc19TdGFydCIsInRpbWUiLCJUaW1lX0xhYmVsIiwiZGFvamlzaGkiLCJvbkxvYWQiLCJHb2xkIiwibm9kZSIsImFjdGl2ZSIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwiQ3VycmVudF9NYXAiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJhdWRpb0VuZ2luZSIsInBsYXlNdXNpYyIsInN0YXJ0Iiwic3RyaW5nIiwic2NoZWR1bGUiLCJEb1NvbWV0aGluZyIsImVuYWJsZWQiLCJ1cGRhdGUiLCJkdCIsImdhaW5TY29yZSIsInNwYXduTmV3V2F0ZXJwaXBlIiwieSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwiV2F0ZXJwaXBlX1VwX3JhbmRZIiwiTWF0aCIsInJhbmRvbSIsIkRpZmZpY3VsdHlfUmF0aW8iLCJXYXRlcnBpcGVfRG93bl9yYW5kWSIsIkdvbGRfcmFuZFkiLCJyYW5kWCIsIk5ld19XYXRlcnBpcGVfVXAiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJOZXdfV2F0ZXJwaXBlX0Rvd24iLCJOZXdfRmFsbF9Hb2xkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxvQkFBRCxDQUFoQzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBR0QsT0FBTyxDQUFDLCtCQUFELENBQTNDOztBQUNBRSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFHWEMsSUFBQUEsSUFBSSxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGSjtBQUdMQyxNQUFBQSxXQUFXLEVBQUU7QUFIUixLQUhLO0FBT1I7QUFDSEMsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGRTtBQUdYQyxNQUFBQSxXQUFXLEVBQUU7QUFIRixLQVJEO0FBWVI7QUFDSEUsSUFBQUEsUUFBUSxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1UsS0FGQTtBQUdUSCxNQUFBQSxXQUFXLEVBQUU7QUFISixLQWJDO0FBaUJSO0FBQ0hJLElBQUFBLFlBQVksRUFBRTtBQUNiLGlCQUFTLElBREk7QUFFYk4sTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNZLE1BRkk7QUFHYkwsTUFBQUEsV0FBVyxFQUFFO0FBSEEsS0FsQkg7QUFzQlI7QUFDSE0sSUFBQUEsY0FBYyxFQUFFO0FBQ2YsaUJBQVMsSUFETTtBQUVmUixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1ksTUFGTTtBQUdmTCxNQUFBQSxXQUFXLEVBQUU7QUFIRSxLQXZCTDtBQTJCUjtBQUNITyxJQUFBQSxTQUFTLEVBQUU7QUFDVixpQkFBUyxJQURDO0FBRVZULE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDWSxNQUZDO0FBR1ZMLE1BQUFBLFdBQVcsRUFBRTtBQUhILEtBNUJBO0FBZ0NSO0FBQ0hRLElBQUFBLFFBQVEsRUFBRSxLQWpDQztBQWlDTTtBQUNqQkMsSUFBQUEsSUFBSSxFQUFFLENBbENLO0FBa0NGO0FBQ1RDLElBQUFBLFVBQVUsRUFBRTtBQUNYLGlCQUFTLElBREU7QUFFWFosTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNVLEtBRkU7QUFHWEgsTUFBQUEsV0FBVyxFQUFFO0FBSEYsS0FuQ0Q7QUF1Q1I7QUFDSFcsSUFBQUEsUUFBUSxFQUFFLENBeENDLENBd0NFOztBQXhDRixHQUhKO0FBNkNSO0FBQ0E7QUFDQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCdEIsSUFBQUEsa0JBQWtCLENBQUN1QixJQUFuQixHQUEwQixDQUExQjtBQUNBdkIsSUFBQUEsa0JBQWtCLENBQUNZLFFBQW5CLEdBQThCLENBQTlCO0FBQ0EsU0FBS0wsSUFBTCxDQUFVaUIsSUFBVixDQUFlQyxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS2QsVUFBTCxDQUFnQmUsWUFBaEIsQ0FBNkJ2QixFQUFFLENBQUNNLE1BQWhDLEVBQXdDa0IsV0FBeEMsR0FBc0QzQixrQkFBa0IsQ0FBQzRCLFdBQXpFO0FBQ0F6QixJQUFBQSxFQUFFLENBQUMwQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUFDQyxNQUFBQSxHQUFHLEVBQUMsMElBQUw7QUFBaUp2QixNQUFBQSxJQUFJLEVBQUU7QUFBdkosS0FBZixFQUE4SyxVQUFVd0IsR0FBVixFQUFlQyxJQUFmLEVBQXFCO0FBQ2xNQyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsSUFBWjtBQUNBOUIsTUFBQUEsRUFBRSxDQUFDaUMsV0FBSCxDQUFlQyxTQUFmLENBQXlCSixJQUF6QjtBQUNDLEtBSEYsRUFMa0IsQ0FTbEI7QUFDQSxHQXpETztBQTJEUkssRUFBQUEsS0FBSyxFQUFFLGlCQUFXO0FBQ2pCLFNBQUtsQixVQUFMLENBQWdCbUIsTUFBaEIsR0FBeUIsQ0FBekIsQ0FEaUIsQ0FDVzs7QUFDNUIsU0FBS2xCLFFBQUwsR0FBZ0IsQ0FBaEI7O0FBQ0EsUUFBSSxLQUFLQSxRQUFMLElBQWlCLENBQXJCLEVBQXdCO0FBQ3ZCLFdBQUttQixRQUFMLENBQWMsWUFBVztBQUFFO0FBQzFCLGFBQUtDLFdBQUw7O0FBQ0EsWUFBSSxLQUFLcEIsUUFBTCxJQUFpQixDQUFyQixFQUF3QjtBQUN2QixlQUFLRCxVQUFMLENBQWdCc0IsT0FBaEIsR0FBMEIsS0FBMUI7QUFDQSxlQUFLeEIsUUFBTCxHQUFnQixJQUFoQjtBQUNBLGVBQUtYLElBQUwsQ0FBVWlCLElBQVYsQ0FBZUMsTUFBZixHQUF3QixJQUF4QjtBQUNBO0FBQ0QsT0FQRCxFQU9HLENBUEg7QUFRQTtBQUNELEdBeEVPO0FBeUVSa0IsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEIsU0FBS3pCLElBQUwsSUFBYSxDQUFiO0FBQ0EsU0FBSzBCLFNBQUwsR0FGb0IsQ0FHcEI7O0FBQ0EsUUFBSSxLQUFLMUIsSUFBTCxHQUFZLEdBQVosSUFBbUIsQ0FBbkIsSUFBd0IsS0FBS0QsUUFBakMsRUFBMkM7QUFDMUMsV0FBSzRCLGlCQUFMO0FBQ0EsS0FObUIsQ0FPcEI7OztBQUNBLFFBQUksS0FBS3ZDLElBQUwsQ0FBVWlCLElBQVYsQ0FBZXVCLENBQWYsR0FBbUIsSUFBdkIsRUFBNkI7QUFDNUI1QyxNQUFBQSxFQUFFLENBQUM2QyxRQUFILENBQVlDLFNBQVosQ0FBc0IsV0FBdEI7QUFDQTtBQUNELEdBcEZPO0FBcUZSO0FBQ0FILEVBQUFBLGlCQXRGUSwrQkFzRlk7QUFDbkIsUUFBSUksa0JBQWtCLEdBQUdDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFoQixHQUFzQixHQUF0QixHQUE0QmxELDZCQUE2QixDQUFDbUQsZ0JBQTlCLEdBQWlELEdBQXRHLENBRG1CLENBQ3dGOztBQUMzRyxRQUFJQyxvQkFBb0IsR0FBR0osa0JBQWtCLEdBQUdDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFyQyxHQUEyQyxJQUEzQyxHQUFrRCxNQUFNbEQsNkJBQTZCLENBQUNtRCxnQkFBakgsQ0FGbUIsQ0FFZ0g7O0FBQ25JLFFBQUlFLFVBQVUsR0FBRyxDQUFDTCxrQkFBa0IsR0FBR0ksb0JBQXRCLElBQThDLENBQS9ELENBSG1CLENBRytDOztBQUNsRSxRQUFJRSxLQUFLLEdBQUcsR0FBWixDQUptQixDQUlGO0FBQ2pCOztBQUNBLFFBQUlDLGdCQUFnQixHQUFHdEQsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLEtBQUs1QyxZQUFwQixDQUF2QjtBQUNBLFNBQUtVLElBQUwsQ0FBVW1DLFFBQVYsQ0FBbUJGLGdCQUFuQjtBQUNBQSxJQUFBQSxnQkFBZ0IsQ0FBQ0csV0FBakIsQ0FBNkJKLEtBQTdCLEVBQW9DTixrQkFBcEM7QUFFQSxRQUFJVyxrQkFBa0IsR0FBRzFELEVBQUUsQ0FBQ3VELFdBQUgsQ0FBZSxLQUFLMUMsY0FBcEIsQ0FBekI7QUFDQSxTQUFLUSxJQUFMLENBQVVtQyxRQUFWLENBQW1CRSxrQkFBbkI7QUFDQUEsSUFBQUEsa0JBQWtCLENBQUNELFdBQW5CLENBQStCSixLQUEvQixFQUFzQ0Ysb0JBQXRDO0FBRUEsUUFBSVEsYUFBYSxHQUFHM0QsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLEtBQUt6QyxTQUFwQixDQUFwQjtBQUNBLFNBQUtPLElBQUwsQ0FBVW1DLFFBQVYsQ0FBbUJHLGFBQW5CO0FBQ0FBLElBQUFBLGFBQWEsQ0FBQ0YsV0FBZCxDQUEwQkosS0FBMUIsRUFBaUNELFVBQWpDO0FBRUEsR0F4R087QUF5R1JWLEVBQUFBLFNBekdRLHVCQXlHSTtBQUNYO0FBQ0EsU0FBS2pDLFFBQUwsQ0FBYzJCLE1BQWQsR0FBdUIsWUFBYXZDLGtCQUFrQixDQUFDWSxRQUFuQixHQUE4QixDQUFsRTtBQUVBLEdBN0dPO0FBOEdSNkIsRUFBQUEsV0E5R1EseUJBOEdNO0FBQUU7QUFDZixRQUFJLEtBQUtwQixRQUFMLElBQWlCLENBQXJCLEVBQXdCO0FBQ3ZCLFdBQUtBLFFBQUwsR0FBZ0IsS0FBS0EsUUFBTCxHQUFnQixDQUFoQztBQUNBLFdBQUtELFVBQUwsQ0FBZ0JtQixNQUFoQixHQUF5QixLQUFLbEIsUUFBOUIsQ0FGdUIsQ0FFaUI7QUFDeEM7QUFDQTtBQUNEO0FBcEhPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5o6n5Yi25ri45oiP6L+b56iL55qESlPohJrmnKxcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblxyXG5cclxuXHRcdEJpcmQ6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuU3ByaXRlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6L295YWl5bCP6bifXHJcblx0XHRCYWNrZ3JvdW5kOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlNwcml0ZSxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i9veWFpeiDjOaZr1xyXG5cdFx0RnJhY3Rpb246IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ovb3lhaXliIbmlbDnu5/orqFcclxuXHRcdFdhdGVycGlwZV9VcDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ovb3lhaXkuIrmlrnmsLTnrqHnmoTpooTliLbkvZNcclxuXHRcdFdhdGVycGlwZV9Eb3duOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i9veWFpeS4i+aWueawtOeuoeeahOmihOWItuS9k1xyXG5cdFx0RmFsbF9Hb2xkOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i9veWFpemHkeW4geeahOmihOWItuS9k1xyXG5cdFx0SXNfU3RhcnQ6IGZhbHNlLCAvL+aOp+WItua4uOaIj+aYr+WQpui/m+ihjFxyXG5cdFx0dGltZTogMCwgLy/ovb3lhaXml7bpl7RcclxuXHRcdFRpbWVfTGFiZWw6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ovb3lhaXlgJLorqHnmoRMYWJlbFxyXG5cdFx0ZGFvamlzaGk6IDMsIC8v6K6+572u5YCS6K6h5pe25pe26Ze0XHJcblx0fSxcclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblx0b25Mb2FkOiBmdW5jdGlvbigpIHtcclxuXHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5Hb2xkID0gMDtcclxuXHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiA9IDA7XHJcblx0XHR0aGlzLkJpcmQubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuXHRcdHRoaXMuQmFja2dyb3VuZC5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IEdhbWVfTG9jYWxfVmFyaWJsZS5DdXJyZW50X01hcDtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHt1cmw6J2h0dHBzOi8vN2E2My16Y3gtNmdiZ2R4ZHkyNTQ4MTZiMC0xMzA0MzQyOTQ3LnRjYi5xY2xvdWQubGEvbXVzaWMvQmFja2dyb3VuZF9NdXNpYy5tcDM/c2lnbj0zODZhMDRhZTAzMTRlNTE4ZDc1NDc3ZTExMTUxOGI0MiZ0PTE2MTA2MjI4MzInLCB0eXBlOiAnbXAzJ30sIGZ1bmN0aW9uIChlcnIsIGRhdGEpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coZGF0YSk7XHJcblx0XHRcdGNjLmF1ZGlvRW5naW5lLnBsYXlNdXNpYyhkYXRhKTtcclxuXHRcdFx0fSk7XHJcblx0XHQvL2NjLmF1ZGlvRW5naW5lLnBsYXkoXCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL211c2ljL0JhY2tncm91bmRfTXVzaWMubXAzP3NpZ249Mzg2YTA0YWUwMzE0ZTUxOGQ3NTQ3N2UxMTE1MThiNDImdD0xNjEwNjIyODMyXCIsIGZhbHNlLDAuMSk7XHJcblx0fSxcclxuXHJcblx0c3RhcnQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dGhpcy5UaW1lX0xhYmVsLnN0cmluZyA9IDM7IC8vICDlnLrmma/mlofmnKzmoYbkuLog5pi+56S6M1xyXG5cdFx0dGhpcy5kYW9qaXNoaSA9IDM7XHJcblx0XHRpZiAodGhpcy5kYW9qaXNoaSA+PSAwKSB7XHJcblx0XHRcdHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7IC8vIOiuoeaXtuWZqOWwhuavj+malCAxcyDmiafooYzkuIDmrKHjgIJcclxuXHRcdFx0XHR0aGlzLkRvU29tZXRoaW5nKCk7XHJcblx0XHRcdFx0aWYgKHRoaXMuZGFvamlzaGkgPT0gMCkge1xyXG5cdFx0XHRcdFx0dGhpcy5UaW1lX0xhYmVsLmVuYWJsZWQgPSBmYWxzZTtcclxuXHRcdFx0XHRcdHRoaXMuSXNfU3RhcnQgPSB0cnVlO1xyXG5cdFx0XHRcdFx0dGhpcy5CaXJkLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0sIDEpO1xyXG5cdFx0fVxyXG5cdH0sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0dGhpcy50aW1lICs9IDE7XHJcblx0XHR0aGlzLmdhaW5TY29yZSgpO1x0XHJcblx0XHQvL+avj+malOS4gOauteaXtumXtOeUn+aIkOS4gOS4quawtOeuoVxyXG5cdFx0aWYgKHRoaXMudGltZSAlIDEwMCA9PSAwICYmIHRoaXMuSXNfU3RhcnQpIHtcclxuXHRcdFx0dGhpcy5zcGF3bk5ld1dhdGVycGlwZSgpO1xyXG5cdFx0fVxyXG5cdFx0Ly/lpoLmnpzlsI/puJ/po57lh7rkuobnlYzpnaLvvIzmuLjmiI/nu5PmnZ/vvIzov5vooYzot7PovazjgIJcclxuXHRcdGlmICh0aGlzLkJpcmQubm9kZS55ID4gMjAwMCkge1xyXG5cdFx0XHRjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lX092ZXJcIik7XHJcblx0XHR9XHJcblx0fSxcclxuXHQvL+maj+acuueUn+aIkOaWsOeahOawtOeuoVxyXG5cdHNwYXduTmV3V2F0ZXJwaXBlKCkge1xyXG5cdFx0dmFyIFdhdGVycGlwZV9VcF9yYW5kWSA9IE1hdGgucmFuZG9tKCkgKiA0MDAgKyA4MDAgKyBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICogMjAwOyAvL+maj+acuueUn+aIkOS4iuaWueawtOeuoeeahOWdkOagh1xyXG5cdFx0dmFyIFdhdGVycGlwZV9Eb3duX3JhbmRZID0gV2F0ZXJwaXBlX1VwX3JhbmRZIC0gTWF0aC5yYW5kb20oKSAqIDIwMCAtIDIwMDAgKyAyMDAgKiBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvOyAvL+maj+acuueUn+aIkOS4i+aWueawtOeuoeeahOWdkOagh1xyXG5cdFx0dmFyIEdvbGRfcmFuZFkgPSAoV2F0ZXJwaXBlX1VwX3JhbmRZICsgV2F0ZXJwaXBlX0Rvd25fcmFuZFkpIC8gMjsgLy/lho3msLTnrqHkuK3pl7TnlJ/miJDph5HluIHnmoTlnZDmoIdcclxuXHRcdHZhciByYW5kWCA9IDcwMDsgLy/nlJ/miJDmsLTnrqHnmoRY5Z2Q5qCHXHJcblx0XHQvL+eUn+aIkOaWsOeahOawtOeuoeWSjOi/m+ihjO+8jOW5tuS4lOaKiuS7luS7rOWKoOWFpeWIsOeUu+W4g+S4rVxyXG5cdFx0dmFyIE5ld19XYXRlcnBpcGVfVXAgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLldhdGVycGlwZV9VcCk7XHJcblx0XHR0aGlzLm5vZGUuYWRkQ2hpbGQoTmV3X1dhdGVycGlwZV9VcCk7XHJcblx0XHROZXdfV2F0ZXJwaXBlX1VwLnNldFBvc2l0aW9uKHJhbmRYLCBXYXRlcnBpcGVfVXBfcmFuZFkpO1xyXG5cclxuXHRcdHZhciBOZXdfV2F0ZXJwaXBlX0Rvd24gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLldhdGVycGlwZV9Eb3duKTtcclxuXHRcdHRoaXMubm9kZS5hZGRDaGlsZChOZXdfV2F0ZXJwaXBlX0Rvd24pO1xyXG5cdFx0TmV3X1dhdGVycGlwZV9Eb3duLnNldFBvc2l0aW9uKHJhbmRYLCBXYXRlcnBpcGVfRG93bl9yYW5kWSk7XHJcblxyXG5cdFx0dmFyIE5ld19GYWxsX0dvbGQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkZhbGxfR29sZCk7XHJcblx0XHR0aGlzLm5vZGUuYWRkQ2hpbGQoTmV3X0ZhbGxfR29sZCk7XHJcblx0XHROZXdfRmFsbF9Hb2xkLnNldFBvc2l0aW9uKHJhbmRYLCBHb2xkX3JhbmRZKTtcclxuXHJcblx0fSxcclxuXHRnYWluU2NvcmUoKSB7XHJcblx0XHQvLyDmm7TmlrAgc2NvcmVEaXNwbGF5IExhYmVsIOeahOaWh+Wtl1xyXG5cdFx0dGhpcy5GcmFjdGlvbi5zdHJpbmcgPSAnU2NvcmU6ICcgKyAoR2FtZV9Mb2NhbF9WYXJpYmxlLkZyYWN0aW9uIC8gMik7XHJcblxyXG5cdH0sXHJcblx0RG9Tb21ldGhpbmcoKSB7IC8vIOWAkuiuoeaXtueul+azlVxyXG5cdFx0aWYgKHRoaXMuZGFvamlzaGkgPj0gMSkge1xyXG5cdFx0XHR0aGlzLmRhb2ppc2hpID0gdGhpcy5kYW9qaXNoaSAtIDE7XHJcblx0XHRcdHRoaXMuVGltZV9MYWJlbC5zdHJpbmcgPSB0aGlzLmRhb2ppc2hpOyAvL+WcuuaZr+S4reaWh+acrOahhuaYvuekuiBcclxuXHRcdFx0Ly9jYy5sb2coXCJkYW9qaXNoaT1cIiArIHRoaXMuZGFvamlzaGkpO1xyXG5cdFx0fVxyXG5cdH1cclxufSk7XHJcbiJdfQ==