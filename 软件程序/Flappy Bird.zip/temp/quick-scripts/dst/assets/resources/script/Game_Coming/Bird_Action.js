
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Bird_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a5d13OmP/tDJbQItrMrcI7P', 'Bird_Action');
// resources/script/Game_Coming/Bird_Action.js

"use strict";

//控制小鸟的运动情况
var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    birdwingAudio: {
      "default": null,
      type: cc.AudioClip
    },
    birddieAudio: {
      "default": null,
      type: cc.AudioClip
    },
    _V_Index: 0,
    //小鸟垂直速度
    _Is_Sart: true,
    //游戏是否进行
    Jump_Up_Acc: 0,
    //上升速度
    Jump_Down_Acc: 0
  },
  onLoad: function onLoad() {
    //开启小鸟的碰撞属性
    var manager = cc.director.getCollisionManager(); //manager.enabledDebugDraw = true;

    manager.enabled = true; //监听屏幕是否被点击

    this.node.parent.on(cc.Node.EventType.TOUCH_START, this.onTouchMove, this);
  },
  onDestroy: function onDestroy() {// 取消键盘输入监听
  },
  start: function start() {},
  update: function update(dt) {
    //如果游戏开始，是的小鸟开始掉落
    if (this._Is_Sart) {
      //随着时间的增长，增加下降速度。
      this._V_Index -= this.Jump_Down_Acc * dt;
    } //通过改变小鸟坐标的形式，使得小鸟移动


    this.node.y += this._V_Index * dt;
  },
  onTouchMove: function onTouchMove(event) {
    //如果屏幕被点击，给予小鸟一个向上的加速度
    this._V_Index = this.Jump_Up_Acc * 20;
    cc.audioEngine.playEffect(this.birdwingAudio, false, 0.2);
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    //如果发生碰撞，调用函数
    console.log("other.name = ", other.node.name, other.node.group, other.node.groupIndex);

    if (other.node.groupIndex === 1) {
      // 与障碍物相撞
      cc.audioEngine.playEffect(this.birddieAudio, false, 0.1);
      this._Is_Sart = false;
      this._V_Index = 3000;
      cc.audioEngine.stopMusic(); //使得小鸟向上飞出屏幕
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxCaXJkX0FjdGlvbi5qcyJdLCJuYW1lcyI6WyJHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImJpcmR3aW5nQXVkaW8iLCJ0eXBlIiwiQXVkaW9DbGlwIiwiYmlyZGRpZUF1ZGlvIiwiX1ZfSW5kZXgiLCJfSXNfU2FydCIsIkp1bXBfVXBfQWNjIiwiSnVtcF9Eb3duX0FjYyIsIm9uTG9hZCIsIm1hbmFnZXIiLCJkaXJlY3RvciIsImdldENvbGxpc2lvbk1hbmFnZXIiLCJlbmFibGVkIiwibm9kZSIsInBhcmVudCIsIm9uIiwiTm9kZSIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwib25Ub3VjaE1vdmUiLCJvbkRlc3Ryb3kiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwieSIsImV2ZW50IiwiYXVkaW9FbmdpbmUiLCJwbGF5RWZmZWN0Iiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImNvbnNvbGUiLCJsb2ciLCJuYW1lIiwiZ3JvdXAiLCJncm91cEluZGV4Iiwic3RvcE11c2ljIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsNkJBQTZCLEdBQUdDLE9BQU8sQ0FBQywrQkFBRCxDQUEzQzs7QUFFQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFHUixhQUFTRCxFQUFFLENBQUNFLFNBSEo7QUFJUkMsRUFBQUEsVUFBVSxFQUFFO0FBRVhDLElBQUFBLGFBQWEsRUFBRTtBQUNMLGlCQUFTLElBREo7QUFFTEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkosS0FGSjtBQU9YQyxJQUFBQSxZQUFZLEVBQUU7QUFDSixpQkFBUyxJQURMO0FBRUpGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZMLEtBUEg7QUFZWEUsSUFBQUEsUUFBUSxFQUFFLENBWkM7QUFZRTtBQUNiQyxJQUFBQSxRQUFRLEVBQUUsSUFiQztBQWFLO0FBQ2hCQyxJQUFBQSxXQUFXLEVBQUUsQ0FkRjtBQWNLO0FBQ2hCQyxJQUFBQSxhQUFhLEVBQUU7QUFmSixHQUpKO0FBdUJSQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQSxRQUFJQyxPQUFPLEdBQUdiLEVBQUUsQ0FBQ2MsUUFBSCxDQUFZQyxtQkFBWixFQUFkLENBRmtCLENBR2xCOztBQUNBRixJQUFBQSxPQUFPLENBQUNHLE9BQVIsR0FBa0IsSUFBbEIsQ0FKa0IsQ0FLbEI7O0FBQ0EsU0FBS0MsSUFBTCxDQUFVQyxNQUFWLENBQWlCQyxFQUFqQixDQUFvQm5CLEVBQUUsQ0FBQ29CLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsV0FBdEMsRUFBbUQsS0FBS0MsV0FBeEQsRUFBcUUsSUFBckU7QUFFQSxHQS9CTztBQWlDUkMsRUFBQUEsU0FqQ1EsdUJBaUNJLENBQ1g7QUFFQSxHQXBDTztBQXNDUkMsRUFBQUEsS0F0Q1EsbUJBc0NBLENBRVAsQ0F4Q087QUEwQ1JDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhO0FBQ3BCO0FBQ0EsUUFBSSxLQUFLbEIsUUFBVCxFQUFtQjtBQUNsQjtBQUNBLFdBQUtELFFBQUwsSUFBaUIsS0FBS0csYUFBTCxHQUFxQmdCLEVBQXRDO0FBQ0EsS0FMbUIsQ0FNcEI7OztBQUNBLFNBQUtWLElBQUwsQ0FBVVcsQ0FBVixJQUFlLEtBQUtwQixRQUFMLEdBQWdCbUIsRUFBL0I7QUFFQSxHQW5ETztBQW9EUkosRUFBQUEsV0FwRFEsdUJBb0RJTSxLQXBESixFQW9EVztBQUNsQjtBQUNBLFNBQUtyQixRQUFMLEdBQWdCLEtBQUtFLFdBQUwsR0FBbUIsRUFBbkM7QUFDQVYsSUFBQUEsRUFBRSxDQUFDOEIsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUszQixhQUEvQixFQUE4QyxLQUE5QyxFQUFvRCxHQUFwRDtBQUNBLEdBeERPO0FBMERSNEIsRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVNDLEtBQVQsRUFBZ0JDLElBQWhCLEVBQXNCO0FBQ3ZDO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFBNkJILEtBQUssQ0FBQ2hCLElBQU4sQ0FBV29CLElBQXhDLEVBQThDSixLQUFLLENBQUNoQixJQUFOLENBQVdxQixLQUF6RCxFQUFnRUwsS0FBSyxDQUFDaEIsSUFBTixDQUFXc0IsVUFBM0U7O0FBQ0EsUUFBSU4sS0FBSyxDQUFDaEIsSUFBTixDQUFXc0IsVUFBWCxLQUEwQixDQUE5QixFQUFpQztBQUFFO0FBQ2xDdkMsTUFBQUEsRUFBRSxDQUFDOEIsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUt4QixZQUEvQixFQUE2QyxLQUE3QyxFQUFtRCxHQUFuRDtBQUNBLFdBQUtFLFFBQUwsR0FBZ0IsS0FBaEI7QUFDQSxXQUFLRCxRQUFMLEdBQWdCLElBQWhCO0FBQ0FSLE1BQUFBLEVBQUUsQ0FBQzhCLFdBQUgsQ0FBZVUsU0FBZixHQUpnQyxDQUtoQztBQUNBO0FBQ0Q7QUFwRU8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/mjqfliLblsI/puJ/nmoTov5Dliqjmg4XlhrVcclxudmFyIEdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUnKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuXHJcblxyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHRwcm9wZXJ0aWVzOiB7XHJcblxyXG5cdFx0YmlyZHdpbmdBdWRpbzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXBcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGJpcmRkaWVBdWRpbzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXBcclxuICAgICAgICB9LFxyXG5cclxuXHRcdF9WX0luZGV4OiAwLCAvL+Wwj+m4n+WeguebtOmAn+W6plxyXG5cdFx0X0lzX1NhcnQ6IHRydWUsIC8v5ri45oiP5piv5ZCm6L+b6KGMXHJcblx0XHRKdW1wX1VwX0FjYzogMCwgLy/kuIrljYfpgJ/luqZcclxuXHRcdEp1bXBfRG93bl9BY2M6IDAsXHJcblx0fSxcclxuXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+W8gOWQr+Wwj+m4n+eahOeisOaSnuWxnuaAp1xyXG5cdFx0dmFyIG1hbmFnZXIgPSBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCk7XHJcblx0XHQvL21hbmFnZXIuZW5hYmxlZERlYnVnRHJhdyA9IHRydWU7XHJcblx0XHRtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0Ly/nm5HlkKzlsY/luZXmmK/lkKbooqvngrnlh7tcclxuXHRcdHRoaXMubm9kZS5wYXJlbnQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMub25Ub3VjaE1vdmUsIHRoaXMpO1xyXG5cclxuXHR9LFxyXG5cclxuXHRvbkRlc3Ryb3koKSB7XHJcblx0XHQvLyDlj5bmtojplK7nm5jovpPlhaXnm5HlkKxcclxuXHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHtcclxuXHRcdC8v5aaC5p6c5ri45oiP5byA5aeL77yM5piv55qE5bCP6bif5byA5aeL5o6J6JC9XHJcblx0XHRpZiAodGhpcy5fSXNfU2FydCkge1xyXG5cdFx0XHQvL+maj+edgOaXtumXtOeahOWinumVv++8jOWinuWKoOS4i+mZjemAn+W6puOAglxyXG5cdFx0XHR0aGlzLl9WX0luZGV4IC09IHRoaXMuSnVtcF9Eb3duX0FjYyAqIGR0O1xyXG5cdFx0fVxyXG5cdFx0Ly/pgJrov4fmlLnlj5jlsI/puJ/lnZDmoIfnmoTlvaLlvI/vvIzkvb/lvpflsI/puJ/np7vliqhcclxuXHRcdHRoaXMubm9kZS55ICs9IHRoaXMuX1ZfSW5kZXggKiBkdDtcclxuXHJcblx0fSxcclxuXHRvblRvdWNoTW92ZShldmVudCkge1xyXG5cdFx0Ly/lpoLmnpzlsY/luZXooqvngrnlh7vvvIznu5nkuojlsI/puJ/kuIDkuKrlkJHkuIrnmoTliqDpgJ/luqZcclxuXHRcdHRoaXMuX1ZfSW5kZXggPSB0aGlzLkp1bXBfVXBfQWNjICogMjA7XHJcblx0XHRjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuYmlyZHdpbmdBdWRpbywgZmFsc2UsMC4yKTtcclxuXHR9LFxyXG5cclxuXHRvbkNvbGxpc2lvbkVudGVyOiBmdW5jdGlvbihvdGhlciwgc2VsZikge1xyXG5cdFx0Ly/lpoLmnpzlj5HnlJ/norDmkp7vvIzosIPnlKjlh73mlbBcclxuXHRcdGNvbnNvbGUubG9nKFwib3RoZXIubmFtZSA9IFwiLCBvdGhlci5ub2RlLm5hbWUsIG90aGVyLm5vZGUuZ3JvdXAsIG90aGVyLm5vZGUuZ3JvdXBJbmRleCk7XHJcblx0XHRpZiAob3RoZXIubm9kZS5ncm91cEluZGV4ID09PSAxKSB7IC8vIOS4jumanOeijeeJqeebuOaSnlxyXG5cdFx0XHRjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuYmlyZGRpZUF1ZGlvLCBmYWxzZSwwLjEpO1xyXG5cdFx0XHR0aGlzLl9Jc19TYXJ0ID0gZmFsc2U7XHJcblx0XHRcdHRoaXMuX1ZfSW5kZXggPSAzMDAwO1xyXG5cdFx0XHRjYy5hdWRpb0VuZ2luZS5zdG9wTXVzaWMoKTtcclxuXHRcdFx0Ly/kvb/lvpflsI/puJ/lkJHkuIrpo57lh7rlsY/luZVcclxuXHRcdH1cclxuXHR9LFxyXG59KTtcclxuIl19