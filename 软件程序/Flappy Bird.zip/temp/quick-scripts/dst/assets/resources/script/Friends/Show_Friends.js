
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Friends/Show_Friends.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1cdc5cSgyZOzKo5C1dUkTPd', 'Show_Friends');
// resources/script/Friends/Show_Friends.js

"use strict";

//加载好友
cc.Class({
  "extends": cc.Component,
  properties: {
    WXSubContextView: cc.SubContextView,
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    console.log("显示排行榜"); //获取时间戳

    var updateTime = parseInt(new Date().getTime() / 1000);
    var getArr = new Array(); //声明向开放数据域传递的变量

    var openDataContext = wx.getOpenDataContext(); //声明开发数据域

    var setArr = [{
      key: "score",
      value: String(Global_Variable.Best_Score)
    }];
    getArr.push("score"); //将score压入开放数据域
    //向开发数据域声明获取好友

    openDataContext.postMessage({
      type: "GET",
      data: getArr,
      timer: updateTime
    }); //将自己的成绩送入开放数据域

    console.log(setArr);
    openDataContext.postMessage({
      type: "SET",
      data: setArr,
      timer: updateTime
    });
    console.log("设置的信息为", setArr); //显示开放数据域

    this.SubContextView = null;
    this._Is_Loading = true;
    this.SubContextView = this.WXSubContextView.getComponent(cc.SubContextView);
    console.log("加载好友框中");
    this.SubContextView.enabled = true;
    this.SubContextView.active = true;
    console.log("加载好友框中");
    this.SubContextView.update();
    console.log("特别正常");
  },
  start: function start() {},
  update: function update(dt) {//加载好友框
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEZyaWVuZHNcXFNob3dfRnJpZW5kcy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIldYU3ViQ29udGV4dFZpZXciLCJTdWJDb250ZXh0VmlldyIsIl9Jc19Mb2FkaW5nIiwib25Mb2FkIiwiY29uc29sZSIsImxvZyIsInVwZGF0ZVRpbWUiLCJwYXJzZUludCIsIkRhdGUiLCJnZXRUaW1lIiwiZ2V0QXJyIiwiQXJyYXkiLCJvcGVuRGF0YUNvbnRleHQiLCJ3eCIsImdldE9wZW5EYXRhQ29udGV4dCIsInNldEFyciIsImtleSIsInZhbHVlIiwiU3RyaW5nIiwiR2xvYmFsX1ZhcmlhYmxlIiwiQmVzdF9TY29yZSIsInB1c2giLCJwb3N0TWVzc2FnZSIsInR5cGUiLCJkYXRhIiwidGltZXIiLCJnZXRDb21wb25lbnQiLCJlbmFibGVkIiwiYWN0aXZlIiwidXBkYXRlIiwic3RhcnQiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsZ0JBQWdCLEVBQUVKLEVBQUUsQ0FBQ0ssY0FEVjtBQUVYQyxJQUFBQSxXQUFXLEVBQUM7QUFGRCxHQUhKO0FBVVJDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVztBQUNsQkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQURrQixDQUVsQjs7QUFDQSxRQUFJQyxVQUFVLEdBQUdDLFFBQVEsQ0FBQyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsS0FBdUIsSUFBeEIsQ0FBekI7QUFDQSxRQUFJQyxNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiLENBSmtCLENBSVE7O0FBQzFCLFFBQUlDLGVBQWUsR0FBR0MsRUFBRSxDQUFDQyxrQkFBSCxFQUF0QixDQUxrQixDQUs2Qjs7QUFDL0MsUUFBSUMsTUFBTSxHQUFHLENBQUM7QUFDYkMsTUFBQUEsR0FBRyxFQUFFLE9BRFE7QUFFYkMsTUFBQUEsS0FBSyxFQUFFQyxNQUFNLENBQUNDLGVBQWUsQ0FBQ0MsVUFBakI7QUFGQSxLQUFELENBQWI7QUFJQVYsSUFBQUEsTUFBTSxDQUFDVyxJQUFQLENBQVksT0FBWixFQVZrQixDQVVJO0FBRXRCOztBQUNBVCxJQUFBQSxlQUFlLENBQUNVLFdBQWhCLENBQTRCO0FBQzNCQyxNQUFBQSxJQUFJLEVBQUUsS0FEcUI7QUFFM0JDLE1BQUFBLElBQUksRUFBRWQsTUFGcUI7QUFHM0JlLE1BQUFBLEtBQUssRUFBRW5CO0FBSG9CLEtBQTVCLEVBYmtCLENBbUJsQjs7QUFDQUYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlVLE1BQVo7QUFDQUgsSUFBQUEsZUFBZSxDQUFDVSxXQUFoQixDQUE0QjtBQUMzQkMsTUFBQUEsSUFBSSxFQUFFLEtBRHFCO0FBRTNCQyxNQUFBQSxJQUFJLEVBQUVULE1BRnFCO0FBRzNCVSxNQUFBQSxLQUFLLEVBQUVuQjtBQUhvQixLQUE1QjtBQUtBRixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCVSxNQUF0QixFQTFCa0IsQ0EyQmxCOztBQUNBLFNBQUtkLGNBQUwsR0FBc0IsSUFBdEI7QUFDQSxTQUFLQyxXQUFMLEdBQWlCLElBQWpCO0FBQ0EsU0FBS0QsY0FBTCxHQUFzQixLQUFLRCxnQkFBTCxDQUFzQjBCLFlBQXRCLENBQW1DOUIsRUFBRSxDQUFDSyxjQUF0QyxDQUF0QjtBQUNBRyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0EsU0FBS0osY0FBTCxDQUFvQjBCLE9BQXBCLEdBQThCLElBQTlCO0FBQ0EsU0FBSzFCLGNBQUwsQ0FBb0IyQixNQUFwQixHQUE2QixJQUE3QjtBQUNBeEIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBLFNBQUtKLGNBQUwsQ0FBb0I0QixNQUFwQjtBQUNBekIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBLEdBL0NPO0FBaURSeUIsRUFBQUEsS0FqRFEsbUJBaURBLENBRVAsQ0FuRE87QUFxRFJELEVBQUFBLE1BQU0sRUFBQyxnQkFBU0UsRUFBVCxFQUFhLENBQ25CO0FBQ0E7QUF2RE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/liqDovb3lpb3lj4tcclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0V1hTdWJDb250ZXh0VmlldzogY2MuU3ViQ29udGV4dFZpZXcsXHJcblx0XHRfSXNfTG9hZGluZzp0cnVlLFxyXG5cdFx0XHJcblx0fSxcclxuXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHRjb25zb2xlLmxvZyhcIuaYvuekuuaOkuihjOamnFwiKTtcclxuXHRcdC8v6I635Y+W5pe26Ze05oizXHJcblx0XHRsZXQgdXBkYXRlVGltZSA9IHBhcnNlSW50KG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMCk7XHJcblx0XHRsZXQgZ2V0QXJyID0gbmV3IEFycmF5KCk7IC8v5aOw5piO5ZCR5byA5pS+5pWw5o2u5Z+f5Lyg6YCS55qE5Y+Y6YePXHJcblx0XHRsZXQgb3BlbkRhdGFDb250ZXh0ID0gd3guZ2V0T3BlbkRhdGFDb250ZXh0KCk7IC8v5aOw5piO5byA5Y+R5pWw5o2u5Z+fXHJcblx0XHRsZXQgc2V0QXJyID0gW3tcclxuXHRcdFx0a2V5OiBcInNjb3JlXCIsXHJcblx0XHRcdHZhbHVlOiBTdHJpbmcoR2xvYmFsX1ZhcmlhYmxlLkJlc3RfU2NvcmUpXHJcblx0XHR9XTtcclxuXHRcdGdldEFyci5wdXNoKFwic2NvcmVcIik7IC8v5bCGc2NvcmXljovlhaXlvIDmlL7mlbDmja7ln59cclxuXHJcblx0XHQvL+WQkeW8gOWPkeaVsOaNruWfn+WjsOaYjuiOt+WPluWlveWPi1xyXG5cdFx0b3BlbkRhdGFDb250ZXh0LnBvc3RNZXNzYWdlKHtcclxuXHRcdFx0dHlwZTogXCJHRVRcIixcclxuXHRcdFx0ZGF0YTogZ2V0QXJyLFxyXG5cdFx0XHR0aW1lcjogdXBkYXRlVGltZVxyXG5cdFx0fSlcclxuXHJcblx0XHQvL+WwhuiHquW3seeahOaIkOe7qemAgeWFpeW8gOaUvuaVsOaNruWfn1xyXG5cdFx0Y29uc29sZS5sb2coc2V0QXJyKTtcclxuXHRcdG9wZW5EYXRhQ29udGV4dC5wb3N0TWVzc2FnZSh7XHJcblx0XHRcdHR5cGU6IFwiU0VUXCIsXHJcblx0XHRcdGRhdGE6IHNldEFycixcclxuXHRcdFx0dGltZXI6IHVwZGF0ZVRpbWVcclxuXHRcdH0pXHJcblx0XHRjb25zb2xlLmxvZyhcIuiuvue9rueahOS/oeaBr+S4ulwiLCBzZXRBcnIpO1xyXG5cdFx0Ly/mmL7npLrlvIDmlL7mlbDmja7ln59cclxuXHRcdHRoaXMuU3ViQ29udGV4dFZpZXcgPSBudWxsO1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz10cnVlO1xyXG5cdFx0dGhpcy5TdWJDb250ZXh0VmlldyA9IHRoaXMuV1hTdWJDb250ZXh0Vmlldy5nZXRDb21wb25lbnQoY2MuU3ViQ29udGV4dFZpZXcpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLliqDovb3lpb3lj4vmoYbkuK1cIik7XHJcblx0XHR0aGlzLlN1YkNvbnRleHRWaWV3LmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0dGhpcy5TdWJDb250ZXh0Vmlldy5hY3RpdmUgPSB0cnVlO1xyXG5cdFx0Y29uc29sZS5sb2coXCLliqDovb3lpb3lj4vmoYbkuK1cIik7XHJcblx0XHR0aGlzLlN1YkNvbnRleHRWaWV3LnVwZGF0ZSgpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLnibnliKvmraPluLhcIik7XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZTpmdW5jdGlvbihkdCkge1xyXG5cdFx0Ly/liqDovb3lpb3lj4vmoYZcclxuXHR9LFxyXG5cdFxyXG5cclxufSk7XG4iXX0=