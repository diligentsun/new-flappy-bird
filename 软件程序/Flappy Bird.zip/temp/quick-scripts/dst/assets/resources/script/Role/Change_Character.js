
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Role/Change_Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '62d69Q/mPZMR7Ofo7rz8dcr', 'Change_Character');
// resources/script/Role/Change_Character.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    console.log("角色ID为", this.Canvas.getChildByName("Character_Id").getComponent(cc.Label).string);
    var Current_id = this.node.getChildByName("Character_Id").getComponent(cc.Label).string;
    WeChat.Updating_Current_Character_id(Current_id);
    this.Canvas.destroy();
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJvbGVcXENoYW5nZV9DaGFyYWN0ZXIuanMiXSwibmFtZXMiOlsiU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkNhbnZhcyIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJvbl9idG5fY2xpY2siLCJjb25zb2xlIiwibG9nIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIkN1cnJlbnRfaWQiLCJub2RlIiwiV2VDaGF0IiwiVXBkYXRpbmdfQ3VycmVudF9DaGFyYWN0ZXJfaWQiLCJkZXN0cm95IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUEsNEJBQTRCLEdBQUdDLE9BQU8sQ0FBQyxnREFBRCxDQUExQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ2RDLElBQUFBLE1BQU0sRUFBQztBQUNHLGlCQUFRLElBRFg7QUFFR0MsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLElBRlg7QUFHTkMsTUFBQUEsV0FBVyxFQUFDO0FBSE47QUFETyxHQUhQO0FBV0w7QUFFQUMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBRXJCQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CLEtBQUtOLE1BQUwsQ0FBWU8sY0FBWixDQUEyQixjQUEzQixFQUEyQ0MsWUFBM0MsQ0FBd0RaLEVBQUUsQ0FBQ2EsS0FBM0QsRUFBa0VDLE1BQXRGO0FBQ04sUUFBSUMsVUFBVSxHQUFDLEtBQUtDLElBQUwsQ0FBVUwsY0FBVixDQUF5QixjQUF6QixFQUF5Q0MsWUFBekMsQ0FBc0RaLEVBQUUsQ0FBQ2EsS0FBekQsRUFBZ0VDLE1BQS9FO0FBQ01HLElBQUFBLE1BQU0sQ0FBQ0MsNkJBQVAsQ0FBcUNILFVBQXJDO0FBQ04sU0FBS1gsTUFBTCxDQUFZZSxPQUFaO0FBRUcsR0FwQkk7QUFxQkxDLEVBQUFBLE1BckJLLGtCQXFCR0MsRUFyQkgsRUFxQk8sQ0FBRTtBQXJCVCxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblx0XHRDYW52YXM6e1xuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuICAgICAgIFxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi6KeS6ImySUTkuLpcIix0aGlzLkNhbnZhcy5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9JZFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyk7XHJcblx0XHR2YXIgQ3VycmVudF9pZD10aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfSWRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LlVwZGF0aW5nX0N1cnJlbnRfQ2hhcmFjdGVyX2lkKEN1cnJlbnRfaWQpO1xyXG5cdFx0dGhpcy5DYW52YXMuZGVzdHJveSgpO1xyXG5cclxuICAgIH0sXHJcbiAgICB1cGRhdGUgKGR0KSB7fSxcclxuXHJcblxyXG59KTtcclxuIl19