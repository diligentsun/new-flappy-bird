
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Delete_Read.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fbdaeLWsLlOfJtmSiczS30X', 'Delete_Read');
// resources/script/Email/Delete_Read.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {},
  Delete_Read: function Delete_Read() {
    //删除已读邮件
    WeChat.Delete_Read(); //获取邮件列表

    WeChat.Loading_Email();
    console.log("邮件信息表", Email_Local_Variable.Email);
    cc.director.loadScene("Email");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxEZWxldGVfUmVhZC5qcyJdLCJuYW1lcyI6WyJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkRlbGV0ZV9SZWFkIiwiV2VDaGF0IiwiTG9hZGluZ19FbWFpbCIsImNvbnNvbGUiLCJsb2ciLCJFbWFpbCIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFNQSxvQkFBb0IsR0FBR0MsT0FBTyxDQUFDLHdDQUFELENBQXBDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU9MQyxFQUFBQSxXQUFXLEVBQUUsdUJBQVU7QUFFbEI7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxXQUFQLEdBSGtCLENBSWpCOztBQUNEQyxJQUFBQSxNQUFNLENBQUNDLGFBQVA7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQlYsb0JBQW9CLENBQUNXLEtBQXpDO0FBQ0FULElBQUFBLEVBQUUsQ0FBQ1UsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE9BQXRCO0FBQ0osR0FmSTtBQWlCTEMsRUFBQUEsS0FqQkssbUJBaUJJLENBRVIsQ0FuQkksQ0FxQkw7O0FBckJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5LiL6L296YKu566x5YiX6KGoXHJcbmNvbnN0IEVtYWlsX0xvY2FsX1ZhcmlhYmxlID0gcmVxdWlyZSgnLi4vTG9jYWxfVmFyaWlibGUvRW1haWxfTG9jYWxfVmFyaWFibGUnKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIERlbGV0ZV9SZWFkOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIFxyXG4gICAgICAgICAvL+WIoOmZpOW3suivu+mCruS7tlxyXG4gICAgICAgICBXZUNoYXQuRGVsZXRlX1JlYWQoKTtcclxuICAgICAgICAgIC8v6I635Y+W6YKu5Lu25YiX6KGoXHJcbiAgICAgICAgIFdlQ2hhdC5Mb2FkaW5nX0VtYWlsKCk7XHJcbiAgICAgICAgIGNvbnNvbGUubG9nKFwi6YKu5Lu25L+h5oGv6KGoXCIsRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwpO1xyXG4gICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJFbWFpbFwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=