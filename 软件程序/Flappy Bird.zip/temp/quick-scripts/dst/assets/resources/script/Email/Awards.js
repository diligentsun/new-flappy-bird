
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Awards.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2e806coFMhP9JcwsZjNhFiV', 'Awards');
// resources/script/Email/Awards.js

"use strict";

var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Gold_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Diamond_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Compassoion_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Title_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Content_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Success_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //发送成功
    Fail_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已有重复邮件
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  Awards: function Awards() {
    WeChat.Loading_All_Email();
    var Title = this.Title_Label.getComponent(cc.Label).string;

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      if (Title === Email_Local_Variable.Email[i].Email_Title) {
        var Fail = cc.instantiate(this.Fail_Box);
        this.Canvas.addChild(Fail);
        Fail.setPosition(0, 0);
        return;
      }
    } //获取时间戳


    var Time = parseInt(new Date().getTime());
    var Gold = this.Gold_Label.getComponent(cc.Label).string;
    var Diamond = this.Diamond_Label.getComponent(cc.Label).string;
    var Compassion = this.Compassoion_Label.getComponent(cc.Label).string;
    var Content = this.Content_Label.getComponent(cc.Label).string;
    var Enclosure = false;
    if (Gold > 0 || Diamond > 0 || Compassion > 0) Enclosure = true;
    WeChat.Awards_Email(Time, Title, Content, Gold, Diamond, Compassion, Enclosure);
    console.log("已发送", Time, Title, Content, Gold, Diamond, Compassion, Enclosure);
    var Success = cc.instantiate(this.Success_Box);
    this.Canvas.addChild(Success);
    Success.setPosition(0, 0);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxBd2FyZHMuanMiXSwibmFtZXMiOlsiRW1haWxfTG9jYWxfVmFyaWFibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJHb2xkX0xhYmVsIiwidHlwZSIsIkxhYmVsIiwic2VyaWFsemFibGUiLCJEaWFtb25kX0xhYmVsIiwiQ29tcGFzc29pb25fTGFiZWwiLCJUaXRsZV9MYWJlbCIsIkNvbnRlbnRfTGFiZWwiLCJTdWNjZXNzX0JveCIsIlByZWZhYiIsIkZhaWxfQm94IiwiQ2FudmFzIiwiTm9kZSIsIkF3YXJkcyIsIldlQ2hhdCIsIkxvYWRpbmdfQWxsX0VtYWlsIiwiVGl0bGUiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJpIiwiRW1haWwiLCJsZW5ndGgiLCJFbWFpbF9UaXRsZSIsIkZhaWwiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJUaW1lIiwicGFyc2VJbnQiLCJEYXRlIiwiZ2V0VGltZSIsIkdvbGQiLCJEaWFtb25kIiwiQ29tcGFzc2lvbiIsIkNvbnRlbnQiLCJFbmNsb3N1cmUiLCJBd2FyZHNfRW1haWwiLCJjb25zb2xlIiwibG9nIiwiU3VjY2VzcyIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQU1BLG9CQUFvQixHQUFHQyxPQUFPLENBQUMsd0NBQUQsQ0FBcEM7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUM7QUFDUCxpQkFBUyxJQURGO0FBRWhCQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGTztBQUdoQkMsTUFBQUEsV0FBVyxFQUFFO0FBSEcsS0FESDtBQU1SQyxJQUFBQSxhQUFhLEVBQUM7QUFDVixpQkFBUyxJQURDO0FBRW5CSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGVTtBQUduQkMsTUFBQUEsV0FBVyxFQUFFO0FBSE0sS0FOTjtBQVdSRSxJQUFBQSxpQkFBaUIsRUFBQztBQUNkLGlCQUFTLElBREs7QUFFdkJKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZjO0FBR3ZCQyxNQUFBQSxXQUFXLEVBQUU7QUFIVSxLQVhWO0FBZ0JSRyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUyxJQUREO0FBRWpCTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGUTtBQUdqQkMsTUFBQUEsV0FBVyxFQUFFO0FBSEksS0FoQko7QUFxQlJJLElBQUFBLGFBQWEsRUFBQztBQUNWLGlCQUFTLElBREM7QUFFbkJOLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZVO0FBR25CQyxNQUFBQSxXQUFXLEVBQUU7QUFITSxLQXJCTjtBQTBCUkssSUFBQUEsV0FBVyxFQUFDO0FBQ1IsaUJBQVMsSUFERDtBQUVqQlAsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNhLE1BRlE7QUFHakJOLE1BQUFBLFdBQVcsRUFBRTtBQUhJLEtBMUJKO0FBOEJOO0FBQ0ZPLElBQUFBLFFBQVEsRUFBQztBQUNMLGlCQUFTLElBREo7QUFFZFQsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNhLE1BRks7QUFHZE4sTUFBQUEsV0FBVyxFQUFFO0FBSEMsS0EvQkQ7QUFtQ047QUFDRlEsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVIVixNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ2dCLElBRkw7QUFHWlQsTUFBQUEsV0FBVyxFQUFDO0FBSEE7QUFwQ0MsR0FIUDtBQThDTFUsRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2JDLElBQUFBLE1BQU0sQ0FBQ0MsaUJBQVA7QUFDQSxRQUFJQyxLQUFLLEdBQUcsS0FBS1YsV0FBTCxDQUFpQlcsWUFBakIsQ0FBOEJyQixFQUFFLENBQUNNLEtBQWpDLEVBQXdDZ0IsTUFBcEQ7O0FBQ0EsU0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUN6QixvQkFBb0IsQ0FBQzBCLEtBQXJCLENBQTJCQyxNQUF6QyxFQUFnREYsQ0FBQyxFQUFqRCxFQUFvRDtBQUNoRCxVQUFHSCxLQUFLLEtBQUd0QixvQkFBb0IsQ0FBQzBCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QkcsV0FBekMsRUFBcUQ7QUFDakQsWUFBSUMsSUFBSSxHQUFHM0IsRUFBRSxDQUFDNEIsV0FBSCxDQUFlLEtBQUtkLFFBQXBCLENBQVg7QUFDQSxhQUFLQyxNQUFMLENBQVljLFFBQVosQ0FBcUJGLElBQXJCO0FBQ0FBLFFBQUFBLElBQUksQ0FBQ0csV0FBTCxDQUFpQixDQUFqQixFQUFtQixDQUFuQjtBQUNBO0FBQ0g7QUFDSixLQVZZLENBYWI7OztBQUNBLFFBQUlDLElBQUksR0FBR0MsUUFBUSxDQUFDLElBQUlDLElBQUosR0FBV0MsT0FBWCxFQUFELENBQW5CO0FBQ0EsUUFBSUMsSUFBSSxHQUFHLEtBQUsvQixVQUFMLENBQWdCaUIsWUFBaEIsQ0FBNkJyQixFQUFFLENBQUNNLEtBQWhDLEVBQXVDZ0IsTUFBbEQ7QUFDQSxRQUFJYyxPQUFPLEdBQUcsS0FBSzVCLGFBQUwsQ0FBbUJhLFlBQW5CLENBQWdDckIsRUFBRSxDQUFDTSxLQUFuQyxFQUEwQ2dCLE1BQXhEO0FBQ0EsUUFBSWUsVUFBVSxHQUFHLEtBQUs1QixpQkFBTCxDQUF1QlksWUFBdkIsQ0FBb0NyQixFQUFFLENBQUNNLEtBQXZDLEVBQThDZ0IsTUFBL0Q7QUFDQSxRQUFJZ0IsT0FBTyxHQUFHLEtBQUszQixhQUFMLENBQW1CVSxZQUFuQixDQUFnQ3JCLEVBQUUsQ0FBQ00sS0FBbkMsRUFBMENnQixNQUF4RDtBQUNBLFFBQUlpQixTQUFTLEdBQUcsS0FBaEI7QUFDQSxRQUFHSixJQUFJLEdBQUMsQ0FBTCxJQUFRQyxPQUFPLEdBQUMsQ0FBaEIsSUFBbUJDLFVBQVUsR0FBQyxDQUFqQyxFQUFtQ0UsU0FBUyxHQUFHLElBQVo7QUFDbkNyQixJQUFBQSxNQUFNLENBQUNzQixZQUFQLENBQW9CVCxJQUFwQixFQUF5QlgsS0FBekIsRUFBK0JrQixPQUEvQixFQUF1Q0gsSUFBdkMsRUFBNENDLE9BQTVDLEVBQW9EQyxVQUFwRCxFQUErREUsU0FBL0Q7QUFDQUUsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQlgsSUFBbEIsRUFBdUJYLEtBQXZCLEVBQTZCa0IsT0FBN0IsRUFBcUNILElBQXJDLEVBQTBDQyxPQUExQyxFQUFrREMsVUFBbEQsRUFBNkRFLFNBQTdEO0FBQ0EsUUFBSUksT0FBTyxHQUFHM0MsRUFBRSxDQUFDNEIsV0FBSCxDQUFlLEtBQUtoQixXQUFwQixDQUFkO0FBQ0EsU0FBS0csTUFBTCxDQUFZYyxRQUFaLENBQXFCYyxPQUFyQjtBQUNBQSxJQUFBQSxPQUFPLENBQUNiLFdBQVIsQ0FBb0IsQ0FBcEIsRUFBc0IsQ0FBdEI7QUFFSCxHQXpFSTtBQTJFTDtBQUVBYyxFQUFBQSxLQTdFSyxtQkE2RUksQ0FFUixDQS9FSSxDQWlGTDs7QUFqRkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgRW1haWxfTG9jYWxfVmFyaWFibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIEdvbGRfTGFiZWw6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBEaWFtb25kX0xhYmVsOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgQ29tcGFzc29pb25fTGFiZWw6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBUaXRsZV9MYWJlbDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIENvbnRlbnRfTGFiZWw6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBTdWNjZXNzX0JveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSwvL+WPkemAgeaIkOWKn1xyXG4gICAgICAgIEZhaWxfQm94OntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICB9LC8v5bey5pyJ6YeN5aSN6YKu5Lu2XHJcbiAgICAgICAgQ2FudmFzOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgQXdhcmRzOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfQWxsX0VtYWlsKCk7XHJcbiAgICAgICAgdmFyIFRpdGxlID0gdGhpcy5UaXRsZV9MYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICBmb3IodmFyIGk9MDtpPEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICBpZihUaXRsZT09PUVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlKXtcclxuICAgICAgICAgICAgICAgIHZhciBGYWlsID0gY2MuaW5zdGFudGlhdGUodGhpcy5GYWlsX0JveCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5hZGRDaGlsZChGYWlsKTtcclxuICAgICAgICAgICAgICAgIEZhaWwuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8v6I635Y+W5pe26Ze05oizXHJcbiAgICAgICAgbGV0IFRpbWUgPSBwYXJzZUludChuZXcgRGF0ZSgpLmdldFRpbWUoKSk7XHJcbiAgICAgICAgdmFyIEdvbGQgPSB0aGlzLkdvbGRfTGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgdmFyIERpYW1vbmQgPSB0aGlzLkRpYW1vbmRfTGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgdmFyIENvbXBhc3Npb24gPSB0aGlzLkNvbXBhc3NvaW9uX0xhYmVsLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgIHZhciBDb250ZW50ID0gdGhpcy5Db250ZW50X0xhYmVsLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgIHZhciBFbmNsb3N1cmUgPSBmYWxzZTtcclxuICAgICAgICBpZihHb2xkPjB8fERpYW1vbmQ+MHx8Q29tcGFzc2lvbj4wKUVuY2xvc3VyZSA9IHRydWU7XHJcbiAgICAgICAgV2VDaGF0LkF3YXJkc19FbWFpbChUaW1lLFRpdGxlLENvbnRlbnQsR29sZCxEaWFtb25kLENvbXBhc3Npb24sRW5jbG9zdXJlKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuW3suWPkemAgVwiLFRpbWUsVGl0bGUsQ29udGVudCxHb2xkLERpYW1vbmQsQ29tcGFzc2lvbixFbmNsb3N1cmUpO1xyXG4gICAgICAgIHZhciBTdWNjZXNzID0gY2MuaW5zdGFudGlhdGUodGhpcy5TdWNjZXNzX0JveCk7XHJcbiAgICAgICAgdGhpcy5DYW52YXMuYWRkQ2hpbGQoU3VjY2Vzcyk7XHJcbiAgICAgICAgU3VjY2Vzcy5zZXRQb3NpdGlvbigwLDApO1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=