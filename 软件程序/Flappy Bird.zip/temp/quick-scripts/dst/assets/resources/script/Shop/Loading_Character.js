
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Loading_Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2926dRot1ZOEaidacXaL7Yi', 'Loading_Character');
// resources/script/Shop/Loading_Character.js

"use strict";

//下载角色
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Shop_Character_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Shop_Character_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var self = this;
    Shop_Character_Local_Varible.Shop_Character_User = null;
    this._Is_Loading = true;
    WeChat.Loading_Shop_Character(); //Shop_Character_Local_Varible.Shop_Character_User.length
  },
  start: function start() {},
  update: function update(dt) {
    //直到加载出角色
    if (this._Is_Loading && Shop_Character_Local_Varible.Shop_Character_User != null) {
      this.Loading_Character();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("sprite").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Character: function Loading_Character() {
    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var New_Shop_Character_Label = cc.instantiate(this.Shop_Character_Label);
      this.Shop_Character_View.addChild(New_Shop_Character_Label);
      this.Loading_Image(New_Shop_Character_Label, Shop_Character_Local_Varible.Shop_Character_User[i].Character_Head_Image);
      New_Shop_Character_Label.getChildByName("Character_Name").getComponent(cc.Label).string = "" + Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXExvYWRpbmdfQ2hhcmFjdGVyLmpzIl0sIm5hbWVzIjpbIlNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJTaG9wX0NoYXJhY3Rlcl9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIlNob3BfQ2hhcmFjdGVyX1ZpZXciLCJOb2RlIiwiX0lzX0xvYWRpbmciLCJvbkxvYWQiLCJzZWxmIiwiU2hvcF9DaGFyYWN0ZXJfVXNlciIsIldlQ2hhdCIsIkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiTG9hZGluZ19DaGFyYWN0ZXIiLCJMb2FkaW5nX0ltYWdlIiwiSW1hZ2VfUGF0aCIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENoaWxkQnlOYW1lIiwiZ2V0Q29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJpIiwibGVuZ3RoIiwiTmV3X1Nob3BfQ2hhcmFjdGVyX0xhYmVsIiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsIkNoYXJhY3Rlcl9IZWFkX0ltYWdlIiwiTGFiZWwiLCJzdHJpbmciLCJDaGFyYWN0ZXJfTmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQU1BLDRCQUE0QixHQUFHQyxPQUFPLENBQUMsZ0RBQUQsQ0FBNUM7O0FBRUFDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBRVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxvQkFBb0IsRUFBRTtBQUNyQixpQkFBUyxJQURZO0FBRXJCQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGWTtBQUdyQkMsTUFBQUEsV0FBVyxFQUFFO0FBSFEsS0FEWDtBQU1YQyxJQUFBQSxtQkFBbUIsRUFBRTtBQUNwQixpQkFBUyxJQURXO0FBRXBCSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1MsSUFGVztBQUdwQkYsTUFBQUEsV0FBVyxFQUFFO0FBSE8sS0FOVjtBQVdYRyxJQUFBQSxXQUFXLEVBQUU7QUFYRixHQUZKO0FBZ0JSO0FBRUFDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVztBQUNsQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBZCxJQUFBQSw0QkFBNEIsQ0FBQ2UsbUJBQTdCLEdBQW1ELElBQW5EO0FBQ0EsU0FBS0gsV0FBTCxHQUFtQixJQUFuQjtBQUNBSSxJQUFBQSxNQUFNLENBQUNDLHNCQUFQLEdBSmtCLENBS2xCO0FBQ0EsR0F4Qk87QUEwQlJDLEVBQUFBLEtBMUJRLG1CQTBCQSxDQUVQLENBNUJPO0FBOEJSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQjtBQUNBLFFBQUksS0FBS1IsV0FBTCxJQUFvQlosNEJBQTRCLENBQUNlLG1CQUE3QixJQUFvRCxJQUE1RSxFQUFrRjtBQUNqRixXQUFLTSxpQkFBTDtBQUNBLFdBQUtULFdBQUwsR0FBbUIsS0FBbkI7QUFDQTtBQUNELEdBcENPO0FBcUNSVSxFQUFBQSxhQXJDUSx5QkFxQ01SLElBckNOLEVBcUNZUyxVQXJDWixFQXFDd0I7QUFDL0IsUUFBSUMsSUFBSSxHQUFHRCxVQUFYO0FBQ0FyQixJQUFBQSxFQUFFLENBQUN1QixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUVILElBRFM7QUFFZGpCLE1BQUFBLElBQUksRUFBRTtBQUZRLEtBQWYsRUFHRyxVQUFTcUIsR0FBVCxFQUFjQyxPQUFkLEVBQXVCQyxJQUF2QixFQUE2QjtBQUMvQixVQUFJQyxLQUFLLEdBQUcsSUFBSTdCLEVBQUUsQ0FBQzhCLFdBQVAsQ0FBbUJILE9BQW5CLENBQVo7O0FBQ0EsVUFBSUQsR0FBSixFQUFTO0FBQ1JLLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JOLEdBQXBCO0FBQ0E7O0FBQ0RkLE1BQUFBLElBQUksQ0FBQ3FCLGNBQUwsQ0FBb0IsUUFBcEIsRUFBOEJDLFlBQTlCLENBQTJDbEMsRUFBRSxDQUFDbUMsTUFBOUMsRUFBc0RDLFdBQXRELEdBQW9FUCxLQUFwRTtBQUVBLEtBVkQ7QUFXQSxHQWxETztBQW1EUlYsRUFBQUEsaUJBbkRRLCtCQW1EVztBQUNsQixTQUFLLElBQUlrQixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHdkMsNEJBQTRCLENBQUNlLG1CQUE3QixDQUFpRHlCLE1BQXJFLEVBQTZFRCxDQUFDLEVBQTlFLEVBQWtGO0FBQ2pGLFVBQUlFLHdCQUF3QixHQUFHdkMsRUFBRSxDQUFDd0MsV0FBSCxDQUFlLEtBQUtwQyxvQkFBcEIsQ0FBL0I7QUFDQSxXQUFLSSxtQkFBTCxDQUF5QmlDLFFBQXpCLENBQWtDRix3QkFBbEM7QUFDQSxXQUFLbkIsYUFBTCxDQUFtQm1CLHdCQUFuQixFQUE2Q3pDLDRCQUE0QixDQUFDZSxtQkFBN0IsQ0FBaUR3QixDQUFqRCxFQUFvREssb0JBQWpHO0FBQ0FILE1BQUFBLHdCQUF3QixDQUFDTixjQUF6QixDQUF3QyxnQkFBeEMsRUFBMERDLFlBQTFELENBQXVFbEMsRUFBRSxDQUFDMkMsS0FBMUUsRUFBaUZDLE1BQWpGLEdBQTBGLEtBQ3pGOUMsNEJBQTRCLENBQUNlLG1CQUE3QixDQUFpRHdCLENBQWpELEVBQW9EUSxjQURyRDtBQUVBO0FBQ0Q7QUEzRE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/kuIvovb3op5LoibJcclxuY29uc3QgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0U2hvcF9DaGFyYWN0ZXJfTGFiZWw6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRTaG9wX0NoYXJhY3Rlcl9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdFx0U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyID0gbnVsbDtcclxuXHRcdHRoaXMuX0lzX0xvYWRpbmcgPSB0cnVlO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIoKTtcclxuXHRcdC8vU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyLmxlbmd0aFxyXG5cdH0sXHJcblxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cclxuXHR1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblx0XHQvL+ebtOWIsOWKoOi9veWHuuinkuiJslxyXG5cdFx0aWYgKHRoaXMuX0lzX0xvYWRpbmcgJiYgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyICE9IG51bGwpIHtcclxuXHRcdFx0dGhpcy5Mb2FkaW5nX0NoYXJhY3RlcigpO1xyXG5cdFx0XHR0aGlzLl9Jc19Mb2FkaW5nID0gZmFsc2U7XHJcblx0XHR9XHJcblx0fSxcclxuXHRMb2FkaW5nX0ltYWdlKHNlbGYsIEltYWdlX1BhdGgpIHtcclxuXHRcdGxldCBfdXJsID0gSW1hZ2VfUGF0aDtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0dXJsOiBfdXJsLFxyXG5cdFx0XHR0eXBlOiAnanBnJ1xyXG5cdFx0fSwgZnVuY3Rpb24oZXJyLCB0ZXh0dXJlLCB0ZXN0KSB7XHJcblx0XHRcdHZhciBmcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0aWYgKGVycikge1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwi5Zu+54mH6ZSZ6K+vXCIsIGVycik7XHJcblx0XHRcdH1cclxuXHRcdFx0c2VsZi5nZXRDaGlsZEJ5TmFtZShcInNwcml0ZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IGZyYW1lO1xyXG5cclxuXHRcdH0pXHJcblx0fSxcclxuXHRMb2FkaW5nX0NoYXJhY3Rlcigpe1xyXG5cdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXIubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0dmFyIE5ld19TaG9wX0NoYXJhY3Rlcl9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuU2hvcF9DaGFyYWN0ZXJfTGFiZWwpO1xyXG5cdFx0XHR0aGlzLlNob3BfQ2hhcmFjdGVyX1ZpZXcuYWRkQ2hpbGQoTmV3X1Nob3BfQ2hhcmFjdGVyX0xhYmVsKTtcclxuXHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19TaG9wX0NoYXJhY3Rlcl9MYWJlbCwgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2ldLkNoYXJhY3Rlcl9IZWFkX0ltYWdlKTtcclxuXHRcdFx0TmV3X1Nob3BfQ2hhcmFjdGVyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICtcclxuXHRcdFx0XHRTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXJbaV0uQ2hhcmFjdGVyX05hbWU7XHJcblx0XHR9XHJcblx0fVxyXG5cclxufSk7XG4iXX0=