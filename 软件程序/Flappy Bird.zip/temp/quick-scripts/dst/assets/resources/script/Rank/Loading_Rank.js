
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Loading_Rank.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ffbc3JL8GNEwI+f8sxUOJw7', 'Loading_Rank');
// resources/script/Rank/Loading_Rank.js

"use strict";

//下载世界排名列表
var Rank_Local_Varible = require('Rank_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Rank_User_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //玩家框
    Rank_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    var self = this;
    Rank_Local_Varible.Word_Rank_User = null;
    this._Is_Loading = true;
    WeChat.Loading_World_Rank();
    console.log(Rank_Local_Varible.Word_Rank_User);
  },
  start: function start() {},
  update: function update(dt) {
    //Rank_Local_Varible.Word_Rank_User.length
    //循环输出玩家框
    if (this._Is_Loading && Rank_Local_Varible.Word_Rank_User) {
      for (var i = 0; i < Rank_Local_Varible.Word_Rank_User.length; i++) {
        console.log("正在加载中");
        var New_Rank_User_Label = cc.instantiate(this.Rank_User_Label);
        this.Rank_View.addChild(New_Rank_User_Label);
        this.Loading_Image(New_Rank_User_Label, Rank_Local_Varible.Word_Rank_User[i].Head_Iamge);
        New_Rank_User_Label.getChildByName("Game_Rank_Show").getComponent(cc.Label).string = "" + (i + 1);
        New_Rank_User_Label.getChildByName("User_Name").getComponent(cc.Label).string = "" + Rank_Local_Varible.Word_Rank_User[i].User_Name;
        New_Rank_User_Label.getChildByName("Best_Score_Text").getComponent(cc.Label).string = "" + Rank_Local_Varible.Word_Rank_User[i].Best_Score + "分";
      }

      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Head_Image_Mask").getChildByName("Head_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXExvYWRpbmdfUmFuay5qcyJdLCJuYW1lcyI6WyJSYW5rX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJSYW5rX1VzZXJfTGFiZWwiLCJ0eXBlIiwiUHJlZmFiIiwic2VyaWFsemFibGUiLCJSYW5rX1ZpZXciLCJOb2RlIiwiX0lzX0xvYWRpbmciLCJvbkxvYWQiLCJzZWxmIiwiV29yZF9SYW5rX1VzZXIiLCJXZUNoYXQiLCJMb2FkaW5nX1dvcmxkX1JhbmsiLCJjb25zb2xlIiwibG9nIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImkiLCJsZW5ndGgiLCJOZXdfUmFua19Vc2VyX0xhYmVsIiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsIkxvYWRpbmdfSW1hZ2UiLCJIZWFkX0lhbWdlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIlVzZXJfTmFtZSIsIkJlc3RfU2NvcmUiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLGtCQUFrQixHQUFHQyxPQUFPLENBQUMscUJBQUQsQ0FBaEM7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNaQyxJQUFBQSxlQUFlLEVBQUM7QUFDWixpQkFBUSxJQURJO0FBRVpDLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxNQUZJO0FBR1pDLE1BQUFBLFdBQVcsRUFBQztBQUhBLEtBREo7QUFLVDtBQUNMQyxJQUFBQSxTQUFTLEVBQUM7QUFDUCxpQkFBUSxJQUREO0FBRVBILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxJQUZEO0FBR1BGLE1BQUFBLFdBQVcsRUFBQztBQUhMLEtBTkk7QUFVWjtBQUNGRyxJQUFBQSxXQUFXLEVBQUM7QUFYRSxHQUhQO0FBa0JMQyxFQUFBQSxNQUFNLEVBQUMsa0JBQVk7QUFDckIsUUFBSUMsSUFBSSxHQUFHLElBQVg7QUFDQWQsSUFBQUEsa0JBQWtCLENBQUNlLGNBQW5CLEdBQWtDLElBQWxDO0FBQ0EsU0FBS0gsV0FBTCxHQUFpQixJQUFqQjtBQUNBSSxJQUFBQSxNQUFNLENBQUNDLGtCQUFQO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZbkIsa0JBQWtCLENBQUNlLGNBQS9CO0FBRUEsR0F6Qk87QUEyQkxLLEVBQUFBLEtBM0JLLG1CQTJCSSxDQUNSLENBNUJJO0FBOEJMQyxFQUFBQSxNQUFNLEVBQUMsZ0JBQVVDLEVBQVYsRUFBYztBQUN2QjtBQUNBO0FBQ0EsUUFBRyxLQUFLVixXQUFMLElBQWtCWixrQkFBa0IsQ0FBQ2UsY0FBeEMsRUFBdUQ7QUFDdEQsV0FBSSxJQUFJUSxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUN2QixrQkFBa0IsQ0FBQ2UsY0FBbkIsQ0FBa0NTLE1BQWhELEVBQXVERCxDQUFDLEVBQXhELEVBQTJEO0FBQzFETCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsWUFBSU0sbUJBQW1CLEdBQUd2QixFQUFFLENBQUN3QixXQUFILENBQWUsS0FBS3BCLGVBQXBCLENBQTFCO0FBQ0EsYUFBS0ksU0FBTCxDQUFlaUIsUUFBZixDQUF3QkYsbUJBQXhCO0FBQ0EsYUFBS0csYUFBTCxDQUFtQkgsbUJBQW5CLEVBQXVDekIsa0JBQWtCLENBQUNlLGNBQW5CLENBQWtDUSxDQUFsQyxFQUFxQ00sVUFBNUU7QUFDQUosUUFBQUEsbUJBQW1CLENBQUNLLGNBQXBCLENBQW1DLGdCQUFuQyxFQUFxREMsWUFBckQsQ0FBa0U3QixFQUFFLENBQUM4QixLQUFyRSxFQUE0RUMsTUFBNUUsR0FBbUYsTUFBSVYsQ0FBQyxHQUFDLENBQU4sQ0FBbkY7QUFDQUUsUUFBQUEsbUJBQW1CLENBQUNLLGNBQXBCLENBQW1DLFdBQW5DLEVBQWdEQyxZQUFoRCxDQUE2RDdCLEVBQUUsQ0FBQzhCLEtBQWhFLEVBQXVFQyxNQUF2RSxHQUE4RSxLQUFHakMsa0JBQWtCLENBQUNlLGNBQW5CLENBQWtDUSxDQUFsQyxFQUFxQ1csU0FBdEg7QUFDQVQsUUFBQUEsbUJBQW1CLENBQUNLLGNBQXBCLENBQW1DLGlCQUFuQyxFQUFzREMsWUFBdEQsQ0FBbUU3QixFQUFFLENBQUM4QixLQUF0RSxFQUE2RUMsTUFBN0UsR0FBb0YsS0FBR2pDLGtCQUFrQixDQUFDZSxjQUFuQixDQUFrQ1EsQ0FBbEMsRUFBcUNZLFVBQXhDLEdBQW1ELEdBQXZJO0FBRUE7O0FBQ0QsV0FBS3ZCLFdBQUwsR0FBaUIsS0FBakI7QUFDQTtBQUNELEdBOUNPO0FBZ0RSZ0IsRUFBQUEsYUFoRFEseUJBZ0RNZCxJQWhETixFQWdEV3NCLFVBaERYLEVBZ0RzQjtBQUMzQixRQUFJQyxJQUFJLEdBQUNELFVBQVQ7QUFDQWxDLElBQUFBLEVBQUUsQ0FBQ29DLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBQ0gsSUFEVTtBQUVkOUIsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVNrQyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJMUMsRUFBRSxDQUFDMkMsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTnZCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJzQixHQUFuQjtBQUNBOztBQUNEM0IsTUFBQUEsSUFBSSxDQUFDZ0IsY0FBTCxDQUFvQixpQkFBcEIsRUFBdUNBLGNBQXZDLENBQXNELFlBQXRELEVBQW9FQyxZQUFwRSxDQUFpRjdCLEVBQUUsQ0FBQzRDLE1BQXBGLEVBQTRGQyxXQUE1RixHQUF3R0gsS0FBeEc7QUFFQSxLQVZEO0FBV0Y7QUE3RE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/kuIvovb3kuJbnlYzmjpLlkI3liJfooahcclxudmFyIFJhbmtfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ1JhbmtfTG9jYWxfVmFyaWFibGUnKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgIFJhbmtfVXNlcl9MYWJlbDp7XHJcbiAgICAgXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuICAgICBcdFx0XHR0eXBlOmNjLlByZWZhYixcclxuICAgICBcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgIH0sLy/njqnlrrbmoYZcclxuXHQgUmFua19WaWV3OntcclxuXHQgXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuXHQgXHRcdFx0dHlwZTpjYy5Ob2RlLFxyXG5cdCBcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdCB9LC8v5o6S5ZCN5qGGXHJcblx0IF9Jc19Mb2FkaW5nOnRydWUsXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBvbkxvYWQ6ZnVuY3Rpb24gKCkge1xyXG5cdFx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdFx0UmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyPW51bGw7XHJcblx0XHR0aGlzLl9Jc19Mb2FkaW5nPXRydWU7XHJcblx0XHRXZUNoYXQuTG9hZGluZ19Xb3JsZF9SYW5rKCk7XHJcblx0XHRjb25zb2xlLmxvZyhSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXIpO1xyXG5cdFx0XHJcblx0fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZTpmdW5jdGlvbiAoZHQpIHtcclxuXHRcdC8vUmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyLmxlbmd0aFxyXG5cdFx0Ly/lvqrnjq/ovpPlh7rnjqnlrrbmoYZcclxuXHRcdGlmKHRoaXMuX0lzX0xvYWRpbmcmJlJhbmtfTG9jYWxfVmFyaWJsZS5Xb3JkX1JhbmtfVXNlcil7XHJcblx0XHRcdGZvcih2YXIgaT0wO2k8UmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyLmxlbmd0aDtpKyspe1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwi5q2j5Zyo5Yqg6L295LitXCIpO1xyXG5cdFx0XHRcdHZhciBOZXdfUmFua19Vc2VyX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5SYW5rX1VzZXJfTGFiZWwpO1xyXG5cdFx0XHRcdHRoaXMuUmFua19WaWV3LmFkZENoaWxkKE5ld19SYW5rX1VzZXJfTGFiZWwpO1xyXG5cdFx0XHRcdHRoaXMuTG9hZGluZ19JbWFnZShOZXdfUmFua19Vc2VyX0xhYmVsLFJhbmtfTG9jYWxfVmFyaWJsZS5Xb3JkX1JhbmtfVXNlcltpXS5IZWFkX0lhbWdlKTtcclxuXHRcdFx0XHROZXdfUmFua19Vc2VyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiR2FtZV9SYW5rX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIisoaSsxKTtcclxuXHRcdFx0XHROZXdfUmFua19Vc2VyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiVXNlcl9OYW1lXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrUmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyW2ldLlVzZXJfTmFtZTtcclxuXHRcdFx0XHROZXdfUmFua19Vc2VyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQmVzdF9TY29yZV9UZXh0XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrUmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyW2ldLkJlc3RfU2NvcmUrXCLliIZcIjtcclxuXHRcdFx0XHRcclxuXHRcdFx0fVxyXG5cdFx0XHR0aGlzLl9Jc19Mb2FkaW5nPWZhbHNlXHJcblx0XHR9XHJcblx0fSxcclxuXHRcclxuXHRMb2FkaW5nX0ltYWdlKHNlbGYsSW1hZ2VfUGF0aCl7XHJcblx0XHRcdFx0bGV0IF91cmw9SW1hZ2VfUGF0aDtcclxuXHRcdFx0XHRjYy5sb2FkZXIubG9hZCh7XHJcblx0XHRcdFx0XHR1cmw6X3VybCxcclxuXHRcdFx0XHRcdHR5cGU6J2pwZydcclxuXHRcdFx0XHR9LGZ1bmN0aW9uKGVycix0ZXh0dXJlLHRlc3Qpe1xyXG5cdFx0XHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi5Zu+54mH6ZSZ6K+vXCIsZXJyKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdHNlbGYuZ2V0Q2hpbGRCeU5hbWUoXCJIZWFkX0ltYWdlX01hc2tcIikuZ2V0Q2hpbGRCeU5hbWUoXCJIZWFkX0ltYWdlXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lPWZyYW1lO1xyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0fSlcclxuXHR9XHJcbn0pO1xyXG4iXX0=