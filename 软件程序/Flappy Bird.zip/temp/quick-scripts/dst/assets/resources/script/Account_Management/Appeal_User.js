
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Appeal_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '566674OTJxDC6nbV9VVDq+a', 'Appeal_User');
// resources/script/Account_Management/Appeal_User.js

"use strict";

//弹出申诉框
cc.Class({
  "extends": cc.Component,
  properties: {
    Appeal_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //申诉框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    } //玩家框节点

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建申诉信息框
    var New_Appeal_Label = cc.instantiate(this.Appeal_Label);
    this.Canvas.addChild(New_Appeal_Label);
    New_Appeal_Label.setPosition(0, 0);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQXBwZWFsX1VzZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJBcHBlYWxfTGFiZWwiLCJ0eXBlIiwiUHJlZmFiIiwic2VyaWFsemFibGUiLCJDYW52YXMiLCJOb2RlIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJOZXdfQXBwZWFsX0xhYmVsIiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsInNldFBvc2l0aW9uIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZJO0FBR2JDLE1BQUFBLFdBQVcsRUFBRTtBQUhBLEtBREg7QUFLUjtBQUNIQyxJQUFBQSxNQUFNLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxJQUZGO0FBR1BGLE1BQUFBLFdBQVcsRUFBRTtBQUhOLEtBTkcsQ0FVUjs7QUFWUSxHQUhKO0FBZ0JSRyxFQUFBQSxLQWhCUSxtQkFnQkEsQ0FFUCxDQWxCTztBQW1CUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUdaLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlLEtBQUtULFlBQXBCLENBQXZCO0FBQ0EsU0FBS0ksTUFBTCxDQUFZTSxRQUFaLENBQXFCRixnQkFBckI7QUFDQUEsSUFBQUEsZ0JBQWdCLENBQUNHLFdBQWpCLENBQTZCLENBQTdCLEVBQWdDLENBQWhDO0FBQ0EsR0F4Qk8sQ0F5QlI7O0FBekJRLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5by55Ye655Sz6K+J5qGGXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdEFwcGVhbF9MYWJlbDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/nlLPor4nmoYZcclxuXHRcdENhbnZhczoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v546p5a625qGG6IqC54K5XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v5Yib5bu655Sz6K+J5L+h5oGv5qGGXHJcblx0XHR2YXIgTmV3X0FwcGVhbF9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQXBwZWFsX0xhYmVsKTtcclxuXHRcdHRoaXMuQ2FudmFzLmFkZENoaWxkKE5ld19BcHBlYWxfTGFiZWwpO1xyXG5cdFx0TmV3X0FwcGVhbF9MYWJlbC5zZXRQb3NpdGlvbigwLCAwKTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=