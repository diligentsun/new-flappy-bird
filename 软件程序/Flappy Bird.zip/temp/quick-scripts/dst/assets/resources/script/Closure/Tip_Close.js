
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Closure/Tip_Close.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ef9d6HOYUVHH5W82LluoCbX', 'Tip_Close');
// resources/script/Closure/Tip_Close.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    tip: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.tip.destroy();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXENsb3N1cmVcXFRpcF9DbG9zZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInRpcCIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxHQUFHLEVBQUM7QUFDQSxpQkFBUyxJQURUO0FBRVRDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQUZBO0FBR1RDLE1BQUFBLFdBQVcsRUFBRTtBQUhKO0FBREksR0FIUDtBQVlMQyxFQUFBQSxLQVpLLG1CQVlJLENBRVIsQ0FkSTtBQWVSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEIsU0FBS0wsR0FBTCxDQUFTTSxPQUFUO0FBQ0E7QUFqQk8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICB0aXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblx0XHJcbiAgICB9LFxyXG5cdG9uX2J0bl9jbGljazogZnVuY3Rpb24oKSB7XHJcblx0XHR0aGlzLnRpcC5kZXN0cm95KCk7XHJcblx0fVxyXG59KTtcclxuIl19