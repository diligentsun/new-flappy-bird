
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Loading_Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'af79b95NVZMY7RSD43KGbtm', 'Loading_Game');
// resources/script/Game_Start/Loading_Game.js

"use strict";

//加载游戏资源
cc.Class({
  "extends": cc.Component,
  properties: {
    Admin_Button: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  onLoad: function onLoad() {
    //是否为管理员
    console.log("管理员的值为", Global_Variable.Is_Admin);
  },
  start: function start() {},
  update: function update(dt) {
    this.Admin_Button.active = Global_Variable.Is_Admin;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXExvYWRpbmdfR2FtZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkFkbWluX0J1dHRvbiIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJvbkxvYWQiLCJjb25zb2xlIiwibG9nIiwiR2xvYmFsX1ZhcmlhYmxlIiwiSXNfQWRtaW4iLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiYWN0aXZlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBRVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQUZJO0FBR2JDLE1BQUFBLFdBQVcsRUFBRTtBQUhBO0FBREgsR0FGSjtBQVVSQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQkMsZUFBZSxDQUFDQyxRQUFyQztBQUVBLEdBZE87QUFnQlJDLEVBQUFBLEtBQUssRUFBRSxpQkFBVyxDQUFFLENBaEJaO0FBa0JSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQixTQUFLWCxZQUFMLENBQWtCWSxNQUFsQixHQUF5QkwsZUFBZSxDQUFDQyxRQUF6QztBQUNBO0FBcEJPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5Yqg6L295ri45oiP6LWE5rqQXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0QWRtaW5fQnV0dG9uOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHR9LFxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Ly/mmK/lkKbkuLrnrqHnkIblkZhcclxuXHRcdGNvbnNvbGUubG9nKFwi566h55CG5ZGY55qE5YC85Li6XCIsR2xvYmFsX1ZhcmlhYmxlLklzX0FkbWluKTtcclxuXHRcdFxyXG5cdH0sXHJcblxyXG5cdHN0YXJ0OiBmdW5jdGlvbigpIHt9LFxyXG5cclxuXHR1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblx0XHR0aGlzLkFkbWluX0J1dHRvbi5hY3RpdmU9R2xvYmFsX1ZhcmlhYmxlLklzX0FkbWluO1xyXG5cdH0sXHJcbn0pO1xuIl19