
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Report_Confirm.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3838dtwztxF5oSVGAKVfDFZ', 'Report_Confirm');
// resources/script/Rank/Report_Confirm.js

"use strict";

//确定举报
var Report_Local_Variable = require('Report_Local_Variable'); //const Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');


cc.Class({
  "extends": cc.Component,
  properties: {
    Report_Content: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //举报框

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //载入举报人的信息
    console.log("点到了吗??");
    var Reported_User_Openid = Report_Local_Variable.openid;
    var Reported_User_Name = Report_Local_Variable.User_Name;
    var Report_Text = this.Report_Content.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "关于对" + Reported_User_Name + "的举报";
    var Content = "系统已收到您的举报，请等待处理			举报原因：" + Report_Text;
    WeChat.Email_Report_And_Appeal(Time, Title, Content);
    console.log("被举报人OPENID", Reported_User_Openid, "举报内容为", Report_Text); //上传举报信息

    WeChat.Uploading_Reported_Information(Report_Local_Variable.openid, Report_Text);
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXFJlcG9ydF9Db25maXJtLmpzIl0sIm5hbWVzIjpbIlJlcG9ydF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIlJlcG9ydF9Db250ZW50IiwidHlwZSIsIkxhYmVsIiwic2VyaWFsemFibGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsImNvbnNvbGUiLCJsb2ciLCJSZXBvcnRlZF9Vc2VyX09wZW5pZCIsIm9wZW5pZCIsIlJlcG9ydGVkX1VzZXJfTmFtZSIsIlVzZXJfTmFtZSIsIlJlcG9ydF9UZXh0IiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiVGltZSIsInBhcnNlSW50IiwiRGF0ZSIsImdldFRpbWUiLCJUaXRsZSIsIkNvbnRlbnQiLCJXZUNoYXQiLCJFbWFpbF9SZXBvcnRfQW5kX0FwcGVhbCIsIlVwbG9hZGluZ19SZXBvcnRlZF9JbmZvcm1hdGlvbiIsIm5vZGUiLCJkZXN0cm95Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUEsSUFBSUEscUJBQXFCLEdBQUdDLE9BQU8sQ0FBQyx1QkFBRCxDQUFuQyxFQUNBOzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBRVhDLElBQUFBLGNBQWMsRUFBRTtBQUNmLGlCQUFTLElBRE07QUFFZkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLEtBRk07QUFHZkMsTUFBQUEsV0FBVyxFQUFFO0FBSEUsS0FGTCxDQU1UOztBQU5TLEdBSEo7QUFZUjtBQUVBO0FBQ0FDLEVBQUFBLEtBZlEsbUJBZUEsQ0FFUCxDQWpCTztBQWtCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDQSxRQUFJQyxvQkFBb0IsR0FBR2QscUJBQXFCLENBQUNlLE1BQWpEO0FBQ0EsUUFBSUMsa0JBQWtCLEdBQUdoQixxQkFBcUIsQ0FBQ2lCLFNBQS9DO0FBQ0EsUUFBSUMsV0FBVyxHQUFHLEtBQUtaLGNBQUwsQ0FBb0JhLFlBQXBCLENBQWlDakIsRUFBRSxDQUFDTSxLQUFwQyxFQUEyQ1ksTUFBN0QsQ0FMd0IsQ0FPdEI7O0FBQ0YsUUFBSUMsSUFBSSxHQUFHQyxRQUFRLENBQUMsSUFBSUMsSUFBSixHQUFXQyxPQUFYLEVBQUQsQ0FBbkI7QUFDQSxRQUFJQyxLQUFLLEdBQUcsUUFBTVQsa0JBQU4sR0FBeUIsS0FBckM7QUFDQSxRQUFJVSxPQUFPLEdBQUUsNEJBQTBCUixXQUF2QztBQUNBUyxJQUFBQSxNQUFNLENBQUNDLHVCQUFQLENBQStCUCxJQUEvQixFQUFvQ0ksS0FBcEMsRUFBMENDLE9BQTFDO0FBQ0FkLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBMEJDLG9CQUExQixFQUFnRCxPQUFoRCxFQUF5REksV0FBekQsRUFad0IsQ0FheEI7O0FBQ0FTLElBQUFBLE1BQU0sQ0FBQ0UsOEJBQVAsQ0FBc0M3QixxQkFBcUIsQ0FBQ2UsTUFBNUQsRUFBb0VHLFdBQXBFO0FBQ0EsU0FBS1ksSUFBTCxDQUFVQyxPQUFWO0FBQ0EsR0FsQ08sQ0FtQ1I7O0FBbkNRLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v56Gu5a6a5Li+5oqlXHJcblxyXG52YXIgUmVwb3J0X0xvY2FsX1ZhcmlhYmxlID0gcmVxdWlyZSgnUmVwb3J0X0xvY2FsX1ZhcmlhYmxlJyk7XHJcbi8vY29uc3QgRW1haWxfTG9jYWxfVmFyaWFibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblxyXG5cdFx0UmVwb3J0X0NvbnRlbnQ6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwvL+S4vuaKpeahhlxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v6L295YWl5Li+5oql5Lq655qE5L+h5oGvXHJcblx0XHRjb25zb2xlLmxvZyhcIueCueWIsOS6huWQlz8/XCIpO1xyXG5cdFx0dmFyIFJlcG9ydGVkX1VzZXJfT3BlbmlkID0gUmVwb3J0X0xvY2FsX1ZhcmlhYmxlLm9wZW5pZDtcclxuXHRcdHZhciBSZXBvcnRlZF9Vc2VyX05hbWUgPSBSZXBvcnRfTG9jYWxfVmFyaWFibGUuVXNlcl9OYW1lO1xyXG5cdFx0dmFyIFJlcG9ydF9UZXh0ID0gdGhpcy5SZXBvcnRfQ29udGVudC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuXHJcblx0XHQgIC8v6I635Y+W5pe26Ze05oizXHJcblx0XHRsZXQgVGltZSA9IHBhcnNlSW50KG5ldyBEYXRlKCkuZ2V0VGltZSgpKTtcclxuXHRcdHZhciBUaXRsZSA9IFwi5YWz5LqO5a+5XCIrUmVwb3J0ZWRfVXNlcl9OYW1lK1wi55qE5Li+5oqlXCI7XHJcblx0XHR2YXIgQ29udGVudCA9XCLns7vnu5/lt7LmlLbliLDmgqjnmoTkuL7miqXvvIzor7fnrYnlvoXlpITnkIZcdFx0XHTkuL7miqXljp/lm6DvvJpcIitSZXBvcnRfVGV4dDtcclxuXHRcdFdlQ2hhdC5FbWFpbF9SZXBvcnRfQW5kX0FwcGVhbChUaW1lLFRpdGxlLENvbnRlbnQpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLooqvkuL7miqXkurpPUEVOSURcIiwgUmVwb3J0ZWRfVXNlcl9PcGVuaWQsIFwi5Li+5oql5YaF5a655Li6XCIsIFJlcG9ydF9UZXh0KTtcclxuXHRcdC8v5LiK5Lyg5Li+5oql5L+h5oGvXHJcblx0XHRXZUNoYXQuVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uKFJlcG9ydF9Mb2NhbF9WYXJpYWJsZS5vcGVuaWQsIFJlcG9ydF9UZXh0KTtcclxuXHRcdHRoaXMubm9kZS5kZXN0cm95KCk7XHJcblx0fVxyXG5cdC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19