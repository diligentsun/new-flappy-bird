
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Loading_Email.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bd112igWp1I7pLIVcdeazws', 'Loading_Email');
// resources/script/Email/Loading_Email.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Email_Read: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已读邮件框
    Email: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //未读邮件框
    Email_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //邮箱框
    No_Read_Number: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //未读邮件计数
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    //获取邮件列表
    Email_Local_Variable.Email = null;
    WeChat.Loading_Email();
    console.log("邮件信息表", Email_Local_Variable.Email);
    this._Is_Loading = true;
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Email_Local_Variable.Email != null) {
      this.Loading_Email();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Email_Type").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Email: function Loading_Email() {
    var No_Read_Number = 0;
    var self = this; //循环输出邮件框

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var New_Email_Label = null; //根据是否已读决定背景(邮件框类型)

      if (Email_Local_Variable.Email[i].Is_Read === true) {
        //新建已读邮件节点
        New_Email_Label = cc.instantiate(this.Email_Read); //加入为子节点

        this.Email_View.addChild(New_Email_Label);
        console.log(New_Email_Label, "第", i + 1, "封邮件");
        console.log("Email_Local_Variable.Email[i].Enclosure:", i, Email_Local_Variable.Email[i].Enclosure);
        console.log("Email_Local_Variable.Email[i].Email_Title:", i, Email_Local_Variable.Email[i].Email_Title);
        console.log("已读");
        console.log("Email_Local_Variable.Email[i].Is_Read:", i, Email_Local_Variable.Email[i].Is_Read); //根据是否有附件决定图标类型

        if (Email_Local_Variable.Email[i].Enclosure === true) //若有附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift2.png?sign=639a28a6a90a604f8cac84ea2eb59eae&t=1610714079");else //若无附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift.png?sign=ca9885f77ec4a7f7b3ffbc83cde81935&t=1610714025");
      } else {
        No_Read_Number++; //新建未读邮件节点

        New_Email_Label = cc.instantiate(this.Email); //加入为子节点

        this.Email_View.addChild(New_Email_Label);
        console.log(New_Email_Label, "第", i + 1, "封邮件");
        console.log("Email_Local_Variable.Email[i].Enclosure:", i, Email_Local_Variable.Email[i].Enclosure);
        console.log("Email_Local_Variable.Email[i].Email_Title:", i, Email_Local_Variable.Email[i].Email_Title);
        console.log("未读");
        console.log("Email_Local_Variable.Email[i].Is_Read:", i, Email_Local_Variable.Email[i].Is_Read);
        if (Email_Local_Variable.Email[i].Enclosure === true) //若有附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift2.png?sign=639a28a6a90a604f8cac84ea2eb59eae&t=1610714079");else //若无附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift.png?sign=ca9885f77ec4a7f7b3ffbc83cde81935&t=1610714025");
      }

      New_Email_Label.getChildByName("Email_Title").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Title;
      New_Email_Label.getChildByName("Email_Label").getChildByName("Email_Content").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Content;
      console.log("New_Email_Label.Email_Type:", New_Email_Label.Email_Type);
    }

    console.log("共", No_Read_Number, "封未读邮件");
    var No_Read_Number_Label = cc.instantiate(this.No_Read_Number);
    this.Canvas.addChild(No_Read_Number_Label);
    No_Read_Number_Label.setPosition(0, 360);
    No_Read_Number_Label.getComponent(cc.Label).string = "" + No_Read_Number + "封未读邮件";
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxMb2FkaW5nX0VtYWlsLmpzIl0sIm5hbWVzIjpbIkVtYWlsX0xvY2FsX1ZhcmlhYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiRW1haWxfUmVhZCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkVtYWlsIiwiRW1haWxfVmlldyIsIk5vZGUiLCJOb19SZWFkX051bWJlciIsIkNhbnZhcyIsIl9Jc19Mb2FkaW5nIiwib25Mb2FkIiwiV2VDaGF0IiwiTG9hZGluZ19FbWFpbCIsImNvbnNvbGUiLCJsb2ciLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiTG9hZGluZ19JbWFnZSIsInNlbGYiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJnZXRDaGlsZEJ5TmFtZSIsImdldENvbXBvbmVudCIsIlNwcml0ZSIsInNwcml0ZUZyYW1lIiwiaSIsImxlbmd0aCIsIk5ld19FbWFpbF9MYWJlbCIsIklzX1JlYWQiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwiRW5jbG9zdXJlIiwiRW1haWxfVGl0bGUiLCJMYWJlbCIsInN0cmluZyIsIkVtYWlsX0NvbnRlbnQiLCJFbWFpbF9UeXBlIiwiTm9fUmVhZF9OdW1iZXJfTGFiZWwiLCJzZXRQb3NpdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQU1BLG9CQUFvQixHQUFHQyxPQUFPLENBQUMsd0NBQUQsQ0FBcEM7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxVQUFVLEVBQUU7QUFDWCxpQkFBUyxJQURFO0FBRVhDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZFO0FBR1hDLE1BQUFBLFdBQVcsRUFBRTtBQUhGLEtBREQ7QUFLUjtBQUNIQyxJQUFBQSxLQUFLLEVBQUU7QUFDTixpQkFBUyxJQURIO0FBRU5ILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZIO0FBR05DLE1BQUFBLFdBQVcsRUFBRTtBQUhQLEtBTkk7QUFVUjtBQUNIRSxJQUFBQSxVQUFVLEVBQUU7QUFDWCxpQkFBUyxJQURFO0FBRVhKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVSxJQUZFO0FBR1hILE1BQUFBLFdBQVcsRUFBRTtBQUhGLEtBWEQ7QUFlUjtBQUNISSxJQUFBQSxjQUFjLEVBQUU7QUFDZixpQkFBUyxJQURNO0FBRWZOLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZNO0FBR2ZDLE1BQUFBLFdBQVcsRUFBRTtBQUhFLEtBaEJMO0FBb0JSO0FBQ0hLLElBQUFBLE1BQU0sRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUFAsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNVLElBRkY7QUFHUEgsTUFBQUEsV0FBVyxFQUFFO0FBSE4sS0FyQkc7QUEwQlhNLElBQUFBLFdBQVcsRUFBRTtBQTFCRixHQUhKO0FBK0JSQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQWhCLElBQUFBLG9CQUFvQixDQUFDVSxLQUFyQixHQUE2QixJQUE3QjtBQUNBTyxJQUFBQSxNQUFNLENBQUNDLGFBQVA7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQnBCLG9CQUFvQixDQUFDVSxLQUExQztBQUNBLFNBQUtLLFdBQUwsR0FBaUIsSUFBakI7QUFDQSxHQXJDTztBQXNDUjtBQUVBO0FBRUFNLEVBQUFBLEtBMUNRLG1CQTBDQSxDQUVQLENBNUNPO0FBNkNSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQixRQUFHLEtBQUtSLFdBQUwsSUFBa0JmLG9CQUFvQixDQUFDVSxLQUFyQixJQUE4QixJQUFuRCxFQUF3RDtBQUN0RCxXQUFLUSxhQUFMO0FBQ0EsV0FBS0gsV0FBTCxHQUFpQixLQUFqQjtBQUNEO0FBQ0QsR0FsRE87QUFtRFJTLEVBQUFBLGFBbkRRLHlCQW1ETUMsSUFuRE4sRUFtRFlDLFVBbkRaLEVBbUR3QjtBQUMvQixRQUFJQyxJQUFJLEdBQUdELFVBQVg7QUFDQXhCLElBQUFBLEVBQUUsQ0FBQzBCLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBRUgsSUFEUztBQUVkcEIsTUFBQUEsSUFBSSxFQUFFO0FBRlEsS0FBZixFQUdHLFVBQVN3QixHQUFULEVBQWNDLE9BQWQsRUFBdUJDLElBQXZCLEVBQTZCO0FBQy9CLFVBQUlDLEtBQUssR0FBRyxJQUFJaEMsRUFBRSxDQUFDaUMsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBWjs7QUFDQSxVQUFJRCxHQUFKLEVBQVM7QUFDUlosUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFvQlcsR0FBcEI7QUFDQTs7QUFDRE4sTUFBQUEsSUFBSSxDQUFDVyxjQUFMLENBQW9CLFlBQXBCLEVBQWtDQyxZQUFsQyxDQUErQ25DLEVBQUUsQ0FBQ29DLE1BQWxELEVBQTBEQyxXQUExRCxHQUF3RUwsS0FBeEU7QUFFQSxLQVZEO0FBV0EsR0FoRU87QUFpRVJoQixFQUFBQSxhQWpFUSwyQkFpRVE7QUFDZixRQUFJTCxjQUFjLEdBQUcsQ0FBckI7QUFDQSxRQUFJWSxJQUFJLEdBQUcsSUFBWCxDQUZlLENBR2Y7O0FBQ0EsU0FBSyxJQUFJZSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHeEMsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCK0IsTUFBL0MsRUFBdURELENBQUMsRUFBeEQsRUFBNEQ7QUFDM0QsVUFBSUUsZUFBZSxHQUFHLElBQXRCLENBRDJELENBRzNEOztBQUNBLFVBQUkxQyxvQkFBb0IsQ0FBQ1UsS0FBckIsQ0FBMkI4QixDQUEzQixFQUE4QkcsT0FBOUIsS0FBMEMsSUFBOUMsRUFBb0Q7QUFDbkQ7QUFDQUQsUUFBQUEsZUFBZSxHQUFHeEMsRUFBRSxDQUFDMEMsV0FBSCxDQUFlLEtBQUt0QyxVQUFwQixDQUFsQixDQUZtRCxDQUduRDs7QUFDQSxhQUFLSyxVQUFMLENBQWdCa0MsUUFBaEIsQ0FBeUJILGVBQXpCO0FBQ0F2QixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXNCLGVBQVosRUFBNkIsR0FBN0IsRUFBa0NGLENBQUMsR0FBRyxDQUF0QyxFQUF5QyxLQUF6QztBQUNBckIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMENBQVosRUFBd0RvQixDQUF4RCxFQUEyRHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTSxTQUF6RjtBQUNBM0IsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNENBQVosRUFBMERvQixDQUExRCxFQUE2RHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTyxXQUEzRjtBQUNBNUIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUNBRCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFzRG9CLENBQXRELEVBQXlEeEMsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJHLE9BQXZGLEVBVG1ELENBVW5EOztBQUNBLFlBQUkzQyxvQkFBb0IsQ0FBQ1UsS0FBckIsQ0FBMkI4QixDQUEzQixFQUE4Qk0sU0FBOUIsS0FBNEMsSUFBaEQsRUFDQztBQUNBLGVBQUt0QixhQUFMLENBQW1Ca0IsZUFBbkIsRUFDQyxvSUFERCxFQUZELEtBTUM7QUFDQSxlQUFLbEIsYUFBTCxDQUFtQmtCLGVBQW5CLEVBQ0MsbUlBREQ7QUFHRCxPQXJCRCxNQXFCTztBQUNON0IsUUFBQUEsY0FBYyxHQURSLENBRU47O0FBQ0E2QixRQUFBQSxlQUFlLEdBQUd4QyxFQUFFLENBQUMwQyxXQUFILENBQWUsS0FBS2xDLEtBQXBCLENBQWxCLENBSE0sQ0FJTjs7QUFDQSxhQUFLQyxVQUFMLENBQWdCa0MsUUFBaEIsQ0FBeUJILGVBQXpCO0FBQ0F2QixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXNCLGVBQVosRUFBNkIsR0FBN0IsRUFBa0NGLENBQUMsR0FBRyxDQUF0QyxFQUF5QyxLQUF6QztBQUNBckIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMENBQVosRUFBd0RvQixDQUF4RCxFQUEyRHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTSxTQUF6RjtBQUNBM0IsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNENBQVosRUFBMERvQixDQUExRCxFQUE2RHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTyxXQUEzRjtBQUNBNUIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUNBRCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFzRG9CLENBQXRELEVBQXlEeEMsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJHLE9BQXZGO0FBRUEsWUFBSTNDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTSxTQUE5QixLQUE0QyxJQUFoRCxFQUNDO0FBQ0EsZUFBS3RCLGFBQUwsQ0FBbUJrQixlQUFuQixFQUNDLG9JQURELEVBRkQsS0FNQztBQUNBLGVBQUtsQixhQUFMLENBQW1Ca0IsZUFBbkIsRUFDQyxtSUFERDtBQUdEOztBQUVEQSxNQUFBQSxlQUFlLENBQUNOLGNBQWhCLENBQStCLGFBQS9CLEVBQThDQyxZQUE5QyxDQUEyRG5DLEVBQUUsQ0FBQzhDLEtBQTlELEVBQXFFQyxNQUFyRSxHQUE4RSxLQUFLakQsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJPLFdBQWpIO0FBQ0FMLE1BQUFBLGVBQWUsQ0FBQ04sY0FBaEIsQ0FBK0IsYUFBL0IsRUFBOENBLGNBQTlDLENBQTZELGVBQTdELEVBQThFQyxZQUE5RSxDQUEyRm5DLEVBQUUsQ0FBQzhDLEtBQTlGLEVBQXFHQyxNQUFyRyxHQUE4RyxLQUFLakQsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJVLGFBQWpKO0FBQ0EvQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ3NCLGVBQWUsQ0FBQ1MsVUFBM0Q7QUFDQTs7QUFDRGhDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEdBQVosRUFBaUJQLGNBQWpCLEVBQWlDLE9BQWpDO0FBQ0EsUUFBSXVDLG9CQUFvQixHQUFHbEQsRUFBRSxDQUFDMEMsV0FBSCxDQUFlLEtBQUsvQixjQUFwQixDQUEzQjtBQUNBLFNBQUtDLE1BQUwsQ0FBWStCLFFBQVosQ0FBcUJPLG9CQUFyQjtBQUNBQSxJQUFBQSxvQkFBb0IsQ0FBQ0MsV0FBckIsQ0FBaUMsQ0FBakMsRUFBb0MsR0FBcEM7QUFDQUQsSUFBQUEsb0JBQW9CLENBQUNmLFlBQXJCLENBQWtDbkMsRUFBRSxDQUFDOEMsS0FBckMsRUFBNENDLE1BQTVDLEdBQXFELEtBQUtwQyxjQUFMLEdBQXNCLE9BQTNFO0FBQ0E7QUEvSE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/kuIvovb3pgq7nrrHliJfooahcclxuY29uc3QgRW1haWxfTG9jYWxfVmFyaWFibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRFbWFpbF9SZWFkOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+W3suivu+mCruS7tuahhlxyXG5cdFx0RW1haWw6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v5pyq6K+76YKu5Lu25qGGXHJcblx0XHRFbWFpbF9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/pgq7nrrHmoYZcclxuXHRcdE5vX1JlYWRfTnVtYmVyOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+acquivu+mCruS7tuiuoeaVsFxyXG5cdFx0Q2FudmFzOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblx0b25Mb2FkOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v6I635Y+W6YKu5Lu25YiX6KGoXHJcblx0XHRFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbCA9IG51bGw7XHJcblx0XHRXZUNoYXQuTG9hZGluZ19FbWFpbCgpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLpgq7ku7bkv6Hmga/ooahcIiwgRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwpO1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz10cnVlO1xyXG5cdH0sXHJcblx0Ly8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cdC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0aWYodGhpcy5fSXNfTG9hZGluZyYmRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwgIT0gbnVsbCl7XHJcblx0XHRcdFx0dGhpcy5Mb2FkaW5nX0VtYWlsKCk7XHJcblx0XHRcdFx0dGhpcy5fSXNfTG9hZGluZz1mYWxzZTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdExvYWRpbmdfSW1hZ2Uoc2VsZiwgSW1hZ2VfUGF0aCkge1xyXG5cdFx0bGV0IF91cmwgPSBJbWFnZV9QYXRoO1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6IF91cmwsXHJcblx0XHRcdHR5cGU6ICdqcGcnXHJcblx0XHR9LCBmdW5jdGlvbihlcnIsIHRleHR1cmUsIHRlc3QpIHtcclxuXHRcdFx0dmFyIGZyYW1lID0gbmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRpZiAoZXJyKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIiwgZXJyKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRzZWxmLmdldENoaWxkQnlOYW1lKFwiRW1haWxfVHlwZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IGZyYW1lO1xyXG5cclxuXHRcdH0pXHJcblx0fSxcclxuXHRMb2FkaW5nX0VtYWlsKCkge1xyXG5cdFx0dmFyIE5vX1JlYWRfTnVtYmVyID0gMDtcclxuXHRcdHZhciBzZWxmID0gdGhpcztcclxuXHRcdC8v5b6q546v6L6T5Ye66YKu5Lu25qGGXHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsLmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdHZhciBOZXdfRW1haWxfTGFiZWwgPSBudWxsO1xyXG5cclxuXHRcdFx0Ly/moLnmja7mmK/lkKblt7Lor7vlhrPlrprog4zmma8o6YKu5Lu25qGG57G75Z6LKVxyXG5cdFx0XHRpZiAoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uSXNfUmVhZCA9PT0gdHJ1ZSkge1xyXG5cdFx0XHRcdC8v5paw5bu65bey6K+76YKu5Lu26IqC54K5XHJcblx0XHRcdFx0TmV3X0VtYWlsX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5FbWFpbF9SZWFkKTtcclxuXHRcdFx0XHQvL+WKoOWFpeS4uuWtkOiKgueCuVxyXG5cdFx0XHRcdHRoaXMuRW1haWxfVmlldy5hZGRDaGlsZChOZXdfRW1haWxfTGFiZWwpO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKE5ld19FbWFpbF9MYWJlbCwgXCLnrKxcIiwgaSArIDEsIFwi5bCB6YKu5Lu2XCIpO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwiRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW5jbG9zdXJlOlwiLCBpLCBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbmNsb3N1cmUpO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwiRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfVGl0bGU6XCIsIGksIEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIuW3suivu1wiKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIkVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLklzX1JlYWQ6XCIsIGksIEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLklzX1JlYWQpO1xyXG5cdFx0XHRcdC8v5qC55o2u5piv5ZCm5pyJ6ZmE5Lu25Yaz5a6a5Zu+5qCH57G75Z6LXHJcblx0XHRcdFx0aWYgKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZSA9PT0gdHJ1ZSlcclxuXHRcdFx0XHRcdC8v6Iul5pyJ6ZmE5Lu2XHJcblx0XHRcdFx0XHR0aGlzLkxvYWRpbmdfSW1hZ2UoTmV3X0VtYWlsX0xhYmVsLFxyXG5cdFx0XHRcdFx0XHRcImh0dHBzOi8vN2E2My16Y3gtNmdiZ2R4ZHkyNTQ4MTZiMC0xMzA0MzQyOTQ3LnRjYi5xY2xvdWQubGEvaW1hZ2UvVGlwcy9HaWZ0Mi5wbmc/c2lnbj02MzlhMjhhNmE5MGE2MDRmOGNhYzg0ZWEyZWI1OWVhZSZ0PTE2MTA3MTQwNzlcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHQvL+iLpeaXoOmZhOS7tlxyXG5cdFx0XHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19FbWFpbF9MYWJlbCxcclxuXHRcdFx0XHRcdFx0XCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL2ltYWdlL1RpcHMvR2lmdC5wbmc/c2lnbj1jYTk4ODVmNzdlYzRhN2Y3YjNmZmJjODNjZGU4MTkzNSZ0PTE2MTA3MTQwMjVcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHROb19SZWFkX051bWJlcisrO1xyXG5cdFx0XHRcdC8v5paw5bu65pyq6K+76YKu5Lu26IqC54K5XHJcblx0XHRcdFx0TmV3X0VtYWlsX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5FbWFpbCk7XHJcblx0XHRcdFx0Ly/liqDlhaXkuLrlrZDoioLngrlcclxuXHRcdFx0XHR0aGlzLkVtYWlsX1ZpZXcuYWRkQ2hpbGQoTmV3X0VtYWlsX0xhYmVsKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhOZXdfRW1haWxfTGFiZWwsIFwi56ysXCIsIGkgKyAxLCBcIuWwgemCruS7tlwiKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIkVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZTpcIiwgaSwgRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW5jbG9zdXJlKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIkVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlOlwiLCBpLCBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9UaXRsZSk7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLmnKror7tcIik7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCJFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5Jc19SZWFkOlwiLCBpLCBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5Jc19SZWFkKTtcclxuXHJcblx0XHRcdFx0aWYgKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZSA9PT0gdHJ1ZSlcclxuXHRcdFx0XHRcdC8v6Iul5pyJ6ZmE5Lu2XHJcblx0XHRcdFx0XHR0aGlzLkxvYWRpbmdfSW1hZ2UoTmV3X0VtYWlsX0xhYmVsLFxyXG5cdFx0XHRcdFx0XHRcImh0dHBzOi8vN2E2My16Y3gtNmdiZ2R4ZHkyNTQ4MTZiMC0xMzA0MzQyOTQ3LnRjYi5xY2xvdWQubGEvaW1hZ2UvVGlwcy9HaWZ0Mi5wbmc/c2lnbj02MzlhMjhhNmE5MGE2MDRmOGNhYzg0ZWEyZWI1OWVhZSZ0PTE2MTA3MTQwNzlcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHQvL+iLpeaXoOmZhOS7tlxyXG5cdFx0XHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19FbWFpbF9MYWJlbCxcclxuXHRcdFx0XHRcdFx0XCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL2ltYWdlL1RpcHMvR2lmdC5wbmc/c2lnbj1jYTk4ODVmNzdlYzRhN2Y3YjNmZmJjODNjZGU4MTkzNSZ0PTE2MTA3MTQwMjVcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0TmV3X0VtYWlsX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiRW1haWxfVGl0bGVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfVGl0bGU7XHJcblx0XHRcdE5ld19FbWFpbF9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkVtYWlsX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiRW1haWxfQ29udGVudFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9Db250ZW50O1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIk5ld19FbWFpbF9MYWJlbC5FbWFpbF9UeXBlOlwiLCBOZXdfRW1haWxfTGFiZWwuRW1haWxfVHlwZSk7XHJcblx0XHR9XHJcblx0XHRjb25zb2xlLmxvZyhcIuWFsVwiLCBOb19SZWFkX051bWJlciwgXCLlsIHmnKror7vpgq7ku7ZcIik7XHJcblx0XHR2YXIgTm9fUmVhZF9OdW1iZXJfTGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLk5vX1JlYWRfTnVtYmVyKTtcclxuXHRcdHRoaXMuQ2FudmFzLmFkZENoaWxkKE5vX1JlYWRfTnVtYmVyX0xhYmVsKTtcclxuXHRcdE5vX1JlYWRfTnVtYmVyX0xhYmVsLnNldFBvc2l0aW9uKDAsIDM2MCk7XHJcblx0XHROb19SZWFkX051bWJlcl9MYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBOb19SZWFkX051bWJlciArIFwi5bCB5pyq6K+76YKu5Lu2XCI7XHJcblx0fVxyXG59KTtcclxuIl19