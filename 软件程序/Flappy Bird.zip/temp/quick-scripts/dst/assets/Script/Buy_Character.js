
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Buy_Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f31eeHyetZCB7tSoBA1W/AE', 'Buy_Character');
// Script/Buy_Character.js

"use strict";

var Alert = {
  btnOK: null,
  btnCancel: null,
  content: null,
  btnOKCallBack: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    Tip: cc.Label
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  show: function show() {
    this.node.active = true;
  },
  hide: function hide() {
    this.node.active = false;
  },
  onClickCancle: function onClickCancle() {
    this.hide();
  },
  onClickConfirm: function onClickConfirm() {
    this.hide();
  },
  setTip: function setTip(string) {
    this.Tip.String = string;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxCdXlfQ2hhcmFjdGVyLmpzIl0sIm5hbWVzIjpbIkFsZXJ0IiwiYnRuT0siLCJidG5DYW5jZWwiLCJjb250ZW50IiwiYnRuT0tDYWxsQmFjayIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiVGlwIiwiTGFiZWwiLCJzdGFydCIsInNob3ciLCJub2RlIiwiYWN0aXZlIiwiaGlkZSIsIm9uQ2xpY2tDYW5jbGUiLCJvbkNsaWNrQ29uZmlybSIsInNldFRpcCIsInN0cmluZyIsIlN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFJQSxLQUFLLEdBQUc7QUFFUkMsRUFBQUEsS0FBSyxFQUFDLElBRkU7QUFHUkMsRUFBQUEsU0FBUyxFQUFDLElBSEY7QUFJUkMsRUFBQUEsT0FBTyxFQUFDLElBSkE7QUFLUkMsRUFBQUEsYUFBYSxFQUFDO0FBTE4sQ0FBWjtBQVFBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDVEMsSUFBQUEsR0FBRyxFQUFDSixFQUFFLENBQUNLO0FBREUsR0FIUDtBQU9MO0FBRUE7QUFFQUMsRUFBQUEsS0FYSyxtQkFXSSxDQUVSLENBYkk7QUFjTEMsRUFBQUEsSUFBSSxFQUFDLGdCQUFVO0FBQ1gsU0FBS0MsSUFBTCxDQUFVQyxNQUFWLEdBQW1CLElBQW5CO0FBQ0gsR0FoQkk7QUFpQkxDLEVBQUFBLElBQUksRUFBQyxnQkFBVTtBQUNYLFNBQUtGLElBQUwsQ0FBVUMsTUFBVixHQUFtQixLQUFuQjtBQUNILEdBbkJJO0FBb0JMRSxFQUFBQSxhQUFhLEVBQUMseUJBQVU7QUFDcEIsU0FBS0QsSUFBTDtBQUNILEdBdEJJO0FBdUJMRSxFQUFBQSxjQUFjLEVBQUMsMEJBQVU7QUFDckIsU0FBS0YsSUFBTDtBQUNILEdBekJJO0FBMEJMRyxFQUFBQSxNQUFNLEVBQUMsZ0JBQVNDLE1BQVQsRUFBZ0I7QUFDbkIsU0FBS1YsR0FBTCxDQUFTVyxNQUFULEdBQWtCRCxNQUFsQjtBQUNILEdBNUJJLENBNkJMOztBQTdCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxudmFyIEFsZXJ0ID0ge1xyXG4gICAgIFxyXG4gICAgYnRuT0s6bnVsbCxcclxuICAgIGJ0bkNhbmNlbDpudWxsLFxyXG4gICAgY29udGVudDpudWxsLFxyXG4gICAgYnRuT0tDYWxsQmFjazpudWxsLFxyXG59XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgVGlwOmNjLkxhYmVsLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sIFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG4gICAgc2hvdzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlIFxyXG4gICAgfSxcclxuICAgIGhpZGU6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2VcclxuICAgIH0sXHJcbiAgICBvbkNsaWNrQ2FuY2xlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5oaWRlKClcclxuICAgIH0sXHJcbiAgICBvbkNsaWNrQ29uZmlybTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuaGlkZSgpXHJcbiAgICB9LFxyXG4gICAgc2V0VGlwOmZ1bmN0aW9uKHN0cmluZyl7XHJcbiAgICAgICAgdGhpcy5UaXAuU3RyaW5nID0gc3RyaW5nXHJcbiAgICB9XHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==