
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Cloud_Image1.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b2407c+gnxIrKO0x/Qzt/Qc', 'Cloud_Image1');
// Script/Cloud_Image1.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  // onLoad () {},
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDbG91ZF9JbWFnZTEuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJJYW1nZSIsIkJHU3ByaXRlIiwidHlwZSIsIlNwcml0ZSIsInNlcmlhbHphYmxlIiwib25Mb2FkIiwic2VsZiIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNUQyxJQUFBQSxLQUFLLEVBQUUsRUFERTtBQUVaQyxJQUFBQSxRQUFRLEVBQUM7QUFDVCxpQkFBUSxJQURDO0FBRVRDLE1BQUFBLElBQUksRUFBQ04sRUFBRSxDQUFDTyxNQUZDO0FBR1RDLE1BQUFBLFdBQVcsRUFBQztBQUhIO0FBRkcsR0FIUDtBQWFMO0FBRUFDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVztBQUNwQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBLFFBQUlDLElBQUksR0FBQ0QsSUFBSSxDQUFDTixLQUFkO0FBQ0FKLElBQUFBLEVBQUUsQ0FBQ1ksTUFBSCxDQUFVQyxJQUFWLENBQWU7QUFDZEMsTUFBQUEsR0FBRyxFQUFDSCxJQURVO0FBRWRMLE1BQUFBLElBQUksRUFBQztBQUZTLEtBQWYsRUFHRSxVQUFTUyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJbEIsRUFBRSxDQUFDbUIsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTkssUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQk4sR0FBbkI7QUFDQTs7QUFDREwsTUFBQUEsSUFBSSxDQUFDTCxRQUFMLENBQWNpQixZQUFkLENBQTJCdEIsRUFBRSxDQUFDTyxNQUE5QixFQUFzQ2dCLFdBQXRDLEdBQWtETCxLQUFsRDtBQUVBLEtBVkQ7QUFXRCxHQTdCUTtBQStCTE0sRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWEsQ0FBRTtBQS9CbEIsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICBJYW1nZTogXCJcIixcclxuXHQgICBCR1Nwcml0ZTp7XG5cdFx0ICBkZWZhdWx0Om51bGwsXG5cdFx0ICB0eXBlOmNjLlNwcml0ZSxcblx0XHQgIHNlcmlhbHphYmxlOnRydWUsXG5cdCAgIH0sXG4gICAgfSxcblxuXG4gICAgLy8gb25Mb2FkICgpIHt9LFxuXG4gICAgb25Mb2FkOmZ1bmN0aW9uKCkge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRsZXQgX3VybD1zZWxmLklhbWdlO1xuXHRcdGNjLmxvYWRlci5sb2FkKHtcblx0XHRcdHVybDpfdXJsLFxuXHRcdFx0dHlwZTonanBnJ1xuXHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XG5cdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xuXHRcdFx0aWYoZXJyKXtcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xuXHRcdFx0fVxuXHRcdFx0c2VsZi5CR1Nwcml0ZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcblx0XHRcdFxuXHRcdH0pXG59LFxuXG4gICAgdXBkYXRlOiBmdW5jdGlvbihkdCkge30sXG59KTtcbiJdfQ==