
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/FriendsView.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '06b61gM/MVNvLdkhaMA7Q0s', 'FriendsView');
// Script/FriendsView.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    WXSubContextView: {
      "default": null,
      type: cc.Node,
      serializable: true
    }
  },
  start: function start() {
    this.subContextView = this.WXSubContextView.getComponent(cc.WXSubContextView);
  },
  showFriends: function showFriends() {
    console.log("显示好友列表"); //获取时间戳

    var updateTime = new Date().valueOf(); //获取好友列表上对应的信息

    var getArr = new Array();
    getArr.push("love");
    var openDataContext = wx.getOpenDataContext();
    openDataContext.postMessage({
      type: "GET",
      data: getArr,
      time: updateTime
    });
    this.subContextView.enabled = true;
    this.WXSubContextView.active = true;
    this.subContextView.update();
  },
  sendMsgToFriendsListdata: function sendMsgToFriendsListdata() {
    console.log("sendMsg"); //时间戳

    var updateTime = new Date().valueOf();
    var value = JSON.stringfy({
      "wxgame": {
        "love": Math.floor(10000 * Math.random()),
        "update_time": updateTime
      }
    });
    var arr = new Array();
    arr.push({
      key: "love",
      value: _value
    });
    var openDataContext = wx.getOpenDataContext();
    openDataContext.postMessage({
      type: "SET",
      data: arr,
      timer: updateTime
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxGcmllbmRzVmlldy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIldYU3ViQ29udGV4dFZpZXciLCJ0eXBlIiwiTm9kZSIsInNlcmlhbGl6YWJsZSIsInN0YXJ0Iiwic3ViQ29udGV4dFZpZXciLCJnZXRDb21wb25lbnQiLCJzaG93RnJpZW5kcyIsImNvbnNvbGUiLCJsb2ciLCJ1cGRhdGVUaW1lIiwiRGF0ZSIsInZhbHVlT2YiLCJnZXRBcnIiLCJBcnJheSIsInB1c2giLCJvcGVuRGF0YUNvbnRleHQiLCJ3eCIsImdldE9wZW5EYXRhQ29udGV4dCIsInBvc3RNZXNzYWdlIiwiZGF0YSIsInRpbWUiLCJlbmFibGVkIiwiYWN0aXZlIiwidXBkYXRlIiwic2VuZE1zZ1RvRnJpZW5kc0xpc3RkYXRhIiwidmFsdWUiLCJKU09OIiwic3RyaW5nZnkiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJhcnIiLCJrZXkiLCJfdmFsdWUiLCJ0aW1lciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLGdCQUFnQixFQUFDO0FBQ2IsaUJBQVEsSUFESztBQUViQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sSUFGSztBQUdiQyxNQUFBQSxZQUFZLEVBQUM7QUFIQTtBQURULEdBSFA7QUFZTEMsRUFBQUEsS0FaSyxtQkFZSTtBQUNMLFNBQUtDLGNBQUwsR0FBc0IsS0FBS0wsZ0JBQUwsQ0FBc0JNLFlBQXRCLENBQW1DVixFQUFFLENBQUNJLGdCQUF0QyxDQUF0QjtBQUNILEdBZEk7QUFlTE8sRUFBQUEsV0FBVyxFQUFDLHVCQUFVO0FBQ2xCQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBRGtCLENBRWxCOztBQUNBLFFBQUlDLFVBQVUsR0FBSSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFqQixDQUhrQixDQUlsQjs7QUFDQSxRQUFJQyxNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0FELElBQUFBLE1BQU0sQ0FBQ0UsSUFBUCxDQUFZLE1BQVo7QUFFQSxRQUFJQyxlQUFlLEdBQUdDLEVBQUUsQ0FBQ0Msa0JBQUgsRUFBdEI7QUFDQUYsSUFBQUEsZUFBZSxDQUFDRyxXQUFoQixDQUE0QjtBQUN4QmxCLE1BQUFBLElBQUksRUFBQyxLQURtQjtBQUV4Qm1CLE1BQUFBLElBQUksRUFBQ1AsTUFGbUI7QUFHeEJRLE1BQUFBLElBQUksRUFBQ1g7QUFIbUIsS0FBNUI7QUFLRCxTQUFLTCxjQUFMLENBQW9CaUIsT0FBcEIsR0FBOEIsSUFBOUI7QUFDQSxTQUFLdEIsZ0JBQUwsQ0FBc0J1QixNQUF0QixHQUErQixJQUEvQjtBQUNBLFNBQU1sQixjQUFOLENBQXFCbUIsTUFBckI7QUFDRixHQWhDSTtBQWlDTEMsRUFBQUEsd0JBQXdCLEVBQUMsb0NBQVU7QUFDL0JqQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaLEVBRCtCLENBRS9COztBQUNBLFFBQUlDLFVBQVUsR0FBSSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFqQjtBQUNBLFFBQUljLEtBQUssR0FBSUMsSUFBSSxDQUFDQyxRQUFMLENBQWM7QUFDdkIsZ0JBQVM7QUFDTCxnQkFBT0MsSUFBSSxDQUFDQyxLQUFMLENBQVksUUFBUUQsSUFBSSxDQUFDRSxNQUFMLEVBQXBCLENBREY7QUFFTCx1QkFBY3JCO0FBRlQ7QUFEYyxLQUFkLENBQWI7QUFNQSxRQUFJc0IsR0FBRyxHQUFFLElBQUlsQixLQUFKLEVBQVQ7QUFDQWtCLElBQUFBLEdBQUcsQ0FBQ2pCLElBQUosQ0FBUztBQUFDa0IsTUFBQUEsR0FBRyxFQUFDLE1BQUw7QUFBWVAsTUFBQUEsS0FBSyxFQUFDUTtBQUFsQixLQUFUO0FBQ0EsUUFBSWxCLGVBQWUsR0FBR0MsRUFBRSxDQUFDQyxrQkFBSCxFQUF0QjtBQUNBRixJQUFBQSxlQUFlLENBQUNHLFdBQWhCLENBQTRCO0FBQ3hCbEIsTUFBQUEsSUFBSSxFQUFDLEtBRG1CO0FBRXhCbUIsTUFBQUEsSUFBSSxFQUFDWSxHQUZtQjtBQUd4QkcsTUFBQUEsS0FBSyxFQUFDekI7QUFIa0IsS0FBNUI7QUFLSDtBQW5ESSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFdYU3ViQ29udGV4dFZpZXc6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICAgICAgc2VyaWFsaXphYmxlOnRydWVcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy5zdWJDb250ZXh0VmlldyA9IHRoaXMuV1hTdWJDb250ZXh0Vmlldy5nZXRDb21wb25lbnQoY2MuV1hTdWJDb250ZXh0VmlldylcclxuICAgIH0sXHJcbiAgICBzaG93RnJpZW5kczpmdW5jdGlvbigpe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5pi+56S65aW95Y+L5YiX6KGoXCIpO1xyXG4gICAgICAgIC8v6I635Y+W5pe26Ze05oizXHJcbiAgICAgICAgbGV0IHVwZGF0ZVRpbWUgPSAobmV3IERhdGUoKSkudmFsdWVPZigpO1xyXG4gICAgICAgIC8v6I635Y+W5aW95Y+L5YiX6KGo5LiK5a+55bqU55qE5L+h5oGvXHJcbiAgICAgICAgbGV0IGdldEFyciA9IG5ldyBBcnJheSgpO1xyXG4gICAgICAgIGdldEFyci5wdXNoKFwibG92ZVwiKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgb3BlbkRhdGFDb250ZXh0ID0gd3guZ2V0T3BlbkRhdGFDb250ZXh0KCk7XHJcbiAgICAgICAgb3BlbkRhdGFDb250ZXh0LnBvc3RNZXNzYWdlKHtcclxuICAgICAgICAgICAgdHlwZTpcIkdFVFwiLFxyXG4gICAgICAgICAgICBkYXRhOmdldEFycixcclxuICAgICAgICAgICAgdGltZTp1cGRhdGVUaW1lICBcclxuICAgICAgICB9KVxyXG4gICAgICAgdGhpcy5zdWJDb250ZXh0Vmlldy5lbmFibGVkID0gdHJ1ZSA7XHJcbiAgICAgICB0aGlzLldYU3ViQ29udGV4dFZpZXcuYWN0aXZlID0gdHJ1ZSA7XHJcbiAgICAgICB0aGlzIC5zdWJDb250ZXh0Vmlldy51cGRhdGUoKTtcclxuICAgIH0sXHJcbiAgICBzZW5kTXNnVG9GcmllbmRzTGlzdGRhdGE6ZnVuY3Rpb24oKXtcclxuICAgICAgICBjb25zb2xlLmxvZyhcInNlbmRNc2dcIik7XHJcbiAgICAgICAgLy/ml7bpl7TmiLNcclxuICAgICAgICBsZXQgdXBkYXRlVGltZSA9IChuZXcgRGF0ZSgpKS52YWx1ZU9mKCk7XHJcbiAgICAgICAgbGV0IHZhbHVlICA9IEpTT04uc3RyaW5nZnkoe1xyXG4gICAgICAgICAgICBcInd4Z2FtZVwiOntcclxuICAgICAgICAgICAgICAgIFwibG92ZVwiOk1hdGguZmxvb3IgKDEwMDAwICogTWF0aC5yYW5kb20oKSksXHJcbiAgICAgICAgICAgICAgICBcInVwZGF0ZV90aW1lXCI6dXBkYXRlVGltZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgbGV0IGFyciA9bmV3IEFycmF5KCk7XHJcbiAgICAgICAgYXJyLnB1c2goe2tleTpcImxvdmVcIix2YWx1ZTpfdmFsdWV9KTtcclxuICAgICAgICBsZXQgb3BlbkRhdGFDb250ZXh0ID0gd3guZ2V0T3BlbkRhdGFDb250ZXh0KCk7XHJcbiAgICAgICAgb3BlbkRhdGFDb250ZXh0LnBvc3RNZXNzYWdlKHtcclxuICAgICAgICAgICAgdHlwZTpcIlNFVFwiLFxyXG4gICAgICAgICAgICBkYXRhOmFycixcclxuICAgICAgICAgICAgdGltZXI6dXBkYXRlVGltZVxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbn0pO1xyXG4iXX0=