
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/People.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '35cf1epWixAa5295ytVUj/q', 'People');
// Script/People.js

"use strict";

var Alert = {
  btnOK: null,
  btnCancel: null,
  content: null,
  btnOKCallBack: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    alert: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  onClickAlert: function onClickAlert() {
    var node = cc.instantiate(this.alert);
    this.node.addChild(node);
    node = node.getComponent('ReportAlert');
    node.setTip('确定举报该好友吗？');
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQZW9wbGUuanMiXSwibmFtZXMiOlsiQWxlcnQiLCJidG5PSyIsImJ0bkNhbmNlbCIsImNvbnRlbnQiLCJidG5PS0NhbGxCYWNrIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJhbGVydCIsIlByZWZhYiIsInN0YXJ0Iiwib25DbGlja0FsZXJ0Iiwibm9kZSIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJnZXRDb21wb25lbnQiLCJzZXRUaXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBSUEsS0FBSyxHQUFHO0FBRVJDLEVBQUFBLEtBQUssRUFBQyxJQUZFO0FBR1JDLEVBQUFBLFNBQVMsRUFBQyxJQUhGO0FBSVJDLEVBQUFBLE9BQU8sRUFBQyxJQUpBO0FBS1JDLEVBQUFBLGFBQWEsRUFBQztBQUxOLENBQVo7QUFRQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBQ0osRUFBRSxDQUFDSztBQURELEdBSFA7QUFPTDtBQUVBO0FBRUFDLEVBQUFBLEtBWEssbUJBV0ksQ0FFUixDQWJJO0FBY0pDLEVBQUFBLFlBQVksRUFBQyx3QkFBVTtBQUNuQixRQUFJQyxJQUFJLEdBQUdSLEVBQUUsQ0FBQ1MsV0FBSCxDQUFlLEtBQUtMLEtBQXBCLENBQVg7QUFDQSxTQUFLSSxJQUFMLENBQVVFLFFBQVYsQ0FBbUJGLElBQW5CO0FBQ0FBLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDRyxZQUFMLENBQWtCLGFBQWxCLENBQVA7QUFDQUgsSUFBQUEsSUFBSSxDQUFDSSxNQUFMLENBQVksV0FBWjtBQUNILEdBbkJHLENBb0JMOztBQXBCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxudmFyIEFsZXJ0ID0ge1xyXG4gICAgIFxyXG4gICAgYnRuT0s6bnVsbCxcclxuICAgIGJ0bkNhbmNlbDpudWxsLFxyXG4gICAgY29udGVudDpudWxsLFxyXG4gICAgYnRuT0tDYWxsQmFjazpudWxsLFxyXG59XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGFsZXJ0OmNjLlByZWZhYixcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LCBcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuICAgICBvbkNsaWNrQWxlcnQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICAgdmFyIG5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmFsZXJ0KTtcclxuICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKG5vZGUpO1xyXG4gICAgICAgICBub2RlID0gbm9kZS5nZXRDb21wb25lbnQoJ1JlcG9ydEFsZXJ0Jyk7XHJcbiAgICAgICAgIG5vZGUuc2V0VGlwKCfnoa7lrprkuL7miqXor6Xlpb3lj4vlkJfvvJ8nKTtcclxuICAgICB9XHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==