
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Buy_Character');
require('./assets/Script/Cloud_Image1');
require('./assets/Script/FriendsListData');
require('./assets/Script/FriendsView');
require('./assets/Script/Jump_Scene1');
require('./assets/Script/People');
require('./assets/cloud/cloud');
require('./assets/resources/script/Account_Management/Appeal_Cancel');
require('./assets/resources/script/Account_Management/Appeal_Confirm');
require('./assets/resources/script/Account_Management/Appeal_User');
require('./assets/resources/script/Account_Management/Cancel_Closure');
require('./assets/resources/script/Account_Management/Closure_Account');
require('./assets/resources/script/Account_Management/Handle_Reported_User');
require('./assets/resources/script/Account_Management/Loading_All_Reported_User');
require('./assets/resources/script/Account_Management/Loading_All_Users');
require('./assets/resources/script/Account_Management/Loading_Reported_Users ');
require('./assets/resources/script/Closure/Closure_Tips');
require('./assets/resources/script/Closure/Tip');
require('./assets/resources/script/Closure/Tip_Close');
require('./assets/resources/script/Email/Accept');
require('./assets/resources/script/Email/Awards');
require('./assets/resources/script/Email/Delete_Read');
require('./assets/resources/script/Email/Email_Information');
require('./assets/resources/script/Email/Email_Waring');
require('./assets/resources/script/Email/Loading_Email');
require('./assets/resources/script/Email/Read_All');
require('./assets/resources/script/Friends/Show_Friends');
require('./assets/resources/script/Game_Coming/Bird_Action');
require('./assets/resources/script/Game_Coming/Game');
require('./assets/resources/script/Game_Coming/Gold_Action');
require('./assets/resources/script/Game_Coming/Gold_Show_Action');
require('./assets/resources/script/Game_Coming/Waterpipe_Action');
require('./assets/resources/script/Game_Login/NewScript');
require('./assets/resources/script/Game_Login/WX_Login');
require('./assets/resources/script/Game_Over/Grade_Show');
require('./assets/resources/script/Game_Start/Change_Difficult');
require('./assets/resources/script/Game_Start/Change_Map');
require('./assets/resources/script/Game_Start/Loading_Bird_Image');
require('./assets/resources/script/Game_Start/Loading_Game');
require('./assets/resources/script/Global_Function/Change_Bird_Image');
require('./assets/resources/script/Global_Function/Close_Box');
require('./assets/resources/script/Global_Function/Cloud_Image');
require('./assets/resources/script/Global_Function/Global_Variable');
require('./assets/resources/script/Global_Function/Global_WeChat');
require('./assets/resources/script/Global_Function/Jump_Scene');
require('./assets/resources/script/Global_Function/Loading_Base_Resouce');
require('./assets/resources/script/Local_Variible/Account_Management_Local_Variable');
require('./assets/resources/script/Local_Variible/Email_Local_Variable');
require('./assets/resources/script/Local_Variible/Game_Difficulty_Local_Varible');
require('./assets/resources/script/Local_Variible/Game_Local_Varible');
require('./assets/resources/script/Local_Variible/Jump_DIfficulty');
require('./assets/resources/script/Local_Variible/Rank_Local_Variable');
require('./assets/resources/script/Local_Variible/Report_Local_Variable');
require('./assets/resources/script/Local_Variible/Shop_Character_Local_Varible');
require('./assets/resources/script/Local_Variible/User_Have_Character_Local_Varible');
require('./assets/resources/script/Rank/Loading_Rank');
require('./assets/resources/script/Rank/My_Rank');
require('./assets/resources/script/Rank/Report_Cancel');
require('./assets/resources/script/Rank/Report_Confirm');
require('./assets/resources/script/Rank/Report_User');
require('./assets/resources/script/Role/Change_Character');
require('./assets/resources/script/Role/Have_Character_Information');
require('./assets/resources/script/Role/Loading_Role');
require('./assets/resources/script/Shop/Buy_Character_Sure');
require('./assets/resources/script/Shop/Character');
require('./assets/resources/script/Shop/Character_Information');
require('./assets/resources/script/Shop/Loading_Character');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Jump_Scene1.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c6f98AzcwBDYJG3lkcaGmT0', 'Jump_Scene1');
// Script/Jump_Scene1.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    scene: ""
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    cc.director.loadScene(this.scene);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxKdW1wX1NjZW5lMS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNjZW5lIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJkaXJlY3RvciIsImxvYWRTY2VuZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBQztBQURFLEdBSFA7QUFPTDtBQUVBO0FBRUFDLEVBQUFBLEtBWEssbUJBV0ksQ0FFUixDQWJJO0FBY0xDLEVBQUFBLFlBQVksRUFBQyx3QkFBVTtBQUNuQk4sSUFBQUEsRUFBRSxDQUFDTyxRQUFILENBQVlDLFNBQVosQ0FBc0IsS0FBS0osS0FBM0I7QUFDSCxHQWhCSSxDQWtCTDs7QUFsQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIHNjZW5lOlwiXCIsXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgb25fYnRuX2NsaWNrOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKHRoaXMuc2NlbmUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/cloud/cloud.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f9929JSAYhKR7C34dP6eiBH', 'cloud');
// cloud/cloud.js

"use strict";

(function () {
  cc.cloud = {
    initialized: false,
    initialize: function initialize(config) {
      if (typeof config === 'undefined' || config === null) config = cc_cloud_commonConfig;

      if (config.platform === 'tencent') {
        if (this.initialized) return this.tencentApp;
        cloudbase && cloudbase.useAdapters(window.adapter);
        this.tencentApp = cloudbase ? cloudbase.init(config.tencent) : null;
        this.initialized = true;
        return this.tencentApp;
      }

      return null;
    }
  };
})();

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcY2xvdWRcXGNsb3VkLmpzIl0sIm5hbWVzIjpbImNjIiwiY2xvdWQiLCJpbml0aWFsaXplZCIsImluaXRpYWxpemUiLCJjb25maWciLCJjY19jbG91ZF9jb21tb25Db25maWciLCJwbGF0Zm9ybSIsInRlbmNlbnRBcHAiLCJjbG91ZGJhc2UiLCJ1c2VBZGFwdGVycyIsIndpbmRvdyIsImFkYXB0ZXIiLCJpbml0IiwidGVuY2VudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxDQUFDLFlBQVk7QUFDWEEsRUFBQUEsRUFBRSxDQUFDQyxLQUFILEdBQVc7QUFDVEMsSUFBQUEsV0FBVyxFQUFFLEtBREo7QUFFVEMsSUFBQUEsVUFGUyxzQkFFRUMsTUFGRixFQUVVO0FBQ2pCLFVBQUksT0FBT0EsTUFBUCxLQUFrQixXQUFsQixJQUFpQ0EsTUFBTSxLQUFLLElBQWhELEVBQXNEQSxNQUFNLEdBQUdDLHFCQUFUOztBQUN0RCxVQUFJRCxNQUFNLENBQUNFLFFBQVAsS0FBb0IsU0FBeEIsRUFBbUM7QUFDakMsWUFBSSxLQUFLSixXQUFULEVBQXNCLE9BQU8sS0FBS0ssVUFBWjtBQUN0QkMsUUFBQUEsU0FBUyxJQUFJQSxTQUFTLENBQUNDLFdBQVYsQ0FBc0JDLE1BQU0sQ0FBQ0MsT0FBN0IsQ0FBYjtBQUNBLGFBQUtKLFVBQUwsR0FBa0JDLFNBQVMsR0FBR0EsU0FBUyxDQUFDSSxJQUFWLENBQWVSLE1BQU0sQ0FBQ1MsT0FBdEIsQ0FBSCxHQUFvQyxJQUEvRDtBQUNBLGFBQUtYLFdBQUwsR0FBbUIsSUFBbkI7QUFDQSxlQUFPLEtBQUtLLFVBQVo7QUFDRDs7QUFDRCxhQUFPLElBQVA7QUFDRDtBQVpRLEdBQVg7QUFjRCxDQWZEIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gKCkge1xyXG4gIGNjLmNsb3VkID0ge1xyXG4gICAgaW5pdGlhbGl6ZWQ6IGZhbHNlLFxyXG4gICAgaW5pdGlhbGl6ZShjb25maWcpIHtcclxuICAgICAgaWYgKHR5cGVvZiBjb25maWcgPT09ICd1bmRlZmluZWQnIHx8IGNvbmZpZyA9PT0gbnVsbCkgY29uZmlnID0gY2NfY2xvdWRfY29tbW9uQ29uZmlnO1xyXG4gICAgICBpZiAoY29uZmlnLnBsYXRmb3JtID09PSAndGVuY2VudCcpIHtcclxuICAgICAgICBpZiAodGhpcy5pbml0aWFsaXplZCkgcmV0dXJuIHRoaXMudGVuY2VudEFwcDtcclxuICAgICAgICBjbG91ZGJhc2UgJiYgY2xvdWRiYXNlLnVzZUFkYXB0ZXJzKHdpbmRvdy5hZGFwdGVyKTtcclxuICAgICAgICB0aGlzLnRlbmNlbnRBcHAgPSBjbG91ZGJhc2UgPyBjbG91ZGJhc2UuaW5pdChjb25maWcudGVuY2VudCkgOiBudWxsO1xyXG4gICAgICAgIHRoaXMuaW5pdGlhbGl6ZWQgPSB0cnVlO1xyXG4gICAgICAgIHJldHVybiB0aGlzLnRlbmNlbnRBcHA7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICB9LFxyXG4gIH07XHJcbn0pKClcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Buy_Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f31eeHyetZCB7tSoBA1W/AE', 'Buy_Character');
// Script/Buy_Character.js

"use strict";

var Alert = {
  btnOK: null,
  btnCancel: null,
  content: null,
  btnOKCallBack: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    Tip: cc.Label
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  show: function show() {
    this.node.active = true;
  },
  hide: function hide() {
    this.node.active = false;
  },
  onClickCancle: function onClickCancle() {
    this.hide();
  },
  onClickConfirm: function onClickConfirm() {
    this.hide();
  },
  setTip: function setTip(string) {
    this.Tip.String = string;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxCdXlfQ2hhcmFjdGVyLmpzIl0sIm5hbWVzIjpbIkFsZXJ0IiwiYnRuT0siLCJidG5DYW5jZWwiLCJjb250ZW50IiwiYnRuT0tDYWxsQmFjayIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiVGlwIiwiTGFiZWwiLCJzdGFydCIsInNob3ciLCJub2RlIiwiYWN0aXZlIiwiaGlkZSIsIm9uQ2xpY2tDYW5jbGUiLCJvbkNsaWNrQ29uZmlybSIsInNldFRpcCIsInN0cmluZyIsIlN0cmluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQSxJQUFJQSxLQUFLLEdBQUc7QUFFUkMsRUFBQUEsS0FBSyxFQUFDLElBRkU7QUFHUkMsRUFBQUEsU0FBUyxFQUFDLElBSEY7QUFJUkMsRUFBQUEsT0FBTyxFQUFDLElBSkE7QUFLUkMsRUFBQUEsYUFBYSxFQUFDO0FBTE4sQ0FBWjtBQVFBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDVEMsSUFBQUEsR0FBRyxFQUFDSixFQUFFLENBQUNLO0FBREUsR0FIUDtBQU9MO0FBRUE7QUFFQUMsRUFBQUEsS0FYSyxtQkFXSSxDQUVSLENBYkk7QUFjTEMsRUFBQUEsSUFBSSxFQUFDLGdCQUFVO0FBQ1gsU0FBS0MsSUFBTCxDQUFVQyxNQUFWLEdBQW1CLElBQW5CO0FBQ0gsR0FoQkk7QUFpQkxDLEVBQUFBLElBQUksRUFBQyxnQkFBVTtBQUNYLFNBQUtGLElBQUwsQ0FBVUMsTUFBVixHQUFtQixLQUFuQjtBQUNILEdBbkJJO0FBb0JMRSxFQUFBQSxhQUFhLEVBQUMseUJBQVU7QUFDcEIsU0FBS0QsSUFBTDtBQUNILEdBdEJJO0FBdUJMRSxFQUFBQSxjQUFjLEVBQUMsMEJBQVU7QUFDckIsU0FBS0YsSUFBTDtBQUNILEdBekJJO0FBMEJMRyxFQUFBQSxNQUFNLEVBQUMsZ0JBQVNDLE1BQVQsRUFBZ0I7QUFDbkIsU0FBS1YsR0FBTCxDQUFTVyxNQUFULEdBQWtCRCxNQUFsQjtBQUNILEdBNUJJLENBNkJMOztBQTdCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxudmFyIEFsZXJ0ID0ge1xyXG4gICAgIFxyXG4gICAgYnRuT0s6bnVsbCxcclxuICAgIGJ0bkNhbmNlbDpudWxsLFxyXG4gICAgY29udGVudDpudWxsLFxyXG4gICAgYnRuT0tDYWxsQmFjazpudWxsLFxyXG59XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgVGlwOmNjLkxhYmVsLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sIFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG4gICAgc2hvdzpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSB0cnVlIFxyXG4gICAgfSxcclxuICAgIGhpZGU6ZnVuY3Rpb24oKXtcclxuICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gZmFsc2VcclxuICAgIH0sXHJcbiAgICBvbkNsaWNrQ2FuY2xlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5oaWRlKClcclxuICAgIH0sXHJcbiAgICBvbkNsaWNrQ29uZmlybTpmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuaGlkZSgpXHJcbiAgICB9LFxyXG4gICAgc2V0VGlwOmZ1bmN0aW9uKHN0cmluZyl7XHJcbiAgICAgICAgdGhpcy5UaXAuU3RyaW5nID0gc3RyaW5nXHJcbiAgICB9XHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/FriendsListData.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ad85aXD335LKas/yf03JNWP', 'FriendsListData');
// Script/FriendsListData.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    content: cc.Node,
    people: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    var _this = this;

    wx.onMessage(function (reData) {
      if (reData.type == "GET") {
        //清空好友列表
        var children = _this.content.children;

        for (var i = 0; i < length; i++) {
          children[i].destroy();
        } //获取好友列表


        wx.getFriendCloudStorage({
          keyList: reData.data,
          success: function success(res) {
            console.log("好友消息：", res.reData, reData.data);

            for (var _i = 0; _i < res.data.length; ++_i) {
              var _parseLove = JSON.parse(res.data[_i].KVDataList[0].value).wxgame.Love;

              _tempArr.pusg(_parseLove);
            } //排序


            function cmp(a, b) {
              return b - a;
            }

            ;

            _tempArr.sort(cmp); //匹配


            var index = 0;

            while (index < _tempArr.length) {
              //根据排序后的数组，生成好友列表
              for (var _i2 = 0; _i2 < res.data.length; _i2++) {
                var _parseLove2 = JSON.parse(res.data[_i2].VDataList[0].value).wxgame.Love;
                K;

                if (_tempArr[index] == _parseLove2) {
                  //生成预制体
                  _this.creatUserBlock(res.data[_i2]); //删除元素


                  res.data.splice(_i2, 1);
                  break;
                }
              }

              index++;
            }
          }
        });
      } else if (reData.type == "SET") {
        //设置微信后台数据存储
        wx.setUserCloudStorage({
          KVDataList: reData.data,
          success: function success(res) {
            console.log("存储成功");
            console.log(res.reData.data);
          },
          fail: function fail(res) {
            console.error(res);
          },
          complete: function complete(res) {}
        });
      }
    });
  },
  //创建好友列表的item条目：people
  creatUserBlock: function creatUserBlock() {
    var node = cc.instantiate(this.people);
    node.parent = this.content;
    node.x = 0; //设置昵称

    var userName = node.getChildByname('ID').getComponent(cc.Label);
    userName.string = user.nickName || user.nickname; //设置头像

    cc.loader.load({
      url: user.avatarUrl,
      type: 'png'
    }, function (err, texture) {
      if (err) {
        console.error(err);
      }

      var userIcon = node.getChildByname('mask').children[0].getComponent(cc.Sprite);
      userIcon.spriteFrame = new cc.spriteFrame(texture);
    }); //设置爱心数

    var love = node.getChildByname('Coin').getComponent(cc.Label);
    var _parseLove = JSON.parse(user.KVDataList[0].value).wxgame.love;
    love.string = _parseLove;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxGcmllbmRzTGlzdERhdGEuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJjb250ZW50IiwiTm9kZSIsInBlb3BsZSIsIlByZWZhYiIsInN0YXJ0Iiwid3giLCJvbk1lc3NhZ2UiLCJyZURhdGEiLCJ0eXBlIiwiY2hpbGRyZW4iLCJpIiwibGVuZ3RoIiwiZGVzdHJveSIsImdldEZyaWVuZENsb3VkU3RvcmFnZSIsImtleUxpc3QiLCJkYXRhIiwic3VjY2VzcyIsInJlcyIsImNvbnNvbGUiLCJsb2ciLCJfcGFyc2VMb3ZlIiwiSlNPTiIsInBhcnNlIiwiS1ZEYXRhTGlzdCIsInZhbHVlIiwid3hnYW1lIiwiTG92ZSIsIl90ZW1wQXJyIiwicHVzZyIsImNtcCIsImEiLCJiIiwic29ydCIsImluZGV4IiwiVkRhdGFMaXN0IiwiSyIsImNyZWF0VXNlckJsb2NrIiwic3BsaWNlIiwic2V0VXNlckNsb3VkU3RvcmFnZSIsImZhaWwiLCJlcnJvciIsImNvbXBsZXRlIiwibm9kZSIsImluc3RhbnRpYXRlIiwicGFyZW50IiwieCIsInVzZXJOYW1lIiwiZ2V0Q2hpbGRCeW5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsInVzZXIiLCJuaWNrTmFtZSIsIm5pY2tuYW1lIiwibG9hZGVyIiwibG9hZCIsInVybCIsImF2YXRhclVybCIsImVyciIsInRleHR1cmUiLCJ1c2VySWNvbiIsIlNwcml0ZSIsInNwcml0ZUZyYW1lIiwibG92ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLE9BQU8sRUFBQ0osRUFBRSxDQUFDSyxJQURIO0FBRVJDLElBQUFBLE1BQU0sRUFBQ04sRUFBRSxDQUFDTztBQUZGLEdBSFA7QUFRTDtBQUVBO0FBRUFDLEVBQUFBLEtBWkssbUJBWUk7QUFBQTs7QUFDTEMsSUFBQUEsRUFBRSxDQUFDQyxTQUFILENBQWEsVUFBQUMsTUFBTSxFQUFFO0FBQ2pCLFVBQUdBLE1BQU0sQ0FBQ0MsSUFBUCxJQUFlLEtBQWxCLEVBQXdCO0FBQ3BCO0FBQ0EsWUFBSUMsUUFBUSxHQUFHLEtBQUksQ0FBQ1QsT0FBTCxDQUFhUyxRQUE1Qjs7QUFDQSxhQUFJLElBQUlDLENBQUMsR0FBRyxDQUFaLEVBQWNBLENBQUMsR0FBQ0MsTUFBaEIsRUFBdUJELENBQUMsRUFBeEIsRUFBMkI7QUFDdkJELFVBQUFBLFFBQVEsQ0FBQ0MsQ0FBRCxDQUFSLENBQVlFLE9BQVo7QUFDSCxTQUxtQixDQU1wQjs7O0FBQ0FQLFFBQUFBLEVBQUUsQ0FBQ1EscUJBQUgsQ0FBeUI7QUFDckJDLFVBQUFBLE9BQU8sRUFBQ1AsTUFBTSxDQUFDUSxJQURNO0FBRXJCQyxVQUFBQSxPQUFPLEVBQUMsaUJBQUFDLEdBQUcsRUFBRTtBQUNUQyxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CRixHQUFHLENBQUNWLE1BQXhCLEVBQStCQSxNQUFNLENBQUNRLElBQXRDOztBQUNBLGlCQUFJLElBQUlMLEVBQUMsR0FBQyxDQUFWLEVBQVlBLEVBQUMsR0FBQ08sR0FBRyxDQUFDRixJQUFKLENBQVNKLE1BQXZCLEVBQThCLEVBQUVELEVBQWhDLEVBQWtDO0FBQzlCLGtCQUFJVSxVQUFVLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXTCxHQUFHLENBQUNGLElBQUosQ0FBU0wsRUFBVCxFQUFZYSxVQUFaLENBQXVCLENBQXZCLEVBQTBCQyxLQUFyQyxFQUE0Q0MsTUFBNUMsQ0FBbURDLElBQXBFOztBQUNBQyxjQUFBQSxRQUFRLENBQUNDLElBQVQsQ0FBY1IsVUFBZDtBQUNILGFBTFEsQ0FNVDs7O0FBQ0EscUJBQVNTLEdBQVQsQ0FBYUMsQ0FBYixFQUFlQyxDQUFmLEVBQWlCO0FBQUMscUJBQU9BLENBQUMsR0FBQ0QsQ0FBVDtBQUFZOztBQUFBOztBQUM5QkgsWUFBQUEsUUFBUSxDQUFDSyxJQUFULENBQWNILEdBQWQsRUFSUyxDQVNUOzs7QUFDQSxnQkFBSUksS0FBSyxHQUFHLENBQVo7O0FBQ0EsbUJBQU1BLEtBQUssR0FBQ04sUUFBUSxDQUFDaEIsTUFBckIsRUFBNEI7QUFDeEI7QUFDQSxtQkFBSSxJQUFJRCxHQUFDLEdBQUUsQ0FBWCxFQUFhQSxHQUFDLEdBQUNPLEdBQUcsQ0FBQ0YsSUFBSixDQUFTSixNQUF4QixFQUErQkQsR0FBQyxFQUFoQyxFQUFtQztBQUMvQixvQkFBSVUsV0FBVSxHQUFHQyxJQUFJLENBQUNDLEtBQUwsQ0FBV0wsR0FBRyxDQUFDRixJQUFKLENBQVNMLEdBQVQsRUFBWXdCLFNBQVosQ0FBc0IsQ0FBdEIsRUFBeUJWLEtBQXBDLEVBQTJDQyxNQUEzQyxDQUFrREMsSUFBbkU7QUFDaENTLGdCQUFBQSxDQUFDOztBQUMrQixvQkFBR1IsUUFBUSxDQUFDTSxLQUFELENBQVIsSUFBbUJiLFdBQXRCLEVBQWlDO0FBQzdCO0FBQ0Esa0JBQUEsS0FBSSxDQUFDZ0IsY0FBTCxDQUFvQm5CLEdBQUcsQ0FBQ0YsSUFBSixDQUFTTCxHQUFULENBQXBCLEVBRjZCLENBRzdCOzs7QUFDQU8sa0JBQUFBLEdBQUcsQ0FBQ0YsSUFBSixDQUFTc0IsTUFBVCxDQUFnQjNCLEdBQWhCLEVBQWtCLENBQWxCO0FBQ0E7QUFDSDtBQUNKOztBQUNEdUIsY0FBQUEsS0FBSztBQUNSO0FBQ0o7QUE1Qm9CLFNBQXpCO0FBOEJDLE9BckNMLE1Bc0NLLElBQUcxQixNQUFNLENBQUNDLElBQVAsSUFBZSxLQUFsQixFQUF3QjtBQUN6QjtBQUNBSCxRQUFBQSxFQUFFLENBQUNpQyxtQkFBSCxDQUF1QjtBQUNuQmYsVUFBQUEsVUFBVSxFQUFDaEIsTUFBTSxDQUFDUSxJQURDO0FBRW5CQyxVQUFBQSxPQUFPLEVBQUMsaUJBQVNDLEdBQVQsRUFBYTtBQUNqQkMsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBRCxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsR0FBRyxDQUFDVixNQUFKLENBQVdRLElBQXZCO0FBQ0gsV0FMa0I7QUFNbkJ3QixVQUFBQSxJQUFJLEVBQUMsY0FBU3RCLEdBQVQsRUFBYTtBQUNkQyxZQUFBQSxPQUFPLENBQUNzQixLQUFSLENBQWN2QixHQUFkO0FBQ0gsV0FSa0I7QUFTbkJ3QixVQUFBQSxRQVRtQixvQkFTVnhCLEdBVFUsRUFTTixDQUVaO0FBWGtCLFNBQXZCO0FBYUg7QUFDSixLQXZERDtBQXdESCxHQXJFSTtBQXNFTDtBQUNBbUIsRUFBQUEsY0FBYyxFQUFDLDBCQUFVO0FBQ3JCLFFBQUlNLElBQUksR0FBRzlDLEVBQUUsQ0FBQytDLFdBQUgsQ0FBZSxLQUFLekMsTUFBcEIsQ0FBWDtBQUNBd0MsSUFBQUEsSUFBSSxDQUFDRSxNQUFMLEdBQWMsS0FBSzVDLE9BQW5CO0FBQ0EwQyxJQUFBQSxJQUFJLENBQUNHLENBQUwsR0FBUyxDQUFULENBSHFCLENBS3JCOztBQUNBLFFBQUlDLFFBQVEsR0FBR0osSUFBSSxDQUFDSyxjQUFMLENBQW9CLElBQXBCLEVBQTBCQyxZQUExQixDQUF1Q3BELEVBQUUsQ0FBQ3FELEtBQTFDLENBQWY7QUFDQUgsSUFBQUEsUUFBUSxDQUFDSSxNQUFULEdBQWlCQyxJQUFJLENBQUNDLFFBQUwsSUFBaUJELElBQUksQ0FBQ0UsUUFBdkMsQ0FQcUIsQ0FRckI7O0FBQ0F6RCxJQUFBQSxFQUFFLENBQUMwRCxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNYQyxNQUFBQSxHQUFHLEVBQUNMLElBQUksQ0FBQ00sU0FERTtBQUVYakQsTUFBQUEsSUFBSSxFQUFDO0FBRk0sS0FBZixFQUdFLFVBQUNrRCxHQUFELEVBQUtDLE9BQUwsRUFBZTtBQUNiLFVBQUdELEdBQUgsRUFBTztBQUNIeEMsUUFBQUEsT0FBTyxDQUFDc0IsS0FBUixDQUFja0IsR0FBZDtBQUNIOztBQUNELFVBQUlFLFFBQVEsR0FBR2xCLElBQUksQ0FBQ0ssY0FBTCxDQUFvQixNQUFwQixFQUE0QnRDLFFBQTVCLENBQXFDLENBQXJDLEVBQXdDdUMsWUFBeEMsQ0FBcURwRCxFQUFFLENBQUNpRSxNQUF4RCxDQUFmO0FBQ0FELE1BQUFBLFFBQVEsQ0FBQ0UsV0FBVCxHQUF1QixJQUFJbEUsRUFBRSxDQUFDa0UsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBdkI7QUFDSCxLQVRELEVBVHFCLENBb0JyQjs7QUFDQSxRQUFJSSxJQUFJLEdBQUdyQixJQUFJLENBQUNLLGNBQUwsQ0FBb0IsTUFBcEIsRUFBNEJDLFlBQTVCLENBQXlDcEQsRUFBRSxDQUFDcUQsS0FBNUMsQ0FBWDtBQUNBLFFBQUk3QixVQUFVLEdBQUdDLElBQUksQ0FBQ0MsS0FBTCxDQUFXNkIsSUFBSSxDQUFDNUIsVUFBTCxDQUFnQixDQUFoQixFQUFtQkMsS0FBOUIsRUFBcUNDLE1BQXJDLENBQTRDc0MsSUFBN0Q7QUFDQUEsSUFBQUEsSUFBSSxDQUFDYixNQUFMLEdBQWM5QixVQUFkO0FBQ0g7QUEvRkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGNvbnRlbnQ6Y2MuTm9kZSxcclxuICAgICAgICBwZW9wbGU6Y2MuUHJlZmFiLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIHd4Lm9uTWVzc2FnZShyZURhdGE9PntcclxuICAgICAgICAgICAgaWYocmVEYXRhLnR5cGUgPT0gXCJHRVRcIil7XHJcbiAgICAgICAgICAgICAgICAvL+a4heepuuWlveWPi+WIl+ihqFxyXG4gICAgICAgICAgICAgICAgbGV0IGNoaWxkcmVuID0gdGhpcy5jb250ZW50LmNoaWxkcmVuO1xyXG4gICAgICAgICAgICAgICAgZm9yKGxldCBpID0gMDtpPGxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICAgICAgICAgIGNoaWxkcmVuW2ldLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8v6I635Y+W5aW95Y+L5YiX6KGoXHJcbiAgICAgICAgICAgICAgICB3eC5nZXRGcmllbmRDbG91ZFN0b3JhZ2Uoe1xyXG4gICAgICAgICAgICAgICAgICAgIGtleUxpc3Q6cmVEYXRhLmRhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzczpyZXM9PntcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLlpb3lj4vmtojmga/vvJpcIixyZXMucmVEYXRhLHJlRGF0YS5kYXRhKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yKGxldCBpPTA7aTxyZXMuZGF0YS5sZW5ndGg7KytpKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBfcGFyc2VMb3ZlID0gSlNPTi5wYXJzZShyZXMuZGF0YVtpXS5LVkRhdGFMaXN0WzBdLnZhbHVlKS53eGdhbWUuTG92ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90ZW1wQXJyLnB1c2coX3BhcnNlTG92ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLy/mjpLluo9cclxuICAgICAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gY21wKGEsYil7cmV0dXJuIGItYTt9O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBfdGVtcEFyci5zb3J0KGNtcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v5Yy56YWNXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpbmRleCA9IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaWxlKGluZGV4PF90ZW1wQXJyLmxlbmd0aCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+agueaNruaOkuW6j+WQjueahOaVsOe7hO+8jOeUn+aIkOWlveWPi+WIl+ihqFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yKGxldCBpID0wO2k8cmVzLmRhdGEubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IF9wYXJzZUxvdmUgPSBKU09OLnBhcnNlKHJlcy5kYXRhW2ldLlZEYXRhTGlzdFswXS52YWx1ZSkud3hnYW1lLkxvdmU7XHJcbktcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZihfdGVtcEFycltpbmRleF0gPT0gX3BhcnNlTG92ZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8v55Sf5oiQ6aKE5Yi25L2TXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3JlYXRVc2VyQmxvY2socmVzLmRhdGFbaV0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvL+WIoOmZpOWFg+e0oFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXMuZGF0YS5zcGxpY2UoaSwxKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5kZXgrKztcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2UgaWYocmVEYXRhLnR5cGUgPT0gXCJTRVRcIil7XHJcbiAgICAgICAgICAgICAgICAvL+iuvue9ruW+ruS/oeWQjuWPsOaVsOaNruWtmOWCqFxyXG4gICAgICAgICAgICAgICAgd3guc2V0VXNlckNsb3VkU3RvcmFnZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgS1ZEYXRhTGlzdDpyZURhdGEuZGF0YSxcclxuICAgICAgICAgICAgICAgICAgICBzdWNjZXNzOmZ1bmN0aW9uKHJlcyl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5a2Y5YKo5oiQ5YqfXCIpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhyZXMucmVEYXRhLmRhdGEpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgZmFpbDpmdW5jdGlvbihyZXMpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKHJlcyk7XHJcbiAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICBjb21wbGV0ZShyZXMpe1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICB9LFxyXG4gICAgLy/liJvlu7rlpb3lj4vliJfooajnmoRpdGVt5p2h55uu77yacGVvcGxlXHJcbiAgICBjcmVhdFVzZXJCbG9jazpmdW5jdGlvbigpe1xyXG4gICAgICAgIGxldCBub2RlID0gY2MuaW5zdGFudGlhdGUodGhpcy5wZW9wbGUpO1xyXG4gICAgICAgIG5vZGUucGFyZW50ID0gdGhpcy5jb250ZW50O1xyXG4gICAgICAgIG5vZGUueCA9IDA7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy/orr7nva7mmLXnp7BcclxuICAgICAgICBsZXQgdXNlck5hbWUgPSBub2RlLmdldENoaWxkQnluYW1lKCdJRCcpLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcbiAgICAgICAgdXNlck5hbWUuc3RyaW5nID11c2VyLm5pY2tOYW1lIHx8IHVzZXIubmlja25hbWU7XHJcbiAgICAgICAgLy/orr7nva7lpLTlg49cclxuICAgICAgICBjYy5sb2FkZXIubG9hZCh7XHJcbiAgICAgICAgICAgIHVybDp1c2VyLmF2YXRhclVybCxcclxuICAgICAgICAgICAgdHlwZToncG5nJ1xyXG4gICAgICAgIH0sKGVycix0ZXh0dXJlKT0+e1xyXG4gICAgICAgICAgICBpZihlcnIpe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCB1c2VySWNvbiA9IG5vZGUuZ2V0Q2hpbGRCeW5hbWUoJ21hc2snKS5jaGlsZHJlblswXS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcclxuICAgICAgICAgICAgdXNlckljb24uc3ByaXRlRnJhbWUgPSBuZXcgY2Muc3ByaXRlRnJhbWUodGV4dHVyZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICAvL+iuvue9rueIseW/g+aVsFxyXG4gICAgICAgIGxldCBsb3ZlID0gbm9kZS5nZXRDaGlsZEJ5bmFtZSgnQ29pbicpLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcbiAgICAgICAgbGV0IF9wYXJzZUxvdmUgPSBKU09OLnBhcnNlKHVzZXIuS1ZEYXRhTGlzdFswXS52YWx1ZSkud3hnYW1lLmxvdmU7XHJcbiAgICAgICAgbG92ZS5zdHJpbmcgPSBfcGFyc2VMb3ZlO1xyXG4gICAgfVxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/FriendsView.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '06b61gM/MVNvLdkhaMA7Q0s', 'FriendsView');
// Script/FriendsView.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    WXSubContextView: {
      "default": null,
      type: cc.Node,
      serializable: true
    }
  },
  start: function start() {
    this.subContextView = this.WXSubContextView.getComponent(cc.WXSubContextView);
  },
  showFriends: function showFriends() {
    console.log("显示好友列表"); //获取时间戳

    var updateTime = new Date().valueOf(); //获取好友列表上对应的信息

    var getArr = new Array();
    getArr.push("love");
    var openDataContext = wx.getOpenDataContext();
    openDataContext.postMessage({
      type: "GET",
      data: getArr,
      time: updateTime
    });
    this.subContextView.enabled = true;
    this.WXSubContextView.active = true;
    this.subContextView.update();
  },
  sendMsgToFriendsListdata: function sendMsgToFriendsListdata() {
    console.log("sendMsg"); //时间戳

    var updateTime = new Date().valueOf();
    var value = JSON.stringfy({
      "wxgame": {
        "love": Math.floor(10000 * Math.random()),
        "update_time": updateTime
      }
    });
    var arr = new Array();
    arr.push({
      key: "love",
      value: _value
    });
    var openDataContext = wx.getOpenDataContext();
    openDataContext.postMessage({
      type: "SET",
      data: arr,
      timer: updateTime
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxGcmllbmRzVmlldy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIldYU3ViQ29udGV4dFZpZXciLCJ0eXBlIiwiTm9kZSIsInNlcmlhbGl6YWJsZSIsInN0YXJ0Iiwic3ViQ29udGV4dFZpZXciLCJnZXRDb21wb25lbnQiLCJzaG93RnJpZW5kcyIsImNvbnNvbGUiLCJsb2ciLCJ1cGRhdGVUaW1lIiwiRGF0ZSIsInZhbHVlT2YiLCJnZXRBcnIiLCJBcnJheSIsInB1c2giLCJvcGVuRGF0YUNvbnRleHQiLCJ3eCIsImdldE9wZW5EYXRhQ29udGV4dCIsInBvc3RNZXNzYWdlIiwiZGF0YSIsInRpbWUiLCJlbmFibGVkIiwiYWN0aXZlIiwidXBkYXRlIiwic2VuZE1zZ1RvRnJpZW5kc0xpc3RkYXRhIiwidmFsdWUiLCJKU09OIiwic3RyaW5nZnkiLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJhcnIiLCJrZXkiLCJfdmFsdWUiLCJ0aW1lciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLGdCQUFnQixFQUFDO0FBQ2IsaUJBQVEsSUFESztBQUViQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sSUFGSztBQUdiQyxNQUFBQSxZQUFZLEVBQUM7QUFIQTtBQURULEdBSFA7QUFZTEMsRUFBQUEsS0FaSyxtQkFZSTtBQUNMLFNBQUtDLGNBQUwsR0FBc0IsS0FBS0wsZ0JBQUwsQ0FBc0JNLFlBQXRCLENBQW1DVixFQUFFLENBQUNJLGdCQUF0QyxDQUF0QjtBQUNILEdBZEk7QUFlTE8sRUFBQUEsV0FBVyxFQUFDLHVCQUFVO0FBQ2xCQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBRGtCLENBRWxCOztBQUNBLFFBQUlDLFVBQVUsR0FBSSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFqQixDQUhrQixDQUlsQjs7QUFDQSxRQUFJQyxNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiO0FBQ0FELElBQUFBLE1BQU0sQ0FBQ0UsSUFBUCxDQUFZLE1BQVo7QUFFQSxRQUFJQyxlQUFlLEdBQUdDLEVBQUUsQ0FBQ0Msa0JBQUgsRUFBdEI7QUFDQUYsSUFBQUEsZUFBZSxDQUFDRyxXQUFoQixDQUE0QjtBQUN4QmxCLE1BQUFBLElBQUksRUFBQyxLQURtQjtBQUV4Qm1CLE1BQUFBLElBQUksRUFBQ1AsTUFGbUI7QUFHeEJRLE1BQUFBLElBQUksRUFBQ1g7QUFIbUIsS0FBNUI7QUFLRCxTQUFLTCxjQUFMLENBQW9CaUIsT0FBcEIsR0FBOEIsSUFBOUI7QUFDQSxTQUFLdEIsZ0JBQUwsQ0FBc0J1QixNQUF0QixHQUErQixJQUEvQjtBQUNBLFNBQU1sQixjQUFOLENBQXFCbUIsTUFBckI7QUFDRixHQWhDSTtBQWlDTEMsRUFBQUEsd0JBQXdCLEVBQUMsb0NBQVU7QUFDL0JqQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaLEVBRCtCLENBRS9COztBQUNBLFFBQUlDLFVBQVUsR0FBSSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUFqQjtBQUNBLFFBQUljLEtBQUssR0FBSUMsSUFBSSxDQUFDQyxRQUFMLENBQWM7QUFDdkIsZ0JBQVM7QUFDTCxnQkFBT0MsSUFBSSxDQUFDQyxLQUFMLENBQVksUUFBUUQsSUFBSSxDQUFDRSxNQUFMLEVBQXBCLENBREY7QUFFTCx1QkFBY3JCO0FBRlQ7QUFEYyxLQUFkLENBQWI7QUFNQSxRQUFJc0IsR0FBRyxHQUFFLElBQUlsQixLQUFKLEVBQVQ7QUFDQWtCLElBQUFBLEdBQUcsQ0FBQ2pCLElBQUosQ0FBUztBQUFDa0IsTUFBQUEsR0FBRyxFQUFDLE1BQUw7QUFBWVAsTUFBQUEsS0FBSyxFQUFDUTtBQUFsQixLQUFUO0FBQ0EsUUFBSWxCLGVBQWUsR0FBR0MsRUFBRSxDQUFDQyxrQkFBSCxFQUF0QjtBQUNBRixJQUFBQSxlQUFlLENBQUNHLFdBQWhCLENBQTRCO0FBQ3hCbEIsTUFBQUEsSUFBSSxFQUFDLEtBRG1CO0FBRXhCbUIsTUFBQUEsSUFBSSxFQUFDWSxHQUZtQjtBQUd4QkcsTUFBQUEsS0FBSyxFQUFDekI7QUFIa0IsS0FBNUI7QUFLSDtBQW5ESSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIFdYU3ViQ29udGV4dFZpZXc6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuICAgICAgICAgICAgc2VyaWFsaXphYmxlOnRydWVcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdGhpcy5zdWJDb250ZXh0VmlldyA9IHRoaXMuV1hTdWJDb250ZXh0Vmlldy5nZXRDb21wb25lbnQoY2MuV1hTdWJDb250ZXh0VmlldylcclxuICAgIH0sXHJcbiAgICBzaG93RnJpZW5kczpmdW5jdGlvbigpe1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5pi+56S65aW95Y+L5YiX6KGoXCIpO1xyXG4gICAgICAgIC8v6I635Y+W5pe26Ze05oizXHJcbiAgICAgICAgbGV0IHVwZGF0ZVRpbWUgPSAobmV3IERhdGUoKSkudmFsdWVPZigpO1xyXG4gICAgICAgIC8v6I635Y+W5aW95Y+L5YiX6KGo5LiK5a+55bqU55qE5L+h5oGvXHJcbiAgICAgICAgbGV0IGdldEFyciA9IG5ldyBBcnJheSgpO1xyXG4gICAgICAgIGdldEFyci5wdXNoKFwibG92ZVwiKTtcclxuICAgICAgICBcclxuICAgICAgICBsZXQgb3BlbkRhdGFDb250ZXh0ID0gd3guZ2V0T3BlbkRhdGFDb250ZXh0KCk7XHJcbiAgICAgICAgb3BlbkRhdGFDb250ZXh0LnBvc3RNZXNzYWdlKHtcclxuICAgICAgICAgICAgdHlwZTpcIkdFVFwiLFxyXG4gICAgICAgICAgICBkYXRhOmdldEFycixcclxuICAgICAgICAgICAgdGltZTp1cGRhdGVUaW1lICBcclxuICAgICAgICB9KVxyXG4gICAgICAgdGhpcy5zdWJDb250ZXh0Vmlldy5lbmFibGVkID0gdHJ1ZSA7XHJcbiAgICAgICB0aGlzLldYU3ViQ29udGV4dFZpZXcuYWN0aXZlID0gdHJ1ZSA7XHJcbiAgICAgICB0aGlzIC5zdWJDb250ZXh0Vmlldy51cGRhdGUoKTtcclxuICAgIH0sXHJcbiAgICBzZW5kTXNnVG9GcmllbmRzTGlzdGRhdGE6ZnVuY3Rpb24oKXtcclxuICAgICAgICBjb25zb2xlLmxvZyhcInNlbmRNc2dcIik7XHJcbiAgICAgICAgLy/ml7bpl7TmiLNcclxuICAgICAgICBsZXQgdXBkYXRlVGltZSA9IChuZXcgRGF0ZSgpKS52YWx1ZU9mKCk7XHJcbiAgICAgICAgbGV0IHZhbHVlICA9IEpTT04uc3RyaW5nZnkoe1xyXG4gICAgICAgICAgICBcInd4Z2FtZVwiOntcclxuICAgICAgICAgICAgICAgIFwibG92ZVwiOk1hdGguZmxvb3IgKDEwMDAwICogTWF0aC5yYW5kb20oKSksXHJcbiAgICAgICAgICAgICAgICBcInVwZGF0ZV90aW1lXCI6dXBkYXRlVGltZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgbGV0IGFyciA9bmV3IEFycmF5KCk7XHJcbiAgICAgICAgYXJyLnB1c2goe2tleTpcImxvdmVcIix2YWx1ZTpfdmFsdWV9KTtcclxuICAgICAgICBsZXQgb3BlbkRhdGFDb250ZXh0ID0gd3guZ2V0T3BlbkRhdGFDb250ZXh0KCk7XHJcbiAgICAgICAgb3BlbkRhdGFDb250ZXh0LnBvc3RNZXNzYWdlKHtcclxuICAgICAgICAgICAgdHlwZTpcIlNFVFwiLFxyXG4gICAgICAgICAgICBkYXRhOmFycixcclxuICAgICAgICAgICAgdGltZXI6dXBkYXRlVGltZVxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Cloud_Image1.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b2407c+gnxIrKO0x/Qzt/Qc', 'Cloud_Image1');
// Script/Cloud_Image1.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  // onLoad () {},
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDbG91ZF9JbWFnZTEuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJJYW1nZSIsIkJHU3ByaXRlIiwidHlwZSIsIlNwcml0ZSIsInNlcmlhbHphYmxlIiwib25Mb2FkIiwic2VsZiIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNUQyxJQUFBQSxLQUFLLEVBQUUsRUFERTtBQUVaQyxJQUFBQSxRQUFRLEVBQUM7QUFDVCxpQkFBUSxJQURDO0FBRVRDLE1BQUFBLElBQUksRUFBQ04sRUFBRSxDQUFDTyxNQUZDO0FBR1RDLE1BQUFBLFdBQVcsRUFBQztBQUhIO0FBRkcsR0FIUDtBQWFMO0FBRUFDLEVBQUFBLE1BQU0sRUFBQyxrQkFBVztBQUNwQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBLFFBQUlDLElBQUksR0FBQ0QsSUFBSSxDQUFDTixLQUFkO0FBQ0FKLElBQUFBLEVBQUUsQ0FBQ1ksTUFBSCxDQUFVQyxJQUFWLENBQWU7QUFDZEMsTUFBQUEsR0FBRyxFQUFDSCxJQURVO0FBRWRMLE1BQUFBLElBQUksRUFBQztBQUZTLEtBQWYsRUFHRSxVQUFTUyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJbEIsRUFBRSxDQUFDbUIsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTkssUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQk4sR0FBbkI7QUFDQTs7QUFDREwsTUFBQUEsSUFBSSxDQUFDTCxRQUFMLENBQWNpQixZQUFkLENBQTJCdEIsRUFBRSxDQUFDTyxNQUE5QixFQUFzQ2dCLFdBQXRDLEdBQWtETCxLQUFsRDtBQUVBLEtBVkQ7QUFXRCxHQTdCUTtBQStCTE0sRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWEsQ0FBRTtBQS9CbEIsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXG4vLyBMZWFybiBBdHRyaWJ1dGU6XG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICBJYW1nZTogXCJcIixcclxuXHQgICBCR1Nwcml0ZTp7XG5cdFx0ICBkZWZhdWx0Om51bGwsXG5cdFx0ICB0eXBlOmNjLlNwcml0ZSxcblx0XHQgIHNlcmlhbHphYmxlOnRydWUsXG5cdCAgIH0sXG4gICAgfSxcblxuXG4gICAgLy8gb25Mb2FkICgpIHt9LFxuXG4gICAgb25Mb2FkOmZ1bmN0aW9uKCkge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRsZXQgX3VybD1zZWxmLklhbWdlO1xuXHRcdGNjLmxvYWRlci5sb2FkKHtcblx0XHRcdHVybDpfdXJsLFxuXHRcdFx0dHlwZTonanBnJ1xuXHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XG5cdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xuXHRcdFx0aWYoZXJyKXtcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xuXHRcdFx0fVxuXHRcdFx0c2VsZi5CR1Nwcml0ZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcblx0XHRcdFxuXHRcdH0pXG59LFxuXG4gICAgdXBkYXRlOiBmdW5jdGlvbihkdCkge30sXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/People.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '35cf1epWixAa5295ytVUj/q', 'People');
// Script/People.js

"use strict";

var Alert = {
  btnOK: null,
  btnCancel: null,
  content: null,
  btnOKCallBack: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    alert: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  onClickAlert: function onClickAlert() {
    var node = cc.instantiate(this.alert);
    this.node.addChild(node);
    node = node.getComponent('ReportAlert');
    node.setTip('确定举报该好友吗？');
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxQZW9wbGUuanMiXSwibmFtZXMiOlsiQWxlcnQiLCJidG5PSyIsImJ0bkNhbmNlbCIsImNvbnRlbnQiLCJidG5PS0NhbGxCYWNrIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJhbGVydCIsIlByZWZhYiIsInN0YXJ0Iiwib25DbGlja0FsZXJ0Iiwibm9kZSIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJnZXRDb21wb25lbnQiLCJzZXRUaXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0EsSUFBSUEsS0FBSyxHQUFHO0FBRVJDLEVBQUFBLEtBQUssRUFBQyxJQUZFO0FBR1JDLEVBQUFBLFNBQVMsRUFBQyxJQUhGO0FBSVJDLEVBQUFBLE9BQU8sRUFBQyxJQUpBO0FBS1JDLEVBQUFBLGFBQWEsRUFBQztBQUxOLENBQVo7QUFRQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEtBQUssRUFBQ0osRUFBRSxDQUFDSztBQURELEdBSFA7QUFPTDtBQUVBO0FBRUFDLEVBQUFBLEtBWEssbUJBV0ksQ0FFUixDQWJJO0FBY0pDLEVBQUFBLFlBQVksRUFBQyx3QkFBVTtBQUNuQixRQUFJQyxJQUFJLEdBQUdSLEVBQUUsQ0FBQ1MsV0FBSCxDQUFlLEtBQUtMLEtBQXBCLENBQVg7QUFDQSxTQUFLSSxJQUFMLENBQVVFLFFBQVYsQ0FBbUJGLElBQW5CO0FBQ0FBLElBQUFBLElBQUksR0FBR0EsSUFBSSxDQUFDRyxZQUFMLENBQWtCLGFBQWxCLENBQVA7QUFDQUgsSUFBQUEsSUFBSSxDQUFDSSxNQUFMLENBQVksV0FBWjtBQUNILEdBbkJHLENBb0JMOztBQXBCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcclxudmFyIEFsZXJ0ID0ge1xyXG4gICAgIFxyXG4gICAgYnRuT0s6bnVsbCxcclxuICAgIGJ0bkNhbmNlbDpudWxsLFxyXG4gICAgY29udGVudDpudWxsLFxyXG4gICAgYnRuT0tDYWxsQmFjazpudWxsLFxyXG59XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIGFsZXJ0OmNjLlByZWZhYixcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LCBcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuICAgICBvbkNsaWNrQWxlcnQ6ZnVuY3Rpb24oKXtcclxuICAgICAgICAgdmFyIG5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmFsZXJ0KTtcclxuICAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKG5vZGUpO1xyXG4gICAgICAgICBub2RlID0gbm9kZS5nZXRDb21wb25lbnQoJ1JlcG9ydEFsZXJ0Jyk7XHJcbiAgICAgICAgIG5vZGUuc2V0VGlwKCfnoa7lrprkuL7miqXor6Xlpb3lj4vlkJfvvJ8nKTtcclxuICAgICB9XHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Handle_Reported_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e02daNVnhVHjIYR/RnbYwcg', 'Handle_Reported_User');
// resources/script/Account_Management/Handle_Reported_User.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Openid_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    WeChat.Handle_Reported_User(this.Openid_Show.getComponent(cc.Label).string);
    this.Account_Label.destroy();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcSGFuZGxlX1JlcG9ydGVkX1VzZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJPcGVuaWRfU2hvdyIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwiQWNjb3VudF9MYWJlbCIsIk5vZGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIldlQ2hhdCIsIkhhbmRsZV9SZXBvcnRlZF9Vc2VyIiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiZGVzdHJveSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFdBQVcsRUFBQztBQUNULGlCQUFRLElBREM7QUFFVEMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLEtBRkM7QUFHVEMsTUFBQUEsV0FBVyxFQUFDO0FBSEgsS0FESjtBQU1mQyxJQUFBQSxhQUFhLEVBQUM7QUFDVixpQkFBUSxJQURFO0FBRVZILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxJQUZFO0FBR1ZGLE1BQUFBLFdBQVcsRUFBQztBQUhGO0FBTkMsR0FIUDtBQWlCTDtBQUVBO0FBRUFHLEVBQUFBLEtBckJLLG1CQXFCSSxDQUVSLENBdkJJO0FBeUJMQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDdkJDLElBQUFBLE1BQU0sQ0FBQ0Msb0JBQVAsQ0FBNEIsS0FBS1QsV0FBTCxDQUFpQlUsWUFBakIsQ0FBOEJkLEVBQUUsQ0FBQ00sS0FBakMsRUFBd0NTLE1BQXBFO0FBQ0gsU0FBS1AsYUFBTCxDQUFtQlEsT0FBbkI7QUFDRDtBQTVCTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgT3BlbmlkX1Nob3c6e1xyXG4gICAgICAgIFx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcbiAgICAgICAgXHRcdFx0dHlwZTpjYy5MYWJlbCxcclxuICAgICAgICBcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sXHJcblx0QWNjb3VudF9MYWJlbDp7XHJcblx0XHRcdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHRcdFx0dHlwZTpjYy5Ob2RlLFxyXG5cdFx0XHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIG9uX2J0bl9jbGljazogZnVuY3Rpb24oKSB7XHJcbiAgICBcdFx0V2VDaGF0LkhhbmRsZV9SZXBvcnRlZF9Vc2VyKHRoaXMuT3BlbmlkX1Nob3cuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcpO1xyXG5cdFx0XHR0aGlzLkFjY291bnRfTGFiZWwuZGVzdHJveSgpO1xyXG5cdH1cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Global_WeChat.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3ae40Cuxy1MB6W58a3Vhe8+', 'Global_WeChat');
// resources/script/Global_Function/Global_WeChat.js

"use strict";

//全局变量
var Rank_Local_Varible = require('Rank_Local_Variable');

var Shop_Character_Local_Variable = require('Shop_Character_Local_Varible');

var User_Have_Character_Local_Varible = require('User_Have_Character_Local_Varible');

var Email_Local_Variable = require('Email_Local_Variable');

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

window.WeChat = {}; //微信登录注册调用

WeChat.onRegisterUser = function (_userinfo) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  console.log(_userinfo);
  wx.cloud.callFunction({
    //调用云函数
    name: "login",
    //传入的参数，玩家信息
    data: {
      userinfo: _userinfo
    },
    success: function success(res) {
      console.log("登录注册成功回调", res);
      Global_Variable.Is_Closured = res.result.Is_Closured;
      Global_Variable.Unsealing_Time = res.result.data[0].Unsealing_Time;
      Global_Variable.openid = res.result.data[0].openid;
      console.log("!res.result.Is_Closured的值为", !res.result.Is_Closured);
      console.log("Global_Variable.Unsealing_Time", Global_Variable.Unsealing_Time);

      if (!res.result.Is_Closured) {
        cc.director.loadScene("Game_Start");
      } else {
        cc.director.loadScene("Closure");
      }
    },
    fail: function fail() {
      Global_Variable.Is_Closured = true;
      console.log("程序出错", console.error);
    }
  });
}; //加载资源


WeChat.Loading_Resources = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    name: "Loading_Resources",
    success: function success(res) {
      //将值赋给全局变量
      console.log("获取成功回调", res);
      Global_Variable.openid = res.result.openid;
      Global_Variable.Gold = res.result.Gold;
      Global_Variable.Diamond = res.result.Diamond;
      Global_Variable.Compassion = res.result.Compassion;
      Global_Variable.User_Head_Image = res.result.User_Head_Image;
      Global_Variable.Best_Score = res.result.Best_Score;
      Global_Variable.User_Name = res.result.User_Name;
      Global_Variable.Current_Character_Id = res.result.Current_Character_Id;
      Global_Variable.Is_Admin = res.result.Is_Admin;
      WeChat.Loading_Bird_Image(Global_Variable.Current_Character_Id);
    },
    fail: function fail() {
      console.log("获取基础物资出错", console.error); //失败了重新赋值

      WeChat.Loading_Resources();
    }
  });
}; //游戏结算


WeChat.Game_Settlement = function (_Add_Gold, _Score) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    name: "Game_Settlement",
    //传入参数，包括增加的金币数量，分数
    data: {
      Add_Gold: _Add_Gold,
      Score: _Score
    },
    success: function success(res) {
      console.log("获取成功回调", res);
      Global_Variable.Gold = res.result.Gold;
      Global_Variable.Diamond = res.result.Diamond;
      Global_Variable.Compassion = res.result.Compassion;
    },
    fail: function fail() {
      console.log("获取基础物资出错", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //加载世界排名


WeChat.Loading_World_Rank = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数		
    name: "Loading_World_Rank",
    success: function success(res) {
      console.log("下载世界排名成功回调", res);
      Rank_Local_Varible.Word_Rank_User = res.result.User_Information.data;
      console.log("Rank_Local_Varible为", Rank_Local_Varible.Word_Rank_User[0].openid);
    },
    fail: function fail() {
      console.log("下载世界排名出错", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //上传举报、申诉列表


WeChat.Uploading_Reported_Information = function (_Openid, _Report_Content) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    name: "Uploading_Reported_Information",
    data: {
      Reported_Openid: _Openid,
      Report_Content: _Report_Content
    },
    success: function success(res) {
      console.log("举报成功回调", res);
    },
    fail: function fail() {
      console.log("举报出错回调", console.error);
    }
  });
};

WeChat.Loading_Character = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Character",
    success: function success(res) {
      console.log("获取角色信息成功", res);
      Shop_Character_Local_Variable.Shop_Character_User = res.result.Character_Information.data;
      User_Have_Character_Local_Varible.User_Have_Character = res.result.User_Have_Character_Information.data;
    },
    fail: function fail() {
      console.log("获取角色信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
};

WeChat.Loading_Shop_Character = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Shop",
    success: function success(res) {
      console.log("获取商店信息成功", res);
      Shop_Character_Local_Variable.Shop_Character_User = res.result.Character_Information.data;
      User_Have_Character_Local_Varible.User_Have_Character = res.result.User_Have_Character_Information.data;
    },
    fail: function fail() {
      console.log("获取商店信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //商店购买跟新


WeChat.Buy_Character_Update = function (_Update_Gold, _Update_Character) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Shop_Buy",
    data: {
      Update_Gold: _Update_Gold,
      Update_Character: _Update_Character
    },
    success: function success(res) {
      console.log("商店获取成功回调", res);
    },
    fail: function fail() {
      console.log("商店获回调出错", console.error);
      WeChat.Loading_Resources();
    }
  });
};

WeChat.Loading_Bird_Image = function (Character_Id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_Bird_Image",
    data: {
      Character_Id: Character_Id
    },
    success: function success(res) {
      console.log("角色图像获取成功回调", res);
      cc.loader.load({
        url: res.result.Character_Image1,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image1 = frame;
      });
      cc.loader.load({
        url: res.result.Character_Image2,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image2 = frame;
      });
      cc.loader.load({
        url: res.result.Character_Image3,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image3 = frame;
      });
      cc.loader.load({
        url: res.result.Character_Image4,
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        Global_Variable.Character_Image4 = frame;
      });
    },
    fail: function fail() {
      console.log("角色图像回调出错", console.error);
    }
  });
};

WeChat.Updating_Current_Character_id = function (Character_Id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Updating_Current_Character_id",
    data: {
      Character_Id: Character_Id
    },
    success: function success(res) {
      console.log("修改当前角色成功回调", res);
      WeChat.Loading_Bird_Image(Character_Id);
    },
    fail: function fail() {
      console.log("修改当前角色失败", console.error);
      WeChat.Loading_Bird_Image(Character_Id);
    }
  });
}; //加载个人邮箱


WeChat.Loading_Email = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_Email",
    success: function success(res) {
      Email_Local_Variable.Email = res.result.User_Email_Information.data;
      console.log("获取邮件信息成功", res);
      console.log("邮件信息表", Email_Local_Variable.Email);
    },
    fail: function fail() {
      console.log("获取邮件信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //加载全部邮箱


WeChat.Loading_All_Email = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_All_Email",
    success: function success(res) {
      Email_Local_Variable.Email = res.result.User_Email_Information.data;
      console.log("获取邮件信息成功", res);
      console.log("邮件信息表", Email_Local_Variable.Email);
    },
    fail: function fail() {
      console.log("获取邮件信息失败", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //已读全部邮件


WeChat.Read_All = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Read_All",
    success: function success(res) {
      console.log("已读邮件成功回调", res);
    },
    fail: function fail() {
      console.log("已读邮件失败", console.error);
    }
  });
}; //删除已读邮件


WeChat.Delete_Read = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Delete_Read",
    success: function success(res) {
      console.log("删除已读邮件成功回调", res);
    },
    fail: function fail() {
      console.log("删除已读邮件失败", console.error);
    }
  });
}; //已读单个邮件


WeChat.Read = function (_id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Read",
    data: {
      _id: _id
    },
    success: function success(res) {
      console.log("已读邮件成功回调", res);
    },
    fail: function fail() {
      console.log("已读邮件失败", console.error);
    }
  });
}; //接受奖励


WeChat.Accept = function (_id, _Add_Gold, _Add_Diamond, _Add_Compassion) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Accept",
    data: {
      _id: _id,
      Add_Gold: _Add_Gold,
      Add_Diamond: _Add_Diamond,
      Add_Compassion: _Add_Compassion
    },
    success: function success(res) {
      console.log("接受奖励成功回调", res);
      Global_Variable.Gold = res.result.Gold;
      Global_Variable.Diamond = res.result.Diamond;
      Global_Variable.Compassion = res.result.Compassion;
    },
    fail: function fail() {
      console.log("获取基础物资出错", console.error);
      WeChat.Loading_Resources();
    }
  });
}; //发放奖励


WeChat.Awards_Email = function (Time, Title, Content, Gold, Diamond, Compassion, Enclosure) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Awards",
    data: {
      Time: Time,
      Email_Title: Title,
      Email_Content: Content,
      Email_Gold: Gold,
      Email_Diamond: Diamond,
      Email_Compassion: Compassion,
      Enclosure: Enclosure
    },
    success: function success(res) {
      console.log("发放奖励成功回调", res);
    },
    fail: function fail() {
      console.log("发放奖励失败", console.error);
    }
  });
};

WeChat.Loading_All_User = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_All_User",
    success: function success(res) {
      console.log("下载全部账号信息成功回调", res);
      Account_Management_Local_Variable.All_Users_Information = res.result.All_Users_Information.data;
      console.log("查看全部账号", Account_Management_Local_Variable.All_Users_Information);
    },
    fail: function fail() {
      console.log("下载全部账号信息失败", console.error);
      WeChat.Loading_All_User();
    }
  });
};

WeChat.Loading_Report_User = function (_openid) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_Report_User",
    data: {
      openid: _openid
    },
    success: function success(res) {
      console.log("下载举报人信息成功回调", res);
      Account_Management_Local_Variable.Report_User_List = res.result.Report_User_List.data;
      console.log("查看所有举报人信息", Account_Management_Local_Variable.Report_User_List);
    },
    fail: function fail() {
      console.log("下载所有举报人信息失败", console.error);
      WeChat.Loading_Report_User(_openid);
    }
  });
};

WeChat.Loading_Reporterd_User = function () {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Loading_All_Reported_Users",
    success: function success(res) {
      console.log("下载被举报人信息成功回调", res);
      Account_Management_Local_Variable.Reported_Users_Information = res.result.Reported_Information.list;
      console.log("查看被举报人信息", Account_Management_Local_Variable.Reported_Users_Information);
    },
    fail: function fail() {
      console.log("下载所有被举报人信息失败", console.error);
      WeChat.Loading_Reporterd_User();
    }
  });
};

WeChat.Email_Report_And_Appeal = function (Time, Title, Content) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Email_Report",
    data: {
      Time: Time,
      Email_Title: Title,
      Email_Content: Content
    },
    success: function success(res) {
      console.log("举报邮件成功回调", res);
    },
    fail: function fail() {
      console.log("举报邮件发送失败", console.error);
      ;
    }
  });
};

WeChat.Email_Warning = function (Time, Title, Content, open_id) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Email_Warning",
    data: {
      Time: Time,
      Email_Title: Title,
      Email_Content: Content,
      open_id: open_id
    },
    success: function success(res) {
      console.log("警告邮件成功回调", res);
    },
    fail: function fail() {
      console.log("警告邮件发送失败", console.error);
      ;
    }
  });
};

WeChat.Handle_Reported_User = function (_openid) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Handle_Reported_User",
    data: {
      openid: _openid
    },
    success: function success(res) {
      console.log("处理被举报人成功回调", res);
    },
    fail: function fail() {
      console.log("处理被举报人失败", console.error);
    }
  });
};

WeChat.Closure_Account = function (Openid, Input) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Closure_Account",
    data: {
      Reported_Openid: Openid,
      Closure_Time: Input
    },
    success: function success(res) {
      console.log("封停账号成功回调", res);
    },
    fail: function fail() {
      console.log("封停账号失败", console.error);
    }
  });
};

WeChat.Cancel_Closure = function (Openid) {
  wx.cloud.init({
    env: "zcx-6gbgdxdy254816b0"
  });
  wx.cloud.callFunction({
    //调用云函数
    //传入的参数
    name: "Cancel_Closure",
    data: {
      Reported_Openid: Openid
    },
    success: function success(res) {
      console.log("解除封停账号成功回调", res);
    },
    fail: function fail() {
      console.log("解除封停账号失败", console.error);
    }
  });
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcR2xvYmFsX1dlQ2hhdC5qcyJdLCJuYW1lcyI6WyJSYW5rX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWFibGUiLCJVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsIkFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZSIsIndpbmRvdyIsIldlQ2hhdCIsIm9uUmVnaXN0ZXJVc2VyIiwiX3VzZXJpbmZvIiwid3giLCJjbG91ZCIsImluaXQiLCJlbnYiLCJjb25zb2xlIiwibG9nIiwiY2FsbEZ1bmN0aW9uIiwibmFtZSIsImRhdGEiLCJ1c2VyaW5mbyIsInN1Y2Nlc3MiLCJyZXMiLCJHbG9iYWxfVmFyaWFibGUiLCJJc19DbG9zdXJlZCIsInJlc3VsdCIsIlVuc2VhbGluZ19UaW1lIiwib3BlbmlkIiwiY2MiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsImZhaWwiLCJlcnJvciIsIkxvYWRpbmdfUmVzb3VyY2VzIiwiR29sZCIsIkRpYW1vbmQiLCJDb21wYXNzaW9uIiwiVXNlcl9IZWFkX0ltYWdlIiwiQmVzdF9TY29yZSIsIlVzZXJfTmFtZSIsIkN1cnJlbnRfQ2hhcmFjdGVyX0lkIiwiSXNfQWRtaW4iLCJMb2FkaW5nX0JpcmRfSW1hZ2UiLCJHYW1lX1NldHRsZW1lbnQiLCJfQWRkX0dvbGQiLCJfU2NvcmUiLCJBZGRfR29sZCIsIlNjb3JlIiwiTG9hZGluZ19Xb3JsZF9SYW5rIiwiV29yZF9SYW5rX1VzZXIiLCJVc2VyX0luZm9ybWF0aW9uIiwiVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uIiwiX09wZW5pZCIsIl9SZXBvcnRfQ29udGVudCIsIlJlcG9ydGVkX09wZW5pZCIsIlJlcG9ydF9Db250ZW50IiwiTG9hZGluZ19DaGFyYWN0ZXIiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIiwiQ2hhcmFjdGVyX0luZm9ybWF0aW9uIiwiVXNlcl9IYXZlX0NoYXJhY3RlciIsIlVzZXJfSGF2ZV9DaGFyYWN0ZXJfSW5mb3JtYXRpb24iLCJMb2FkaW5nX1Nob3BfQ2hhcmFjdGVyIiwiQnV5X0NoYXJhY3Rlcl9VcGRhdGUiLCJfVXBkYXRlX0dvbGQiLCJfVXBkYXRlX0NoYXJhY3RlciIsIlVwZGF0ZV9Hb2xkIiwiVXBkYXRlX0NoYXJhY3RlciIsIkNoYXJhY3Rlcl9JZCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJDaGFyYWN0ZXJfSW1hZ2UxIiwidHlwZSIsImVyciIsInRleHR1cmUiLCJ0ZXN0IiwiZnJhbWUiLCJTcHJpdGVGcmFtZSIsIkNoYXJhY3Rlcl9JbWFnZTIiLCJDaGFyYWN0ZXJfSW1hZ2UzIiwiQ2hhcmFjdGVyX0ltYWdlNCIsIlVwZGF0aW5nX0N1cnJlbnRfQ2hhcmFjdGVyX2lkIiwiTG9hZGluZ19FbWFpbCIsIkVtYWlsIiwiVXNlcl9FbWFpbF9JbmZvcm1hdGlvbiIsIkxvYWRpbmdfQWxsX0VtYWlsIiwiUmVhZF9BbGwiLCJEZWxldGVfUmVhZCIsIlJlYWQiLCJfaWQiLCJBY2NlcHQiLCJfQWRkX0RpYW1vbmQiLCJfQWRkX0NvbXBhc3Npb24iLCJBZGRfRGlhbW9uZCIsIkFkZF9Db21wYXNzaW9uIiwiQXdhcmRzX0VtYWlsIiwiVGltZSIsIlRpdGxlIiwiQ29udGVudCIsIkVuY2xvc3VyZSIsIkVtYWlsX1RpdGxlIiwiRW1haWxfQ29udGVudCIsIkVtYWlsX0dvbGQiLCJFbWFpbF9EaWFtb25kIiwiRW1haWxfQ29tcGFzc2lvbiIsIkxvYWRpbmdfQWxsX1VzZXIiLCJBbGxfVXNlcnNfSW5mb3JtYXRpb24iLCJMb2FkaW5nX1JlcG9ydF9Vc2VyIiwiX29wZW5pZCIsIlJlcG9ydF9Vc2VyX0xpc3QiLCJMb2FkaW5nX1JlcG9ydGVyZF9Vc2VyIiwiUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb24iLCJSZXBvcnRlZF9JbmZvcm1hdGlvbiIsImxpc3QiLCJFbWFpbF9SZXBvcnRfQW5kX0FwcGVhbCIsIkVtYWlsX1dhcm5pbmciLCJvcGVuX2lkIiwiSGFuZGxlX1JlcG9ydGVkX1VzZXIiLCJDbG9zdXJlX0FjY291bnQiLCJPcGVuaWQiLCJJbnB1dCIsIkNsb3N1cmVfVGltZSIsIkNhbmNlbF9DbG9zdXJlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxxQkFBRCxDQUFoQzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBQ0QsT0FBTyxDQUFDLDhCQUFELENBQXpDOztBQUNBLElBQUlFLGlDQUFpQyxHQUFDRixPQUFPLENBQUMsbUNBQUQsQ0FBN0M7O0FBQ0EsSUFBSUcsb0JBQW9CLEdBQUdILE9BQU8sQ0FBQyxzQkFBRCxDQUFsQzs7QUFDQSxJQUFJSSxpQ0FBaUMsR0FBQ0osT0FBTyxDQUFDLG1DQUFELENBQTdDOztBQUNBSyxNQUFNLENBQUNDLE1BQVAsR0FBZ0IsRUFBaEIsRUFDQTs7QUFDQUEsTUFBTSxDQUFDQyxjQUFQLEdBQXdCLFVBQVNDLFNBQVQsRUFBb0I7QUFDM0NDLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFDYkMsSUFBQUEsR0FBRyxFQUFFO0FBRFEsR0FBZDtBQUdBQyxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWU4sU0FBWjtBQUNBQyxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUUsT0FGZTtBQUdyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUU7QUFDTEMsTUFBQUEsUUFBUSxFQUFFVjtBQURMLEtBSmU7QUFPckJXLElBQUFBLE9BUHFCLG1CQU9iQyxHQVBhLEVBT1I7QUFDWlAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF3Qk0sR0FBeEI7QUFDQUMsTUFBQUEsZUFBZSxDQUFDQyxXQUFoQixHQUE4QkYsR0FBRyxDQUFDRyxNQUFKLENBQVdELFdBQXpDO0FBQ0FELE1BQUFBLGVBQWUsQ0FBQ0csY0FBaEIsR0FBaUNKLEdBQUcsQ0FBQ0csTUFBSixDQUFXTixJQUFYLENBQWdCLENBQWhCLEVBQW1CTyxjQUFwRDtBQUNBSCxNQUFBQSxlQUFlLENBQUNJLE1BQWhCLEdBQXlCTCxHQUFHLENBQUNHLE1BQUosQ0FBV04sSUFBWCxDQUFnQixDQUFoQixFQUFtQlEsTUFBNUM7QUFDQVosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBeUMsQ0FBQ00sR0FBRyxDQUFDRyxNQUFKLENBQVdELFdBQXJEO0FBQ0FULE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdDQUFaLEVBQTZDTyxlQUFlLENBQUNHLGNBQTdEOztBQUNBLFVBQUcsQ0FBQ0osR0FBRyxDQUFDRyxNQUFKLENBQVdELFdBQWYsRUFBMkI7QUFDMUJJLFFBQUFBLEVBQUUsQ0FBQ0MsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFlBQXRCO0FBQ0EsT0FGRCxNQUVLO0FBQ0pGLFFBQUFBLEVBQUUsQ0FBQ0MsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFNBQXRCO0FBQ0E7QUFFRCxLQXBCb0I7QUFxQnJCQyxJQUFBQSxJQXJCcUIsa0JBcUJkO0FBQ05SLE1BQUFBLGVBQWUsQ0FBQ0MsV0FBaEIsR0FBOEIsSUFBOUI7QUFDQVQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFvQkQsT0FBTyxDQUFDaUIsS0FBNUI7QUFDQTtBQXhCb0IsR0FBdEI7QUEwQkEsQ0EvQkQsRUFnQ0E7OztBQUNBeEIsTUFBTSxDQUFDeUIsaUJBQVAsR0FBMkIsWUFBVztBQUNyQ3RCLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFDYkMsSUFBQUEsR0FBRyxFQUFFO0FBRFEsR0FBZDtBQUdBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUUsbUJBRmU7QUFHckJHLElBQUFBLE9BSHFCLG1CQUdiQyxHQUhhLEVBR1I7QUFDWjtBQUNBUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCTSxHQUF0QjtBQUNBQyxNQUFBQSxlQUFlLENBQUNJLE1BQWhCLEdBQXlCTCxHQUFHLENBQUNHLE1BQUosQ0FBV0UsTUFBcEM7QUFDQUosTUFBQUEsZUFBZSxDQUFDVyxJQUFoQixHQUF1QlosR0FBRyxDQUFDRyxNQUFKLENBQVdTLElBQWxDO0FBQ0FYLE1BQUFBLGVBQWUsQ0FBQ1ksT0FBaEIsR0FBMEJiLEdBQUcsQ0FBQ0csTUFBSixDQUFXVSxPQUFyQztBQUNBWixNQUFBQSxlQUFlLENBQUNhLFVBQWhCLEdBQTZCZCxHQUFHLENBQUNHLE1BQUosQ0FBV1csVUFBeEM7QUFDQWIsTUFBQUEsZUFBZSxDQUFDYyxlQUFoQixHQUFrQ2YsR0FBRyxDQUFDRyxNQUFKLENBQVdZLGVBQTdDO0FBQ0FkLE1BQUFBLGVBQWUsQ0FBQ2UsVUFBaEIsR0FBNkJoQixHQUFHLENBQUNHLE1BQUosQ0FBV2EsVUFBeEM7QUFDQWYsTUFBQUEsZUFBZSxDQUFDZ0IsU0FBaEIsR0FBNEJqQixHQUFHLENBQUNHLE1BQUosQ0FBV2MsU0FBdkM7QUFDQWhCLE1BQUFBLGVBQWUsQ0FBQ2lCLG9CQUFoQixHQUFxQ2xCLEdBQUcsQ0FBQ0csTUFBSixDQUFXZSxvQkFBaEQ7QUFDQWpCLE1BQUFBLGVBQWUsQ0FBQ2tCLFFBQWhCLEdBQXlCbkIsR0FBRyxDQUFDRyxNQUFKLENBQVdnQixRQUFwQztBQUNBakMsTUFBQUEsTUFBTSxDQUFDa0Msa0JBQVAsQ0FBMEJuQixlQUFlLENBQUNpQixvQkFBMUM7QUFDQSxLQWhCb0I7QUFpQnJCVCxJQUFBQSxJQWpCcUIsa0JBaUJkO0FBQ05oQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCRCxPQUFPLENBQUNpQixLQUFoQyxFQURNLENBRU47O0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBckJvQixHQUF0QjtBQXVCQSxDQTNCRCxFQTRCQTs7O0FBQ0F6QixNQUFNLENBQUNtQyxlQUFQLEdBQXlCLFVBQVNDLFNBQVQsRUFBb0JDLE1BQXBCLEVBQTRCO0FBQ3BEbEMsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUNiQyxJQUFBQSxHQUFHLEVBQUU7QUFEUSxHQUFkO0FBR0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0FDLElBQUFBLElBQUksRUFBRSxpQkFGZTtBQUdyQjtBQUNBQyxJQUFBQSxJQUFJLEVBQUU7QUFDTDJCLE1BQUFBLFFBQVEsRUFBRUYsU0FETDtBQUVMRyxNQUFBQSxLQUFLLEVBQUVGO0FBRkYsS0FKZTtBQVNyQnhCLElBQUFBLE9BVHFCLG1CQVNiQyxHQVRhLEVBU1I7QUFFWlAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFzQk0sR0FBdEI7QUFDQUMsTUFBQUEsZUFBZSxDQUFDVyxJQUFoQixHQUF1QlosR0FBRyxDQUFDRyxNQUFKLENBQVdTLElBQWxDO0FBQ0FYLE1BQUFBLGVBQWUsQ0FBQ1ksT0FBaEIsR0FBMEJiLEdBQUcsQ0FBQ0csTUFBSixDQUFXVSxPQUFyQztBQUNBWixNQUFBQSxlQUFlLENBQUNhLFVBQWhCLEdBQTZCZCxHQUFHLENBQUNHLE1BQUosQ0FBV1csVUFBeEM7QUFDQSxLQWZvQjtBQWdCckJMLElBQUFBLElBaEJxQixrQkFnQmQ7QUFDTmhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JELE9BQU8sQ0FBQ2lCLEtBQWhDO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBbkJvQixHQUF0QjtBQXFCQSxDQXpCRCxFQTBCQTs7O0FBQ0F6QixNQUFNLENBQUN3QyxrQkFBUCxHQUE0QixZQUFXO0FBQ3RDckMsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUNiQyxJQUFBQSxHQUFHLEVBQUU7QUFEUSxHQUFkO0FBR0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0FDLElBQUFBLElBQUksRUFBRSxvQkFGZTtBQUlyQkcsSUFBQUEsT0FKcUIsbUJBSWJDLEdBSmEsRUFJUjtBQUVaUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQTBCTSxHQUExQjtBQUNBckIsTUFBQUEsa0JBQWtCLENBQUNnRCxjQUFuQixHQUFvQzNCLEdBQUcsQ0FBQ0csTUFBSixDQUFXeUIsZ0JBQVgsQ0FBNEIvQixJQUFoRTtBQUNBSixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxxQkFBWixFQUFtQ2Ysa0JBQWtCLENBQUNnRCxjQUFuQixDQUFrQyxDQUFsQyxFQUFxQ3RCLE1BQXhFO0FBQ0EsS0FUb0I7QUFVckJJLElBQUFBLElBVnFCLGtCQVVkO0FBQ05oQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCRCxPQUFPLENBQUNpQixLQUFoQztBQUNBeEIsTUFBQUEsTUFBTSxDQUFDeUIsaUJBQVA7QUFDQTtBQWJvQixHQUF0QjtBQWVBLENBbkJELEVBcUJBOzs7QUFDQXpCLE1BQU0sQ0FBQzJDLDhCQUFQLEdBQXdDLFVBQVNDLE9BQVQsRUFBa0JDLGVBQWxCLEVBQW1DO0FBRTFFMUMsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUNiQyxJQUFBQSxHQUFHLEVBQUU7QUFEUSxHQUFkO0FBR0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0FDLElBQUFBLElBQUksRUFBRSxnQ0FGZTtBQUdyQkMsSUFBQUEsSUFBSSxFQUFFO0FBQ0xtQyxNQUFBQSxlQUFlLEVBQUVGLE9BRFo7QUFFTEcsTUFBQUEsY0FBYyxFQUFFRjtBQUZYLEtBSGU7QUFRckJoQyxJQUFBQSxPQVJxQixtQkFRYkMsR0FSYSxFQVFSO0FBQ1pQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JNLEdBQXRCO0FBQ0EsS0FWb0I7QUFXckJTLElBQUFBLElBWHFCLGtCQVdkO0FBQ05oQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCRCxPQUFPLENBQUNpQixLQUE5QjtBQUNBO0FBYm9CLEdBQXRCO0FBZUEsQ0FwQkQ7O0FBc0JBeEIsTUFBTSxDQUFDZ0QsaUJBQVAsR0FBeUIsWUFBWTtBQUNwQzdDLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxXQUhnQjtBQU1yQkcsSUFBQUEsT0FOcUIsbUJBTWJDLEdBTmEsRUFNVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBbkIsTUFBQUEsNkJBQTZCLENBQUNzRCxtQkFBOUIsR0FBa0RuQyxHQUFHLENBQUNHLE1BQUosQ0FBV2lDLHFCQUFYLENBQWlDdkMsSUFBbkY7QUFDQWYsTUFBQUEsaUNBQWlDLENBQUN1RCxtQkFBbEMsR0FBc0RyQyxHQUFHLENBQUNHLE1BQUosQ0FBV21DLCtCQUFYLENBQTJDekMsSUFBakc7QUFDQSxLQVZvQjtBQVdyQlksSUFBQUEsSUFYcUIsa0JBV2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBZG9CLEdBQXRCO0FBZ0JBLENBbEJEOztBQW9CQXpCLE1BQU0sQ0FBQ3FELHNCQUFQLEdBQThCLFlBQVU7QUFDdkNsRCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsTUFIZ0I7QUFNckJHLElBQUFBLE9BTnFCLG1CQU1iQyxHQU5hLEVBTVQ7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQW5CLE1BQUFBLDZCQUE2QixDQUFDc0QsbUJBQTlCLEdBQWtEbkMsR0FBRyxDQUFDRyxNQUFKLENBQVdpQyxxQkFBWCxDQUFpQ3ZDLElBQW5GO0FBQ0FmLE1BQUFBLGlDQUFpQyxDQUFDdUQsbUJBQWxDLEdBQXNEckMsR0FBRyxDQUFDRyxNQUFKLENBQVdtQywrQkFBWCxDQUEyQ3pDLElBQWpHO0FBQ0EsS0FWb0I7QUFXckJZLElBQUFBLElBWHFCLGtCQVdmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCRCxPQUFPLENBQUNpQixLQUEvQjtBQUNBeEIsTUFBQUEsTUFBTSxDQUFDeUIsaUJBQVA7QUFDQTtBQWRvQixHQUF0QjtBQWdCQSxDQWxCRCxFQXFCQTs7O0FBQ0F6QixNQUFNLENBQUNzRCxvQkFBUCxHQUE0QixVQUFVQyxZQUFWLEVBQXVCQyxpQkFBdkIsRUFBMEM7QUFDckVyRCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsVUFIZ0I7QUFLckJDLElBQUFBLElBQUksRUFBQztBQUNKOEMsTUFBQUEsV0FBVyxFQUFDRixZQURSO0FBRUpHLE1BQUFBLGdCQUFnQixFQUFDRjtBQUZiLEtBTGdCO0FBVXJCM0MsSUFBQUEsT0FWcUIsbUJBVWJDLEdBVmEsRUFVVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBLEtBWm9CO0FBYXJCUyxJQUFBQSxJQWJxQixrQkFhZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWixFQUFzQkQsT0FBTyxDQUFDaUIsS0FBOUI7QUFDQXhCLE1BQUFBLE1BQU0sQ0FBQ3lCLGlCQUFQO0FBQ0E7QUFoQm9CLEdBQXRCO0FBa0JBLENBcEJEOztBQXNCQXpCLE1BQU0sQ0FBQ2tDLGtCQUFQLEdBQTBCLFVBQVV5QixZQUFWLEVBQXdCO0FBQ2pEeEQsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLG9CQUhnQjtBQUtyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pnRCxNQUFBQSxZQUFZLEVBQUNBO0FBRFQsS0FMZ0I7QUFTckI5QyxJQUFBQSxPQVRxQixtQkFTYkMsR0FUYSxFQVNUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBeUJNLEdBQXpCO0FBRUFNLE1BQUFBLEVBQUUsQ0FBQ3dDLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLFFBQUFBLEdBQUcsRUFBQ2hELEdBQUcsQ0FBQ0csTUFBSixDQUFXOEMsZ0JBREQ7QUFFZEMsUUFBQUEsSUFBSSxFQUFDO0FBRlMsT0FBZixFQUdFLFVBQVNDLEdBQVQsRUFBYUMsT0FBYixFQUFxQkMsSUFBckIsRUFBMEI7QUFDM0IsWUFBSUMsS0FBSyxHQUFDLElBQUloRCxFQUFFLENBQUNpRCxXQUFQLENBQW1CSCxPQUFuQixDQUFWOztBQUNBLFlBQUdELEdBQUgsRUFBTztBQUNOMUQsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQnlELEdBQW5CO0FBQ0E7O0FBQ0RsRCxRQUFBQSxlQUFlLENBQUNnRCxnQkFBaEIsR0FBaUNLLEtBQWpDO0FBQ0EsT0FURDtBQVVBaEQsTUFBQUEsRUFBRSxDQUFDd0MsTUFBSCxDQUFVQyxJQUFWLENBQWU7QUFDZEMsUUFBQUEsR0FBRyxFQUFDaEQsR0FBRyxDQUFDRyxNQUFKLENBQVdxRCxnQkFERDtBQUVkTixRQUFBQSxJQUFJLEVBQUM7QUFGUyxPQUFmLEVBR0UsVUFBU0MsR0FBVCxFQUFhQyxPQUFiLEVBQXFCQyxJQUFyQixFQUEwQjtBQUMzQixZQUFJQyxLQUFLLEdBQUMsSUFBSWhELEVBQUUsQ0FBQ2lELFdBQVAsQ0FBbUJILE9BQW5CLENBQVY7O0FBQ0EsWUFBR0QsR0FBSCxFQUFPO0FBQ04xRCxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CeUQsR0FBbkI7QUFDQTs7QUFDRGxELFFBQUFBLGVBQWUsQ0FBQ3VELGdCQUFoQixHQUFpQ0YsS0FBakM7QUFDQSxPQVREO0FBVUFoRCxNQUFBQSxFQUFFLENBQUN3QyxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxRQUFBQSxHQUFHLEVBQUNoRCxHQUFHLENBQUNHLE1BQUosQ0FBV3NELGdCQUREO0FBRWRQLFFBQUFBLElBQUksRUFBQztBQUZTLE9BQWYsRUFHRSxVQUFTQyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFlBQUlDLEtBQUssR0FBQyxJQUFJaEQsRUFBRSxDQUFDaUQsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxZQUFHRCxHQUFILEVBQU87QUFDTjFELFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJ5RCxHQUFuQjtBQUNBOztBQUNEbEQsUUFBQUEsZUFBZSxDQUFDd0QsZ0JBQWhCLEdBQWlDSCxLQUFqQztBQUNBLE9BVEQ7QUFVQWhELE1BQUFBLEVBQUUsQ0FBQ3dDLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLFFBQUFBLEdBQUcsRUFBQ2hELEdBQUcsQ0FBQ0csTUFBSixDQUFXdUQsZ0JBREQ7QUFFZFIsUUFBQUEsSUFBSSxFQUFDO0FBRlMsT0FBZixFQUdFLFVBQVNDLEdBQVQsRUFBYUMsT0FBYixFQUFxQkMsSUFBckIsRUFBMEI7QUFDM0IsWUFBSUMsS0FBSyxHQUFDLElBQUloRCxFQUFFLENBQUNpRCxXQUFQLENBQW1CSCxPQUFuQixDQUFWOztBQUNBLFlBQUdELEdBQUgsRUFBTztBQUNOMUQsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQnlELEdBQW5CO0FBQ0E7O0FBQ0RsRCxRQUFBQSxlQUFlLENBQUN5RCxnQkFBaEIsR0FBaUNKLEtBQWpDO0FBQ0EsT0FURDtBQVVBLEtBcERvQjtBQXNEckI3QyxJQUFBQSxJQXREcUIsa0JBc0RmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCRCxPQUFPLENBQUNpQixLQUEvQjtBQUNBO0FBeERvQixHQUF0QjtBQTBEQSxDQTVERDs7QUE4REF4QixNQUFNLENBQUN5RSw2QkFBUCxHQUFxQyxVQUFVZCxZQUFWLEVBQXdCO0FBQzVEeEQsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLCtCQUhnQjtBQUtyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pnRCxNQUFBQSxZQUFZLEVBQUNBO0FBRFQsS0FMZ0I7QUFTckI5QyxJQUFBQSxPQVRxQixtQkFTYkMsR0FUYSxFQVNUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBeUJNLEdBQXpCO0FBQ0FkLE1BQUFBLE1BQU0sQ0FBQ2tDLGtCQUFQLENBQTBCeUIsWUFBMUI7QUFDQSxLQVpvQjtBQWNyQnBDLElBQUFBLElBZHFCLGtCQWNmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCRCxPQUFPLENBQUNpQixLQUEvQjtBQUNBeEIsTUFBQUEsTUFBTSxDQUFDa0Msa0JBQVAsQ0FBMEJ5QixZQUExQjtBQUNBO0FBakJvQixHQUF0QjtBQW1CQSxDQXJCRCxFQXVCQTs7O0FBQ0EzRCxNQUFNLENBQUMwRSxhQUFQLEdBQXFCLFlBQVU7QUFDOUJ2RSxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsZUFIZ0I7QUFJckJHLElBQUFBLE9BSnFCLG1CQUliQyxHQUphLEVBSVQ7QUFDWGpCLE1BQUFBLG9CQUFvQixDQUFDOEUsS0FBckIsR0FBMkI3RCxHQUFHLENBQUNHLE1BQUosQ0FBVzJELHNCQUFYLENBQWtDakUsSUFBN0Q7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQVAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQlgsb0JBQW9CLENBQUM4RSxLQUF6QztBQUNBLEtBUm9CO0FBU3JCcEQsSUFBQUEsSUFUcUIsa0JBU2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBWm9CLEdBQXRCO0FBZUEsQ0FqQkQsRUFrQkE7OztBQUNBekIsTUFBTSxDQUFDNkUsaUJBQVAsR0FBeUIsWUFBVTtBQUNsQzFFLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxtQkFIZ0I7QUFJckJHLElBQUFBLE9BSnFCLG1CQUliQyxHQUphLEVBSVQ7QUFDWGpCLE1BQUFBLG9CQUFvQixDQUFDOEUsS0FBckIsR0FBMkI3RCxHQUFHLENBQUNHLE1BQUosQ0FBVzJELHNCQUFYLENBQWtDakUsSUFBN0Q7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQVAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQlgsb0JBQW9CLENBQUM4RSxLQUF6QztBQUNBLEtBUm9CO0FBU3JCcEQsSUFBQUEsSUFUcUIsa0JBU2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBWm9CLEdBQXRCO0FBZUEsQ0FqQkQsRUFrQkE7OztBQUNBekIsTUFBTSxDQUFDOEUsUUFBUCxHQUFnQixZQUFZO0FBQzNCM0UsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLFVBSGdCO0FBSXJCRyxJQUFBQSxPQUpxQixtQkFJYkMsR0FKYSxFQUlUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJNLEdBQXZCO0FBQ0EsS0FOb0I7QUFRckJTLElBQUFBLElBUnFCLGtCQVFmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCRCxPQUFPLENBQUNpQixLQUE3QjtBQUNBO0FBVm9CLEdBQXRCO0FBWUEsQ0FkRCxFQWVBOzs7QUFDQXhCLE1BQU0sQ0FBQytFLFdBQVAsR0FBbUIsWUFBWTtBQUM5QjVFLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxhQUhnQjtBQUlyQkcsSUFBQUEsT0FKcUIsbUJBSWJDLEdBSmEsRUFJVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQXlCTSxHQUF6QjtBQUNBLEtBTm9CO0FBUXJCUyxJQUFBQSxJQVJxQixrQkFRZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1QkQsT0FBTyxDQUFDaUIsS0FBL0I7QUFDQTtBQVZvQixHQUF0QjtBQVlBLENBZEQsRUFlQTs7O0FBQ0F4QixNQUFNLENBQUNnRixJQUFQLEdBQVksVUFBU0MsR0FBVCxFQUFhO0FBQ3hCOUUsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLE1BSGdCO0FBSXJCQyxJQUFBQSxJQUFJLEVBQUM7QUFDSnNFLE1BQUFBLEdBQUcsRUFBQ0E7QUFEQSxLQUpnQjtBQU9yQnBFLElBQUFBLE9BUHFCLG1CQU9iQyxHQVBhLEVBT1Q7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQSxLQVRvQjtBQVdyQlMsSUFBQUEsSUFYcUIsa0JBV2Y7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBcUJELE9BQU8sQ0FBQ2lCLEtBQTdCO0FBQ0E7QUFib0IsR0FBdEI7QUFlQSxDQWpCRCxFQWtCQTs7O0FBQ0F4QixNQUFNLENBQUNrRixNQUFQLEdBQWMsVUFBU0QsR0FBVCxFQUFhN0MsU0FBYixFQUF1QitDLFlBQXZCLEVBQW9DQyxlQUFwQyxFQUFvRDtBQUNqRWpGLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxRQUhnQjtBQUlyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pzRSxNQUFBQSxHQUFHLEVBQUNBLEdBREE7QUFFSjNDLE1BQUFBLFFBQVEsRUFBQ0YsU0FGTDtBQUdKaUQsTUFBQUEsV0FBVyxFQUFDRixZQUhSO0FBSUpHLE1BQUFBLGNBQWMsRUFBQ0Y7QUFKWCxLQUpnQjtBQVVyQnZFLElBQUFBLE9BVnFCLG1CQVViQyxHQVZhLEVBVVQ7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQUMsTUFBQUEsZUFBZSxDQUFDVyxJQUFoQixHQUF1QlosR0FBRyxDQUFDRyxNQUFKLENBQVdTLElBQWxDO0FBQ0FYLE1BQUFBLGVBQWUsQ0FBQ1ksT0FBaEIsR0FBMEJiLEdBQUcsQ0FBQ0csTUFBSixDQUFXVSxPQUFyQztBQUNBWixNQUFBQSxlQUFlLENBQUNhLFVBQWhCLEdBQTZCZCxHQUFHLENBQUNHLE1BQUosQ0FBV1csVUFBeEM7QUFDQSxLQWZvQjtBQWlCckJMLElBQUFBLElBakJxQixrQkFpQmY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JELE9BQU8sQ0FBQ2lCLEtBQWhDO0FBQ0F4QixNQUFBQSxNQUFNLENBQUN5QixpQkFBUDtBQUNBO0FBcEJvQixHQUF0QjtBQXNCQSxDQXhCRCxFQXlCQTs7O0FBQ0F6QixNQUFNLENBQUN1RixZQUFQLEdBQW9CLFVBQVNDLElBQVQsRUFBY0MsS0FBZCxFQUFvQkMsT0FBcEIsRUFBNEJoRSxJQUE1QixFQUFpQ0MsT0FBakMsRUFBeUNDLFVBQXpDLEVBQW9EK0QsU0FBcEQsRUFBOEQ7QUFDakZ4RixFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsUUFIZ0I7QUFJckJDLElBQUFBLElBQUksRUFBQztBQUNKNkUsTUFBQUEsSUFBSSxFQUFDQSxJQUREO0FBRUpJLE1BQUFBLFdBQVcsRUFBQ0gsS0FGUjtBQUdKSSxNQUFBQSxhQUFhLEVBQUNILE9BSFY7QUFJSkksTUFBQUEsVUFBVSxFQUFDcEUsSUFKUDtBQUtKcUUsTUFBQUEsYUFBYSxFQUFDcEUsT0FMVjtBQU1KcUUsTUFBQUEsZ0JBQWdCLEVBQUNwRSxVQU5iO0FBT0orRCxNQUFBQSxTQUFTLEVBQUNBO0FBUE4sS0FKZ0I7QUFhckI5RSxJQUFBQSxPQWJxQixtQkFhYkMsR0FiYSxFQWFUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJNLEdBQXZCO0FBQ0EsS0Fmb0I7QUFpQnJCUyxJQUFBQSxJQWpCcUIsa0JBaUJmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCRCxPQUFPLENBQUNpQixLQUE5QjtBQUNBO0FBbkJvQixHQUF0QjtBQXFCQSxDQXZCRDs7QUF5QkF4QixNQUFNLENBQUNpRyxnQkFBUCxHQUF3QixZQUFZO0FBQ25DOUYsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLGtCQUhnQjtBQUtyQkcsSUFBQUEsT0FMcUIsbUJBS2JDLEdBTGEsRUFLVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaLEVBQTJCTSxHQUEzQjtBQUNBaEIsTUFBQUEsaUNBQWlDLENBQUNvRyxxQkFBbEMsR0FBd0RwRixHQUFHLENBQUNHLE1BQUosQ0FBV2lGLHFCQUFYLENBQWlDdkYsSUFBekY7QUFDQUosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQlYsaUNBQWlDLENBQUNvRyxxQkFBdkQ7QUFDQSxLQVRvQjtBQVdyQjNFLElBQUFBLElBWHFCLGtCQVdmO0FBQ0xoQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQXlCRCxPQUFPLENBQUNpQixLQUFqQztBQUNBeEIsTUFBQUEsTUFBTSxDQUFDaUcsZ0JBQVA7QUFDQTtBQWRvQixHQUF0QjtBQWdCQSxDQWxCRDs7QUFvQkFqRyxNQUFNLENBQUNtRyxtQkFBUCxHQUEyQixVQUFVQyxPQUFWLEVBQW1CO0FBQzdDakcsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNDLElBQVQsQ0FBYztBQUFDQyxJQUFBQSxHQUFHLEVBQUM7QUFBTCxHQUFkO0FBQ0FILEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTSyxZQUFULENBQXNCO0FBQ3JCO0FBQ0E7QUFDQUMsSUFBQUEsSUFBSSxFQUFDLHFCQUhnQjtBQUtyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0pRLE1BQUFBLE1BQU0sRUFBQ2lGO0FBREgsS0FMZ0I7QUFTckJ2RixJQUFBQSxPQVRxQixtQkFTYkMsR0FUYSxFQVNUO0FBQ1hQLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVosRUFBMEJNLEdBQTFCO0FBQ0FoQixNQUFBQSxpQ0FBaUMsQ0FBQ3VHLGdCQUFsQyxHQUFtRHZGLEdBQUcsQ0FBQ0csTUFBSixDQUFXb0YsZ0JBQVgsQ0FBNEIxRixJQUEvRTtBQUNBSixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCVixpQ0FBaUMsQ0FBQ3VHLGdCQUExRDtBQUNBLEtBYm9CO0FBZXJCOUUsSUFBQUEsSUFmcUIsa0JBZWY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVosRUFBMEJELE9BQU8sQ0FBQ2lCLEtBQWxDO0FBQ0F4QixNQUFBQSxNQUFNLENBQUNtRyxtQkFBUCxDQUEyQkMsT0FBM0I7QUFDQTtBQWxCb0IsR0FBdEI7QUFvQkEsQ0F0QkQ7O0FBd0JBcEcsTUFBTSxDQUFDc0csc0JBQVAsR0FBOEIsWUFBWTtBQUN6Q25HLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyw0QkFIZ0I7QUFJckJHLElBQUFBLE9BSnFCLG1CQUliQyxHQUphLEVBSVQ7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQk0sR0FBM0I7QUFDQWhCLE1BQUFBLGlDQUFpQyxDQUFDeUcsMEJBQWxDLEdBQTZEekYsR0FBRyxDQUFDRyxNQUFKLENBQVd1RixvQkFBWCxDQUFnQ0MsSUFBN0Y7QUFDQWxHLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJWLGlDQUFpQyxDQUFDeUcsMEJBQXpEO0FBQ0EsS0FSb0I7QUFTckJoRixJQUFBQSxJQVRxQixrQkFTZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUEyQkQsT0FBTyxDQUFDaUIsS0FBbkM7QUFDQXhCLE1BQUFBLE1BQU0sQ0FBQ3NHLHNCQUFQO0FBQ0E7QUFab0IsR0FBdEI7QUFjQSxDQWhCRDs7QUFrQkF0RyxNQUFNLENBQUMwRyx1QkFBUCxHQUErQixVQUFVbEIsSUFBVixFQUFlQyxLQUFmLEVBQXFCQyxPQUFyQixFQUE4QjtBQUM1RHZGLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxjQUhnQjtBQUlyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0o2RSxNQUFBQSxJQUFJLEVBQUNBLElBREQ7QUFFSkksTUFBQUEsV0FBVyxFQUFDSCxLQUZSO0FBR0pJLE1BQUFBLGFBQWEsRUFBQ0g7QUFIVixLQUpnQjtBQVNyQjdFLElBQUFBLE9BVHFCLG1CQVNiQyxHQVRhLEVBU1Q7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1Qk0sR0FBdkI7QUFDQSxLQVhvQjtBQVlyQlMsSUFBQUEsSUFacUIsa0JBWWY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQXNDO0FBQ3RDO0FBZG9CLEdBQXRCO0FBZ0JBLENBbEJEOztBQW9CQXhCLE1BQU0sQ0FBQzJHLGFBQVAsR0FBcUIsVUFBVW5CLElBQVYsRUFBZUMsS0FBZixFQUFxQkMsT0FBckIsRUFBNkJrQixPQUE3QixFQUFzQztBQUMxRHpHLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxlQUhnQjtBQUlyQkMsSUFBQUEsSUFBSSxFQUFDO0FBQ0o2RSxNQUFBQSxJQUFJLEVBQUNBLElBREQ7QUFFSkksTUFBQUEsV0FBVyxFQUFDSCxLQUZSO0FBR0pJLE1BQUFBLGFBQWEsRUFBQ0gsT0FIVjtBQUlKa0IsTUFBQUEsT0FBTyxFQUFDQTtBQUpKLEtBSmdCO0FBVXJCL0YsSUFBQUEsT0FWcUIsbUJBVWJDLEdBVmEsRUFVVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBLEtBWm9CO0FBYXJCUyxJQUFBQSxJQWJxQixrQkFhZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1QkQsT0FBTyxDQUFDaUIsS0FBL0I7QUFBc0M7QUFDdEM7QUFmb0IsR0FBdEI7QUFpQkEsQ0FuQkQ7O0FBcUJBeEIsTUFBTSxDQUFDNkcsb0JBQVAsR0FBNEIsVUFBU1QsT0FBVCxFQUFpQjtBQUM1Q2pHLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxzQkFIZ0I7QUFJckJDLElBQUFBLElBQUksRUFBQztBQUNKUSxNQUFBQSxNQUFNLEVBQUNpRjtBQURILEtBSmdCO0FBT3JCdkYsSUFBQUEsT0FQcUIsbUJBT2JDLEdBUGEsRUFPVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxZQUFaLEVBQXlCTSxHQUF6QjtBQUNBLEtBVG9CO0FBVXJCUyxJQUFBQSxJQVZxQixrQkFVZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWixFQUF1QkQsT0FBTyxDQUFDaUIsS0FBL0I7QUFDQTtBQVpvQixHQUF0QjtBQWNBLENBaEJEOztBQWtCQXhCLE1BQU0sQ0FBQzhHLGVBQVAsR0FBeUIsVUFBU0MsTUFBVCxFQUFnQkMsS0FBaEIsRUFBc0I7QUFDOUM3RyxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0MsSUFBVCxDQUFjO0FBQUNDLElBQUFBLEdBQUcsRUFBQztBQUFMLEdBQWQ7QUFDQUgsRUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVNLLFlBQVQsQ0FBc0I7QUFDckI7QUFDQTtBQUNBQyxJQUFBQSxJQUFJLEVBQUMsaUJBSGdCO0FBSXJCQyxJQUFBQSxJQUFJLEVBQUM7QUFDSm1DLE1BQUFBLGVBQWUsRUFBQ2lFLE1BRFo7QUFFSkUsTUFBQUEsWUFBWSxFQUFDRDtBQUZULEtBSmdCO0FBUXJCbkcsSUFBQUEsT0FScUIsbUJBUWJDLEdBUmEsRUFRVDtBQUNYUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXVCTSxHQUF2QjtBQUNBLEtBVm9CO0FBV3JCUyxJQUFBQSxJQVhxQixrQkFXZjtBQUNMaEIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQkQsT0FBTyxDQUFDaUIsS0FBN0I7QUFDQTtBQWJvQixHQUF0QjtBQWVBLENBakJEOztBQW1CQXhCLE1BQU0sQ0FBQ2tILGNBQVAsR0FBd0IsVUFBU0gsTUFBVCxFQUFnQjtBQUN2QzVHLEVBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTQyxJQUFULENBQWM7QUFBQ0MsSUFBQUEsR0FBRyxFQUFDO0FBQUwsR0FBZDtBQUNBSCxFQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBU0ssWUFBVCxDQUFzQjtBQUNyQjtBQUNBO0FBQ0FDLElBQUFBLElBQUksRUFBQyxnQkFIZ0I7QUFJckJDLElBQUFBLElBQUksRUFBQztBQUNKbUMsTUFBQUEsZUFBZSxFQUFDaUU7QUFEWixLQUpnQjtBQU9yQmxHLElBQUFBLE9BUHFCLG1CQU9iQyxHQVBhLEVBT1Q7QUFDWFAsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWixFQUF5Qk0sR0FBekI7QUFDQSxLQVRvQjtBQVVyQlMsSUFBQUEsSUFWcUIsa0JBVWY7QUFDTGhCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBdUJELE9BQU8sQ0FBQ2lCLEtBQS9CO0FBQ0E7QUFab0IsR0FBdEI7QUFjQSxDQWhCRCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lhajlsYDlj5jph49cclxudmFyIFJhbmtfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ1JhbmtfTG9jYWxfVmFyaWFibGUnKTtcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlhYmxlPXJlcXVpcmUoJ1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxudmFyIFVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZT1yZXF1aXJlKCdVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxudmFyIEVtYWlsX0xvY2FsX1ZhcmlhYmxlID0gcmVxdWlyZSgnRW1haWxfTG9jYWxfVmFyaWFibGUnKTtcclxudmFyIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZT1yZXF1aXJlKCdBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUnKTtcclxud2luZG93LldlQ2hhdCA9IHt9O1xyXG4vL+W+ruS/oeeZu+W9leazqOWGjOiwg+eUqFxyXG5XZUNoYXQub25SZWdpc3RlclVzZXIgPSBmdW5jdGlvbihfdXNlcmluZm8pIHtcclxuXHR3eC5jbG91ZC5pbml0KHtcclxuXHRcdGVudjogXCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwiXHJcblx0fSlcclxuXHRjb25zb2xlLmxvZyhfdXNlcmluZm8pO1xyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0bmFtZTogXCJsb2dpblwiLFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbDvvIznjqnlrrbkv6Hmga9cclxuXHRcdGRhdGE6IHtcclxuXHRcdFx0dXNlcmluZm86IF91c2VyaW5mbyxcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcykge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIueZu+W9leazqOWGjOaIkOWKn+Wbnuiwg1wiLCByZXMpO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuSXNfQ2xvc3VyZWQgPSByZXMucmVzdWx0LklzX0Nsb3N1cmVkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuVW5zZWFsaW5nX1RpbWUgPSByZXMucmVzdWx0LmRhdGFbMF0uVW5zZWFsaW5nX1RpbWU7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5vcGVuaWQgPSByZXMucmVzdWx0LmRhdGFbMF0ub3BlbmlkO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIiFyZXMucmVzdWx0LklzX0Nsb3N1cmVk55qE5YC85Li6XCIsIXJlcy5yZXN1bHQuSXNfQ2xvc3VyZWQpO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIkdsb2JhbF9WYXJpYWJsZS5VbnNlYWxpbmdfVGltZVwiLEdsb2JhbF9WYXJpYWJsZS5VbnNlYWxpbmdfVGltZSk7XHJcblx0XHRcdGlmKCFyZXMucmVzdWx0LklzX0Nsb3N1cmVkKXtcclxuXHRcdFx0XHRjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lX1N0YXJ0XCIpO1xyXG5cdFx0XHR9ZWxzZXtcclxuXHRcdFx0XHRjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJDbG9zdXJlXCIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdFxyXG5cdFx0fSxcclxuXHRcdGZhaWwoKSB7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Jc19DbG9zdXJlZCA9IHRydWU7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi56iL5bqP5Ye66ZSZXCIsIGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/liqDovb3otYTmupBcclxuV2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzID0gZnVuY3Rpb24oKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7XHJcblx0XHRlbnY6IFwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIlxyXG5cdH0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHRuYW1lOiBcIkxvYWRpbmdfUmVzb3VyY2VzXCIsXHJcblx0XHRzdWNjZXNzKHJlcykge1xyXG5cdFx0XHQvL+WwhuWAvOi1i+e7meWFqOWxgOWPmOmHj1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuiOt+WPluaIkOWKn+Wbnuiwg1wiLCByZXMpO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUub3BlbmlkID0gcmVzLnJlc3VsdC5vcGVuaWQ7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Hb2xkID0gcmVzLnJlc3VsdC5Hb2xkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuRGlhbW9uZCA9IHJlcy5yZXN1bHQuRGlhbW9uZDtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb24gPSByZXMucmVzdWx0LkNvbXBhc3Npb247XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Vc2VyX0hlYWRfSW1hZ2UgPSByZXMucmVzdWx0LlVzZXJfSGVhZF9JbWFnZTtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkJlc3RfU2NvcmUgPSByZXMucmVzdWx0LkJlc3RfU2NvcmU7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Vc2VyX05hbWUgPSByZXMucmVzdWx0LlVzZXJfTmFtZTtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkN1cnJlbnRfQ2hhcmFjdGVyX0lkPXJlcy5yZXN1bHQuQ3VycmVudF9DaGFyYWN0ZXJfSWQ7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Jc19BZG1pbj1yZXMucmVzdWx0LklzX0FkbWluO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19CaXJkX0ltYWdlKEdsb2JhbF9WYXJpYWJsZS5DdXJyZW50X0NoYXJhY3Rlcl9JZCk7XHJcblx0XHR9LFxyXG5cdFx0ZmFpbCgpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bln7rnoYDnianotYTlh7rplJlcIiwgY29uc29sZS5lcnJvcik7XHJcblx0XHRcdC8v5aSx6LSl5LqG6YeN5paw6LWL5YC8XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/muLjmiI/nu5PnrpdcclxuV2VDaGF0LkdhbWVfU2V0dGxlbWVudCA9IGZ1bmN0aW9uKF9BZGRfR29sZCwgX1Njb3JlKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7XHJcblx0XHRlbnY6IFwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIlxyXG5cdH0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHRuYW1lOiBcIkdhbWVfU2V0dGxlbWVudFwiLFxyXG5cdFx0Ly/kvKDlhaXlj4LmlbDvvIzljIXmi6zlop7liqDnmoTph5HluIHmlbDph4/vvIzliIbmlbBcclxuXHRcdGRhdGE6IHtcclxuXHRcdFx0QWRkX0dvbGQ6IF9BZGRfR29sZCxcclxuXHRcdFx0U2NvcmU6IF9TY29yZSxcclxuXHRcdH0sXHJcblxyXG5cdFx0c3VjY2VzcyhyZXMpIHtcclxuXHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5oiQ5Yqf5Zue6LCDXCIsIHJlcyk7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Hb2xkID0gcmVzLnJlc3VsdC5Hb2xkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuRGlhbW9uZCA9IHJlcy5yZXN1bHQuRGlhbW9uZDtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb24gPSByZXMucmVzdWx0LkNvbXBhc3Npb247XHJcblx0XHR9LFxyXG5cdFx0ZmFpbCgpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bln7rnoYDnianotYTlh7rplJlcIiwgY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/liqDovb3kuJbnlYzmjpLlkI1cclxuV2VDaGF0LkxvYWRpbmdfV29ybGRfUmFuayA9IGZ1bmN0aW9uKCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe1xyXG5cdFx0ZW52OiBcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJcclxuXHR9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFx0XHRcclxuXHRcdG5hbWU6IFwiTG9hZGluZ19Xb3JsZF9SYW5rXCIsXHJcblxyXG5cdFx0c3VjY2VzcyhyZXMpIHtcclxuXHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5LiL6L295LiW55WM5o6S5ZCN5oiQ5Yqf5Zue6LCDXCIsIHJlcyk7XHJcblx0XHRcdFJhbmtfTG9jYWxfVmFyaWJsZS5Xb3JkX1JhbmtfVXNlciA9IHJlcy5yZXN1bHQuVXNlcl9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIlJhbmtfTG9jYWxfVmFyaWJsZeS4ulwiLCBSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXJbMF0ub3BlbmlkKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4i+i9veS4lueVjOaOkuWQjeWHuumUmVwiLCBjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHR9XHJcblx0fSlcclxufVxyXG5cclxuLy/kuIrkvKDkuL7miqXjgIHnlLPor4nliJfooahcclxuV2VDaGF0LlVwbG9hZGluZ19SZXBvcnRlZF9JbmZvcm1hdGlvbiA9IGZ1bmN0aW9uKF9PcGVuaWQsIF9SZXBvcnRfQ29udGVudCkge1xyXG5cclxuXHR3eC5jbG91ZC5pbml0KHtcclxuXHRcdGVudjogXCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwiXHJcblx0fSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdG5hbWU6IFwiVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uXCIsXHJcblx0XHRkYXRhOiB7XHJcblx0XHRcdFJlcG9ydGVkX09wZW5pZDogX09wZW5pZCxcclxuXHRcdFx0UmVwb3J0X0NvbnRlbnQ6IF9SZXBvcnRfQ29udGVudCxcclxuXHRcdH0sXHJcblxyXG5cdFx0c3VjY2VzcyhyZXMpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkuL7miqXmiJDlip/lm57osINcIiwgcmVzKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCkge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4vuaKpeWHuumUmeWbnuiwg1wiLCBjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuTG9hZGluZ19DaGFyYWN0ZXI9ZnVuY3Rpb24gKCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJDaGFyYWN0ZXJcIixcclxuXHRcdFxyXG5cclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W6KeS6Imy5L+h5oGv5oiQ5YqfXCIscmVzKTtcclxuXHRcdFx0U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWFibGUuU2hvcF9DaGFyYWN0ZXJfVXNlcj1yZXMucmVzdWx0LkNoYXJhY3Rlcl9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3Rlcj1yZXMucmVzdWx0LlVzZXJfSGF2ZV9DaGFyYWN0ZXJfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W6KeS6Imy5L+h5oGv5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5Mb2FkaW5nX1Nob3BfQ2hhcmFjdGVyPWZ1bmN0aW9uKCl7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIlNob3BcIixcclxuXHRcdFxyXG5cclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5ZWG5bqX5L+h5oGv5oiQ5YqfXCIscmVzKTtcclxuXHRcdFx0U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWFibGUuU2hvcF9DaGFyYWN0ZXJfVXNlcj1yZXMucmVzdWx0LkNoYXJhY3Rlcl9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3Rlcj1yZXMucmVzdWx0LlVzZXJfSGF2ZV9DaGFyYWN0ZXJfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5ZWG5bqX5L+h5oGv5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcblxyXG4vL+WVhuW6l+i0reS5sOi3n+aWsFxyXG5XZUNoYXQuQnV5X0NoYXJhY3Rlcl9VcGRhdGU9ZnVuY3Rpb24gKF9VcGRhdGVfR29sZCxfVXBkYXRlX0NoYXJhY3Rlcikge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJTaG9wX0J1eVwiLFxyXG5cdFx0XHJcblx0XHRkYXRhOntcclxuXHRcdFx0VXBkYXRlX0dvbGQ6X1VwZGF0ZV9Hb2xkLFxyXG5cdFx0XHRVcGRhdGVfQ2hhcmFjdGVyOl9VcGRhdGVfQ2hhcmFjdGVyLFxyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0c3VjY2VzcyhyZXMpe1x0XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCLllYblupfojrflj5bmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLllYblupfojrflm57osIPlh7rplJlcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHR9XHJcblx0fSlcclxufVxyXG5cclxuV2VDaGF0LkxvYWRpbmdfQmlyZF9JbWFnZT1mdW5jdGlvbiAoQ2hhcmFjdGVyX0lkKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIkxvYWRpbmdfQmlyZF9JbWFnZVwiLFxyXG5cdFx0XHJcblx0XHRkYXRhOntcclxuXHRcdFx0Q2hhcmFjdGVyX0lkOkNoYXJhY3Rlcl9JZCxcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6KeS6Imy5Zu+5YOP6I635Y+W5oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdFx0XHJcblx0XHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0XHR1cmw6cmVzLnJlc3VsdC5DaGFyYWN0ZXJfSW1hZ2UxLFxyXG5cdFx0XHRcdHR5cGU6J2pwZydcclxuXHRcdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2UxPWZyYW1lO1xyXG5cdFx0XHR9KTtcclxuXHRcdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHRcdHVybDpyZXMucmVzdWx0LkNoYXJhY3Rlcl9JbWFnZTIsXHJcblx0XHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0XHR9LGZ1bmN0aW9uKGVycix0ZXh0dXJlLHRlc3Qpe1xyXG5cdFx0XHRcdHZhciBmcmFtZT1uZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XHJcblx0XHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi5Zu+54mH6ZSZ6K+vXCIsZXJyKTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTI9ZnJhbWU7XHJcblx0XHRcdH0pO1xyXG5cdFx0XHRjYy5sb2FkZXIubG9hZCh7XHJcblx0XHRcdFx0dXJsOnJlcy5yZXN1bHQuQ2hhcmFjdGVyX0ltYWdlMyxcclxuXHRcdFx0XHR0eXBlOidqcGcnXHJcblx0XHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XHJcblx0XHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0XHRpZihlcnIpe1xyXG5cdFx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlMz1mcmFtZTtcclxuXHRcdFx0fSk7XHJcblx0XHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0XHR1cmw6cmVzLnJlc3VsdC5DaGFyYWN0ZXJfSW1hZ2U0LFxyXG5cdFx0XHRcdHR5cGU6J2pwZydcclxuXHRcdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2U0PWZyYW1lO1xyXG5cdFx0XHR9KVxyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuinkuiJsuWbvuWDj+Wbnuiwg+WHuumUmVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5VcGRhdGluZ19DdXJyZW50X0NoYXJhY3Rlcl9pZD1mdW5jdGlvbiAoQ2hhcmFjdGVyX0lkKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIlVwZGF0aW5nX0N1cnJlbnRfQ2hhcmFjdGVyX2lkXCIsXHJcblx0XHRcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRDaGFyYWN0ZXJfSWQ6Q2hhcmFjdGVyX0lkLFxyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0c3VjY2VzcyhyZXMpe1x0XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkv67mlLnlvZPliY3op5LoibLmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19CaXJkX0ltYWdlKENoYXJhY3Rlcl9JZCk7XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5L+u5pS55b2T5YmN6KeS6Imy5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX0JpcmRfSW1hZ2UoQ2hhcmFjdGVyX0lkKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG4vL+WKoOi9veS4quS6uumCrueusVxyXG5XZUNoYXQuTG9hZGluZ19FbWFpbD1mdW5jdGlvbigpe1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJMb2FkaW5nX0VtYWlsXCIsXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsPXJlcy5yZXN1bHQuVXNlcl9FbWFpbF9JbmZvcm1hdGlvbi5kYXRhO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuiOt+WPlumCruS7tuS/oeaBr+aIkOWKn1wiLHJlcyk7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6YKu5Lu25L+h5oGv6KGoXCIsRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bpgq7ku7bkv6Hmga/lpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHR9XHJcblx0XHRcclxuXHR9KVxyXG59XHJcbi8v5Yqg6L295YWo6YOo6YKu566xXHJcbldlQ2hhdC5Mb2FkaW5nX0FsbF9FbWFpbD1mdW5jdGlvbigpe1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJMb2FkaW5nX0FsbF9FbWFpbFwiLFxyXG5cdFx0c3VjY2VzcyhyZXMpe1xyXG5cdFx0XHRFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbD1yZXMucmVzdWx0LlVzZXJfRW1haWxfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLojrflj5bpgq7ku7bkv6Hmga/miJDlip9cIixyZXMpO1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIumCruS7tuS/oeaBr+ihqFwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W6YKu5Lu25L+h5oGv5aSx6LSlXCIsY29uc29sZS5lcnJvcik7XHJcblx0XHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdFx0fVxyXG5cdFx0XHJcblx0fSlcclxufVxyXG4vL+W3suivu+WFqOmDqOmCruS7tlxyXG5XZUNoYXQuUmVhZF9BbGw9ZnVuY3Rpb24gKCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJSZWFkX0FsbFwiLFxyXG5cdFx0c3VjY2VzcyhyZXMpe1x0XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlt7Lor7vpgq7ku7bmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuW3suivu+mCruS7tuWksei0pVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuLy/liKDpmaTlt7Lor7vpgq7ku7ZcclxuV2VDaGF0LkRlbGV0ZV9SZWFkPWZ1bmN0aW9uICgpIHtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiRGVsZXRlX1JlYWRcIixcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Yig6Zmk5bey6K+76YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLliKDpmaTlt7Lor7vpgq7ku7blpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcbi8v5bey6K+75Y2V5Liq6YKu5Lu2XHJcbldlQ2hhdC5SZWFkPWZ1bmN0aW9uKF9pZCl7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIlJlYWRcIixcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRfaWQ6X2lkLFxyXG5cdFx0fSxcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5bey6K+76YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlt7Lor7vpgq7ku7blpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcbi8v5o6l5Y+X5aWW5YqxXHJcbldlQ2hhdC5BY2NlcHQ9ZnVuY3Rpb24oX2lkLF9BZGRfR29sZCxfQWRkX0RpYW1vbmQsX0FkZF9Db21wYXNzaW9uKXtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiQWNjZXB0XCIsXHJcblx0XHRkYXRhOntcclxuXHRcdFx0X2lkOl9pZCxcclxuXHRcdFx0QWRkX0dvbGQ6X0FkZF9Hb2xkLFxyXG5cdFx0XHRBZGRfRGlhbW9uZDpfQWRkX0RpYW1vbmQsXHJcblx0XHRcdEFkZF9Db21wYXNzaW9uOl9BZGRfQ29tcGFzc2lvbixcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHRcdFxyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuaOpeWPl+WlluWKseaIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHRcdEdsb2JhbF9WYXJpYWJsZS5Hb2xkID0gcmVzLnJlc3VsdC5Hb2xkO1xyXG5cdFx0XHRHbG9iYWxfVmFyaWFibGUuRGlhbW9uZCA9IHJlcy5yZXN1bHQuRGlhbW9uZDtcclxuXHRcdFx0R2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb24gPSByZXMucmVzdWx0LkNvbXBhc3Npb247XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6I635Y+W5Z+656GA54mp6LWE5Ye66ZSZXCIsIGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19SZXNvdXJjZXMoKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcbi8v5Y+R5pS+5aWW5YqxXHJcbldlQ2hhdC5Bd2FyZHNfRW1haWw9ZnVuY3Rpb24oVGltZSxUaXRsZSxDb250ZW50LEdvbGQsRGlhbW9uZCxDb21wYXNzaW9uLEVuY2xvc3VyZSl7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIkF3YXJkc1wiLFxyXG5cdFx0ZGF0YTp7XHJcblx0XHRcdFRpbWU6VGltZSxcclxuXHRcdFx0RW1haWxfVGl0bGU6VGl0bGUsXHJcblx0XHRcdEVtYWlsX0NvbnRlbnQ6Q29udGVudCxcclxuXHRcdFx0RW1haWxfR29sZDpHb2xkLFxyXG5cdFx0XHRFbWFpbF9EaWFtb25kOkRpYW1vbmQsXHJcblx0XHRcdEVtYWlsX0NvbXBhc3Npb246Q29tcGFzc2lvbixcclxuXHRcdFx0RW5jbG9zdXJlOkVuY2xvc3VyZSxcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHRcdFxyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuWPkeaUvuWlluWKseaIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHR9LFxyXG5cdFx0XHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Y+R5pS+5aWW5Yqx5aSx6LSlXCIsIGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5Mb2FkaW5nX0FsbF9Vc2VyPWZ1bmN0aW9uICgpIHtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiTG9hZGluZ19BbGxfVXNlclwiLFxyXG5cdFx0XHJcblx0XHRzdWNjZXNzKHJlcyl7XHRcdFxyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4i+i9veWFqOmDqOi0puWPt+S/oeaBr+aIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHRcdEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5BbGxfVXNlcnNfSW5mb3JtYXRpb249cmVzLnJlc3VsdC5BbGxfVXNlcnNfSW5mb3JtYXRpb24uZGF0YTtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLmn6XnnIvlhajpg6jotKblj7dcIixBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuQWxsX1VzZXJzX0luZm9ybWF0aW9uKTtcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkuIvovb3lhajpg6jotKblj7fkv6Hmga/lpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfQWxsX1VzZXIoKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuTG9hZGluZ19SZXBvcnRfVXNlcj1mdW5jdGlvbiAoX29wZW5pZCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJMb2FkaW5nX1JlcG9ydF9Vc2VyXCIsXHJcblx0XHRcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRvcGVuaWQ6X29wZW5pZCxcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdHN1Y2Nlc3MocmVzKXtcdFx0XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5LiL6L295Li+5oql5Lq65L+h5oGv5oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3Q9cmVzLnJlc3VsdC5SZXBvcnRfVXNlcl9MaXN0LmRhdGE7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5p+l55yL5omA5pyJ5Li+5oql5Lq65L+h5oGvXCIsQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3QpO1xyXG5cdFx0fSxcclxuXHRcdFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuS4i+i9veaJgOacieS4vuaKpeS6uuS/oeaBr+Wksei0pVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0XHRXZUNoYXQuTG9hZGluZ19SZXBvcnRfVXNlcihfb3BlbmlkKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuTG9hZGluZ19SZXBvcnRlcmRfVXNlcj1mdW5jdGlvbiAoKSB7XHJcblx0d3guY2xvdWQuaW5pdCh7ZW52OlwiemN4LTZnYmdkeGR5MjU0ODE2YjBcIn0pXHJcblx0d3guY2xvdWQuY2FsbEZ1bmN0aW9uKHtcclxuXHRcdC8v6LCD55So5LqR5Ye95pWwXHJcblx0XHQvL+S8oOWFpeeahOWPguaVsFxyXG5cdFx0bmFtZTpcIkxvYWRpbmdfQWxsX1JlcG9ydGVkX1VzZXJzXCIsXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5LiL6L296KKr5Li+5oql5Lq65L+h5oGv5oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uPXJlcy5yZXN1bHQuUmVwb3J0ZWRfSW5mb3JtYXRpb24ubGlzdDtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLmn6XnnIvooqvkuL7miqXkurrkv6Hmga9cIixBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb24pO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLkuIvovb3miYDmnInooqvkuL7miqXkurrkv6Hmga/lpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdFx0V2VDaGF0LkxvYWRpbmdfUmVwb3J0ZXJkX1VzZXIoKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuRW1haWxfUmVwb3J0X0FuZF9BcHBlYWw9ZnVuY3Rpb24gKFRpbWUsVGl0bGUsQ29udGVudCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJFbWFpbF9SZXBvcnRcIixcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRUaW1lOlRpbWUsXHJcblx0XHRcdEVtYWlsX1RpdGxlOlRpdGxlLFxyXG5cdFx0XHRFbWFpbF9Db250ZW50OkNvbnRlbnRcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Li+5oql6YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi5Li+5oql6YKu5Lu25Y+R6YCB5aSx6LSlXCIsY29uc29sZS5lcnJvcik7O1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5FbWFpbF9XYXJuaW5nPWZ1bmN0aW9uIChUaW1lLFRpdGxlLENvbnRlbnQsb3Blbl9pZCkge1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJFbWFpbF9XYXJuaW5nXCIsXHJcblx0XHRkYXRhOntcclxuXHRcdFx0VGltZTpUaW1lLFxyXG5cdFx0XHRFbWFpbF9UaXRsZTpUaXRsZSxcclxuXHRcdFx0RW1haWxfQ29udGVudDpDb250ZW50LFxyXG5cdFx0XHRvcGVuX2lkOm9wZW5faWRcclxuXHRcdH0sXHJcblx0XHRzdWNjZXNzKHJlcyl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6K2m5ZGK6YKu5Lu25oiQ5Yqf5Zue6LCDXCIscmVzKTtcclxuXHRcdH0sXHJcblx0XHRmYWlsKCl7XHJcblx0XHRcdGNvbnNvbGUubG9nKFwi6K2m5ZGK6YKu5Lu25Y+R6YCB5aSx6LSlXCIsY29uc29sZS5lcnJvcik7O1xyXG5cdFx0fVxyXG5cdH0pXHJcbn1cclxuXHJcbldlQ2hhdC5IYW5kbGVfUmVwb3J0ZWRfVXNlcj1mdW5jdGlvbihfb3BlbmlkKXtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiSGFuZGxlX1JlcG9ydGVkX1VzZXJcIixcclxuXHRcdGRhdGE6e1xyXG5cdFx0XHRvcGVuaWQ6X29wZW5pZFxyXG5cdFx0fSxcclxuXHRcdHN1Y2Nlc3MocmVzKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlpITnkIbooqvkuL7miqXkurrmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlpITnkIbooqvkuL7miqXkurrlpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuQ2xvc3VyZV9BY2NvdW50ID0gZnVuY3Rpb24oT3BlbmlkLElucHV0KXtcclxuXHR3eC5jbG91ZC5pbml0KHtlbnY6XCJ6Y3gtNmdiZ2R4ZHkyNTQ4MTZiMFwifSlcclxuXHR3eC5jbG91ZC5jYWxsRnVuY3Rpb24oe1xyXG5cdFx0Ly/osIPnlKjkupHlh73mlbBcclxuXHRcdC8v5Lyg5YWl55qE5Y+C5pWwXHJcblx0XHRuYW1lOlwiQ2xvc3VyZV9BY2NvdW50XCIsXHJcblx0XHRkYXRhOntcclxuXHRcdFx0UmVwb3J0ZWRfT3BlbmlkOk9wZW5pZCxcclxuXHRcdFx0Q2xvc3VyZV9UaW1lOklucHV0LFxyXG5cdFx0fSxcclxuXHRcdHN1Y2Nlc3MocmVzKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlsIHlgZzotKblj7fmiJDlip/lm57osINcIixyZXMpO1xyXG5cdFx0fSxcclxuXHRcdGZhaWwoKXtcclxuXHRcdFx0Y29uc29sZS5sb2coXCLlsIHlgZzotKblj7flpLHotKVcIixjb25zb2xlLmVycm9yKTtcclxuXHRcdH1cclxuXHR9KVxyXG59XHJcblxyXG5XZUNoYXQuQ2FuY2VsX0Nsb3N1cmUgPSBmdW5jdGlvbihPcGVuaWQpe1xyXG5cdHd4LmNsb3VkLmluaXQoe2VudjpcInpjeC02Z2JnZHhkeTI1NDgxNmIwXCJ9KVxyXG5cdHd4LmNsb3VkLmNhbGxGdW5jdGlvbih7XHJcblx0XHQvL+iwg+eUqOS6keWHveaVsFxyXG5cdFx0Ly/kvKDlhaXnmoTlj4LmlbBcclxuXHRcdG5hbWU6XCJDYW5jZWxfQ2xvc3VyZVwiLFxyXG5cdFx0ZGF0YTp7XHJcblx0XHRcdFJlcG9ydGVkX09wZW5pZDpPcGVuaWQsXHJcblx0XHR9LFxyXG5cdFx0c3VjY2VzcyhyZXMpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuino+mZpOWwgeWBnOi0puWPt+aIkOWKn+Wbnuiwg1wiLHJlcyk7XHJcblx0XHR9LFxyXG5cdFx0ZmFpbCgpe1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIuino+mZpOWwgeWBnOi0puWPt+Wksei0pVwiLGNvbnNvbGUuZXJyb3IpO1xyXG5cdFx0fVxyXG5cdH0pXHJcbn0iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Closure/Tip.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '92d67ihDSlIL5FHV3xxiZud', 'Tip');
// resources/script/Closure/Tip.js

"use strict";

//弹出提示框
cc.Class({
  "extends": cc.Component,
  properties: {
    Tip: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //提示框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    } //玩家框节点

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建申诉信息框
    var New_Tip = cc.instantiate(this.Tip);
    this.Canvas.parent.addChild(New_Tip);
    New_Tip.setPosition(0, 0);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXENsb3N1cmVcXFRpcC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIlRpcCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkNhbnZhcyIsIk5vZGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIk5ld19UaXAiLCJpbnN0YW50aWF0ZSIsInBhcmVudCIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLEdBQUcsRUFBRTtBQUNKLGlCQUFTLElBREw7QUFFSkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRkw7QUFHSkMsTUFBQUEsV0FBVyxFQUFFO0FBSFQsS0FETTtBQUtSO0FBQ0hDLElBQUFBLE1BQU0sRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUEgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNTLElBRkY7QUFHUEYsTUFBQUEsV0FBVyxFQUFFO0FBSE4sS0FORyxDQVVSOztBQVZRLEdBSEo7QUFnQlJHLEVBQUFBLEtBaEJRLG1CQWdCQSxDQUVQLENBbEJPO0FBbUJSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEI7QUFDQSxRQUFJQyxPQUFPLEdBQUdaLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlLEtBQUtULEdBQXBCLENBQWQ7QUFDQSxTQUFLSSxNQUFMLENBQVlNLE1BQVosQ0FBbUJDLFFBQW5CLENBQTRCSCxPQUE1QjtBQUNBQSxJQUFBQSxPQUFPLENBQUNJLFdBQVIsQ0FBb0IsQ0FBcEIsRUFBdUIsQ0FBdkI7QUFDQSxHQXhCTyxDQXlCUjs7QUF6QlEsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lvLnlh7rmj5DnpLrmoYZcclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0VGlwOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+aPkOekuuahhlxyXG5cdFx0Q2FudmFzOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/njqnlrrbmoYboioLngrlcclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Ly/liJvlu7rnlLPor4nkv6Hmga/moYZcclxuXHRcdHZhciBOZXdfVGlwID0gY2MuaW5zdGFudGlhdGUodGhpcy5UaXApO1xyXG5cdFx0dGhpcy5DYW52YXMucGFyZW50LmFkZENoaWxkKE5ld19UaXApO1xyXG5cdFx0TmV3X1RpcC5zZXRQb3NpdGlvbigwLCAwKTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Awards.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2e806coFMhP9JcwsZjNhFiV', 'Awards');
// resources/script/Email/Awards.js

"use strict";

var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Gold_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Diamond_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Compassoion_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Title_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Content_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Success_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //发送成功
    Fail_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已有重复邮件
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  Awards: function Awards() {
    WeChat.Loading_All_Email();
    var Title = this.Title_Label.getComponent(cc.Label).string;

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      if (Title === Email_Local_Variable.Email[i].Email_Title) {
        var Fail = cc.instantiate(this.Fail_Box);
        this.Canvas.addChild(Fail);
        Fail.setPosition(0, 0);
        return;
      }
    } //获取时间戳


    var Time = parseInt(new Date().getTime());
    var Gold = this.Gold_Label.getComponent(cc.Label).string;
    var Diamond = this.Diamond_Label.getComponent(cc.Label).string;
    var Compassion = this.Compassoion_Label.getComponent(cc.Label).string;
    var Content = this.Content_Label.getComponent(cc.Label).string;
    var Enclosure = false;
    if (Gold > 0 || Diamond > 0 || Compassion > 0) Enclosure = true;
    WeChat.Awards_Email(Time, Title, Content, Gold, Diamond, Compassion, Enclosure);
    console.log("已发送", Time, Title, Content, Gold, Diamond, Compassion, Enclosure);
    var Success = cc.instantiate(this.Success_Box);
    this.Canvas.addChild(Success);
    Success.setPosition(0, 0);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxBd2FyZHMuanMiXSwibmFtZXMiOlsiRW1haWxfTG9jYWxfVmFyaWFibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJHb2xkX0xhYmVsIiwidHlwZSIsIkxhYmVsIiwic2VyaWFsemFibGUiLCJEaWFtb25kX0xhYmVsIiwiQ29tcGFzc29pb25fTGFiZWwiLCJUaXRsZV9MYWJlbCIsIkNvbnRlbnRfTGFiZWwiLCJTdWNjZXNzX0JveCIsIlByZWZhYiIsIkZhaWxfQm94IiwiQ2FudmFzIiwiTm9kZSIsIkF3YXJkcyIsIldlQ2hhdCIsIkxvYWRpbmdfQWxsX0VtYWlsIiwiVGl0bGUiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJpIiwiRW1haWwiLCJsZW5ndGgiLCJFbWFpbF9UaXRsZSIsIkZhaWwiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJUaW1lIiwicGFyc2VJbnQiLCJEYXRlIiwiZ2V0VGltZSIsIkdvbGQiLCJEaWFtb25kIiwiQ29tcGFzc2lvbiIsIkNvbnRlbnQiLCJFbmNsb3N1cmUiLCJBd2FyZHNfRW1haWwiLCJjb25zb2xlIiwibG9nIiwiU3VjY2VzcyIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQU1BLG9CQUFvQixHQUFHQyxPQUFPLENBQUMsd0NBQUQsQ0FBcEM7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUM7QUFDUCxpQkFBUyxJQURGO0FBRWhCQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGTztBQUdoQkMsTUFBQUEsV0FBVyxFQUFFO0FBSEcsS0FESDtBQU1SQyxJQUFBQSxhQUFhLEVBQUM7QUFDVixpQkFBUyxJQURDO0FBRW5CSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGVTtBQUduQkMsTUFBQUEsV0FBVyxFQUFFO0FBSE0sS0FOTjtBQVdSRSxJQUFBQSxpQkFBaUIsRUFBQztBQUNkLGlCQUFTLElBREs7QUFFdkJKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZjO0FBR3ZCQyxNQUFBQSxXQUFXLEVBQUU7QUFIVSxLQVhWO0FBZ0JSRyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUyxJQUREO0FBRWpCTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGUTtBQUdqQkMsTUFBQUEsV0FBVyxFQUFFO0FBSEksS0FoQko7QUFxQlJJLElBQUFBLGFBQWEsRUFBQztBQUNWLGlCQUFTLElBREM7QUFFbkJOLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZVO0FBR25CQyxNQUFBQSxXQUFXLEVBQUU7QUFITSxLQXJCTjtBQTBCUkssSUFBQUEsV0FBVyxFQUFDO0FBQ1IsaUJBQVMsSUFERDtBQUVqQlAsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNhLE1BRlE7QUFHakJOLE1BQUFBLFdBQVcsRUFBRTtBQUhJLEtBMUJKO0FBOEJOO0FBQ0ZPLElBQUFBLFFBQVEsRUFBQztBQUNMLGlCQUFTLElBREo7QUFFZFQsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNhLE1BRks7QUFHZE4sTUFBQUEsV0FBVyxFQUFFO0FBSEMsS0EvQkQ7QUFtQ047QUFDRlEsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVIVixNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ2dCLElBRkw7QUFHWlQsTUFBQUEsV0FBVyxFQUFDO0FBSEE7QUFwQ0MsR0FIUDtBQThDTFUsRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2JDLElBQUFBLE1BQU0sQ0FBQ0MsaUJBQVA7QUFDQSxRQUFJQyxLQUFLLEdBQUcsS0FBS1YsV0FBTCxDQUFpQlcsWUFBakIsQ0FBOEJyQixFQUFFLENBQUNNLEtBQWpDLEVBQXdDZ0IsTUFBcEQ7O0FBQ0EsU0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUN6QixvQkFBb0IsQ0FBQzBCLEtBQXJCLENBQTJCQyxNQUF6QyxFQUFnREYsQ0FBQyxFQUFqRCxFQUFvRDtBQUNoRCxVQUFHSCxLQUFLLEtBQUd0QixvQkFBb0IsQ0FBQzBCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QkcsV0FBekMsRUFBcUQ7QUFDakQsWUFBSUMsSUFBSSxHQUFHM0IsRUFBRSxDQUFDNEIsV0FBSCxDQUFlLEtBQUtkLFFBQXBCLENBQVg7QUFDQSxhQUFLQyxNQUFMLENBQVljLFFBQVosQ0FBcUJGLElBQXJCO0FBQ0FBLFFBQUFBLElBQUksQ0FBQ0csV0FBTCxDQUFpQixDQUFqQixFQUFtQixDQUFuQjtBQUNBO0FBQ0g7QUFDSixLQVZZLENBYWI7OztBQUNBLFFBQUlDLElBQUksR0FBR0MsUUFBUSxDQUFDLElBQUlDLElBQUosR0FBV0MsT0FBWCxFQUFELENBQW5CO0FBQ0EsUUFBSUMsSUFBSSxHQUFHLEtBQUsvQixVQUFMLENBQWdCaUIsWUFBaEIsQ0FBNkJyQixFQUFFLENBQUNNLEtBQWhDLEVBQXVDZ0IsTUFBbEQ7QUFDQSxRQUFJYyxPQUFPLEdBQUcsS0FBSzVCLGFBQUwsQ0FBbUJhLFlBQW5CLENBQWdDckIsRUFBRSxDQUFDTSxLQUFuQyxFQUEwQ2dCLE1BQXhEO0FBQ0EsUUFBSWUsVUFBVSxHQUFHLEtBQUs1QixpQkFBTCxDQUF1QlksWUFBdkIsQ0FBb0NyQixFQUFFLENBQUNNLEtBQXZDLEVBQThDZ0IsTUFBL0Q7QUFDQSxRQUFJZ0IsT0FBTyxHQUFHLEtBQUszQixhQUFMLENBQW1CVSxZQUFuQixDQUFnQ3JCLEVBQUUsQ0FBQ00sS0FBbkMsRUFBMENnQixNQUF4RDtBQUNBLFFBQUlpQixTQUFTLEdBQUcsS0FBaEI7QUFDQSxRQUFHSixJQUFJLEdBQUMsQ0FBTCxJQUFRQyxPQUFPLEdBQUMsQ0FBaEIsSUFBbUJDLFVBQVUsR0FBQyxDQUFqQyxFQUFtQ0UsU0FBUyxHQUFHLElBQVo7QUFDbkNyQixJQUFBQSxNQUFNLENBQUNzQixZQUFQLENBQW9CVCxJQUFwQixFQUF5QlgsS0FBekIsRUFBK0JrQixPQUEvQixFQUF1Q0gsSUFBdkMsRUFBNENDLE9BQTVDLEVBQW9EQyxVQUFwRCxFQUErREUsU0FBL0Q7QUFDQUUsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQlgsSUFBbEIsRUFBdUJYLEtBQXZCLEVBQTZCa0IsT0FBN0IsRUFBcUNILElBQXJDLEVBQTBDQyxPQUExQyxFQUFrREMsVUFBbEQsRUFBNkRFLFNBQTdEO0FBQ0EsUUFBSUksT0FBTyxHQUFHM0MsRUFBRSxDQUFDNEIsV0FBSCxDQUFlLEtBQUtoQixXQUFwQixDQUFkO0FBQ0EsU0FBS0csTUFBTCxDQUFZYyxRQUFaLENBQXFCYyxPQUFyQjtBQUNBQSxJQUFBQSxPQUFPLENBQUNiLFdBQVIsQ0FBb0IsQ0FBcEIsRUFBc0IsQ0FBdEI7QUFFSCxHQXpFSTtBQTJFTDtBQUVBYyxFQUFBQSxLQTdFSyxtQkE2RUksQ0FFUixDQS9FSSxDQWlGTDs7QUFqRkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgRW1haWxfTG9jYWxfVmFyaWFibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIEdvbGRfTGFiZWw6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBEaWFtb25kX0xhYmVsOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgQ29tcGFzc29pb25fTGFiZWw6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBUaXRsZV9MYWJlbDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIENvbnRlbnRfTGFiZWw6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBTdWNjZXNzX0JveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcbiAgICAgICAgfSwvL+WPkemAgeaIkOWKn1xyXG4gICAgICAgIEZhaWxfQm94OntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICB9LC8v5bey5pyJ6YeN5aSN6YKu5Lu2XHJcbiAgICAgICAgQ2FudmFzOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuICAgICAgICAgICAgdHlwZTpjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgQXdhcmRzOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfQWxsX0VtYWlsKCk7XHJcbiAgICAgICAgdmFyIFRpdGxlID0gdGhpcy5UaXRsZV9MYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICBmb3IodmFyIGk9MDtpPEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICBpZihUaXRsZT09PUVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlKXtcclxuICAgICAgICAgICAgICAgIHZhciBGYWlsID0gY2MuaW5zdGFudGlhdGUodGhpcy5GYWlsX0JveCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5hZGRDaGlsZChGYWlsKTtcclxuICAgICAgICAgICAgICAgIEZhaWwuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgIFxyXG4gICAgICAgIFxyXG4gICAgICAgIC8v6I635Y+W5pe26Ze05oizXHJcbiAgICAgICAgbGV0IFRpbWUgPSBwYXJzZUludChuZXcgRGF0ZSgpLmdldFRpbWUoKSk7XHJcbiAgICAgICAgdmFyIEdvbGQgPSB0aGlzLkdvbGRfTGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgdmFyIERpYW1vbmQgPSB0aGlzLkRpYW1vbmRfTGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgdmFyIENvbXBhc3Npb24gPSB0aGlzLkNvbXBhc3NvaW9uX0xhYmVsLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgIHZhciBDb250ZW50ID0gdGhpcy5Db250ZW50X0xhYmVsLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgIHZhciBFbmNsb3N1cmUgPSBmYWxzZTtcclxuICAgICAgICBpZihHb2xkPjB8fERpYW1vbmQ+MHx8Q29tcGFzc2lvbj4wKUVuY2xvc3VyZSA9IHRydWU7XHJcbiAgICAgICAgV2VDaGF0LkF3YXJkc19FbWFpbChUaW1lLFRpdGxlLENvbnRlbnQsR29sZCxEaWFtb25kLENvbXBhc3Npb24sRW5jbG9zdXJlKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIuW3suWPkemAgVwiLFRpbWUsVGl0bGUsQ29udGVudCxHb2xkLERpYW1vbmQsQ29tcGFzc2lvbixFbmNsb3N1cmUpO1xyXG4gICAgICAgIHZhciBTdWNjZXNzID0gY2MuaW5zdGFudGlhdGUodGhpcy5TdWNjZXNzX0JveCk7XHJcbiAgICAgICAgdGhpcy5DYW52YXMuYWRkQ2hpbGQoU3VjY2Vzcyk7XHJcbiAgICAgICAgU3VjY2Vzcy5zZXRQb3NpdGlvbigwLDApO1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1f137N8wjtIf6TUMv85q+ne', 'Game');
// resources/script/Game_Coming/Game.js

"use strict";

//控制游戏进程的JS脚本
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Bird: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //载入小鸟
    Background: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //载入背景
    Fraction: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //载入分数统计
    Waterpipe_Up: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入上方水管的预制体
    Waterpipe_Down: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入下方水管的预制体
    Fall_Gold: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入金币的预制体
    Is_Start: false,
    //控制游戏是否进行
    time: 0,
    //载入时间
    Time_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //载入倒计的Label
    daojishi: 3 //设置倒计时时间

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onLoad: function onLoad() {
    Game_Local_Varible.Gold = 0;
    Game_Local_Varible.Fraction = 0;
    this.Bird.node.active = false;
    this.Background.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
    cc.loader.load({
      url: 'https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/music/Background_Music.mp3?sign=386a04ae0314e518d75477e111518b42&t=1610622832',
      type: 'mp3'
    }, function (err, data) {
      console.log(data);
      cc.audioEngine.playMusic(data);
    }); //cc.audioEngine.play("https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/music/Background_Music.mp3?sign=386a04ae0314e518d75477e111518b42&t=1610622832", false,0.1);
  },
  start: function start() {
    this.Time_Label.string = 3; //  场景文本框为 显示3

    this.daojishi = 3;

    if (this.daojishi >= 0) {
      this.schedule(function () {
        // 计时器将每隔 1s 执行一次。
        this.DoSomething();

        if (this.daojishi == 0) {
          this.Time_Label.enabled = false;
          this.Is_Start = true;
          this.Bird.node.active = true;
        }
      }, 1);
    }
  },
  update: function update(dt) {
    this.time += 1;
    this.gainScore(); //每隔一段时间生成一个水管

    if (this.time % 100 == 0 && this.Is_Start) {
      this.spawnNewWaterpipe();
    } //如果小鸟飞出了界面，游戏结束，进行跳转。


    if (this.Bird.node.y > 2000) {
      cc.director.loadScene("Game_Over");
    }
  },
  //随机生成新的水管
  spawnNewWaterpipe: function spawnNewWaterpipe() {
    var Waterpipe_Up_randY = Math.random() * 400 + 800 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 200; //随机生成上方水管的坐标

    var Waterpipe_Down_randY = Waterpipe_Up_randY - Math.random() * 200 - 2000 + 200 * Game_Difficulty_Local_Varible.Difficulty_Ratio; //随机生成下方水管的坐标

    var Gold_randY = (Waterpipe_Up_randY + Waterpipe_Down_randY) / 2; //再水管中间生成金币的坐标

    var randX = 700; //生成水管的X坐标
    //生成新的水管和进行，并且把他们加入到画布中

    var New_Waterpipe_Up = cc.instantiate(this.Waterpipe_Up);
    this.node.addChild(New_Waterpipe_Up);
    New_Waterpipe_Up.setPosition(randX, Waterpipe_Up_randY);
    var New_Waterpipe_Down = cc.instantiate(this.Waterpipe_Down);
    this.node.addChild(New_Waterpipe_Down);
    New_Waterpipe_Down.setPosition(randX, Waterpipe_Down_randY);
    var New_Fall_Gold = cc.instantiate(this.Fall_Gold);
    this.node.addChild(New_Fall_Gold);
    New_Fall_Gold.setPosition(randX, Gold_randY);
  },
  gainScore: function gainScore() {
    // 更新 scoreDisplay Label 的文字
    this.Fraction.string = 'Score: ' + Game_Local_Varible.Fraction / 2;
  },
  DoSomething: function DoSomething() {
    // 倒计时算法
    if (this.daojishi >= 1) {
      this.daojishi = this.daojishi - 1;
      this.Time_Label.string = this.daojishi; //场景中文本框显示 
      //cc.log("daojishi=" + this.daojishi);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxHYW1lLmpzIl0sIm5hbWVzIjpbIkdhbWVfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQmlyZCIsInR5cGUiLCJTcHJpdGUiLCJzZXJpYWx6YWJsZSIsIkJhY2tncm91bmQiLCJGcmFjdGlvbiIsIkxhYmVsIiwiV2F0ZXJwaXBlX1VwIiwiUHJlZmFiIiwiV2F0ZXJwaXBlX0Rvd24iLCJGYWxsX0dvbGQiLCJJc19TdGFydCIsInRpbWUiLCJUaW1lX0xhYmVsIiwiZGFvamlzaGkiLCJvbkxvYWQiLCJHb2xkIiwibm9kZSIsImFjdGl2ZSIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwiQ3VycmVudF9NYXAiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwiZGF0YSIsImNvbnNvbGUiLCJsb2ciLCJhdWRpb0VuZ2luZSIsInBsYXlNdXNpYyIsInN0YXJ0Iiwic3RyaW5nIiwic2NoZWR1bGUiLCJEb1NvbWV0aGluZyIsImVuYWJsZWQiLCJ1cGRhdGUiLCJkdCIsImdhaW5TY29yZSIsInNwYXduTmV3V2F0ZXJwaXBlIiwieSIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwiV2F0ZXJwaXBlX1VwX3JhbmRZIiwiTWF0aCIsInJhbmRvbSIsIkRpZmZpY3VsdHlfUmF0aW8iLCJXYXRlcnBpcGVfRG93bl9yYW5kWSIsIkdvbGRfcmFuZFkiLCJyYW5kWCIsIk5ld19XYXRlcnBpcGVfVXAiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJOZXdfV2F0ZXJwaXBlX0Rvd24iLCJOZXdfRmFsbF9Hb2xkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxvQkFBRCxDQUFoQzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBR0QsT0FBTyxDQUFDLCtCQUFELENBQTNDOztBQUNBRSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFHWEMsSUFBQUEsSUFBSSxFQUFFO0FBQ0wsaUJBQVMsSUFESjtBQUVMQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGSjtBQUdMQyxNQUFBQSxXQUFXLEVBQUU7QUFIUixLQUhLO0FBT1I7QUFDSEMsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGRTtBQUdYQyxNQUFBQSxXQUFXLEVBQUU7QUFIRixLQVJEO0FBWVI7QUFDSEUsSUFBQUEsUUFBUSxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1UsS0FGQTtBQUdUSCxNQUFBQSxXQUFXLEVBQUU7QUFISixLQWJDO0FBaUJSO0FBQ0hJLElBQUFBLFlBQVksRUFBRTtBQUNiLGlCQUFTLElBREk7QUFFYk4sTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNZLE1BRkk7QUFHYkwsTUFBQUEsV0FBVyxFQUFFO0FBSEEsS0FsQkg7QUFzQlI7QUFDSE0sSUFBQUEsY0FBYyxFQUFFO0FBQ2YsaUJBQVMsSUFETTtBQUVmUixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1ksTUFGTTtBQUdmTCxNQUFBQSxXQUFXLEVBQUU7QUFIRSxLQXZCTDtBQTJCUjtBQUNITyxJQUFBQSxTQUFTLEVBQUU7QUFDVixpQkFBUyxJQURDO0FBRVZULE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDWSxNQUZDO0FBR1ZMLE1BQUFBLFdBQVcsRUFBRTtBQUhILEtBNUJBO0FBZ0NSO0FBQ0hRLElBQUFBLFFBQVEsRUFBRSxLQWpDQztBQWlDTTtBQUNqQkMsSUFBQUEsSUFBSSxFQUFFLENBbENLO0FBa0NGO0FBQ1RDLElBQUFBLFVBQVUsRUFBRTtBQUNYLGlCQUFTLElBREU7QUFFWFosTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNVLEtBRkU7QUFHWEgsTUFBQUEsV0FBVyxFQUFFO0FBSEYsS0FuQ0Q7QUF1Q1I7QUFDSFcsSUFBQUEsUUFBUSxFQUFFLENBeENDLENBd0NFOztBQXhDRixHQUhKO0FBNkNSO0FBQ0E7QUFDQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCdEIsSUFBQUEsa0JBQWtCLENBQUN1QixJQUFuQixHQUEwQixDQUExQjtBQUNBdkIsSUFBQUEsa0JBQWtCLENBQUNZLFFBQW5CLEdBQThCLENBQTlCO0FBQ0EsU0FBS0wsSUFBTCxDQUFVaUIsSUFBVixDQUFlQyxNQUFmLEdBQXdCLEtBQXhCO0FBQ0EsU0FBS2QsVUFBTCxDQUFnQmUsWUFBaEIsQ0FBNkJ2QixFQUFFLENBQUNNLE1BQWhDLEVBQXdDa0IsV0FBeEMsR0FBc0QzQixrQkFBa0IsQ0FBQzRCLFdBQXpFO0FBQ0F6QixJQUFBQSxFQUFFLENBQUMwQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUFDQyxNQUFBQSxHQUFHLEVBQUMsMElBQUw7QUFBaUp2QixNQUFBQSxJQUFJLEVBQUU7QUFBdkosS0FBZixFQUE4SyxVQUFVd0IsR0FBVixFQUFlQyxJQUFmLEVBQXFCO0FBQ2xNQyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsSUFBWjtBQUNBOUIsTUFBQUEsRUFBRSxDQUFDaUMsV0FBSCxDQUFlQyxTQUFmLENBQXlCSixJQUF6QjtBQUNDLEtBSEYsRUFMa0IsQ0FTbEI7QUFDQSxHQXpETztBQTJEUkssRUFBQUEsS0FBSyxFQUFFLGlCQUFXO0FBQ2pCLFNBQUtsQixVQUFMLENBQWdCbUIsTUFBaEIsR0FBeUIsQ0FBekIsQ0FEaUIsQ0FDVzs7QUFDNUIsU0FBS2xCLFFBQUwsR0FBZ0IsQ0FBaEI7O0FBQ0EsUUFBSSxLQUFLQSxRQUFMLElBQWlCLENBQXJCLEVBQXdCO0FBQ3ZCLFdBQUttQixRQUFMLENBQWMsWUFBVztBQUFFO0FBQzFCLGFBQUtDLFdBQUw7O0FBQ0EsWUFBSSxLQUFLcEIsUUFBTCxJQUFpQixDQUFyQixFQUF3QjtBQUN2QixlQUFLRCxVQUFMLENBQWdCc0IsT0FBaEIsR0FBMEIsS0FBMUI7QUFDQSxlQUFLeEIsUUFBTCxHQUFnQixJQUFoQjtBQUNBLGVBQUtYLElBQUwsQ0FBVWlCLElBQVYsQ0FBZUMsTUFBZixHQUF3QixJQUF4QjtBQUNBO0FBQ0QsT0FQRCxFQU9HLENBUEg7QUFRQTtBQUNELEdBeEVPO0FBeUVSa0IsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEIsU0FBS3pCLElBQUwsSUFBYSxDQUFiO0FBQ0EsU0FBSzBCLFNBQUwsR0FGb0IsQ0FHcEI7O0FBQ0EsUUFBSSxLQUFLMUIsSUFBTCxHQUFZLEdBQVosSUFBbUIsQ0FBbkIsSUFBd0IsS0FBS0QsUUFBakMsRUFBMkM7QUFDMUMsV0FBSzRCLGlCQUFMO0FBQ0EsS0FObUIsQ0FPcEI7OztBQUNBLFFBQUksS0FBS3ZDLElBQUwsQ0FBVWlCLElBQVYsQ0FBZXVCLENBQWYsR0FBbUIsSUFBdkIsRUFBNkI7QUFDNUI1QyxNQUFBQSxFQUFFLENBQUM2QyxRQUFILENBQVlDLFNBQVosQ0FBc0IsV0FBdEI7QUFDQTtBQUNELEdBcEZPO0FBcUZSO0FBQ0FILEVBQUFBLGlCQXRGUSwrQkFzRlk7QUFDbkIsUUFBSUksa0JBQWtCLEdBQUdDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFoQixHQUFzQixHQUF0QixHQUE0QmxELDZCQUE2QixDQUFDbUQsZ0JBQTlCLEdBQWlELEdBQXRHLENBRG1CLENBQ3dGOztBQUMzRyxRQUFJQyxvQkFBb0IsR0FBR0osa0JBQWtCLEdBQUdDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFyQyxHQUEyQyxJQUEzQyxHQUFrRCxNQUFNbEQsNkJBQTZCLENBQUNtRCxnQkFBakgsQ0FGbUIsQ0FFZ0g7O0FBQ25JLFFBQUlFLFVBQVUsR0FBRyxDQUFDTCxrQkFBa0IsR0FBR0ksb0JBQXRCLElBQThDLENBQS9ELENBSG1CLENBRytDOztBQUNsRSxRQUFJRSxLQUFLLEdBQUcsR0FBWixDQUptQixDQUlGO0FBQ2pCOztBQUNBLFFBQUlDLGdCQUFnQixHQUFHdEQsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLEtBQUs1QyxZQUFwQixDQUF2QjtBQUNBLFNBQUtVLElBQUwsQ0FBVW1DLFFBQVYsQ0FBbUJGLGdCQUFuQjtBQUNBQSxJQUFBQSxnQkFBZ0IsQ0FBQ0csV0FBakIsQ0FBNkJKLEtBQTdCLEVBQW9DTixrQkFBcEM7QUFFQSxRQUFJVyxrQkFBa0IsR0FBRzFELEVBQUUsQ0FBQ3VELFdBQUgsQ0FBZSxLQUFLMUMsY0FBcEIsQ0FBekI7QUFDQSxTQUFLUSxJQUFMLENBQVVtQyxRQUFWLENBQW1CRSxrQkFBbkI7QUFDQUEsSUFBQUEsa0JBQWtCLENBQUNELFdBQW5CLENBQStCSixLQUEvQixFQUFzQ0Ysb0JBQXRDO0FBRUEsUUFBSVEsYUFBYSxHQUFHM0QsRUFBRSxDQUFDdUQsV0FBSCxDQUFlLEtBQUt6QyxTQUFwQixDQUFwQjtBQUNBLFNBQUtPLElBQUwsQ0FBVW1DLFFBQVYsQ0FBbUJHLGFBQW5CO0FBQ0FBLElBQUFBLGFBQWEsQ0FBQ0YsV0FBZCxDQUEwQkosS0FBMUIsRUFBaUNELFVBQWpDO0FBRUEsR0F4R087QUF5R1JWLEVBQUFBLFNBekdRLHVCQXlHSTtBQUNYO0FBQ0EsU0FBS2pDLFFBQUwsQ0FBYzJCLE1BQWQsR0FBdUIsWUFBYXZDLGtCQUFrQixDQUFDWSxRQUFuQixHQUE4QixDQUFsRTtBQUVBLEdBN0dPO0FBOEdSNkIsRUFBQUEsV0E5R1EseUJBOEdNO0FBQUU7QUFDZixRQUFJLEtBQUtwQixRQUFMLElBQWlCLENBQXJCLEVBQXdCO0FBQ3ZCLFdBQUtBLFFBQUwsR0FBZ0IsS0FBS0EsUUFBTCxHQUFnQixDQUFoQztBQUNBLFdBQUtELFVBQUwsQ0FBZ0JtQixNQUFoQixHQUF5QixLQUFLbEIsUUFBOUIsQ0FGdUIsQ0FFaUI7QUFDeEM7QUFDQTtBQUNEO0FBcEhPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5o6n5Yi25ri45oiP6L+b56iL55qESlPohJrmnKxcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblxyXG5cclxuXHRcdEJpcmQ6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuU3ByaXRlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6L295YWl5bCP6bifXHJcblx0XHRCYWNrZ3JvdW5kOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlNwcml0ZSxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i9veWFpeiDjOaZr1xyXG5cdFx0RnJhY3Rpb246IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ovb3lhaXliIbmlbDnu5/orqFcclxuXHRcdFdhdGVycGlwZV9VcDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ovb3lhaXkuIrmlrnmsLTnrqHnmoTpooTliLbkvZNcclxuXHRcdFdhdGVycGlwZV9Eb3duOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i9veWFpeS4i+aWueawtOeuoeeahOmihOWItuS9k1xyXG5cdFx0RmFsbF9Hb2xkOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i9veWFpemHkeW4geeahOmihOWItuS9k1xyXG5cdFx0SXNfU3RhcnQ6IGZhbHNlLCAvL+aOp+WItua4uOaIj+aYr+WQpui/m+ihjFxyXG5cdFx0dGltZTogMCwgLy/ovb3lhaXml7bpl7RcclxuXHRcdFRpbWVfTGFiZWw6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ovb3lhaXlgJLorqHnmoRMYWJlbFxyXG5cdFx0ZGFvamlzaGk6IDMsIC8v6K6+572u5YCS6K6h5pe25pe26Ze0XHJcblx0fSxcclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblx0b25Mb2FkOiBmdW5jdGlvbigpIHtcclxuXHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5Hb2xkID0gMDtcclxuXHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiA9IDA7XHJcblx0XHR0aGlzLkJpcmQubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuXHRcdHRoaXMuQmFja2dyb3VuZC5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IEdhbWVfTG9jYWxfVmFyaWJsZS5DdXJyZW50X01hcDtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHt1cmw6J2h0dHBzOi8vN2E2My16Y3gtNmdiZ2R4ZHkyNTQ4MTZiMC0xMzA0MzQyOTQ3LnRjYi5xY2xvdWQubGEvbXVzaWMvQmFja2dyb3VuZF9NdXNpYy5tcDM/c2lnbj0zODZhMDRhZTAzMTRlNTE4ZDc1NDc3ZTExMTUxOGI0MiZ0PTE2MTA2MjI4MzInLCB0eXBlOiAnbXAzJ30sIGZ1bmN0aW9uIChlcnIsIGRhdGEpIHtcclxuXHRcdFx0Y29uc29sZS5sb2coZGF0YSk7XHJcblx0XHRcdGNjLmF1ZGlvRW5naW5lLnBsYXlNdXNpYyhkYXRhKTtcclxuXHRcdFx0fSk7XHJcblx0XHQvL2NjLmF1ZGlvRW5naW5lLnBsYXkoXCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL211c2ljL0JhY2tncm91bmRfTXVzaWMubXAzP3NpZ249Mzg2YTA0YWUwMzE0ZTUxOGQ3NTQ3N2UxMTE1MThiNDImdD0xNjEwNjIyODMyXCIsIGZhbHNlLDAuMSk7XHJcblx0fSxcclxuXHJcblx0c3RhcnQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dGhpcy5UaW1lX0xhYmVsLnN0cmluZyA9IDM7IC8vICDlnLrmma/mlofmnKzmoYbkuLog5pi+56S6M1xyXG5cdFx0dGhpcy5kYW9qaXNoaSA9IDM7XHJcblx0XHRpZiAodGhpcy5kYW9qaXNoaSA+PSAwKSB7XHJcblx0XHRcdHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7IC8vIOiuoeaXtuWZqOWwhuavj+malCAxcyDmiafooYzkuIDmrKHjgIJcclxuXHRcdFx0XHR0aGlzLkRvU29tZXRoaW5nKCk7XHJcblx0XHRcdFx0aWYgKHRoaXMuZGFvamlzaGkgPT0gMCkge1xyXG5cdFx0XHRcdFx0dGhpcy5UaW1lX0xhYmVsLmVuYWJsZWQgPSBmYWxzZTtcclxuXHRcdFx0XHRcdHRoaXMuSXNfU3RhcnQgPSB0cnVlO1xyXG5cdFx0XHRcdFx0dGhpcy5CaXJkLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0sIDEpO1xyXG5cdFx0fVxyXG5cdH0sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0dGhpcy50aW1lICs9IDE7XHJcblx0XHR0aGlzLmdhaW5TY29yZSgpO1x0XHJcblx0XHQvL+avj+malOS4gOauteaXtumXtOeUn+aIkOS4gOS4quawtOeuoVxyXG5cdFx0aWYgKHRoaXMudGltZSAlIDEwMCA9PSAwICYmIHRoaXMuSXNfU3RhcnQpIHtcclxuXHRcdFx0dGhpcy5zcGF3bk5ld1dhdGVycGlwZSgpO1xyXG5cdFx0fVxyXG5cdFx0Ly/lpoLmnpzlsI/puJ/po57lh7rkuobnlYzpnaLvvIzmuLjmiI/nu5PmnZ/vvIzov5vooYzot7PovazjgIJcclxuXHRcdGlmICh0aGlzLkJpcmQubm9kZS55ID4gMjAwMCkge1xyXG5cdFx0XHRjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lX092ZXJcIik7XHJcblx0XHR9XHJcblx0fSxcclxuXHQvL+maj+acuueUn+aIkOaWsOeahOawtOeuoVxyXG5cdHNwYXduTmV3V2F0ZXJwaXBlKCkge1xyXG5cdFx0dmFyIFdhdGVycGlwZV9VcF9yYW5kWSA9IE1hdGgucmFuZG9tKCkgKiA0MDAgKyA4MDAgKyBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICogMjAwOyAvL+maj+acuueUn+aIkOS4iuaWueawtOeuoeeahOWdkOagh1xyXG5cdFx0dmFyIFdhdGVycGlwZV9Eb3duX3JhbmRZID0gV2F0ZXJwaXBlX1VwX3JhbmRZIC0gTWF0aC5yYW5kb20oKSAqIDIwMCAtIDIwMDAgKyAyMDAgKiBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvOyAvL+maj+acuueUn+aIkOS4i+aWueawtOeuoeeahOWdkOagh1xyXG5cdFx0dmFyIEdvbGRfcmFuZFkgPSAoV2F0ZXJwaXBlX1VwX3JhbmRZICsgV2F0ZXJwaXBlX0Rvd25fcmFuZFkpIC8gMjsgLy/lho3msLTnrqHkuK3pl7TnlJ/miJDph5HluIHnmoTlnZDmoIdcclxuXHRcdHZhciByYW5kWCA9IDcwMDsgLy/nlJ/miJDmsLTnrqHnmoRY5Z2Q5qCHXHJcblx0XHQvL+eUn+aIkOaWsOeahOawtOeuoeWSjOi/m+ihjO+8jOW5tuS4lOaKiuS7luS7rOWKoOWFpeWIsOeUu+W4g+S4rVxyXG5cdFx0dmFyIE5ld19XYXRlcnBpcGVfVXAgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLldhdGVycGlwZV9VcCk7XHJcblx0XHR0aGlzLm5vZGUuYWRkQ2hpbGQoTmV3X1dhdGVycGlwZV9VcCk7XHJcblx0XHROZXdfV2F0ZXJwaXBlX1VwLnNldFBvc2l0aW9uKHJhbmRYLCBXYXRlcnBpcGVfVXBfcmFuZFkpO1xyXG5cclxuXHRcdHZhciBOZXdfV2F0ZXJwaXBlX0Rvd24gPSBjYy5pbnN0YW50aWF0ZSh0aGlzLldhdGVycGlwZV9Eb3duKTtcclxuXHRcdHRoaXMubm9kZS5hZGRDaGlsZChOZXdfV2F0ZXJwaXBlX0Rvd24pO1xyXG5cdFx0TmV3X1dhdGVycGlwZV9Eb3duLnNldFBvc2l0aW9uKHJhbmRYLCBXYXRlcnBpcGVfRG93bl9yYW5kWSk7XHJcblxyXG5cdFx0dmFyIE5ld19GYWxsX0dvbGQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkZhbGxfR29sZCk7XHJcblx0XHR0aGlzLm5vZGUuYWRkQ2hpbGQoTmV3X0ZhbGxfR29sZCk7XHJcblx0XHROZXdfRmFsbF9Hb2xkLnNldFBvc2l0aW9uKHJhbmRYLCBHb2xkX3JhbmRZKTtcclxuXHJcblx0fSxcclxuXHRnYWluU2NvcmUoKSB7XHJcblx0XHQvLyDmm7TmlrAgc2NvcmVEaXNwbGF5IExhYmVsIOeahOaWh+Wtl1xyXG5cdFx0dGhpcy5GcmFjdGlvbi5zdHJpbmcgPSAnU2NvcmU6ICcgKyAoR2FtZV9Mb2NhbF9WYXJpYmxlLkZyYWN0aW9uIC8gMik7XHJcblxyXG5cdH0sXHJcblx0RG9Tb21ldGhpbmcoKSB7IC8vIOWAkuiuoeaXtueul+azlVxyXG5cdFx0aWYgKHRoaXMuZGFvamlzaGkgPj0gMSkge1xyXG5cdFx0XHR0aGlzLmRhb2ppc2hpID0gdGhpcy5kYW9qaXNoaSAtIDE7XHJcblx0XHRcdHRoaXMuVGltZV9MYWJlbC5zdHJpbmcgPSB0aGlzLmRhb2ppc2hpOyAvL+WcuuaZr+S4reaWh+acrOahhuaYvuekuiBcclxuXHRcdFx0Ly9jYy5sb2coXCJkYW9qaXNoaT1cIiArIHRoaXMuZGFvamlzaGkpO1xyXG5cdFx0fVxyXG5cdH1cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Friends/Show_Friends.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1cdc5cSgyZOzKo5C1dUkTPd', 'Show_Friends');
// resources/script/Friends/Show_Friends.js

"use strict";

//加载好友
cc.Class({
  "extends": cc.Component,
  properties: {
    WXSubContextView: cc.SubContextView,
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    console.log("显示排行榜"); //获取时间戳

    var updateTime = parseInt(new Date().getTime() / 1000);
    var getArr = new Array(); //声明向开放数据域传递的变量

    var openDataContext = wx.getOpenDataContext(); //声明开发数据域

    var setArr = [{
      key: "score",
      value: String(Global_Variable.Best_Score)
    }];
    getArr.push("score"); //将score压入开放数据域
    //向开发数据域声明获取好友

    openDataContext.postMessage({
      type: "GET",
      data: getArr,
      timer: updateTime
    }); //将自己的成绩送入开放数据域

    console.log(setArr);
    openDataContext.postMessage({
      type: "SET",
      data: setArr,
      timer: updateTime
    });
    console.log("设置的信息为", setArr); //显示开放数据域

    this.SubContextView = null;
    this._Is_Loading = true;
    this.SubContextView = this.WXSubContextView.getComponent(cc.SubContextView);
    console.log("加载好友框中");
    this.SubContextView.enabled = true;
    this.SubContextView.active = true;
    console.log("加载好友框中");
    this.SubContextView.update();
    console.log("特别正常");
  },
  start: function start() {},
  update: function update(dt) {//加载好友框
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEZyaWVuZHNcXFNob3dfRnJpZW5kcy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIldYU3ViQ29udGV4dFZpZXciLCJTdWJDb250ZXh0VmlldyIsIl9Jc19Mb2FkaW5nIiwib25Mb2FkIiwiY29uc29sZSIsImxvZyIsInVwZGF0ZVRpbWUiLCJwYXJzZUludCIsIkRhdGUiLCJnZXRUaW1lIiwiZ2V0QXJyIiwiQXJyYXkiLCJvcGVuRGF0YUNvbnRleHQiLCJ3eCIsImdldE9wZW5EYXRhQ29udGV4dCIsInNldEFyciIsImtleSIsInZhbHVlIiwiU3RyaW5nIiwiR2xvYmFsX1ZhcmlhYmxlIiwiQmVzdF9TY29yZSIsInB1c2giLCJwb3N0TWVzc2FnZSIsInR5cGUiLCJkYXRhIiwidGltZXIiLCJnZXRDb21wb25lbnQiLCJlbmFibGVkIiwiYWN0aXZlIiwidXBkYXRlIiwic3RhcnQiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsZ0JBQWdCLEVBQUVKLEVBQUUsQ0FBQ0ssY0FEVjtBQUVYQyxJQUFBQSxXQUFXLEVBQUM7QUFGRCxHQUhKO0FBVVJDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVztBQUNsQkMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQURrQixDQUVsQjs7QUFDQSxRQUFJQyxVQUFVLEdBQUdDLFFBQVEsQ0FBQyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsS0FBdUIsSUFBeEIsQ0FBekI7QUFDQSxRQUFJQyxNQUFNLEdBQUcsSUFBSUMsS0FBSixFQUFiLENBSmtCLENBSVE7O0FBQzFCLFFBQUlDLGVBQWUsR0FBR0MsRUFBRSxDQUFDQyxrQkFBSCxFQUF0QixDQUxrQixDQUs2Qjs7QUFDL0MsUUFBSUMsTUFBTSxHQUFHLENBQUM7QUFDYkMsTUFBQUEsR0FBRyxFQUFFLE9BRFE7QUFFYkMsTUFBQUEsS0FBSyxFQUFFQyxNQUFNLENBQUNDLGVBQWUsQ0FBQ0MsVUFBakI7QUFGQSxLQUFELENBQWI7QUFJQVYsSUFBQUEsTUFBTSxDQUFDVyxJQUFQLENBQVksT0FBWixFQVZrQixDQVVJO0FBRXRCOztBQUNBVCxJQUFBQSxlQUFlLENBQUNVLFdBQWhCLENBQTRCO0FBQzNCQyxNQUFBQSxJQUFJLEVBQUUsS0FEcUI7QUFFM0JDLE1BQUFBLElBQUksRUFBRWQsTUFGcUI7QUFHM0JlLE1BQUFBLEtBQUssRUFBRW5CO0FBSG9CLEtBQTVCLEVBYmtCLENBbUJsQjs7QUFDQUYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlVLE1BQVo7QUFDQUgsSUFBQUEsZUFBZSxDQUFDVSxXQUFoQixDQUE0QjtBQUMzQkMsTUFBQUEsSUFBSSxFQUFFLEtBRHFCO0FBRTNCQyxNQUFBQSxJQUFJLEVBQUVULE1BRnFCO0FBRzNCVSxNQUFBQSxLQUFLLEVBQUVuQjtBQUhvQixLQUE1QjtBQUtBRixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCVSxNQUF0QixFQTFCa0IsQ0EyQmxCOztBQUNBLFNBQUtkLGNBQUwsR0FBc0IsSUFBdEI7QUFDQSxTQUFLQyxXQUFMLEdBQWlCLElBQWpCO0FBQ0EsU0FBS0QsY0FBTCxHQUFzQixLQUFLRCxnQkFBTCxDQUFzQjBCLFlBQXRCLENBQW1DOUIsRUFBRSxDQUFDSyxjQUF0QyxDQUF0QjtBQUNBRyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0EsU0FBS0osY0FBTCxDQUFvQjBCLE9BQXBCLEdBQThCLElBQTlCO0FBQ0EsU0FBSzFCLGNBQUwsQ0FBb0IyQixNQUFwQixHQUE2QixJQUE3QjtBQUNBeEIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBLFNBQUtKLGNBQUwsQ0FBb0I0QixNQUFwQjtBQUNBekIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBLEdBL0NPO0FBaURSeUIsRUFBQUEsS0FqRFEsbUJBaURBLENBRVAsQ0FuRE87QUFxRFJELEVBQUFBLE1BQU0sRUFBQyxnQkFBU0UsRUFBVCxFQUFhLENBQ25CO0FBQ0E7QUF2RE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/liqDovb3lpb3lj4tcclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0V1hTdWJDb250ZXh0VmlldzogY2MuU3ViQ29udGV4dFZpZXcsXHJcblx0XHRfSXNfTG9hZGluZzp0cnVlLFxyXG5cdFx0XHJcblx0fSxcclxuXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHRjb25zb2xlLmxvZyhcIuaYvuekuuaOkuihjOamnFwiKTtcclxuXHRcdC8v6I635Y+W5pe26Ze05oizXHJcblx0XHRsZXQgdXBkYXRlVGltZSA9IHBhcnNlSW50KG5ldyBEYXRlKCkuZ2V0VGltZSgpIC8gMTAwMCk7XHJcblx0XHRsZXQgZ2V0QXJyID0gbmV3IEFycmF5KCk7IC8v5aOw5piO5ZCR5byA5pS+5pWw5o2u5Z+f5Lyg6YCS55qE5Y+Y6YePXHJcblx0XHRsZXQgb3BlbkRhdGFDb250ZXh0ID0gd3guZ2V0T3BlbkRhdGFDb250ZXh0KCk7IC8v5aOw5piO5byA5Y+R5pWw5o2u5Z+fXHJcblx0XHRsZXQgc2V0QXJyID0gW3tcclxuXHRcdFx0a2V5OiBcInNjb3JlXCIsXHJcblx0XHRcdHZhbHVlOiBTdHJpbmcoR2xvYmFsX1ZhcmlhYmxlLkJlc3RfU2NvcmUpXHJcblx0XHR9XTtcclxuXHRcdGdldEFyci5wdXNoKFwic2NvcmVcIik7IC8v5bCGc2NvcmXljovlhaXlvIDmlL7mlbDmja7ln59cclxuXHJcblx0XHQvL+WQkeW8gOWPkeaVsOaNruWfn+WjsOaYjuiOt+WPluWlveWPi1xyXG5cdFx0b3BlbkRhdGFDb250ZXh0LnBvc3RNZXNzYWdlKHtcclxuXHRcdFx0dHlwZTogXCJHRVRcIixcclxuXHRcdFx0ZGF0YTogZ2V0QXJyLFxyXG5cdFx0XHR0aW1lcjogdXBkYXRlVGltZVxyXG5cdFx0fSlcclxuXHJcblx0XHQvL+WwhuiHquW3seeahOaIkOe7qemAgeWFpeW8gOaUvuaVsOaNruWfn1xyXG5cdFx0Y29uc29sZS5sb2coc2V0QXJyKTtcclxuXHRcdG9wZW5EYXRhQ29udGV4dC5wb3N0TWVzc2FnZSh7XHJcblx0XHRcdHR5cGU6IFwiU0VUXCIsXHJcblx0XHRcdGRhdGE6IHNldEFycixcclxuXHRcdFx0dGltZXI6IHVwZGF0ZVRpbWVcclxuXHRcdH0pXHJcblx0XHRjb25zb2xlLmxvZyhcIuiuvue9rueahOS/oeaBr+S4ulwiLCBzZXRBcnIpO1xyXG5cdFx0Ly/mmL7npLrlvIDmlL7mlbDmja7ln59cclxuXHRcdHRoaXMuU3ViQ29udGV4dFZpZXcgPSBudWxsO1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz10cnVlO1xyXG5cdFx0dGhpcy5TdWJDb250ZXh0VmlldyA9IHRoaXMuV1hTdWJDb250ZXh0Vmlldy5nZXRDb21wb25lbnQoY2MuU3ViQ29udGV4dFZpZXcpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLliqDovb3lpb3lj4vmoYbkuK1cIik7XHJcblx0XHR0aGlzLlN1YkNvbnRleHRWaWV3LmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0dGhpcy5TdWJDb250ZXh0Vmlldy5hY3RpdmUgPSB0cnVlO1xyXG5cdFx0Y29uc29sZS5sb2coXCLliqDovb3lpb3lj4vmoYbkuK1cIik7XHJcblx0XHR0aGlzLlN1YkNvbnRleHRWaWV3LnVwZGF0ZSgpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLnibnliKvmraPluLhcIik7XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZTpmdW5jdGlvbihkdCkge1xyXG5cdFx0Ly/liqDovb3lpb3lj4vmoYZcclxuXHR9LFxyXG5cdFxyXG5cclxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Login/WX_Login.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '87438YORgpMZrY2yjMH+Zna', 'WX_Login');
// resources/script/Game_Login/WX_Login.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  onLoad: function onLoad() {
    //调用微信登录函数，登录游戏
    wx.login({
      success: function success(res) {
        if (res.code) {
          console.log("登录成功，获取到code", res.code);
        }

        var button = wx.createUserInfoButton({
          type: 'text',
          text: '开始游戏',
          style: {
            left: wx.getSystemInfoSync().screenWidth / 2 - 60,
            top: wx.getSystemInfoSync().screenHeight / 2 - 60,
            width: 120,
            height: 40,
            lineHeight: 40,
            backgroundColor: '#00aa00',
            color: '#ffffff',
            textAlign: 'center',
            fontSize: 16,
            borderRadius: 90
          }
        });
        button.hide();
        button.show();
        button.onTap(function (res) {
          console.log(res);

          if (res.errMsg === "getUserInfo:ok") {
            console.log("已经授权"); //获取注册信息

            console.log(res.userInfo);
            WeChat.onRegisterUser(res.userInfo);
            button.destroy(); //cc.director.loadScene("Game_Start");
          } else {
            console.log("没有授权");
          }
        });
      }
    });
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfTG9naW5cXFdYX0xvZ2luLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwid3giLCJsb2dpbiIsInN1Y2Nlc3MiLCJyZXMiLCJjb2RlIiwiY29uc29sZSIsImxvZyIsImJ1dHRvbiIsImNyZWF0ZVVzZXJJbmZvQnV0dG9uIiwidHlwZSIsInRleHQiLCJzdHlsZSIsImxlZnQiLCJnZXRTeXN0ZW1JbmZvU3luYyIsInNjcmVlbldpZHRoIiwidG9wIiwic2NyZWVuSGVpZ2h0Iiwid2lkdGgiLCJoZWlnaHQiLCJsaW5lSGVpZ2h0IiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJ0ZXh0QWxpZ24iLCJmb250U2l6ZSIsImJvcmRlclJhZGl1cyIsImhpZGUiLCJzaG93Iiwib25UYXAiLCJlcnJNc2ciLCJ1c2VySW5mbyIsIldlQ2hhdCIsIm9uUmVnaXN0ZXJVc2VyIiwiZGVzdHJveSIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUUsRUFISjtBQU9SQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQUMsSUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUkMsTUFBQUEsT0FBTyxFQUFFLGlCQUFTQyxHQUFULEVBQWM7QUFDdEIsWUFBSUEsR0FBRyxDQUFDQyxJQUFSLEVBQWM7QUFDYkMsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QkgsR0FBRyxDQUFDQyxJQUFoQztBQUNBOztBQUNELFlBQUlHLE1BQU0sR0FBR1AsRUFBRSxDQUFDUSxvQkFBSCxDQUF3QjtBQUNwQ0MsVUFBQUEsSUFBSSxFQUFFLE1BRDhCO0FBRXBDQyxVQUFBQSxJQUFJLEVBQUUsTUFGOEI7QUFHcENDLFVBQUFBLEtBQUssRUFBRTtBQUNOQyxZQUFBQSxJQUFJLEVBQUVaLEVBQUUsQ0FBQ2EsaUJBQUgsR0FBdUJDLFdBQXZCLEdBQXFDLENBQXJDLEdBQXlDLEVBRHpDO0FBRU5DLFlBQUFBLEdBQUcsRUFBRWYsRUFBRSxDQUFDYSxpQkFBSCxHQUF1QkcsWUFBdkIsR0FBc0MsQ0FBdEMsR0FBMEMsRUFGekM7QUFHTkMsWUFBQUEsS0FBSyxFQUFFLEdBSEQ7QUFJTkMsWUFBQUEsTUFBTSxFQUFFLEVBSkY7QUFLTkMsWUFBQUEsVUFBVSxFQUFFLEVBTE47QUFNTkMsWUFBQUEsZUFBZSxFQUFFLFNBTlg7QUFPTkMsWUFBQUEsS0FBSyxFQUFFLFNBUEQ7QUFRTkMsWUFBQUEsU0FBUyxFQUFFLFFBUkw7QUFTTkMsWUFBQUEsUUFBUSxFQUFFLEVBVEo7QUFVTkMsWUFBQUEsWUFBWSxFQUFFO0FBVlI7QUFINkIsU0FBeEIsQ0FBYjtBQWdCQWpCLFFBQUFBLE1BQU0sQ0FBQ2tCLElBQVA7QUFDQWxCLFFBQUFBLE1BQU0sQ0FBQ21CLElBQVA7QUFDQW5CLFFBQUFBLE1BQU0sQ0FBQ29CLEtBQVAsQ0FBYSxVQUFDeEIsR0FBRCxFQUFTO0FBQ3JCRSxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUgsR0FBWjs7QUFFQSxjQUFJQSxHQUFHLENBQUN5QixNQUFKLEtBQWUsZ0JBQW5CLEVBQXFDO0FBQ3BDdkIsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQURvQyxDQUVwQzs7QUFDQUQsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlILEdBQUcsQ0FBQzBCLFFBQWhCO0FBQ0FDLFlBQUFBLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQjVCLEdBQUcsQ0FBQzBCLFFBQTFCO0FBQ0F0QixZQUFBQSxNQUFNLENBQUN5QixPQUFQLEdBTG9DLENBTXBDO0FBQ0EsV0FQRCxNQU9NO0FBQ0wzQixZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0E7QUFDRCxTQWJEO0FBY0E7QUFyQ08sS0FBVDtBQXVDQSxHQWhETztBQWtEUjJCLEVBQUFBLEtBbERRLG1CQWtEQSxDQUVQLENBcERPLENBd0RSOztBQXhEUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0fSxcclxuXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+iwg+eUqOW+ruS/oeeZu+W9leWHveaVsO+8jOeZu+W9lea4uOaIj1xyXG5cdFx0d3gubG9naW4oe1xyXG5cdFx0XHRzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuXHRcdFx0XHRpZiAocmVzLmNvZGUpIHtcclxuXHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi55m75b2V5oiQ5Yqf77yM6I635Y+W5YiwY29kZVwiLCByZXMuY29kZSk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHZhciBidXR0b24gPSB3eC5jcmVhdGVVc2VySW5mb0J1dHRvbih7XHJcblx0XHRcdFx0XHR0eXBlOiAndGV4dCcsXHJcblx0XHRcdFx0XHR0ZXh0OiAn5byA5aeL5ri45oiPJyxcclxuXHRcdFx0XHRcdHN0eWxlOiB7XHJcblx0XHRcdFx0XHRcdGxlZnQ6IHd4LmdldFN5c3RlbUluZm9TeW5jKCkuc2NyZWVuV2lkdGggLyAyIC0gNjAsXHJcblx0XHRcdFx0XHRcdHRvcDogd3guZ2V0U3lzdGVtSW5mb1N5bmMoKS5zY3JlZW5IZWlnaHQgLyAyIC0gNjAsXHJcblx0XHRcdFx0XHRcdHdpZHRoOiAxMjAsXHJcblx0XHRcdFx0XHRcdGhlaWdodDogNDAsXHJcblx0XHRcdFx0XHRcdGxpbmVIZWlnaHQ6IDQwLFxyXG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3I6ICcjMDBhYTAwJyxcclxuXHRcdFx0XHRcdFx0Y29sb3I6ICcjZmZmZmZmJyxcclxuXHRcdFx0XHRcdFx0dGV4dEFsaWduOiAnY2VudGVyJyxcclxuXHRcdFx0XHRcdFx0Zm9udFNpemU6IDE2LFxyXG5cdFx0XHRcdFx0XHRib3JkZXJSYWRpdXM6IDkwLFxyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdH0pO1xyXG5cdFx0XHRcdGJ1dHRvbi5oaWRlKCk7XHJcblx0XHRcdFx0YnV0dG9uLnNob3coKTtcclxuXHRcdFx0XHRidXR0b24ub25UYXAoKHJlcykgPT4ge1xyXG5cdFx0XHRcdFx0Y29uc29sZS5sb2cocmVzKTtcclxuXHJcblx0XHRcdFx0XHRpZiAocmVzLmVyck1zZyA9PT0gXCJnZXRVc2VySW5mbzpva1wiKSB7XHJcblx0XHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi5bey57uP5o6I5p2DXCIpO1xyXG5cdFx0XHRcdFx0XHQvL+iOt+WPluazqOWGjOS/oeaBr1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhyZXMudXNlckluZm8pO1xyXG5cdFx0XHRcdFx0XHRXZUNoYXQub25SZWdpc3RlclVzZXIocmVzLnVzZXJJbmZvKTtcclxuXHRcdFx0XHRcdFx0YnV0dG9uLmRlc3Ryb3koKTtcclxuXHRcdFx0XHRcdFx0Ly9jYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lX1N0YXJ0XCIpO1xyXG5cdFx0XHRcdFx0fWVsc2Uge1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuayoeacieaOiOadg1wiKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblx0XHRcclxuXHR9LFxyXG5cdFxyXG5cdFxyXG5cclxuXHQvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Change_Map.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '734952mXWpNIbJ+BxxqrbWv', 'Change_Map');
// resources/script/Game_Start/Change_Map.js

"use strict";

//改变地图难度
var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  // onLoad () {},
  onLoad: function onLoad() {},
  update: function update(dt) {},
  on_btn_click: function on_btn_click() {
    //改变背景
    var frame = this.node.getComponent(cc.Sprite).spriteFrame; //改变地图变量

    Game_Local_Varible.Current_Map = frame;

    if (Game_Local_Varible.Current_Map != null) {
      this.BGSprite.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
    } else {
      cc.loader.load({
        url: "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Map/Map_Desert.jpg?sign=1ff843bf81f16ee3d008efbd49344610&t=1608450857",
        type: 'jpg'
      }, function (err, texture, test) {
        var frame = new cc.SpriteFrame(texture);

        if (err) {
          console.log("图片错误", err);
        }

        this.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
      });
    }

    console.log("Current_Map.typeof=" + Game_Local_Varible.Current_Map);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXENoYW5nZV9NYXAuanMiXSwibmFtZXMiOlsiR2FtZV9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQkdTcHJpdGUiLCJ0eXBlIiwiU3ByaXRlIiwic2VyaWFsemFibGUiLCJvbkxvYWQiLCJ1cGRhdGUiLCJkdCIsIm9uX2J0bl9jbGljayIsImZyYW1lIiwibm9kZSIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwiQ3VycmVudF9NYXAiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJTcHJpdGVGcmFtZSIsImNvbnNvbGUiLCJsb2ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxrQkFBa0IsR0FBR0MsT0FBTyxDQUFDLG9CQUFELENBQWhDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsUUFBUSxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGQTtBQUdUQyxNQUFBQSxXQUFXLEVBQUU7QUFISjtBQURDLEdBSEo7QUFZUjtBQUVBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVcsQ0FBRSxDQWRiO0FBZVJDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhLENBQUUsQ0FmZjtBQWtCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0EsUUFBSUMsS0FBSyxHQUFHLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QmQsRUFBRSxDQUFDTSxNQUExQixFQUFrQ1MsV0FBOUMsQ0FGd0IsQ0FHeEI7O0FBQ0FqQixJQUFBQSxrQkFBa0IsQ0FBQ2tCLFdBQW5CLEdBQWlDSixLQUFqQzs7QUFDQSxRQUFHZCxrQkFBa0IsQ0FBQ2tCLFdBQW5CLElBQWdDLElBQW5DLEVBQXdDO0FBQ3ZDLFdBQUtaLFFBQUwsQ0FBY1UsWUFBZCxDQUEyQmQsRUFBRSxDQUFDTSxNQUE5QixFQUFzQ1MsV0FBdEMsR0FBb0RqQixrQkFBa0IsQ0FBQ2tCLFdBQXZFO0FBQ0EsS0FGRCxNQUVLO0FBQ0poQixNQUFBQSxFQUFFLENBQUNpQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxRQUFBQSxHQUFHLEVBQUUsd0lBRFM7QUFFZGQsUUFBQUEsSUFBSSxFQUFFO0FBRlEsT0FBZixFQUdHLFVBQVNlLEdBQVQsRUFBY0MsT0FBZCxFQUF1QkMsSUFBdkIsRUFBNkI7QUFDL0IsWUFBSVYsS0FBSyxHQUFHLElBQUlaLEVBQUUsQ0FBQ3VCLFdBQVAsQ0FBbUJGLE9BQW5CLENBQVo7O0FBQ0EsWUFBSUQsR0FBSixFQUFTO0FBQ1JJLFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JMLEdBQXBCO0FBQ0E7O0FBQ0QsYUFBS2hCLFFBQUwsQ0FBY1UsWUFBZCxDQUEyQmQsRUFBRSxDQUFDTSxNQUE5QixFQUFzQ1MsV0FBdEMsR0FBb0RILEtBQXBEO0FBQ0EsT0FURDtBQVVBOztBQUVEWSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBd0IzQixrQkFBa0IsQ0FBQ2tCLFdBQXZEO0FBQ0E7QUF2Q08sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/mlLnlj5jlnLDlm77pmr7luqZcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRCR1Nwcml0ZToge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5TcHJpdGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHR9LFxyXG5cclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge30sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge30sXHJcblxyXG5cclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Ly/mlLnlj5jog4zmma9cclxuXHRcdHZhciBmcmFtZSA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZTtcclxuXHRcdC8v5pS55Y+Y5Zyw5Zu+5Y+Y6YePXHJcblx0XHRHYW1lX0xvY2FsX1ZhcmlibGUuQ3VycmVudF9NYXAgPSBmcmFtZTtcclxuXHRcdGlmKEdhbWVfTG9jYWxfVmFyaWJsZS5DdXJyZW50X01hcCE9bnVsbCl7XHJcblx0XHRcdHRoaXMuQkdTcHJpdGUuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWUgPSBHYW1lX0xvY2FsX1ZhcmlibGUuQ3VycmVudF9NYXA7XHJcblx0XHR9ZWxzZXtcclxuXHRcdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHRcdHVybDogXCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL2ltYWdlL01hcC9NYXBfRGVzZXJ0LmpwZz9zaWduPTFmZjg0M2JmODFmMTZlZTNkMDA4ZWZiZDQ5MzQ0NjEwJnQ9MTYwODQ1MDg1N1wiLFxyXG5cdFx0XHRcdHR5cGU6ICdqcGcnXHJcblx0XHRcdH0sIGZ1bmN0aW9uKGVyciwgdGV4dHVyZSwgdGVzdCkge1xyXG5cdFx0XHRcdHZhciBmcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0XHRpZiAoZXJyKSB7XHJcblx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLCBlcnIpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHR0aGlzLkJHU3ByaXRlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gZnJhbWU7XHJcblx0XHRcdH0pXHJcblx0XHR9XHJcblx0XHRcclxuXHRcdGNvbnNvbGUubG9nKFwiQ3VycmVudF9NYXAudHlwZW9mPVwiICsgR2FtZV9Mb2NhbF9WYXJpYmxlLkN1cnJlbnRfTWFwKTtcclxuXHR9XHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Over/Grade_Show.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a7b33r7cXNCMYXNoW8XFev8', 'Grade_Show');
// resources/script/Game_Over/Grade_Show.js

"use strict";

//进行游戏结束后的结算
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Grade_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //调入金币显示的Label
    Fraction_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //调入分数显示的Label
    Background: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //调入分数显示的Lab

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    WeChat.Game_Settlement(Math.floor(Game_Local_Varible.Fraction / 4 * Game_Difficulty_Local_Varible.Difficulty_Ratio + Game_Local_Varible.Gold), Game_Local_Varible.Fraction / 2); //将分数传入云数据库中

    this.Grade_Show.string = "一共通过了" + Game_Local_Varible.Fraction / 2 + "根水管\n收获了" + Math.floor(Game_Local_Varible.Fraction / 4 * Game_Difficulty_Local_Varible.Difficulty_Ratio + Game_Local_Varible.Gold) + "枚金币"; //将Label更新

    this.Fraction_Show.string = Game_Local_Varible.Fraction / 2 * Game_Difficulty_Local_Varible.Difficulty_Ratio; //更新前端Label

    this.Background.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfT3ZlclxcR3JhZGVfU2hvdy5qcyJdLCJuYW1lcyI6WyJHYW1lX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkdyYWRlX1Nob3ciLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsIkZyYWN0aW9uX1Nob3ciLCJCYWNrZ3JvdW5kIiwiU3ByaXRlIiwib25Mb2FkIiwiV2VDaGF0IiwiR2FtZV9TZXR0bGVtZW50IiwiTWF0aCIsImZsb29yIiwiRnJhY3Rpb24iLCJEaWZmaWN1bHR5X1JhdGlvIiwiR29sZCIsInN0cmluZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwiQ3VycmVudF9NYXAiLCJzdGFydCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxvQkFBRCxDQUFoQzs7QUFDQSxJQUFJQyw2QkFBNkIsR0FBR0QsT0FBTyxDQUFDLCtCQUFELENBQTNDOztBQUVBRSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGRTtBQUdYQyxNQUFBQSxXQUFXLEVBQUU7QUFIRixLQUREO0FBS1I7QUFDSEMsSUFBQUEsYUFBYSxFQUFFO0FBQ2QsaUJBQVMsSUFESztBQUVkSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGSztBQUdkQyxNQUFBQSxXQUFXLEVBQUU7QUFIQyxLQU5KO0FBVVI7QUFDSEUsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1UsTUFGRTtBQUdYSCxNQUFBQSxXQUFXLEVBQUU7QUFIRixLQVhELENBZVI7O0FBZlEsR0FISjtBQXFCUjtBQUVBSSxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFFbEJDLElBQUFBLE1BQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsSUFBSSxDQUFDQyxLQUFMLENBQVdsQixrQkFBa0IsQ0FBQ21CLFFBQW5CLEdBQThCLENBQTlCLEdBQWtDakIsNkJBQTZCLENBQUNrQixnQkFBaEUsR0FDakNwQixrQkFBa0IsQ0FBQ3FCLElBREcsQ0FBdkIsRUFDMkJyQixrQkFBa0IsQ0FBQ21CLFFBQW5CLEdBQThCLENBRHpELEVBRmtCLENBRzJDOztBQUM3RCxTQUFLWixVQUFMLENBQWdCZSxNQUFoQixHQUF5QixVQUFXdEIsa0JBQWtCLENBQUNtQixRQUFuQixHQUE4QixDQUF6QyxHQUE4QyxVQUE5QyxHQUE0REYsSUFBSSxDQUFDQyxLQUFMLENBQVdsQixrQkFBa0IsQ0FDaEhtQixRQUQ4RixHQUNuRixDQURtRixHQUMvRWpCLDZCQUE2QixDQUFDa0IsZ0JBRGlELEdBQzlCcEIsa0JBQWtCLENBQUNxQixJQURBLENBQTVELEdBQ3FFLEtBRDlGLENBSmtCLENBS21GOztBQUNyRyxTQUFLVixhQUFMLENBQW1CVyxNQUFuQixHQUE2QnRCLGtCQUFrQixDQUFDbUIsUUFBbkIsR0FBOEIsQ0FBL0IsR0FBb0NqQiw2QkFBNkIsQ0FBQ2tCLGdCQUE5RixDQU5rQixDQU04Rjs7QUFDaEgsU0FBS1IsVUFBTCxDQUFnQlcsWUFBaEIsQ0FBNkJwQixFQUFFLENBQUNVLE1BQWhDLEVBQXdDVyxXQUF4QyxHQUFzRHhCLGtCQUFrQixDQUFDeUIsV0FBekU7QUFDQSxHQS9CTztBQWlDUkMsRUFBQUEsS0FqQ1EsbUJBaUNBLENBQUUsQ0FqQ0Y7QUFtQ1JDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhLENBQUU7QUFuQ2YsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/ov5vooYzmuLjmiI/nu5PmnZ/lkI7nmoTnu5PnrpdcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0R3JhZGVfU2hvdzoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+iwg+WFpemHkeW4geaYvuekuueahExhYmVsXHJcblx0XHRGcmFjdGlvbl9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6LCD5YWl5YiG5pWw5pi+56S655qETGFiZWxcclxuXHRcdEJhY2tncm91bmQ6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuU3ByaXRlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6LCD5YWl5YiG5pWw5pi+56S655qETGFiXHJcblx0fSxcclxuXHJcblx0Ly8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblxyXG5cdFx0V2VDaGF0LkdhbWVfU2V0dGxlbWVudChNYXRoLmZsb29yKEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiAvIDQgKiBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICtcclxuXHRcdFx0R2FtZV9Mb2NhbF9WYXJpYmxlLkdvbGQpLCBHYW1lX0xvY2FsX1ZhcmlibGUuRnJhY3Rpb24gLyAyKTsgLy/lsIbliIbmlbDkvKDlhaXkupHmlbDmja7lupPkuK1cclxuXHRcdHRoaXMuR3JhZGVfU2hvdy5zdHJpbmcgPSBcIuS4gOWFsemAmui/h+S6hlwiICsgKEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiAvIDIpICsgXCLmoLnmsLTnrqFcXG7mlLbojrfkuoZcIiArIChNYXRoLmZsb29yKEdhbWVfTG9jYWxfVmFyaWJsZVxyXG5cdFx0XHQuRnJhY3Rpb24gLyA0ICogR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbyArIEdhbWVfTG9jYWxfVmFyaWJsZS5Hb2xkKSkgKyBcIuaemumHkeW4gVwiOyAvL+WwhkxhYmVs5pu05pawXHJcblx0XHR0aGlzLkZyYWN0aW9uX1Nob3cuc3RyaW5nID0gKEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiAvIDIpICogR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbzsgLy/mm7TmlrDliY3nq69MYWJlbFxyXG5cdFx0dGhpcy5CYWNrZ3JvdW5kLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gR2FtZV9Mb2NhbF9WYXJpYmxlLkN1cnJlbnRfTWFwO1xyXG5cdH0sXHJcblxyXG5cdHN0YXJ0KCkge30sXHJcblxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHt9LFxyXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Game_Local_Varible.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0dac3D7735OkZ6XLHfugRmJ', 'Game_Local_Varible');
// resources/script/Local_Variible/Game_Local_Varible.js

"use strict";

//游戏界面的局部变量
module.exports = {
  //分数统计
  Fraction: 0,
  //获得金币
  Gold: 0,
  //当前地图
  Current_Map: {
    "default": null,
    type: cc.SpriteFrame,
    serialzable: true
  }
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxHYW1lX0xvY2FsX1ZhcmlibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIkZyYWN0aW9uIiwiR29sZCIsIkN1cnJlbnRfTWFwIiwidHlwZSIsImNjIiwiU3ByaXRlRnJhbWUiLCJzZXJpYWx6YWJsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDaEI7QUFDQUMsRUFBQUEsUUFBUSxFQUFFLENBRk07QUFHaEI7QUFDQUMsRUFBQUEsSUFBSSxFQUFFLENBSlU7QUFLaEI7QUFDQUMsRUFBQUEsV0FBVyxFQUFFO0FBQ1osZUFBUyxJQURHO0FBRVpDLElBQUFBLElBQUksRUFBRUMsRUFBRSxDQUFDQyxXQUZHO0FBR1pDLElBQUFBLFdBQVcsRUFBRTtBQUhEO0FBTkcsQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5ri45oiP55WM6Z2i55qE5bGA6YOo5Y+Y6YePXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG5cdC8v5YiG5pWw57uf6K6hXHJcblx0RnJhY3Rpb246IDAsXHJcblx0Ly/ojrflvpfph5HluIFcclxuXHRHb2xkOiAwLFxyXG5cdC8v5b2T5YmN5Zyw5Zu+XHJcblx0Q3VycmVudF9NYXA6IHtcclxuXHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHR0eXBlOiBjYy5TcHJpdGVGcmFtZSxcclxuXHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdH0sXHJcbn07XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Loading_Rank.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ffbc3JL8GNEwI+f8sxUOJw7', 'Loading_Rank');
// resources/script/Rank/Loading_Rank.js

"use strict";

//下载世界排名列表
var Rank_Local_Varible = require('Rank_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Rank_User_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //玩家框
    Rank_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    var self = this;
    Rank_Local_Varible.Word_Rank_User = null;
    this._Is_Loading = true;
    WeChat.Loading_World_Rank();
    console.log(Rank_Local_Varible.Word_Rank_User);
  },
  start: function start() {},
  update: function update(dt) {
    //Rank_Local_Varible.Word_Rank_User.length
    //循环输出玩家框
    if (this._Is_Loading && Rank_Local_Varible.Word_Rank_User) {
      for (var i = 0; i < Rank_Local_Varible.Word_Rank_User.length; i++) {
        console.log("正在加载中");
        var New_Rank_User_Label = cc.instantiate(this.Rank_User_Label);
        this.Rank_View.addChild(New_Rank_User_Label);
        this.Loading_Image(New_Rank_User_Label, Rank_Local_Varible.Word_Rank_User[i].Head_Iamge);
        New_Rank_User_Label.getChildByName("Game_Rank_Show").getComponent(cc.Label).string = "" + (i + 1);
        New_Rank_User_Label.getChildByName("User_Name").getComponent(cc.Label).string = "" + Rank_Local_Varible.Word_Rank_User[i].User_Name;
        New_Rank_User_Label.getChildByName("Best_Score_Text").getComponent(cc.Label).string = "" + Rank_Local_Varible.Word_Rank_User[i].Best_Score + "分";
      }

      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Head_Image_Mask").getChildByName("Head_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXExvYWRpbmdfUmFuay5qcyJdLCJuYW1lcyI6WyJSYW5rX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJSYW5rX1VzZXJfTGFiZWwiLCJ0eXBlIiwiUHJlZmFiIiwic2VyaWFsemFibGUiLCJSYW5rX1ZpZXciLCJOb2RlIiwiX0lzX0xvYWRpbmciLCJvbkxvYWQiLCJzZWxmIiwiV29yZF9SYW5rX1VzZXIiLCJXZUNoYXQiLCJMb2FkaW5nX1dvcmxkX1JhbmsiLCJjb25zb2xlIiwibG9nIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImkiLCJsZW5ndGgiLCJOZXdfUmFua19Vc2VyX0xhYmVsIiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsIkxvYWRpbmdfSW1hZ2UiLCJIZWFkX0lhbWdlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIlVzZXJfTmFtZSIsIkJlc3RfU2NvcmUiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLGtCQUFrQixHQUFHQyxPQUFPLENBQUMscUJBQUQsQ0FBaEM7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNaQyxJQUFBQSxlQUFlLEVBQUM7QUFDWixpQkFBUSxJQURJO0FBRVpDLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxNQUZJO0FBR1pDLE1BQUFBLFdBQVcsRUFBQztBQUhBLEtBREo7QUFLVDtBQUNMQyxJQUFBQSxTQUFTLEVBQUM7QUFDUCxpQkFBUSxJQUREO0FBRVBILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxJQUZEO0FBR1BGLE1BQUFBLFdBQVcsRUFBQztBQUhMLEtBTkk7QUFVWjtBQUNGRyxJQUFBQSxXQUFXLEVBQUM7QUFYRSxHQUhQO0FBa0JMQyxFQUFBQSxNQUFNLEVBQUMsa0JBQVk7QUFDckIsUUFBSUMsSUFBSSxHQUFHLElBQVg7QUFDQWQsSUFBQUEsa0JBQWtCLENBQUNlLGNBQW5CLEdBQWtDLElBQWxDO0FBQ0EsU0FBS0gsV0FBTCxHQUFpQixJQUFqQjtBQUNBSSxJQUFBQSxNQUFNLENBQUNDLGtCQUFQO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZbkIsa0JBQWtCLENBQUNlLGNBQS9CO0FBRUEsR0F6Qk87QUEyQkxLLEVBQUFBLEtBM0JLLG1CQTJCSSxDQUNSLENBNUJJO0FBOEJMQyxFQUFBQSxNQUFNLEVBQUMsZ0JBQVVDLEVBQVYsRUFBYztBQUN2QjtBQUNBO0FBQ0EsUUFBRyxLQUFLVixXQUFMLElBQWtCWixrQkFBa0IsQ0FBQ2UsY0FBeEMsRUFBdUQ7QUFDdEQsV0FBSSxJQUFJUSxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUN2QixrQkFBa0IsQ0FBQ2UsY0FBbkIsQ0FBa0NTLE1BQWhELEVBQXVERCxDQUFDLEVBQXhELEVBQTJEO0FBQzFETCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsWUFBSU0sbUJBQW1CLEdBQUd2QixFQUFFLENBQUN3QixXQUFILENBQWUsS0FBS3BCLGVBQXBCLENBQTFCO0FBQ0EsYUFBS0ksU0FBTCxDQUFlaUIsUUFBZixDQUF3QkYsbUJBQXhCO0FBQ0EsYUFBS0csYUFBTCxDQUFtQkgsbUJBQW5CLEVBQXVDekIsa0JBQWtCLENBQUNlLGNBQW5CLENBQWtDUSxDQUFsQyxFQUFxQ00sVUFBNUU7QUFDQUosUUFBQUEsbUJBQW1CLENBQUNLLGNBQXBCLENBQW1DLGdCQUFuQyxFQUFxREMsWUFBckQsQ0FBa0U3QixFQUFFLENBQUM4QixLQUFyRSxFQUE0RUMsTUFBNUUsR0FBbUYsTUFBSVYsQ0FBQyxHQUFDLENBQU4sQ0FBbkY7QUFDQUUsUUFBQUEsbUJBQW1CLENBQUNLLGNBQXBCLENBQW1DLFdBQW5DLEVBQWdEQyxZQUFoRCxDQUE2RDdCLEVBQUUsQ0FBQzhCLEtBQWhFLEVBQXVFQyxNQUF2RSxHQUE4RSxLQUFHakMsa0JBQWtCLENBQUNlLGNBQW5CLENBQWtDUSxDQUFsQyxFQUFxQ1csU0FBdEg7QUFDQVQsUUFBQUEsbUJBQW1CLENBQUNLLGNBQXBCLENBQW1DLGlCQUFuQyxFQUFzREMsWUFBdEQsQ0FBbUU3QixFQUFFLENBQUM4QixLQUF0RSxFQUE2RUMsTUFBN0UsR0FBb0YsS0FBR2pDLGtCQUFrQixDQUFDZSxjQUFuQixDQUFrQ1EsQ0FBbEMsRUFBcUNZLFVBQXhDLEdBQW1ELEdBQXZJO0FBRUE7O0FBQ0QsV0FBS3ZCLFdBQUwsR0FBaUIsS0FBakI7QUFDQTtBQUNELEdBOUNPO0FBZ0RSZ0IsRUFBQUEsYUFoRFEseUJBZ0RNZCxJQWhETixFQWdEV3NCLFVBaERYLEVBZ0RzQjtBQUMzQixRQUFJQyxJQUFJLEdBQUNELFVBQVQ7QUFDQWxDLElBQUFBLEVBQUUsQ0FBQ29DLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBQ0gsSUFEVTtBQUVkOUIsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVNrQyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJMUMsRUFBRSxDQUFDMkMsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTnZCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJzQixHQUFuQjtBQUNBOztBQUNEM0IsTUFBQUEsSUFBSSxDQUFDZ0IsY0FBTCxDQUFvQixpQkFBcEIsRUFBdUNBLGNBQXZDLENBQXNELFlBQXRELEVBQW9FQyxZQUFwRSxDQUFpRjdCLEVBQUUsQ0FBQzRDLE1BQXBGLEVBQTRGQyxXQUE1RixHQUF3R0gsS0FBeEc7QUFFQSxLQVZEO0FBV0Y7QUE3RE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/kuIvovb3kuJbnlYzmjpLlkI3liJfooahcclxudmFyIFJhbmtfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ1JhbmtfTG9jYWxfVmFyaWFibGUnKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgIFJhbmtfVXNlcl9MYWJlbDp7XHJcbiAgICAgXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuICAgICBcdFx0XHR0eXBlOmNjLlByZWZhYixcclxuICAgICBcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgIH0sLy/njqnlrrbmoYZcclxuXHQgUmFua19WaWV3OntcclxuXHQgXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuXHQgXHRcdFx0dHlwZTpjYy5Ob2RlLFxyXG5cdCBcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdCB9LC8v5o6S5ZCN5qGGXHJcblx0IF9Jc19Mb2FkaW5nOnRydWUsXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBvbkxvYWQ6ZnVuY3Rpb24gKCkge1xyXG5cdFx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdFx0UmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyPW51bGw7XHJcblx0XHR0aGlzLl9Jc19Mb2FkaW5nPXRydWU7XHJcblx0XHRXZUNoYXQuTG9hZGluZ19Xb3JsZF9SYW5rKCk7XHJcblx0XHRjb25zb2xlLmxvZyhSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXIpO1xyXG5cdFx0XHJcblx0fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICB9LFxyXG5cclxuICAgIHVwZGF0ZTpmdW5jdGlvbiAoZHQpIHtcclxuXHRcdC8vUmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyLmxlbmd0aFxyXG5cdFx0Ly/lvqrnjq/ovpPlh7rnjqnlrrbmoYZcclxuXHRcdGlmKHRoaXMuX0lzX0xvYWRpbmcmJlJhbmtfTG9jYWxfVmFyaWJsZS5Xb3JkX1JhbmtfVXNlcil7XHJcblx0XHRcdGZvcih2YXIgaT0wO2k8UmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyLmxlbmd0aDtpKyspe1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwi5q2j5Zyo5Yqg6L295LitXCIpO1xyXG5cdFx0XHRcdHZhciBOZXdfUmFua19Vc2VyX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5SYW5rX1VzZXJfTGFiZWwpO1xyXG5cdFx0XHRcdHRoaXMuUmFua19WaWV3LmFkZENoaWxkKE5ld19SYW5rX1VzZXJfTGFiZWwpO1xyXG5cdFx0XHRcdHRoaXMuTG9hZGluZ19JbWFnZShOZXdfUmFua19Vc2VyX0xhYmVsLFJhbmtfTG9jYWxfVmFyaWJsZS5Xb3JkX1JhbmtfVXNlcltpXS5IZWFkX0lhbWdlKTtcclxuXHRcdFx0XHROZXdfUmFua19Vc2VyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiR2FtZV9SYW5rX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIisoaSsxKTtcclxuXHRcdFx0XHROZXdfUmFua19Vc2VyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiVXNlcl9OYW1lXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrUmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyW2ldLlVzZXJfTmFtZTtcclxuXHRcdFx0XHROZXdfUmFua19Vc2VyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQmVzdF9TY29yZV9UZXh0XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrUmFua19Mb2NhbF9WYXJpYmxlLldvcmRfUmFua19Vc2VyW2ldLkJlc3RfU2NvcmUrXCLliIZcIjtcclxuXHRcdFx0XHRcclxuXHRcdFx0fVxyXG5cdFx0XHR0aGlzLl9Jc19Mb2FkaW5nPWZhbHNlXHJcblx0XHR9XHJcblx0fSxcclxuXHRcclxuXHRMb2FkaW5nX0ltYWdlKHNlbGYsSW1hZ2VfUGF0aCl7XHJcblx0XHRcdFx0bGV0IF91cmw9SW1hZ2VfUGF0aDtcclxuXHRcdFx0XHRjYy5sb2FkZXIubG9hZCh7XHJcblx0XHRcdFx0XHR1cmw6X3VybCxcclxuXHRcdFx0XHRcdHR5cGU6J2pwZydcclxuXHRcdFx0XHR9LGZ1bmN0aW9uKGVycix0ZXh0dXJlLHRlc3Qpe1xyXG5cdFx0XHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0XHRcdGNvbnNvbGUubG9nKFwi5Zu+54mH6ZSZ6K+vXCIsZXJyKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdHNlbGYuZ2V0Q2hpbGRCeU5hbWUoXCJIZWFkX0ltYWdlX01hc2tcIikuZ2V0Q2hpbGRCeU5hbWUoXCJIZWFkX0ltYWdlXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lPWZyYW1lO1xyXG5cdFx0XHRcdFx0XHJcblx0XHRcdFx0fSlcclxuXHR9XHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Role/Have_Character_Information.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4ab376ZptJEGo98hDU3KGrZ', 'Have_Character_Information');
// resources/script/Role/Have_Character_Information.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Buy_Character_Background: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    var self = this;
    var This_Name = this.Character_Name.getComponent(cc.Label).string;
    WeChat.Loading_Shop_Character();

    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var List_Name = Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;

      if (This_Name === List_Name) {
        //当前点击的角色
        var This_information = Shop_Character_Local_Varible.Shop_Character_User[i];
        var New_Buy_Character_Background = cc.instantiate(this.Buy_Character_Background);
        this.Canvas.parent.parent.parent.addChild(New_Buy_Character_Background);
        New_Buy_Character_Background.setPosition(0, -210);
        console.log("图片地址为", This_information);
        this.Loading_Image(New_Buy_Character_Background, This_information.Character_Head_Image);
        New_Buy_Character_Background.getChildByName("Character_Name").getComponent(cc.Label).string = "" + This_information.Character_Name;
        New_Buy_Character_Background.getChildByName("Character_Synopsis").getComponent(cc.Label).string = "" + This_information.Character_Synopsis;
        New_Buy_Character_Background.getChildByName("Bounce_Power_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Jump_Speed;
        New_Buy_Character_Background.getChildByName("Weight_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fall_Speed;
        New_Buy_Character_Background.getChildByName("Speed_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fly_Speed;
        New_Buy_Character_Background.getChildByName("Skill_Name_Label").getComponent(cc.Label).string = "" + This_information.Skill_Name;
        New_Buy_Character_Background.getChildByName("Skill_Effect_Label").getComponent(cc.Label).string = "" + This_information.Skill_Synopsis;
        New_Buy_Character_Background.getChildByName("Character_Id").getComponent(cc.Label).string = "" + This_information.Character_Id;
        New_Buy_Character_Background.getChildByName("Background1").getComponent(cc.Sprite).fillRange = This_information.Character_Jump_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background2").getComponent(cc.Sprite).fillRange = This_information.Character_Fall_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background3").getComponent(cc.Sprite).fillRange = This_information.Character_Fly_Speed / 100;
        break;
      }
    }
  },
  update: function update(dt) {},
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Character_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJvbGVcXEhhdmVfQ2hhcmFjdGVyX0luZm9ybWF0aW9uLmpzIl0sIm5hbWVzIjpbIlNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJCdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQiLCJ0eXBlIiwiUHJlZmFiIiwic2VyaWFsemFibGUiLCJDaGFyYWN0ZXJfTmFtZSIsIkxhYmVsIiwiQ2FudmFzIiwiTm9kZSIsIm9uX2J0bl9jbGljayIsInNlbGYiLCJUaGlzX05hbWUiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJXZUNoYXQiLCJMb2FkaW5nX1Nob3BfQ2hhcmFjdGVyIiwiaSIsIlNob3BfQ2hhcmFjdGVyX1VzZXIiLCJsZW5ndGgiLCJMaXN0X05hbWUiLCJUaGlzX2luZm9ybWF0aW9uIiwiTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZCIsImluc3RhbnRpYXRlIiwicGFyZW50IiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiIsImNvbnNvbGUiLCJsb2ciLCJMb2FkaW5nX0ltYWdlIiwiQ2hhcmFjdGVyX0hlYWRfSW1hZ2UiLCJnZXRDaGlsZEJ5TmFtZSIsIkNoYXJhY3Rlcl9TeW5vcHNpcyIsIkNoYXJhY3Rlcl9KdW1wX1NwZWVkIiwiQ2hhcmFjdGVyX0ZhbGxfU3BlZWQiLCJDaGFyYWN0ZXJfRmx5X1NwZWVkIiwiU2tpbGxfTmFtZSIsIlNraWxsX1N5bm9wc2lzIiwiQ2hhcmFjdGVyX0lkIiwiU3ByaXRlIiwiZmlsbFJhbmdlIiwidXBkYXRlIiwiZHQiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJzcHJpdGVGcmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJQSw0QkFBNEIsR0FBR0MsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsd0JBQXdCLEVBQUM7QUFDckIsaUJBQVEsSUFEYTtBQUU5QkMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRnNCO0FBRzlCQyxNQUFBQSxXQUFXLEVBQUM7QUFIa0IsS0FEakI7QUFNUkMsSUFBQUEsY0FBYyxFQUFDO0FBQ1gsaUJBQVEsSUFERztBQUVwQkgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRlk7QUFHcEJGLE1BQUFBLFdBQVcsRUFBQztBQUhRLEtBTlA7QUFXUkcsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csSUFGTDtBQUdaSixNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQVhDLEdBSFA7QUFxQkw7QUFFQUssRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3JCLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsU0FBUyxHQUFDLEtBQUtOLGNBQUwsQ0FBb0JPLFlBQXBCLENBQWlDZixFQUFFLENBQUNTLEtBQXBDLEVBQTJDTyxNQUF6RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLHNCQUFQOztBQUdBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDckIsNEJBQTRCLENBQUNzQixtQkFBN0IsQ0FBaURDLE1BQS9ELEVBQXNFRixDQUFDLEVBQXZFLEVBQTBFO0FBQ3RFLFVBQUlHLFNBQVMsR0FBQ3hCLDRCQUE0QixDQUFDc0IsbUJBQTdCLENBQWlERCxDQUFqRCxFQUFvRFgsY0FBbEU7O0FBRUEsVUFBR00sU0FBUyxLQUFHUSxTQUFmLEVBQXlCO0FBQ3JCO0FBQ0EsWUFBSUMsZ0JBQWdCLEdBQUN6Qiw0QkFBNEIsQ0FBQ3NCLG1CQUE3QixDQUFpREQsQ0FBakQsQ0FBckI7QUFFQSxZQUFJSyw0QkFBNEIsR0FBR3hCLEVBQUUsQ0FBQ3lCLFdBQUgsQ0FBZSxLQUFLckIsd0JBQXBCLENBQW5DO0FBQ0EsYUFBS00sTUFBTCxDQUFZZ0IsTUFBWixDQUFtQkEsTUFBbkIsQ0FBMEJBLE1BQTFCLENBQWlDQyxRQUFqQyxDQUEwQ0gsNEJBQTFDO0FBQ0FBLFFBQUFBLDRCQUE0QixDQUFDSSxXQUE3QixDQUF5QyxDQUF6QyxFQUEyQyxDQUFDLEdBQTVDO0FBQ0FDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBb0JQLGdCQUFwQjtBQUVBLGFBQUtRLGFBQUwsQ0FBbUJQLDRCQUFuQixFQUFnREQsZ0JBQWdCLENBQUNTLG9CQUFqRTtBQUNBUixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsZ0JBQTVDLEVBQThEbEIsWUFBOUQsQ0FBMkVmLEVBQUUsQ0FBQ1MsS0FBOUUsRUFBcUZPLE1BQXJGLEdBQTRGLEtBQUdPLGdCQUFnQixDQUFDZixjQUFoSDtBQUNBZ0IsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ1csa0JBQXBIO0FBQ0FWLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QywyQkFBNUMsRUFBeUVsQixZQUF6RSxDQUFzRmYsRUFBRSxDQUFDUyxLQUF6RixFQUFnR08sTUFBaEcsR0FBdUcsS0FBR08sZ0JBQWdCLENBQUNZLG9CQUEzSDtBQUNBWCxRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMscUJBQTVDLEVBQW1FbEIsWUFBbkUsQ0FBZ0ZmLEVBQUUsQ0FBQ1MsS0FBbkYsRUFBMEZPLE1BQTFGLEdBQWlHLEtBQUdPLGdCQUFnQixDQUFDYSxvQkFBckg7QUFDQVosUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ2MsbUJBQXBIO0FBQ0FiLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxrQkFBNUMsRUFBZ0VsQixZQUFoRSxDQUE2RWYsRUFBRSxDQUFDUyxLQUFoRixFQUF1Rk8sTUFBdkYsR0FBOEYsS0FBR08sZ0JBQWdCLENBQUNlLFVBQWxIO0FBQ0FkLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxvQkFBNUMsRUFBa0VsQixZQUFsRSxDQUErRWYsRUFBRSxDQUFDUyxLQUFsRixFQUF5Rk8sTUFBekYsR0FBZ0csS0FBR08sZ0JBQWdCLENBQUNnQixjQUFwSDtBQUNBZixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsY0FBNUMsRUFBNERsQixZQUE1RCxDQUF5RWYsRUFBRSxDQUFDUyxLQUE1RSxFQUFtRk8sTUFBbkYsR0FBMEYsS0FBR08sZ0JBQWdCLENBQUNpQixZQUE5RztBQUNBaEIsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGFBQTVDLEVBQTJEbEIsWUFBM0QsQ0FBd0VmLEVBQUUsQ0FBQ3lDLE1BQTNFLEVBQW1GQyxTQUFuRixHQUE2Rm5CLGdCQUFnQixDQUFDWSxvQkFBakIsR0FBc0MsR0FBbkk7QUFDQVgsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGFBQTVDLEVBQTJEbEIsWUFBM0QsQ0FBd0VmLEVBQUUsQ0FBQ3lDLE1BQTNFLEVBQW1GQyxTQUFuRixHQUE2Rm5CLGdCQUFnQixDQUFDYSxvQkFBakIsR0FBc0MsR0FBbkk7QUFDQVosUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGFBQTVDLEVBQTJEbEIsWUFBM0QsQ0FBd0VmLEVBQUUsQ0FBQ3lDLE1BQTNFLEVBQW1GQyxTQUFuRixHQUE2Rm5CLGdCQUFnQixDQUFDYyxtQkFBakIsR0FBcUMsR0FBbEk7QUFDQTtBQUNIO0FBQ0o7QUFDSixHQXhESTtBQXlETE0sRUFBQUEsTUF6REssa0JBeURHQyxFQXpESCxFQXlETyxDQUFFLENBekRUO0FBMEROYixFQUFBQSxhQTFETSx5QkEwRFFsQixJQTFEUixFQTBEYWdDLFVBMURiLEVBMER3QjtBQUMvQixRQUFJQyxJQUFJLEdBQUNELFVBQVQ7QUFDQTdDLElBQUFBLEVBQUUsQ0FBQytDLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBQ0gsSUFEVTtBQUVkekMsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVM2QyxHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJckQsRUFBRSxDQUFDc0QsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTnJCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJvQixHQUFuQjtBQUNBOztBQUNEckMsTUFBQUEsSUFBSSxDQUFDb0IsY0FBTCxDQUFvQixpQkFBcEIsRUFBdUNsQixZQUF2QyxDQUFvRGYsRUFBRSxDQUFDeUMsTUFBdkQsRUFBK0RjLFdBQS9ELEdBQTJFRixLQUEzRTtBQUVBLEtBVkQ7QUFXRDtBQXZFUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDaGFyYWN0ZXJfTmFtZTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgVGhpc19OYW1lPXRoaXMuQ2hhcmFjdGVyX05hbWUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIoKTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXIubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBMaXN0X05hbWU9U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2ldLkNoYXJhY3Rlcl9OYW1lO1xyXG5cclxuICAgICAgICAgICAgaWYoVGhpc19OYW1lPT09TGlzdF9OYW1lKXtcclxuICAgICAgICAgICAgICAgIC8v5b2T5YmN54K55Ye755qE6KeS6ImyXHJcbiAgICAgICAgICAgICAgICB2YXIgVGhpc19pbmZvcm1hdGlvbj1TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXJbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkJ1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LnBhcmVudC5hZGRDaGlsZChOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kKTtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuc2V0UG9zaXRpb24oMCwtMjEwKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Zu+54mH5Zyw5Z2A5Li6XCIsVGhpc19pbmZvcm1hdGlvbik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQsVGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSGVhZF9JbWFnZSk7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9TeW5vcHNpc1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX1N5bm9wc2lzO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJvdW5jZV9Qb3dlcl9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9KdW1wX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIldlaWdodF9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GYWxsX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNwZWVkX051bWJlcl9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0ZseV9TcGVlZDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJTa2lsbF9OYW1lX0xhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGhpc19pbmZvcm1hdGlvbi5Ta2lsbF9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNraWxsX0VmZmVjdF9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uU2tpbGxfU3lub3BzaXM7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX0lkXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSWQ7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZDFcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuZmlsbFJhbmdlPVRoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0p1bXBfU3BlZWQvMTAwO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmQyXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLmZpbGxSYW5nZT1UaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GYWxsX1NwZWVkLzEwMDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJCYWNrZ3JvdW5kM1wiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5maWxsUmFuZ2U9VGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfRmx5X1NwZWVkLzEwMDtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHVwZGF0ZSAoZHQpIHt9LFxyXG4gIFx0TG9hZGluZ19JbWFnZShzZWxmLEltYWdlX1BhdGgpe1xyXG5cdFx0bGV0IF91cmw9SW1hZ2VfUGF0aDtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0dXJsOl91cmwsXHJcblx0XHRcdHR5cGU6J2pwZydcclxuXHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XHJcblx0XHRcdHZhciBmcmFtZT1uZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XHJcblx0XHRcdGlmKGVycil7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xyXG5cdFx0XHR9XHJcblx0XHRcdHNlbGYuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfSW1hZ2VcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9ZnJhbWU7XHJcblx0XHRcdFxyXG5cdFx0fSlcclxufVxyXG5cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Buy_Character_Sure.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'aac19v+FeVMJLHchDHDMilr', 'Buy_Character_Sure');
// resources/script/Shop/Buy_Character_Sure.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

var User_Have_Character_Local_Varible = require('../Local_Variible/User_Have_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Reminder_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Id: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Price_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    WeChat.Loading_Shop_Character(); //读取当前点击的角色金币

    var This_Information_Price = this.Price_Label.getComponent(cc.Label).string; //读取当前点击的角色信息

    var This_Information = this.Character_Id.getComponent(cc.Label).string; //读取用户拥有的金币

    var User_Gold = Global_Variable.Gold;
    var New_Reminder_Box = cc.instantiate(this.Reminder_Box);
    this.Canvas.parent.parent.addChild(New_Reminder_Box);
    New_Reminder_Box.setPosition(0, -400);
    var flag = 0;

    for (var i = 0; i < User_Have_Character_Local_Varible.User_Have_Character.length; i++) {
      //读取用户拥有的角色信息
      var User_Character_Information = User_Have_Character_Local_Varible.User_Have_Character[i]; //判断已经拥有角色
      //判断是否是本机用户

      if (This_Information == User_Character_Information.Character_Id && Global_Variable.openid == User_Character_Information.openid) {
        New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "您已拥有该商品";
        flag = 1;
        break; //输出已经拥有
      }
    }

    console.log("小鸟价格", This_Information_Price);
    console.log("用户金币数", User_Gold); //判断用户金币是否购买的起当前小鸟       

    if (User_Gold < This_Information_Price && flag == 0) {
      New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "金币不足购买商品";
    }

    if (User_Gold >= This_Information_Price && flag == 0) {
      New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "购买成功该商品";
      User_Gold = User_Gold - This_Information_Price;
      WeChat.Buy_Character_Update(User_Gold, This_Information);
    }
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXEJ1eV9DaGFyYWN0ZXJfU3VyZS5qcyJdLCJuYW1lcyI6WyJTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsIlVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiUmVtaW5kZXJfQm94IiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQ2hhcmFjdGVyX0lkIiwiTGFiZWwiLCJQcmljZV9MYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJvbl9idG5fY2xpY2siLCJXZUNoYXQiLCJMb2FkaW5nX1Nob3BfQ2hhcmFjdGVyIiwiVGhpc19JbmZvcm1hdGlvbl9QcmljZSIsImdldENvbXBvbmVudCIsInN0cmluZyIsIlRoaXNfSW5mb3JtYXRpb24iLCJVc2VyX0dvbGQiLCJHbG9iYWxfVmFyaWFibGUiLCJHb2xkIiwiTmV3X1JlbWluZGVyX0JveCIsImluc3RhbnRpYXRlIiwicGFyZW50IiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiIsImZsYWciLCJpIiwiVXNlcl9IYXZlX0NoYXJhY3RlciIsImxlbmd0aCIsIlVzZXJfQ2hhcmFjdGVyX0luZm9ybWF0aW9uIiwib3BlbmlkIiwiZ2V0Q2hpbGRCeU5hbWUiLCJjb25zb2xlIiwibG9nIiwiQnV5X0NoYXJhY3Rlcl9VcGRhdGUiLCJ1cGRhdGUiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJQSw0QkFBNEIsR0FBR0MsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBLElBQU1DLGlDQUFpQyxHQUFHRCxPQUFPLENBQUMscURBQUQsQ0FBakQ7O0FBQ0FFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxZQUFZLEVBQUM7QUFDVCxpQkFBUSxJQURDO0FBRWxCQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGVTtBQUdsQkMsTUFBQUEsV0FBVyxFQUFDO0FBSE0sS0FETDtBQU1SQyxJQUFBQSxZQUFZLEVBQUM7QUFDVCxpQkFBUSxJQURDO0FBRWxCSCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1MsS0FGVTtBQUdsQkYsTUFBQUEsV0FBVyxFQUFDO0FBSE0sS0FOTDtBQVdSRyxJQUFBQSxXQUFXLEVBQUM7QUFDUixpQkFBUSxJQURBO0FBRWpCTCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1MsS0FGUztBQUdqQkYsTUFBQUEsV0FBVyxFQUFDO0FBSEssS0FYSjtBQWdCUkksSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITixNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1ksSUFGTDtBQUdaTCxNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQWhCQyxHQUhQO0FBMEJMO0FBQ0FNLEVBQUFBLFlBQVksRUFBQyx3QkFBWTtBQUVyQkMsSUFBQUEsTUFBTSxDQUFDQyxzQkFBUCxHQUZxQixDQU9yQjs7QUFDQSxRQUFJQyxzQkFBc0IsR0FBQyxLQUFLTixXQUFMLENBQWlCTyxZQUFqQixDQUE4QmpCLEVBQUUsQ0FBQ1MsS0FBakMsRUFBd0NTLE1BQW5FLENBUnFCLENBU3JCOztBQUNBLFFBQUlDLGdCQUFnQixHQUFDLEtBQUtYLFlBQUwsQ0FBa0JTLFlBQWxCLENBQStCakIsRUFBRSxDQUFDUyxLQUFsQyxFQUF5Q1MsTUFBOUQsQ0FWcUIsQ0FXckI7O0FBQ0EsUUFBSUUsU0FBUyxHQUFDQyxlQUFlLENBQUNDLElBQTlCO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUd2QixFQUFFLENBQUN3QixXQUFILENBQWUsS0FBS3BCLFlBQXBCLENBQXZCO0FBQ0EsU0FBS08sTUFBTCxDQUFZYyxNQUFaLENBQW1CQSxNQUFuQixDQUEwQkMsUUFBMUIsQ0FBbUNILGdCQUFuQztBQUNBQSxJQUFBQSxnQkFBZ0IsQ0FBQ0ksV0FBakIsQ0FBNkIsQ0FBN0IsRUFBK0IsQ0FBQyxHQUFoQztBQUNBLFFBQUlDLElBQUksR0FBQyxDQUFUOztBQUdBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDOUIsaUNBQWlDLENBQUMrQixtQkFBbEMsQ0FBc0RDLE1BQXBFLEVBQTJFRixDQUFDLEVBQTVFLEVBQStFO0FBQy9FO0FBQ0EsVUFBSUcsMEJBQTBCLEdBQUNqQyxpQ0FBaUMsQ0FBQytCLG1CQUFsQyxDQUFzREQsQ0FBdEQsQ0FBL0IsQ0FGK0UsQ0FHM0U7QUFDQTs7QUFDSSxVQUFJVixnQkFBZ0IsSUFBRWEsMEJBQTBCLENBQUN4QixZQUE5QyxJQUE4RGEsZUFBZSxDQUFDWSxNQUFoQixJQUF3QkQsMEJBQTBCLENBQUNDLE1BQXBILEVBQTRIO0FBQ3hIVixRQUFBQSxnQkFBZ0IsQ0FBQ1csY0FBakIsQ0FBZ0MsZUFBaEMsRUFBaURqQixZQUFqRCxDQUE4RGpCLEVBQUUsQ0FBQ1MsS0FBakUsRUFBd0VTLE1BQXhFLEdBQStFLFNBQS9FO0FBQ0FVLFFBQUFBLElBQUksR0FBQyxDQUFMO0FBQ0EsY0FId0gsQ0FJeEg7QUFDWDtBQUNBOztBQUNETyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CcEIsc0JBQW5CO0FBQ0FtQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CaEIsU0FBcEIsRUFoQ3FCLENBaUNyQjs7QUFDQSxRQUFJQSxTQUFTLEdBQUNKLHNCQUFYLElBQXFDWSxJQUFJLElBQUUsQ0FBOUMsRUFBaUQ7QUFDN0NMLE1BQUFBLGdCQUFnQixDQUFDVyxjQUFqQixDQUFnQyxlQUFoQyxFQUFpRGpCLFlBQWpELENBQThEakIsRUFBRSxDQUFDUyxLQUFqRSxFQUF3RVMsTUFBeEUsR0FBK0UsVUFBL0U7QUFDSDs7QUFDRCxRQUFJRSxTQUFTLElBQUVKLHNCQUFaLElBQXNDWSxJQUFJLElBQUUsQ0FBL0MsRUFBa0Q7QUFDOUNMLE1BQUFBLGdCQUFnQixDQUFDVyxjQUFqQixDQUFnQyxlQUFoQyxFQUFpRGpCLFlBQWpELENBQThEakIsRUFBRSxDQUFDUyxLQUFqRSxFQUF3RVMsTUFBeEUsR0FBK0UsU0FBL0U7QUFDQUUsTUFBQUEsU0FBUyxHQUFDQSxTQUFTLEdBQUNKLHNCQUFwQjtBQUNBRixNQUFBQSxNQUFNLENBQUN1QixvQkFBUCxDQUE0QmpCLFNBQTVCLEVBQXNDRCxnQkFBdEM7QUFDSDtBQUtKLEdBekVJO0FBMkVEbUIsRUFBQUEsTUEzRUMsa0JBMkVPQyxFQTNFUCxFQTJFVyxDQUFFO0FBM0ViLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG52YXIgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxuY29uc3QgVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnLi4vTG9jYWxfVmFyaWlibGUvVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgUmVtaW5kZXJfQm94OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDaGFyYWN0ZXJfSWQ6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgUHJpY2VfTGFiZWw6eyAgXHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuICAgIG9uX2J0bl9jbGljazpmdW5jdGlvbiAoKSB7XHJcblxyXG4gICAgICAgIFdlQ2hhdC5Mb2FkaW5nX1Nob3BfQ2hhcmFjdGVyKCk7XHJcblxyXG4gICAgICBcclxuXHJcblxyXG4gICAgICAgIC8v6K+75Y+W5b2T5YmN54K55Ye755qE6KeS6Imy6YeR5biBXHJcbiAgICAgICAgdmFyIFRoaXNfSW5mb3JtYXRpb25fUHJpY2U9dGhpcy5QcmljZV9MYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICAvL+ivu+WPluW9k+WJjeeCueWHu+eahOinkuiJsuS/oeaBr1xyXG4gICAgICAgIHZhciBUaGlzX0luZm9ybWF0aW9uPXRoaXMuQ2hhcmFjdGVyX0lkLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG4gICAgICAgIC8v6K+75Y+W55So5oi35oul5pyJ55qE6YeR5biBXHJcbiAgICAgICAgdmFyIFVzZXJfR29sZD1HbG9iYWxfVmFyaWFibGUuR29sZDtcclxuICAgICAgICB2YXIgTmV3X1JlbWluZGVyX0JveCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuUmVtaW5kZXJfQm94KTtcclxuICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LmFkZENoaWxkKE5ld19SZW1pbmRlcl9Cb3gpO1xyXG4gICAgICAgIE5ld19SZW1pbmRlcl9Cb3guc2V0UG9zaXRpb24oMCwtNDAwKTtcclxuICAgICAgICB2YXIgZmxhZz0wO1xyXG5cclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3Rlci5sZW5ndGg7aSsrKXtcclxuICAgICAgICAvL+ivu+WPlueUqOaIt+aLpeacieeahOinkuiJsuS/oeaBr1xyXG4gICAgICAgIHZhciBVc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbj1Vc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuVXNlcl9IYXZlX0NoYXJhY3RlcltpXTtcclxuICAgICAgICAgICAgLy/liKTmlq3lt7Lnu4/mi6XmnInop5LoibJcclxuICAgICAgICAgICAgLy/liKTmlq3mmK/lkKbmmK/mnKzmnLrnlKjmiLdcclxuICAgICAgICAgICAgICAgIGlmKChUaGlzX0luZm9ybWF0aW9uPT1Vc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSWQpJiYoR2xvYmFsX1ZhcmlhYmxlLm9wZW5pZD09VXNlcl9DaGFyYWN0ZXJfSW5mb3JtYXRpb24ub3BlbmlkKSl7XHJcbiAgICAgICAgICAgICAgICAgICAgTmV3X1JlbWluZGVyX0JveC5nZXRDaGlsZEJ5TmFtZShcIlJlbWluZGVyX1RleHRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCLmgqjlt7Lmi6XmnInor6XllYblk4FcIjtcclxuICAgICAgICAgICAgICAgICAgICBmbGFnPTE7XHJcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/ovpPlh7rlt7Lnu4/mi6XmnIlcclxuICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5bCP6bif5Lu35qC8XCIsVGhpc19JbmZvcm1hdGlvbl9QcmljZSk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCLnlKjmiLfph5HluIHmlbBcIixVc2VyX0dvbGQpO1xyXG4gICAgICAgIC8v5Yik5pat55So5oi36YeR5biB5piv5ZCm6LSt5Lmw55qE6LW35b2T5YmN5bCP6bifICAgICAgIFxyXG4gICAgICAgIGlmKChVc2VyX0dvbGQ8VGhpc19JbmZvcm1hdGlvbl9QcmljZSkmJihmbGFnPT0wKSl7XHJcbiAgICAgICAgICAgIE5ld19SZW1pbmRlcl9Cb3guZ2V0Q2hpbGRCeU5hbWUoXCJSZW1pbmRlcl9UZXh0XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwi6YeR5biB5LiN6Laz6LSt5Lmw5ZWG5ZOBXCI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKChVc2VyX0dvbGQ+PVRoaXNfSW5mb3JtYXRpb25fUHJpY2UpJiYoZmxhZz09MCkpe1xyXG4gICAgICAgICAgICBOZXdfUmVtaW5kZXJfQm94LmdldENoaWxkQnlOYW1lKFwiUmVtaW5kZXJfVGV4dFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIui0reS5sOaIkOWKn+ivpeWVhuWTgVwiO1xyXG4gICAgICAgICAgICBVc2VyX0dvbGQ9VXNlcl9Hb2xkLVRoaXNfSW5mb3JtYXRpb25fUHJpY2U7XHJcbiAgICAgICAgICAgIFdlQ2hhdC5CdXlfQ2hhcmFjdGVyX1VwZGF0ZShVc2VyX0dvbGQsVGhpc19JbmZvcm1hdGlvbik7XHJcbiAgICAgICAgfVxyXG4gXHJcblxyXG5cclxuXHJcbiAgICB9LFxyXG5cclxuICAgICAgICB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Loading_All_Users.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f1ea21R/gtMBb5z8qlYax3s', 'Loading_All_Users');
// resources/script/Account_Management/Loading_All_Users.js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //账号管理预制体
    Account_Managent_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this._Is_Loading = true;
    Account_Management_Local_Variable.All_Users_Information = null;
    WeChat.Loading_All_User();
    console.log("输出账号个数", Account_Management_Local_Variable.All_Users_Information.length);
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Account_Management_Local_Variable.All_Users_Information != null) {
      this.Loading_All_User();
      this._Is_Loading = false;
    }
  },
  Loading_All_User: function Loading_All_User() {
    for (var i = 0; i < Account_Management_Local_Variable.All_Users_Information.length; i++) {
      console.log("1");
      var New_Account_Label = cc.instantiate(this.Account_Label);
      this.Account_Managent_View.addChild(New_Account_Label);
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].openid;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].User_state;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].Reported_Count;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcTG9hZGluZ19BbGxfVXNlcnMuanMiXSwibmFtZXMiOlsiQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQWNjb3VudF9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkFjY291bnRfTWFuYWdlbnRfVmlldyIsIk5vZGUiLCJfSXNfTG9hZGluZyIsIm9uTG9hZCIsIkFsbF9Vc2Vyc19JbmZvcm1hdGlvbiIsIldlQ2hhdCIsIkxvYWRpbmdfQWxsX1VzZXIiLCJjb25zb2xlIiwibG9nIiwibGVuZ3RoIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImkiLCJOZXdfQWNjb3VudF9MYWJlbCIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJnZXRDaGlsZEJ5TmFtZSIsImdldENvbXBvbmVudCIsIkxhYmVsIiwic3RyaW5nIiwib3BlbmlkIiwiVXNlcl9zdGF0ZSIsIlJlcG9ydGVkX0NvdW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLGlDQUFpQyxHQUFHQyxPQUFPLENBQUMsbUNBQUQsQ0FBL0M7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxhQUFhLEVBQUU7QUFDZCxpQkFBUyxJQURLO0FBRWRDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZLO0FBR2RDLE1BQUFBLFdBQVcsRUFBRTtBQUhDLEtBREo7QUFLUjtBQUNIQyxJQUFBQSxxQkFBcUIsRUFBRTtBQUN0QixpQkFBUyxJQURhO0FBRXRCSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1MsSUFGYTtBQUd0QkYsTUFBQUEsV0FBVyxFQUFFO0FBSFMsS0FOWjtBQVVSO0FBQ0hHLElBQUFBLFdBQVcsRUFBRTtBQVhGLEdBSEo7QUFpQlI7QUFFQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCLFNBQUtELFdBQUwsR0FBaUIsSUFBakI7QUFDQVosSUFBQUEsaUNBQWlDLENBQUNjLHFCQUFsQyxHQUF3RCxJQUF4RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLGdCQUFQO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JsQixpQ0FBaUMsQ0FBQ2MscUJBQWxDLENBQXdESyxNQUE5RTtBQUNBLEdBeEJPO0FBMEJSQyxFQUFBQSxLQTFCUSxtQkEwQkEsQ0FFUCxDQTVCTztBQThCUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEIsUUFBRyxLQUFLVixXQUFMLElBQWtCWixpQ0FBaUMsQ0FBQ2MscUJBQWxDLElBQXlELElBQTlFLEVBQW1GO0FBQ2xGLFdBQUtFLGdCQUFMO0FBQ0EsV0FBS0osV0FBTCxHQUFpQixLQUFqQjtBQUNBO0FBQ0QsR0FuQ087QUFxQ1JJLEVBQUFBLGdCQXJDUSw4QkFxQ1c7QUFDbEIsU0FBSyxJQUFJTyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHdkIsaUNBQWlDLENBQUNjLHFCQUFsQyxDQUF3REssTUFBNUUsRUFBb0ZJLENBQUMsRUFBckYsRUFBeUY7QUFDeEZOLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEdBQVo7QUFDQSxVQUFJTSxpQkFBaUIsR0FBR3RCLEVBQUUsQ0FBQ3VCLFdBQUgsQ0FBZSxLQUFLbkIsYUFBcEIsQ0FBeEI7QUFDQSxXQUFLSSxxQkFBTCxDQUEyQmdCLFFBQTNCLENBQW9DRixpQkFBcEM7QUFDQUEsTUFBQUEsaUJBQWlCLENBQUNHLGNBQWxCLENBQWlDLDBCQUFqQyxFQUE2REEsY0FBN0QsQ0FBNEUsZUFBNUUsRUFBNkZBLGNBQTdGLENBQ0MsY0FERCxFQUNpQkMsWUFEakIsQ0FDOEIxQixFQUFFLENBQUMyQixLQURqQyxFQUN3Q0MsTUFEeEMsR0FDaUQsS0FBSzlCLGlDQUFpQyxDQUFDYyxxQkFBbEMsQ0FBd0RTLENBQXhELEVBQTJEUSxNQURqSDtBQUVBUCxNQUFBQSxpQkFBaUIsQ0FBQ0csY0FBbEIsQ0FBaUMsMEJBQWpDLEVBQTZEQSxjQUE3RCxDQUE0RSxzQkFBNUUsRUFBb0dBLGNBQXBHLENBQ0MscUJBREQsRUFDd0JDLFlBRHhCLENBQ3FDMUIsRUFBRSxDQUFDMkIsS0FEeEMsRUFDK0NDLE1BRC9DLEdBQ3dELEtBQUs5QixpQ0FBaUMsQ0FBQ2MscUJBQWxDLENBQzVEUyxDQUQ0RCxFQUN6RFMsVUFGSjtBQUdBUixNQUFBQSxpQkFBaUIsQ0FBQ0csY0FBbEIsQ0FBaUMsMEJBQWpDLEVBQTZEQSxjQUE3RCxDQUE0RSwyQ0FBNUUsRUFBeUhBLGNBQXpILENBQ0MsMENBREQsRUFDNkNDLFlBRDdDLENBQzBEMUIsRUFBRSxDQUFDMkIsS0FEN0QsRUFDb0VDLE1BRHBFLEdBQzZFLEtBQUs5QixpQ0FBaUMsQ0FBQ2MscUJBQWxDLENBQ2pGUyxDQURpRixFQUM5RVUsY0FGSjtBQUdBO0FBQ0Q7QUFuRE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJ0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRBY2NvdW50X0xhYmVsOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i0puWPt+euoeeQhumihOWItuS9k1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VudF9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/mjpLlkI3moYZcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz10cnVlO1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbj1udWxsO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfQWxsX1VzZXIoKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi6L6T5Ye66LSm5Y+35Liq5pWwXCIsIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5BbGxfVXNlcnNfSW5mb3JtYXRpb24ubGVuZ3RoKTtcclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0aWYodGhpcy5fSXNfTG9hZGluZyYmQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbiE9bnVsbCl7XHJcblx0XHRcdHRoaXMuTG9hZGluZ19BbGxfVXNlcigpO1xyXG5cdFx0XHR0aGlzLl9Jc19Mb2FkaW5nPWZhbHNlO1xyXG5cdFx0fVxyXG5cdH0sXHJcblxyXG5cdExvYWRpbmdfQWxsX1VzZXIoKSB7XHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5BbGxfVXNlcnNfSW5mb3JtYXRpb24ubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0Y29uc29sZS5sb2coXCIxXCIpO1xyXG5cdFx0XHR2YXIgTmV3X0FjY291bnRfTGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkFjY291bnRfTGFiZWwpO1xyXG5cdFx0XHR0aGlzLkFjY291bnRfTWFuYWdlbnRfVmlldy5hZGRDaGlsZChOZXdfQWNjb3VudF9MYWJlbCk7XHJcblx0XHRcdE5ld19BY2NvdW50X0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9NYW5hZ2VtZW50X0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiVXNlcl9JZF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcclxuXHRcdFx0XHRcIlVzZXJfSWRfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuQWxsX1VzZXJzX0luZm9ybWF0aW9uW2ldLm9wZW5pZDtcclxuXHRcdFx0TmV3X0FjY291bnRfTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X01hbmFnZW1lbnRfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X1N0YXR1c19MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcclxuXHRcdFx0XHRcIkFjY291bnRfU3RhdHVzX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbltcclxuXHRcdFx0XHRpXS5Vc2VyX3N0YXRlO1xyXG5cdFx0XHROZXdfQWNjb3VudF9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfTWFuYWdlbWVudF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFxyXG5cdFx0XHRcdFwiQ3VtdWxhdGl2ZV9OdW1iZXJfT2ZfUmVwb3J0ZWRfQ2FzZXNfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuQWxsX1VzZXJzX0luZm9ybWF0aW9uW1xyXG5cdFx0XHRcdGldLlJlcG9ydGVkX0NvdW50O1xyXG5cdFx0fVxyXG5cdH0sXHJcbn0pO1xuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Closure_Account.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3ff96/E4BtH1onOg+sWVBCi', 'Closure_Account');
// resources/script/Account_Management/Closure_Account.js

"use strict";

//封停账号
cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    User_Id_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Input_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    var Openid = this.User_Id_Show.getComponent(cc.Label).string;
    var Input = Number(this.Input_Show.getComponent(cc.Label).string);

    if (!isNaN(Input)) {
      WeChat.Closure_Account(Openid, Input);
      WeChat.Handle_Reported_User(Openid);
      this.Account_Label.destroy();
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQ2xvc3VyZV9BY2NvdW50LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQWNjb3VudF9MYWJlbCIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJVc2VyX0lkX1Nob3ciLCJMYWJlbCIsIklucHV0X1Nob3ciLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIk9wZW5pZCIsImdldENvbXBvbmVudCIsInN0cmluZyIsIklucHV0IiwiTnVtYmVyIiwiaXNOYU4iLCJXZUNoYXQiLCJDbG9zdXJlX0FjY291bnQiLCJIYW5kbGVfUmVwb3J0ZWRfVXNlciIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLGFBQWEsRUFBQztBQUNiLGlCQUFTLElBREk7QUFFYkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLElBRkk7QUFHYkMsTUFBQUEsV0FBVyxFQUFFO0FBSEEsS0FESDtBQU1YQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxLQUZJO0FBR2JGLE1BQUFBLFdBQVcsRUFBRTtBQUhBLEtBTkg7QUFXWEcsSUFBQUEsVUFBVSxFQUFFO0FBQ1gsaUJBQVMsSUFERTtBQUVYTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1MsS0FGRTtBQUdYRixNQUFBQSxXQUFXLEVBQUU7QUFIRjtBQVhELEdBSEo7QUFzQlI7QUFFQTtBQUVBSSxFQUFBQSxLQTFCUSxtQkEwQkEsQ0FFUCxDQTVCTztBQTZCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCLFFBQUlDLE1BQU0sR0FBQyxLQUFLTCxZQUFMLENBQWtCTSxZQUFsQixDQUErQmQsRUFBRSxDQUFDUyxLQUFsQyxFQUF5Q00sTUFBcEQ7QUFDQSxRQUFJQyxLQUFLLEdBQUNDLE1BQU0sQ0FBQyxLQUFLUCxVQUFMLENBQWdCSSxZQUFoQixDQUE2QmQsRUFBRSxDQUFDUyxLQUFoQyxFQUF1Q00sTUFBeEMsQ0FBaEI7O0FBQ0EsUUFBSSxDQUFDRyxLQUFLLENBQUNGLEtBQUQsQ0FBVixFQUFrQjtBQUNsQkcsTUFBQUEsTUFBTSxDQUFDQyxlQUFQLENBQXVCUCxNQUF2QixFQUE4QkcsS0FBOUI7QUFDQUcsTUFBQUEsTUFBTSxDQUFDRSxvQkFBUCxDQUE0QlIsTUFBNUI7QUFDQSxXQUFLVCxhQUFMLENBQW1Ca0IsT0FBbkI7QUFDQztBQUNELEdBckNPLENBdUNSOztBQXZDUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+WwgeWBnOi0puWPt1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRBY2NvdW50X0xhYmVsOntcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTm9kZSxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LFxyXG5cdFx0VXNlcl9JZF9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRJbnB1dF9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRcclxuXHR9LFxyXG5cclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIE9wZW5pZD10aGlzLlVzZXJfSWRfU2hvdy5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuXHRcdHZhciBJbnB1dD1OdW1iZXIodGhpcy5JbnB1dF9TaG93LmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKTtcclxuXHRcdGlmICghaXNOYU4oSW5wdXQpKXtcclxuXHRcdFdlQ2hhdC5DbG9zdXJlX0FjY291bnQoT3BlbmlkLElucHV0KTtcclxuXHRcdFdlQ2hhdC5IYW5kbGVfUmVwb3J0ZWRfVXNlcihPcGVuaWQpO1xyXG5cdFx0dGhpcy5BY2NvdW50X0xhYmVsLmRlc3Ryb3koKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Loading_All_Reported_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'afec0r3ZNlGZL+pBm6bChur', 'Loading_All_Reported_User');
// resources/script/Account_Management/Loading_All_Reported_User.js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Uid_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //Openid
    Report_Information_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  // update (dt) {},
  on_btn_click: function on_btn_click() {
    var Openid = this.Uid_Show.getComponent(cc.Label).string;
    WeChat.Loading_Report_User(Openid);
    console.log("下拉举报");
    WeChat.Loading_All_User();
    console.log("输出账号个数", Account_Management_Local_Variable.Report_User_List.length);

    for (var i = 0; i < Account_Management_Local_Variable.Report_User_List.length; i++) {
      console.log("1");
      var New_Report_Information_Label = cc.instantiate(this.Report_Information_Label);
      this.Account_Label.addChild(New_Report_Information_Label);
      New_Report_Information_Label.getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Report_User_List[i].Report_Openid;
      New_Report_Information_Label.getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Report_User_List[i].Report_Time.toString();
      New_Report_Information_Label.getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Report_User_List[i].Report_Reason;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcTG9hZGluZ19BbGxfUmVwb3J0ZWRfVXNlci5qcyJdLCJuYW1lcyI6WyJBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJVaWRfU2hvdyIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwiUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsIiwiUHJlZmFiIiwiQWNjb3VudF9MYWJlbCIsIk5vZGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIk9wZW5pZCIsImdldENvbXBvbmVudCIsInN0cmluZyIsIldlQ2hhdCIsIkxvYWRpbmdfUmVwb3J0X1VzZXIiLCJjb25zb2xlIiwibG9nIiwiTG9hZGluZ19BbGxfVXNlciIsIlJlcG9ydF9Vc2VyX0xpc3QiLCJsZW5ndGgiLCJpIiwiTmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbCIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJnZXRDaGlsZEJ5TmFtZSIsIlJlcG9ydF9PcGVuaWQiLCJSZXBvcnRfVGltZSIsInRvU3RyaW5nIiwiUmVwb3J0X1JlYXNvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxpQ0FBaUMsR0FBQ0MsT0FBTyxDQUFDLG1DQUFELENBQTdDOztBQUVBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsUUFBUSxFQUFDO0FBQ1IsaUJBQVEsSUFEQTtBQUVSQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sS0FGQTtBQUdSQyxNQUFBQSxXQUFXLEVBQUM7QUFISixLQURFO0FBS1Q7QUFDRkMsSUFBQUEsd0JBQXdCLEVBQUM7QUFDeEIsaUJBQVEsSUFEZ0I7QUFFeEJILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxNQUZnQjtBQUd4QkYsTUFBQUEsV0FBVyxFQUFDO0FBSFksS0FOZDtBQVdYRyxJQUFBQSxhQUFhLEVBQUM7QUFDYixpQkFBUSxJQURLO0FBRWJMLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDVyxJQUZLO0FBR2JKLE1BQUFBLFdBQVcsRUFBQztBQUhDO0FBWEgsR0FISjtBQXNCUjtBQUVBO0FBRUFLLEVBQUFBLEtBMUJRLG1CQTBCQSxDQUVQLENBNUJPO0FBOEJSO0FBQ0FDLEVBQUFBLFlBQVksRUFBRSx3QkFBVztBQUN4QixRQUFJQyxNQUFNLEdBQUMsS0FBS1YsUUFBTCxDQUFjVyxZQUFkLENBQTJCZixFQUFFLENBQUNNLEtBQTlCLEVBQXFDVSxNQUFoRDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLG1CQUFQLENBQTJCSixNQUEzQjtBQUNBSyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FILElBQUFBLE1BQU0sQ0FBQ0ksZ0JBQVA7QUFDQUYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQnRCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1EQyxNQUF4RTs7QUFDQSxTQUFJLElBQUlDLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQzFCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1EQyxNQUFqRSxFQUF3RUMsQ0FBQyxFQUF6RSxFQUE0RTtBQUMzRUwsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksR0FBWjtBQUNBLFVBQUlLLDRCQUE0QixHQUFDekIsRUFBRSxDQUFDMEIsV0FBSCxDQUFlLEtBQUtsQix3QkFBcEIsQ0FBakM7QUFDQSxXQUFLRSxhQUFMLENBQW1CaUIsUUFBbkIsQ0FBNEJGLDRCQUE1QjtBQUNBQSxNQUFBQSw0QkFBNEIsQ0FBQ0csY0FBN0IsQ0FBNEMsZUFBNUMsRUFBNkRBLGNBQTdELENBQTRFLGNBQTVFLEVBQTRGYixZQUE1RixDQUF5R2YsRUFBRSxDQUFDTSxLQUE1RyxFQUFtSFUsTUFBbkgsR0FBMEgsS0FBR2xCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1ERSxDQUFuRCxFQUFzREssYUFBbkw7QUFDQUosTUFBQUEsNEJBQTRCLENBQUNHLGNBQTdCLENBQTRDLHNCQUE1QyxFQUFvRUEsY0FBcEUsQ0FBbUYscUJBQW5GLEVBQTBHYixZQUExRyxDQUF1SGYsRUFBRSxDQUFDTSxLQUExSCxFQUFpSVUsTUFBakksR0FBd0ksS0FBR2xCLGlDQUFpQyxDQUFDd0IsZ0JBQWxDLENBQW1ERSxDQUFuRCxFQUFzRE0sV0FBdEQsQ0FBa0VDLFFBQWxFLEVBQTNJO0FBQ0FOLE1BQUFBLDRCQUE0QixDQUFDRyxjQUE3QixDQUE0QywyQ0FBNUMsRUFBeUZBLGNBQXpGLENBQXdHLDBDQUF4RyxFQUFvSmIsWUFBcEosQ0FBaUtmLEVBQUUsQ0FBQ00sS0FBcEssRUFBMktVLE1BQTNLLEdBQWtMLEtBQUdsQixpQ0FBaUMsQ0FBQ3dCLGdCQUFsQyxDQUFtREUsQ0FBbkQsRUFBc0RRLGFBQTNPO0FBQ0E7QUFDRDtBQTdDTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlPXJlcXVpcmUoJ0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0VWlkX1Nob3c6e1xyXG5cdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSwvL09wZW5pZFxyXG5cdFx0UmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsOntcclxuXHRcdFx0ZGVmYXVsdDpudWxsLFxyXG5cdFx0XHR0eXBlOmNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRBY2NvdW50X0xhYmVsOntcclxuXHRcdFx0ZGVmYXVsdDpudWxsLFxyXG5cdFx0XHR0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcblx0XHR9LFxyXG5cdFx0XG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cclxuXHQvLyB1cGRhdGUgKGR0KSB7fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIE9wZW5pZD10aGlzLlVpZF9TaG93LmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfUmVwb3J0X1VzZXIoT3BlbmlkKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi5LiL5ouJ5Li+5oqlXCIpO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfQWxsX1VzZXIoKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi6L6T5Ye66LSm5Y+35Liq5pWwXCIsQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3QubGVuZ3RoKTtcclxuXHRcdGZvcih2YXIgaT0wO2k8QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3QubGVuZ3RoO2krKyl7XHRcclxuXHRcdFx0Y29uc29sZS5sb2coXCIxXCIpO1xyXG5cdFx0XHR2YXIgTmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbD1jYy5pbnN0YW50aWF0ZSh0aGlzLlJlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbCk7XHJcblx0XHRcdHRoaXMuQWNjb3VudF9MYWJlbC5hZGRDaGlsZChOZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsKTtcclxuXHRcdFx0TmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIlVzZXJfSWRfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXCJVc2VyX0lkX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0X1VzZXJfTGlzdFtpXS5SZXBvcnRfT3BlbmlkO1xyXG5cdFx0XHROZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9TdGF0dXNfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X1N0YXR1c19TaG93XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydF9Vc2VyX0xpc3RbaV0uUmVwb3J0X1RpbWUudG9TdHJpbmcoKTtcclxuXHRcdFx0TmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiQ3VtdWxhdGl2ZV9OdW1iZXJfT2ZfUmVwb3J0ZWRfQ2FzZXNfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5SZXBvcnRfVXNlcl9MaXN0W2ldLlJlcG9ydF9SZWFzb247XHJcblx0XHR9XHJcblx0fVxyXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Closure/Tip_Close.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ef9d6HOYUVHH5W82LluoCbX', 'Tip_Close');
// resources/script/Closure/Tip_Close.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    tip: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.tip.destroy();
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXENsb3N1cmVcXFRpcF9DbG9zZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInRpcCIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxHQUFHLEVBQUM7QUFDQSxpQkFBUyxJQURUO0FBRVRDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQUZBO0FBR1RDLE1BQUFBLFdBQVcsRUFBRTtBQUhKO0FBREksR0FIUDtBQVlMQyxFQUFBQSxLQVpLLG1CQVlJLENBRVIsQ0FkSTtBQWVSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEIsU0FBS0wsR0FBTCxDQUFTTSxPQUFUO0FBQ0E7QUFqQk8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICB0aXA6e1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblx0XHJcbiAgICB9LFxyXG5cdG9uX2J0bl9jbGljazogZnVuY3Rpb24oKSB7XHJcblx0XHR0aGlzLnRpcC5kZXN0cm95KCk7XHJcblx0fVxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Appeal_Confirm.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'de10cJbjlJPIq8tcs3hqSTQ', 'Appeal_Confirm');
// resources/script/Account_Management/Appeal_Confirm.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    Appeal_Content: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //举报框

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //载入申诉人的信息
    console.log("点到了吗??");
    var Appeal_Text = this.Appeal_Content.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "关于对账号的申诉";
    var Content = "系统已收到您的申诉，请等待处理			申诉原因：" + Appeal_Text;
    WeChat.Email_Report_And_Appeal(Time, Title, Content);
    console.log("申诉内容为", Appeal_Text); //上传举报信息

    WeChat.Uploading_Reported_Information(Global_Variable.openid, Appeal_Text);
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQXBwZWFsX0NvbmZpcm0uanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJBcHBlYWxfQ29udGVudCIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJjb25zb2xlIiwibG9nIiwiQXBwZWFsX1RleHQiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJUaW1lIiwicGFyc2VJbnQiLCJEYXRlIiwiZ2V0VGltZSIsIlRpdGxlIiwiQ29udGVudCIsIldlQ2hhdCIsIkVtYWlsX1JlcG9ydF9BbmRfQXBwZWFsIiwiVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uIiwiR2xvYmFsX1ZhcmlhYmxlIiwib3BlbmlkIiwibm9kZSIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUVYQyxJQUFBQSxjQUFjLEVBQUU7QUFDZixpQkFBUyxJQURNO0FBRWZDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZNO0FBR2ZDLE1BQUFBLFdBQVcsRUFBRTtBQUhFLEtBRkwsQ0FNVDs7QUFOUyxHQUhKO0FBWVI7QUFFQTtBQUNBQyxFQUFBQSxLQWZRLG1CQWVBLENBRVAsQ0FqQk87QUFrQlJDLEVBQUFBLFlBQVksRUFBRSx3QkFBVztBQUN4QjtBQUNBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0EsUUFBSUMsV0FBVyxHQUFHLEtBQUtSLGNBQUwsQ0FBb0JTLFlBQXBCLENBQWlDYixFQUFFLENBQUNNLEtBQXBDLEVBQTJDUSxNQUE3RCxDQUh3QixDQUt0Qjs7QUFDRixRQUFJQyxJQUFJLEdBQUdDLFFBQVEsQ0FBQyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBRCxDQUFuQjtBQUNBLFFBQUlDLEtBQUssR0FBRyxVQUFaO0FBQ0EsUUFBSUMsT0FBTyxHQUFFLDRCQUEwQlIsV0FBdkM7QUFDQVMsSUFBQUEsTUFBTSxDQUFDQyx1QkFBUCxDQUErQlAsSUFBL0IsRUFBb0NJLEtBQXBDLEVBQTBDQyxPQUExQztBQUNBVixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQXFCQyxXQUFyQixFQVZ3QixDQVd4Qjs7QUFDQVMsSUFBQUEsTUFBTSxDQUFDRSw4QkFBUCxDQUFzQ0MsZUFBZSxDQUFDQyxNQUF0RCxFQUE2RGIsV0FBN0Q7QUFDQSxTQUFLYyxJQUFMLENBQVVDLE9BQVY7QUFDQSxHQWhDTyxDQWlDUjs7QUFqQ1EsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cclxuXHRcdEFwcGVhbF9Db250ZW50OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sLy/kuL7miqXmoYZcclxuXHR9LFxyXG5cclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cdG9uX2J0bl9jbGljazogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+i9veWFpeeUs+ivieS6uueahOS/oeaBr1xyXG5cdFx0Y29uc29sZS5sb2coXCLngrnliLDkuoblkJc/P1wiKTtcclxuXHRcdHZhciBBcHBlYWxfVGV4dCA9IHRoaXMuQXBwZWFsX0NvbnRlbnQuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcblxyXG5cdFx0ICAvL+iOt+WPluaXtumXtOaIs1xyXG5cdFx0bGV0IFRpbWUgPSBwYXJzZUludChuZXcgRGF0ZSgpLmdldFRpbWUoKSk7XHJcblx0XHR2YXIgVGl0bGUgPSBcIuWFs+S6juWvuei0puWPt+eahOeUs+iviVwiO1xyXG5cdFx0dmFyIENvbnRlbnQgPVwi57O757uf5bey5pS25Yiw5oKo55qE55Sz6K+J77yM6K+3562J5b6F5aSE55CGXHRcdFx055Sz6K+J5Y6f5Zug77yaXCIrQXBwZWFsX1RleHQ7XHJcblx0XHRXZUNoYXQuRW1haWxfUmVwb3J0X0FuZF9BcHBlYWwoVGltZSxUaXRsZSxDb250ZW50KTtcclxuXHRcdGNvbnNvbGUubG9nKFwi55Sz6K+J5YaF5a655Li6XCIsIEFwcGVhbF9UZXh0KTtcclxuXHRcdC8v5LiK5Lyg5Li+5oql5L+h5oGvXHJcblx0XHRXZUNoYXQuVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uKEdsb2JhbF9WYXJpYWJsZS5vcGVuaWQsQXBwZWFsX1RleHQpO1xyXG5cdFx0dGhpcy5ub2RlLmRlc3Ryb3koKTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Cancel_Closure.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c2475IN0ABFuY27U34UTn1M', 'Cancel_Closure');
// resources/script/Account_Management/Cancel_Closure.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    User_Id_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //Openid

  },
  start: function start() {
    WeChat.Cancel_Closure;
  },
  on_btn_click: function on_btn_click() {
    var Openid = this.User_Id_Show.getComponent(cc.Label).string;
    WeChat.Cancel_Closure(Openid);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQ2FuY2VsX0Nsb3N1cmUuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJVc2VyX0lkX1Nob3ciLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsInN0YXJ0IiwiV2VDaGF0IiwiQ2FuY2VsX0Nsb3N1cmUiLCJvbl9idG5fY2xpY2siLCJPcGVuaWQiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNkQyxJQUFBQSxZQUFZLEVBQUM7QUFDWixpQkFBUSxJQURJO0FBRVpDLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxLQUZJO0FBR1pDLE1BQUFBLFdBQVcsRUFBQztBQUhBLEtBREMsQ0FLWjs7QUFMWSxHQUhQO0FBWUxDLEVBQUFBLEtBWkssbUJBWUk7QUFDYkMsSUFBQUEsTUFBTSxDQUFDQyxjQUFQO0FBQ0ssR0FkSTtBQWVSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEIsUUFBSUMsTUFBTSxHQUFDLEtBQUtSLFlBQUwsQ0FBa0JTLFlBQWxCLENBQStCYixFQUFFLENBQUNNLEtBQWxDLEVBQXlDUSxNQUFwRDtBQUNBTCxJQUFBQSxNQUFNLENBQUNDLGNBQVAsQ0FBc0JFLE1BQXRCO0FBQ0EsR0FsQk8sQ0FtQkw7O0FBbkJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHRcdFVzZXJfSWRfU2hvdzp7XHJcblx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcblx0XHR9LC8vT3BlbmlkXHJcbiAgICB9LFxyXG5cclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbldlQ2hhdC5DYW5jZWxfQ2xvc3VyZVxyXG4gICAgfSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIE9wZW5pZD10aGlzLlVzZXJfSWRfU2hvdy5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuXHRcdFdlQ2hhdC5DYW5jZWxfQ2xvc3VyZShPcGVuaWQpO1xyXG5cdH1cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Closure/Closure_Tips.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5eeabuJZA1Gm6NyqsZ1kn6R', 'Closure_Tips');
// resources/script/Closure/Closure_Tips.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Closure_Tips_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //封号信息显示

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    //封号提示
    this.Closure_Tips_Show.getComponent(cc.Label).string = "因为违规操作\n你的帐号已经封停\n将在" + Global_Variable.Unsealing_Time + "后\n解封";
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXENsb3N1cmVcXENsb3N1cmVfVGlwcy5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkNsb3N1cmVfVGlwc19TaG93IiwidHlwZSIsIkxhYmVsIiwic2VyaWFsemFibGUiLCJzdGFydCIsImdldENvbXBvbmVudCIsInN0cmluZyIsIkdsb2JhbF9WYXJpYWJsZSIsIlVuc2VhbGluZ19UaW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDTkMsSUFBQUEsaUJBQWlCLEVBQUU7QUFDbEIsaUJBQVMsSUFEUztBQUVsQkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLEtBRlM7QUFHbEJDLE1BQUFBLFdBQVcsRUFBRTtBQUhLLEtBRGIsQ0FLSjs7QUFMSSxHQUhQO0FBV0w7QUFFQTtBQUVBQyxFQUFBQSxLQWZLLG1CQWVJO0FBQ1g7QUFDQSxTQUFLSixpQkFBTCxDQUF1QkssWUFBdkIsQ0FBb0NULEVBQUUsQ0FBQ00sS0FBdkMsRUFBOENJLE1BQTlDLEdBQXFELHlCQUF1QkMsZUFBZSxDQUFDQyxjQUF2QyxHQUFzRCxPQUEzRztBQUNHLEdBbEJJLENBb0JMOztBQXBCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgXHRcdENsb3N1cmVfVGlwc19TaG93OiB7XHJcbiAgICAgICAgXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuICAgICAgICBcdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuICAgICAgICBcdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuICAgICAgICBcdFx0fSwvL+WwgeWPt+S/oeaBr+aYvuekulxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cdFx0Ly/lsIHlj7fmj5DnpLpcclxuXHRcdHRoaXMuQ2xvc3VyZV9UaXBzX1Nob3cuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCLlm6DkuLrov53op4Tmk43kvZxcXG7kvaDnmoTluJDlj7flt7Lnu4/lsIHlgZxcXG7lsIblnKhcIitHbG9iYWxfVmFyaWFibGUuVW5zZWFsaW5nX1RpbWUrXCLlkI5cXG7op6PlsIFcIjtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Loading_Reported_Users .js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'cc8ca7SnsNONIRq0fD+GC6m', 'Loading_Reported_Users ');
// resources/script/Account_Management/Loading_Reported_Users .js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //账号管理预制体
    Account_Managent_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    Report_Information_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    Account_Management_Local_Variable.Reported_Users_Information = null;
    this._Is_Loading = true;
    WeChat.Loading_Reporterd_User();
    console.log("被举报人信息个数", Account_Management_Local_Variable.Reported_Users_Information.length);
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Account_Management_Local_Variable.Reported_Users_Information != null) {
      this.Loading_Reported_Users();
      this._Is_Loading = false;
    }
  },
  Loading_Reported_Users: function Loading_Reported_Users() {
    for (var i = 0; i < Account_Management_Local_Variable.Reported_Users_Information.length; i++) {
      console.log("1");
      var New_Account_Label = cc.instantiate(this.Account_Label);
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Reported_Users_Information[i].openid;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Reported_Users_Information[i].User_state;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].Reported_Count;
      var openidlist = Account_Management_Local_Variable.Reported_Users_Information[i].openidlist;
      New_Account_Label.height = 500 + openidlist.length * 200;
      this.Account_Managent_View.addChild(New_Account_Label);

      for (var j = 0; j < openidlist.length; j++) {
        console.log("查看openidlist", openidlist[j]);
        var New_Report_Information_Label = cc.instantiate(this.Report_Information_Label);
        New_Account_Label.addChild(New_Report_Information_Label);
        New_Report_Information_Label.getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + openidlist[j].Reported_Openid;
        New_Report_Information_Label.getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + openidlist[j].Report_Time.toString();
        New_Report_Information_Label.getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + openidlist[j].Report_Reason;
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcTG9hZGluZ19SZXBvcnRlZF9Vc2VycyAuanMiXSwibmFtZXMiOlsiQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQWNjb3VudF9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkFjY291bnRfTWFuYWdlbnRfVmlldyIsIk5vZGUiLCJSZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwiLCJfSXNfTG9hZGluZyIsIm9uTG9hZCIsIlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uIiwiV2VDaGF0IiwiTG9hZGluZ19SZXBvcnRlcmRfVXNlciIsImNvbnNvbGUiLCJsb2ciLCJsZW5ndGgiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiTG9hZGluZ19SZXBvcnRlZF9Vc2VycyIsImkiLCJOZXdfQWNjb3VudF9MYWJlbCIsImluc3RhbnRpYXRlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIm9wZW5pZCIsIlVzZXJfc3RhdGUiLCJBbGxfVXNlcnNfSW5mb3JtYXRpb24iLCJSZXBvcnRlZF9Db3VudCIsIm9wZW5pZGxpc3QiLCJoZWlnaHQiLCJhZGRDaGlsZCIsImoiLCJOZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsIiwiUmVwb3J0ZWRfT3BlbmlkIiwiUmVwb3J0X1RpbWUiLCJ0b1N0cmluZyIsIlJlcG9ydF9SZWFzb24iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsaUNBQWlDLEdBQUdDLE9BQU8sQ0FBQyxtQ0FBRCxDQUEvQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLGFBQWEsRUFBRTtBQUNkLGlCQUFTLElBREs7QUFFZEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRks7QUFHZEMsTUFBQUEsV0FBVyxFQUFFO0FBSEMsS0FESjtBQUtSO0FBQ0hDLElBQUFBLHFCQUFxQixFQUFFO0FBQ3RCLGlCQUFTLElBRGE7QUFFdEJILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxJQUZhO0FBR3RCRixNQUFBQSxXQUFXLEVBQUU7QUFIUyxLQU5aO0FBVVI7QUFDSEcsSUFBQUEsd0JBQXdCLEVBQUU7QUFDekIsaUJBQVMsSUFEZ0I7QUFFekJMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZnQjtBQUd6QkMsTUFBQUEsV0FBVyxFQUFFO0FBSFksS0FYZjtBQWdCWEksSUFBQUEsV0FBVyxFQUFFO0FBaEJGLEdBSEo7QUFzQlI7QUFFQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCZCxJQUFBQSxpQ0FBaUMsQ0FBQ2UsMEJBQWxDLEdBQStELElBQS9EO0FBQ0EsU0FBS0YsV0FBTCxHQUFtQixJQUFuQjtBQUNBRyxJQUFBQSxNQUFNLENBQUNDLHNCQUFQO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVosRUFBd0JuQixpQ0FBaUMsQ0FBQ2UsMEJBQWxDLENBQTZESyxNQUFyRjtBQUVBLEdBOUJPO0FBZ0NSQyxFQUFBQSxLQWhDUSxtQkFnQ0EsQ0FFUCxDQWxDTztBQW9DUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEIsUUFBSSxLQUFLVixXQUFMLElBQW9CYixpQ0FBaUMsQ0FBQ2UsMEJBQWxDLElBQWdFLElBQXhGLEVBQThGO0FBQzdGLFdBQUtTLHNCQUFMO0FBQ0EsV0FBS1gsV0FBTCxHQUFtQixLQUFuQjtBQUNBO0FBQ0QsR0F6Q087QUEwQ1JXLEVBQUFBLHNCQTFDUSxvQ0EwQ2lCO0FBQ3hCLFNBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR3pCLGlDQUFpQyxDQUFDZSwwQkFBbEMsQ0FBNkRLLE1BQWpGLEVBQXlGSyxDQUFDLEVBQTFGLEVBQThGO0FBQzdGUCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxHQUFaO0FBQ0EsVUFBSU8saUJBQWlCLEdBQUd4QixFQUFFLENBQUN5QixXQUFILENBQWUsS0FBS3JCLGFBQXBCLENBQXhCO0FBQ0FvQixNQUFBQSxpQkFBaUIsQ0FBQ0UsY0FBbEIsQ0FBaUMsMEJBQWpDLEVBQTZEQSxjQUE3RCxDQUE0RSxlQUE1RSxFQUE2RkEsY0FBN0YsQ0FDQyxjQURELEVBQ2lCQyxZQURqQixDQUM4QjNCLEVBQUUsQ0FBQzRCLEtBRGpDLEVBQ3dDQyxNQUR4QyxHQUNpRCxLQUFLL0IsaUNBQWlDLENBQUNlLDBCQUFsQyxDQUNyRFUsQ0FEcUQsRUFDbERPLE1BRko7QUFHQU4sTUFBQUEsaUJBQWlCLENBQUNFLGNBQWxCLENBQWlDLDBCQUFqQyxFQUE2REEsY0FBN0QsQ0FBNEUsc0JBQTVFLEVBQW9HQSxjQUFwRyxDQUNDLHFCQURELEVBQ3dCQyxZQUR4QixDQUNxQzNCLEVBQUUsQ0FBQzRCLEtBRHhDLEVBQytDQyxNQUQvQyxHQUN3RCxLQUFLL0IsaUNBQWlDLENBQUNlLDBCQUFsQyxDQUM1RFUsQ0FENEQsRUFDekRRLFVBRko7QUFHQVAsTUFBQUEsaUJBQWlCLENBQUNFLGNBQWxCLENBQWlDLDBCQUFqQyxFQUE2REEsY0FBN0QsQ0FDQywyQ0FERCxFQUM4Q0EsY0FEOUMsQ0FDNkQsMENBRDdELEVBQ3lHQyxZQUR6RyxDQUVDM0IsRUFBRSxDQUFDNEIsS0FGSixFQUVXQyxNQUZYLEdBRW9CLEtBQUsvQixpQ0FBaUMsQ0FBQ2tDLHFCQUFsQyxDQUF3RFQsQ0FBeEQsRUFBMkRVLGNBRnBGO0FBR0EsVUFBSUMsVUFBVSxHQUFHcEMsaUNBQWlDLENBQUNlLDBCQUFsQyxDQUE2RFUsQ0FBN0QsRUFBZ0VXLFVBQWpGO0FBQ0FWLE1BQUFBLGlCQUFpQixDQUFDVyxNQUFsQixHQUEyQixNQUFNRCxVQUFVLENBQUNoQixNQUFYLEdBQW9CLEdBQXJEO0FBQ0EsV0FBS1YscUJBQUwsQ0FBMkI0QixRQUEzQixDQUFvQ1osaUJBQXBDOztBQUNBLFdBQUssSUFBSWEsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsVUFBVSxDQUFDaEIsTUFBL0IsRUFBdUNtQixDQUFDLEVBQXhDLEVBQTRDO0FBQzNDckIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQUE0QmlCLFVBQVUsQ0FBQ0csQ0FBRCxDQUF0QztBQUNBLFlBQUlDLDRCQUE0QixHQUFHdEMsRUFBRSxDQUFDeUIsV0FBSCxDQUFlLEtBQUtmLHdCQUFwQixDQUFuQztBQUNBYyxRQUFBQSxpQkFBaUIsQ0FBQ1ksUUFBbEIsQ0FBMkJFLDRCQUEzQjtBQUNBQSxRQUFBQSw0QkFBNEIsQ0FBQ1osY0FBN0IsQ0FBNEMsZUFBNUMsRUFBNkRBLGNBQTdELENBQTRFLGNBQTVFLEVBQTRGQyxZQUE1RixDQUF5RzNCLEVBQUUsQ0FBQzRCLEtBQTVHLEVBQ0VDLE1BREYsR0FDVyxLQUFLSyxVQUFVLENBQUNHLENBQUQsQ0FBVixDQUFjRSxlQUQ5QjtBQUVBRCxRQUFBQSw0QkFBNEIsQ0FBQ1osY0FBN0IsQ0FBNEMsc0JBQTVDLEVBQW9FQSxjQUFwRSxDQUFtRixxQkFBbkYsRUFBMEdDLFlBQTFHLENBQ0MzQixFQUFFLENBQUM0QixLQURKLEVBQ1dDLE1BRFgsR0FDb0IsS0FBS0ssVUFBVSxDQUFDRyxDQUFELENBQVYsQ0FBY0csV0FBZCxDQUEwQkMsUUFBMUIsRUFEekI7QUFFQUgsUUFBQUEsNEJBQTRCLENBQUNaLGNBQTdCLENBQTRDLDJDQUE1QyxFQUF5RkEsY0FBekYsQ0FDQywwQ0FERCxFQUM2Q0MsWUFEN0MsQ0FDMEQzQixFQUFFLENBQUM0QixLQUQ3RCxFQUNvRUMsTUFEcEUsR0FDNkUsS0FBS0ssVUFBVSxDQUFDRyxDQUFELENBQVYsQ0FBY0ssYUFEaEc7QUFFQTtBQUVEO0FBQ0Q7QUF2RU8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJ0FjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRBY2NvdW50X0xhYmVsOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+i0puWPt+euoeeQhumihOWItuS9k1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VudF9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/mjpLlkI3moYZcclxuXHRcdFJlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0QWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uID0gbnVsbDtcclxuXHRcdHRoaXMuX0lzX0xvYWRpbmcgPSB0cnVlO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfUmVwb3J0ZXJkX1VzZXIoKTtcclxuXHRcdGNvbnNvbGUubG9nKFwi6KKr5Li+5oql5Lq65L+h5oGv5Liq5pWwXCIsIEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5SZXBvcnRlZF9Vc2Vyc19JbmZvcm1hdGlvbi5sZW5ndGgpO1xyXG5cclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0aWYgKHRoaXMuX0lzX0xvYWRpbmcgJiYgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLlJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uICE9IG51bGwpIHtcclxuXHRcdFx0dGhpcy5Mb2FkaW5nX1JlcG9ydGVkX1VzZXJzKCk7XHJcblx0XHRcdHRoaXMuX0lzX0xvYWRpbmcgPSBmYWxzZTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdExvYWRpbmdfUmVwb3J0ZWRfVXNlcnMoKSB7XHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IEFjY291bnRfTWFuYWdlbWVudF9Mb2NhbF9WYXJpYWJsZS5SZXBvcnRlZF9Vc2Vyc19JbmZvcm1hdGlvbi5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIjFcIik7XHJcblx0XHRcdHZhciBOZXdfQWNjb3VudF9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQWNjb3VudF9MYWJlbCk7XHJcblx0XHRcdE5ld19BY2NvdW50X0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9NYW5hZ2VtZW50X0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiVXNlcl9JZF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcclxuXHRcdFx0XHRcIlVzZXJfSWRfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb25bXHJcblx0XHRcdFx0aV0ub3BlbmlkO1xyXG5cdFx0XHROZXdfQWNjb3VudF9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfTWFuYWdlbWVudF9MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfU3RhdHVzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFxyXG5cdFx0XHRcdFwiQWNjb3VudF9TdGF0dXNfU2hvd1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb25bXHJcblx0XHRcdFx0aV0uVXNlcl9zdGF0ZTtcclxuXHRcdFx0TmV3X0FjY291bnRfTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJBY2NvdW50X01hbmFnZW1lbnRfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXHJcblx0XHRcdFx0XCJDdW11bGF0aXZlX051bWJlcl9PZl9SZXBvcnRlZF9DYXNlc19MYWJlbFwiKS5nZXRDaGlsZEJ5TmFtZShcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX1Nob3dcIikuZ2V0Q29tcG9uZW50KFxyXG5cdFx0XHRcdGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgQWNjb3VudF9NYW5hZ2VtZW50X0xvY2FsX1ZhcmlhYmxlLkFsbF9Vc2Vyc19JbmZvcm1hdGlvbltpXS5SZXBvcnRlZF9Db3VudDtcclxuXHRcdFx0dmFyIG9wZW5pZGxpc3QgPSBBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuUmVwb3J0ZWRfVXNlcnNfSW5mb3JtYXRpb25baV0ub3BlbmlkbGlzdDtcclxuXHRcdFx0TmV3X0FjY291bnRfTGFiZWwuaGVpZ2h0ID0gNTAwICsgb3BlbmlkbGlzdC5sZW5ndGggKiAyMDA7XHJcblx0XHRcdHRoaXMuQWNjb3VudF9NYW5hZ2VudF9WaWV3LmFkZENoaWxkKE5ld19BY2NvdW50X0xhYmVsKTtcclxuXHRcdFx0Zm9yICh2YXIgaiA9IDA7IGogPCBvcGVuaWRsaXN0Lmxlbmd0aDsgaisrKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLmn6XnnItvcGVuaWRsaXN0XCIsIG9wZW5pZGxpc3Rbal0pO1xyXG5cdFx0XHRcdHZhciBOZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5SZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwpO1xyXG5cdFx0XHRcdE5ld19BY2NvdW50X0xhYmVsLmFkZENoaWxkKE5ld19SZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwpO1xyXG5cdFx0XHRcdE5ld19SZXBvcnRfSW5mb3JtYXRpb25fTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJVc2VyX0lkX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiVXNlcl9JZF9TaG93XCIpLmdldENvbXBvbmVudChjYy5MYWJlbClcclxuXHRcdFx0XHRcdC5zdHJpbmcgPSBcIlwiICsgb3BlbmlkbGlzdFtqXS5SZXBvcnRlZF9PcGVuaWQ7XHJcblx0XHRcdFx0TmV3X1JlcG9ydF9JbmZvcm1hdGlvbl9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkFjY291bnRfU3RhdHVzX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiQWNjb3VudF9TdGF0dXNfU2hvd1wiKS5nZXRDb21wb25lbnQoXHJcblx0XHRcdFx0XHRjYy5MYWJlbCkuc3RyaW5nID0gXCJcIiArIG9wZW5pZGxpc3Rbal0uUmVwb3J0X1RpbWUudG9TdHJpbmcoKTtcclxuXHRcdFx0XHROZXdfUmVwb3J0X0luZm9ybWF0aW9uX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQ3VtdWxhdGl2ZV9OdW1iZXJfT2ZfUmVwb3J0ZWRfQ2FzZXNfTGFiZWxcIikuZ2V0Q2hpbGRCeU5hbWUoXHJcblx0XHRcdFx0XHRcIkN1bXVsYXRpdmVfTnVtYmVyX09mX1JlcG9ydGVkX0Nhc2VzX1Nob3dcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgb3BlbmlkbGlzdFtqXS5SZXBvcnRfUmVhc29uO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0fVxyXG5cdH1cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Delete_Read.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fbdaeLWsLlOfJtmSiczS30X', 'Delete_Read');
// resources/script/Email/Delete_Read.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {},
  Delete_Read: function Delete_Read() {
    //删除已读邮件
    WeChat.Delete_Read(); //获取邮件列表

    WeChat.Loading_Email();
    console.log("邮件信息表", Email_Local_Variable.Email);
    cc.director.loadScene("Email");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxEZWxldGVfUmVhZC5qcyJdLCJuYW1lcyI6WyJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkRlbGV0ZV9SZWFkIiwiV2VDaGF0IiwiTG9hZGluZ19FbWFpbCIsImNvbnNvbGUiLCJsb2ciLCJFbWFpbCIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFNQSxvQkFBb0IsR0FBR0MsT0FBTyxDQUFDLHdDQUFELENBQXBDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU9MQyxFQUFBQSxXQUFXLEVBQUUsdUJBQVU7QUFFbEI7QUFDQUMsSUFBQUEsTUFBTSxDQUFDRCxXQUFQLEdBSGtCLENBSWpCOztBQUNEQyxJQUFBQSxNQUFNLENBQUNDLGFBQVA7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQlYsb0JBQW9CLENBQUNXLEtBQXpDO0FBQ0FULElBQUFBLEVBQUUsQ0FBQ1UsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE9BQXRCO0FBQ0osR0FmSTtBQWlCTEMsRUFBQUEsS0FqQkssbUJBaUJJLENBRVIsQ0FuQkksQ0FxQkw7O0FBckJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5LiL6L296YKu566x5YiX6KGoXHJcbmNvbnN0IEVtYWlsX0xvY2FsX1ZhcmlhYmxlID0gcmVxdWlyZSgnLi4vTG9jYWxfVmFyaWlibGUvRW1haWxfTG9jYWxfVmFyaWFibGUnKTtcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgXHJcbiAgICB9LFxyXG5cclxuICAgIERlbGV0ZV9SZWFkOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIFxyXG4gICAgICAgICAvL+WIoOmZpOW3suivu+mCruS7tlxyXG4gICAgICAgICBXZUNoYXQuRGVsZXRlX1JlYWQoKTtcclxuICAgICAgICAgIC8v6I635Y+W6YKu5Lu25YiX6KGoXHJcbiAgICAgICAgIFdlQ2hhdC5Mb2FkaW5nX0VtYWlsKCk7XHJcbiAgICAgICAgIGNvbnNvbGUubG9nKFwi6YKu5Lu25L+h5oGv6KGoXCIsRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwpO1xyXG4gICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJFbWFpbFwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Email_Waring.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f95f53B521Flo6ICudvtupm', 'Email_Waring');
// resources/script/Email/Email_Waring.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    OPENID_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  Warning: function Warning() {
    var open_id = this.OPENID_Label.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "账号异常警告";
    var Content = "您的账号可能存在异常，如核实有违规行为，系统将对您作出惩罚";
    WeChat.Email_Warning(Time, Title, Content, open_id);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxFbWFpbF9XYXJpbmcuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJPUEVOSURfTGFiZWwiLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsIldhcm5pbmciLCJvcGVuX2lkIiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiVGltZSIsInBhcnNlSW50IiwiRGF0ZSIsImdldFRpbWUiLCJUaXRsZSIsIkNvbnRlbnQiLCJXZUNoYXQiLCJFbWFpbF9XYXJuaW5nIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNUQyxJQUFBQSxZQUFZLEVBQUM7QUFDUixpQkFBUyxJQUREO0FBRVJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZEO0FBR1JDLE1BQUFBLFdBQVcsRUFBRTtBQUhMO0FBREosR0FIUDtBQVdMQyxFQUFBQSxPQUFPLEVBQUMsbUJBQVU7QUFDZCxRQUFJQyxPQUFPLEdBQUMsS0FBS0wsWUFBTCxDQUFrQk0sWUFBbEIsQ0FBK0JWLEVBQUUsQ0FBQ00sS0FBbEMsRUFBeUNLLE1BQXJELENBRGMsQ0FFZDs7QUFDTixRQUFJQyxJQUFJLEdBQUdDLFFBQVEsQ0FBQyxJQUFJQyxJQUFKLEdBQVdDLE9BQVgsRUFBRCxDQUFuQjtBQUNBLFFBQUlDLEtBQUssR0FBRyxRQUFaO0FBQ0EsUUFBSUMsT0FBTyxHQUFFLCtCQUFiO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0MsYUFBUCxDQUFxQlAsSUFBckIsRUFBMEJJLEtBQTFCLEVBQWdDQyxPQUFoQyxFQUF3Q1IsT0FBeEM7QUFDRyxHQWxCSTtBQW9CTFcsRUFBQUEsS0FwQkssbUJBb0JJLENBRVIsQ0F0QkksQ0F3Qkw7O0FBeEJLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgT1BFTklEX0xhYmVsOntcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTGFiZWwsXHJcbiAgICAgICAgICAgIHNlcmlhbHphYmxlOiB0cnVlLFxyXG4gICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBXYXJuaW5nOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIG9wZW5faWQ9dGhpcy5PUEVOSURfTGFiZWwuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgLy/ojrflj5bml7bpl7TmiLNcclxuXHRcdGxldCBUaW1lID0gcGFyc2VJbnQobmV3IERhdGUoKS5nZXRUaW1lKCkpO1xyXG5cdFx0dmFyIFRpdGxlID0gXCLotKblj7flvILluLjorablkYpcIjtcclxuXHRcdHZhciBDb250ZW50ID1cIuaCqOeahOi0puWPt+WPr+iDveWtmOWcqOW8guW4uO+8jOWmguaguOWunuaciei/neinhOihjOS4uu+8jOezu+e7n+WwhuWvueaCqOS9nOWHuuaDqee9mlwiO1xyXG5cdFx0V2VDaGF0LkVtYWlsX1dhcm5pbmcoVGltZSxUaXRsZSxDb250ZW50LG9wZW5faWQpO1xyXG4gICAgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Gold_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '85f41MkxtRAJbqu2YeY3nrd', 'Gold_Action');
// resources/script/Game_Coming/Gold_Action.js

"use strict";

//金币运动函数
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    coinAudio: {
      "default": null,
      type: cc.AudioClip
    },
    Move_Speed: 0,
    //金币的移动速度
    x: 0,
    //金币x坐标
    y: 0,
    //金币y坐标
    Gold_Show: {
      //金币的预制体
      "default": null,
      type: cc.Prefab,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    //打开碰撞属性
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; //manager.enabledDebugDraw = true;
  },
  start: function start() {},
  update: function update(dt) {
    //通过更新金币的x坐标，让金币前进
    this.node.x -= 5 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 2; //如果金币超出界面，毁灭掉金币

    if (this.node.x < -600) {
      this.node.destroy();
    }
  },
  //碰撞判断	
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log("other.name = ", other.node.name, other.node.group, other.node.groupIndex);

    if (other.node.groupIndex === 0) {
      //如果和小鸟碰撞
      var Gold_Show_Label = cc.instantiate(this.Gold_Show); //加入金币显示框

      Game_Local_Varible.Gold += 1;
      this.node.destroy(); //移除该金币

      this.node.parent.addChild(Gold_Show_Label);
      Gold_Show_Label.setPosition(400, 750);
      cc.audioEngine.playEffect(this.coinAudio, false, 0.6);
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxHb2xkX0FjdGlvbi5qcyJdLCJuYW1lcyI6WyJHYW1lX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNvaW5BdWRpbyIsInR5cGUiLCJBdWRpb0NsaXAiLCJNb3ZlX1NwZWVkIiwieCIsInkiLCJHb2xkX1Nob3ciLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIm9uTG9hZCIsIm1hbmFnZXIiLCJkaXJlY3RvciIsImdldENvbGxpc2lvbk1hbmFnZXIiLCJlbmFibGVkIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm5vZGUiLCJEaWZmaWN1bHR5X1JhdGlvIiwiZGVzdHJveSIsIm9uQ29sbGlzaW9uRW50ZXIiLCJvdGhlciIsInNlbGYiLCJjb25zb2xlIiwibG9nIiwibmFtZSIsImdyb3VwIiwiZ3JvdXBJbmRleCIsIkdvbGRfU2hvd19MYWJlbCIsImluc3RhbnRpYXRlIiwiR29sZCIsInBhcmVudCIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJhdWRpb0VuZ2luZSIsInBsYXlFZmZlY3QiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxrQkFBa0IsR0FBR0MsT0FBTyxDQUFDLG9CQUFELENBQWhDOztBQUNBLElBQUlDLDZCQUE2QixHQUFHRCxPQUFPLENBQUMsK0JBQUQsQ0FBM0M7O0FBRUFFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUVYQyxJQUFBQSxTQUFTLEVBQUU7QUFDRCxpQkFBUyxJQURSO0FBRURDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZSLEtBRkE7QUFPWEMsSUFBQUEsVUFBVSxFQUFFLENBUEQ7QUFPSTtBQUNmQyxJQUFBQSxDQUFDLEVBQUUsQ0FSUTtBQVFMO0FBQ05DLElBQUFBLENBQUMsRUFBRSxDQVRRO0FBU0w7QUFDTkMsSUFBQUEsU0FBUyxFQUFFO0FBQUU7QUFDWixpQkFBUyxJQURDO0FBRVZMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVyxNQUZDO0FBR1ZDLE1BQUFBLFdBQVcsRUFBRTtBQUhIO0FBVkEsR0FISjtBQXFCUjtBQUNBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQSxRQUFJQyxPQUFPLEdBQUdkLEVBQUUsQ0FBQ2UsUUFBSCxDQUFZQyxtQkFBWixFQUFkO0FBQ0FGLElBQUFBLE9BQU8sQ0FBQ0csT0FBUixHQUFrQixJQUFsQixDQUhrQixDQUlsQjtBQUNBLEdBM0JPO0FBNkJSQyxFQUFBQSxLQUFLLEVBQUUsaUJBQVcsQ0FBRSxDQTdCWjtBQThCUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWE7QUFDcEI7QUFDQSxTQUFLQyxJQUFMLENBQVViLENBQVYsSUFBZ0IsSUFBSVQsNkJBQTZCLENBQUN1QixnQkFBOUIsR0FBaUQsQ0FBckUsQ0FGb0IsQ0FHcEI7O0FBQ0EsUUFBSSxLQUFLRCxJQUFMLENBQVViLENBQVYsR0FBYyxDQUFDLEdBQW5CLEVBQXdCO0FBQ3ZCLFdBQUthLElBQUwsQ0FBVUUsT0FBVjtBQUVBO0FBQ0QsR0F0Q087QUF1Q1I7QUFDQUMsRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVNDLEtBQVQsRUFBZ0JDLElBQWhCLEVBQXNCO0FBRXZDQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxlQUFaLEVBQTZCSCxLQUFLLENBQUNKLElBQU4sQ0FBV1EsSUFBeEMsRUFBOENKLEtBQUssQ0FBQ0osSUFBTixDQUFXUyxLQUF6RCxFQUFnRUwsS0FBSyxDQUFDSixJQUFOLENBQVdVLFVBQTNFOztBQUNBLFFBQUlOLEtBQUssQ0FBQ0osSUFBTixDQUFXVSxVQUFYLEtBQTBCLENBQTlCLEVBQWlDO0FBQUU7QUFDbEMsVUFBSUMsZUFBZSxHQUFHaEMsRUFBRSxDQUFDaUMsV0FBSCxDQUFlLEtBQUt2QixTQUFwQixDQUF0QixDQURnQyxDQUNzQjs7QUFDdERiLE1BQUFBLGtCQUFrQixDQUFDcUMsSUFBbkIsSUFBMkIsQ0FBM0I7QUFDQSxXQUFLYixJQUFMLENBQVVFLE9BQVYsR0FIZ0MsQ0FHWDs7QUFDckIsV0FBS0YsSUFBTCxDQUFVYyxNQUFWLENBQWlCQyxRQUFqQixDQUEwQkosZUFBMUI7QUFDQUEsTUFBQUEsZUFBZSxDQUFDSyxXQUFoQixDQUE0QixHQUE1QixFQUFpQyxHQUFqQztBQUNBckMsTUFBQUEsRUFBRSxDQUFDc0MsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUtuQyxTQUEvQixFQUEwQyxLQUExQyxFQUFnRCxHQUFoRDtBQUVBO0FBQ0Q7QUFwRE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/ph5HluIHov5Dliqjlh73mlbBcclxudmFyIEdhbWVfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG4gIFxyXG5cdFx0Y29pbkF1ZGlvOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcFxyXG4gICAgICAgIH0sXHJcblxyXG5cdFx0TW92ZV9TcGVlZDogMCwgLy/ph5HluIHnmoTnp7vliqjpgJ/luqZcclxuXHRcdHg6IDAsIC8v6YeR5biBeOWdkOagh1xyXG5cdFx0eTogMCwgLy/ph5HluIF55Z2Q5qCHXHJcblx0XHRHb2xkX1Nob3c6IHsgLy/ph5HluIHnmoTpooTliLbkvZNcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0fSxcclxuXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+aJk+W8gOeisOaSnuWxnuaAp1xyXG5cdFx0dmFyIG1hbmFnZXIgPSBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCk7XHJcblx0XHRtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0Ly9tYW5hZ2VyLmVuYWJsZWREZWJ1Z0RyYXcgPSB0cnVlO1xyXG5cdH0sXHJcblxyXG5cdHN0YXJ0OiBmdW5jdGlvbigpIHt9LFxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHtcclxuXHRcdC8v6YCa6L+H5pu05paw6YeR5biB55qEeOWdkOagh++8jOiuqemHkeW4geWJjei/m1xyXG5cdFx0dGhpcy5ub2RlLnggLT0gKDUgKyBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICogMik7XHJcblx0XHQvL+WmguaenOmHkeW4gei2heWHuueVjOmdou+8jOavgeeBreaOiemHkeW4gVxyXG5cdFx0aWYgKHRoaXMubm9kZS54IDwgLTYwMCkge1xyXG5cdFx0XHR0aGlzLm5vZGUuZGVzdHJveSgpO1xyXG5cclxuXHRcdH1cclxuXHR9LFxyXG5cdC8v56Kw5pKe5Yik5patXHRcclxuXHRvbkNvbGxpc2lvbkVudGVyOiBmdW5jdGlvbihvdGhlciwgc2VsZikge1xyXG5cclxuXHRcdGNvbnNvbGUubG9nKFwib3RoZXIubmFtZSA9IFwiLCBvdGhlci5ub2RlLm5hbWUsIG90aGVyLm5vZGUuZ3JvdXAsIG90aGVyLm5vZGUuZ3JvdXBJbmRleCk7XHJcblx0XHRpZiAob3RoZXIubm9kZS5ncm91cEluZGV4ID09PSAwKSB7IC8v5aaC5p6c5ZKM5bCP6bif56Kw5pKeXHJcblx0XHRcdHZhciBHb2xkX1Nob3dfTGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkdvbGRfU2hvdyk7IC8v5Yqg5YWl6YeR5biB5pi+56S65qGGXHJcblx0XHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5Hb2xkICs9IDE7XHJcblx0XHRcdHRoaXMubm9kZS5kZXN0cm95KCk7IC8v56e76Zmk6K+l6YeR5biBXHJcblx0XHRcdHRoaXMubm9kZS5wYXJlbnQuYWRkQ2hpbGQoR29sZF9TaG93X0xhYmVsKTtcclxuXHRcdFx0R29sZF9TaG93X0xhYmVsLnNldFBvc2l0aW9uKDQwMCwgNzUwKTtcclxuXHRcdFx0Y2MuYXVkaW9FbmdpbmUucGxheUVmZmVjdCh0aGlzLmNvaW5BdWRpbywgZmFsc2UsMC42KTtcclxuXHRcclxuXHRcdH1cclxuXHR9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Email_Information.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1c8bc2GdkJAwamUQNO6/X0g', 'Email_Information');
// resources/script/Email/Email_Information.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Email_Information: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //邮件信息页面
    Email_Title: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //邮件标题
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  Open_Email: function Open_Email() {
    var self = this;
    var This_Title = this.Email_Title.getComponent(cc.Label).string;
    WeChat.Loading_Email();

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var Title = Email_Local_Variable.Email[i].Email_Title;

      if (This_Title === Title) {
        //当前点击的邮件
        console.log("当前邮件内容为1：", Email_Local_Variable.Email[i]); //为当前邮件新建节点

        var New_Email_Information = cc.instantiate(this.Email_Information);
        this.Canvas.parent.parent.parent.parent.addChild(New_Email_Information); //设置节点即邮件信息界面的位置

        New_Email_Information.setPosition(0, 0); // if(Email_Local_Variable.Email[i].Enclosure===false)New_Email_Information.Determine.Button.interactable = false;
        //载入邮件信息

        var Time = new Date(parseInt(Email_Local_Variable.Email[i].Time)).toLocaleString().replace(/:\d{1,2}$/, ' ');
        New_Email_Information.getChildByName("Email_Title").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Title;
        New_Email_Information.getChildByName("Email_Content").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Content;
        New_Email_Information.getChildByName("Diamond").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Diamond;
        New_Email_Information.getChildByName("Gold").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Gold;
        New_Email_Information.getChildByName("Compassion").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Compassion;
        New_Email_Information.getChildByName("Time").getComponent(cc.Label).string = "" + Time; //将邮件设为已读

        WeChat.Read(Email_Local_Variable.Email[i]._id);
        console.log("已将邮件设为已读");
        console.log("邮件id:", Email_Local_Variable.Email[i]._id);
        break;
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxFbWFpbF9JbmZvcm1hdGlvbi5qcyJdLCJuYW1lcyI6WyJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkVtYWlsX0luZm9ybWF0aW9uIiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiRW1haWxfVGl0bGUiLCJMYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJPcGVuX0VtYWlsIiwic2VsZiIsIlRoaXNfVGl0bGUiLCJnZXRDb21wb25lbnQiLCJzdHJpbmciLCJXZUNoYXQiLCJMb2FkaW5nX0VtYWlsIiwiaSIsIkVtYWlsIiwibGVuZ3RoIiwiVGl0bGUiLCJjb25zb2xlIiwibG9nIiwiTmV3X0VtYWlsX0luZm9ybWF0aW9uIiwiaW5zdGFudGlhdGUiLCJwYXJlbnQiLCJhZGRDaGlsZCIsInNldFBvc2l0aW9uIiwiVGltZSIsIkRhdGUiLCJwYXJzZUludCIsInRvTG9jYWxlU3RyaW5nIiwicmVwbGFjZSIsImdldENoaWxkQnlOYW1lIiwiRW1haWxfQ29udGVudCIsIkVtYWlsX0RpYW1vbmQiLCJFbWFpbF9Hb2xkIiwiRW1haWxfQ29tcGFzc2lvbiIsIlJlYWQiLCJfaWQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFNQSxvQkFBb0IsR0FBR0MsT0FBTyxDQUFDLHdDQUFELENBQXBDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsaUJBQWlCLEVBQUM7QUFDZCxpQkFBUSxJQURNO0FBRXZCQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGZTtBQUd2QkMsTUFBQUEsV0FBVyxFQUFDO0FBSFcsS0FEVjtBQUtOO0FBQ0ZDLElBQUFBLFdBQVcsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFakJILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxLQUZTO0FBR2pCRixNQUFBQSxXQUFXLEVBQUM7QUFISyxLQU5KO0FBVU47QUFDRkcsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csSUFGTDtBQUdaSixNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQVhDLEdBSFA7QUFzQkw7QUFFQUssRUFBQUEsVUFBVSxFQUFFLHNCQUFXO0FBQ25CLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsVUFBVSxHQUFDLEtBQUtOLFdBQUwsQ0FBaUJPLFlBQWpCLENBQThCZixFQUFFLENBQUNTLEtBQWpDLEVBQXdDTyxNQUF2RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLGFBQVA7O0FBR0EsU0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFZQSxDQUFDLEdBQUNyQixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCQyxNQUF6QyxFQUFnREYsQ0FBQyxFQUFqRCxFQUFvRDtBQUNoRCxVQUFJRyxLQUFLLEdBQUN4QixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QlgsV0FBeEM7O0FBRUEsVUFBR00sVUFBVSxLQUFHUSxLQUFoQixFQUFzQjtBQUNsQjtBQUNBQyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLEVBQXdCMUIsb0JBQW9CLENBQUNzQixLQUFyQixDQUEyQkQsQ0FBM0IsQ0FBeEIsRUFGa0IsQ0FHbEI7O0FBQ0EsWUFBSU0scUJBQXFCLEdBQUd6QixFQUFFLENBQUMwQixXQUFILENBQWUsS0FBS3RCLGlCQUFwQixDQUE1QjtBQUNBLGFBQUtNLE1BQUwsQ0FBWWlCLE1BQVosQ0FBbUJBLE1BQW5CLENBQTBCQSxNQUExQixDQUFpQ0EsTUFBakMsQ0FBd0NDLFFBQXhDLENBQWlESCxxQkFBakQsRUFMa0IsQ0FNbEI7O0FBQ0FBLFFBQUFBLHFCQUFxQixDQUFDSSxXQUF0QixDQUFrQyxDQUFsQyxFQUFvQyxDQUFwQyxFQVBrQixDQVFsQjtBQUNBOztBQUNBLFlBQUlDLElBQUksR0FBQyxJQUFJQyxJQUFKLENBQVNDLFFBQVEsQ0FBQ2xDLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCVyxJQUEvQixDQUFqQixFQUF1REcsY0FBdkQsR0FBd0VDLE9BQXhFLENBQWdGLFdBQWhGLEVBQTRGLEdBQTVGLENBQVQ7QUFDQVQsUUFBQUEscUJBQXFCLENBQUNVLGNBQXRCLENBQXFDLGFBQXJDLEVBQW9EcEIsWUFBcEQsQ0FBaUVmLEVBQUUsQ0FBQ1MsS0FBcEUsRUFBMkVPLE1BQTNFLEdBQWtGLEtBQUdsQixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QlgsV0FBbkg7QUFDQWlCLFFBQUFBLHFCQUFxQixDQUFDVSxjQUF0QixDQUFxQyxlQUFyQyxFQUFzRHBCLFlBQXRELENBQW1FZixFQUFFLENBQUNTLEtBQXRFLEVBQTZFTyxNQUE3RSxHQUFvRixLQUFHbEIsb0JBQW9CLENBQUNzQixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJpQixhQUFySDtBQUNBWCxRQUFBQSxxQkFBcUIsQ0FBQ1UsY0FBdEIsQ0FBcUMsU0FBckMsRUFBZ0RwQixZQUFoRCxDQUE2RGYsRUFBRSxDQUFDUyxLQUFoRSxFQUF1RU8sTUFBdkUsR0FBOEUsS0FBR2xCLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCa0IsYUFBL0c7QUFDQVosUUFBQUEscUJBQXFCLENBQUNVLGNBQXRCLENBQXFDLE1BQXJDLEVBQTZDcEIsWUFBN0MsQ0FBMERmLEVBQUUsQ0FBQ1MsS0FBN0QsRUFBb0VPLE1BQXBFLEdBQTJFLEtBQUdsQixvQkFBb0IsQ0FBQ3NCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4Qm1CLFVBQTVHO0FBQ0FiLFFBQUFBLHFCQUFxQixDQUFDVSxjQUF0QixDQUFxQyxZQUFyQyxFQUFtRHBCLFlBQW5ELENBQWdFZixFQUFFLENBQUNTLEtBQW5FLEVBQTBFTyxNQUExRSxHQUFpRixLQUFHbEIsb0JBQW9CLENBQUNzQixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJvQixnQkFBbEg7QUFDQWQsUUFBQUEscUJBQXFCLENBQUNVLGNBQXRCLENBQXFDLE1BQXJDLEVBQTZDcEIsWUFBN0MsQ0FBMERmLEVBQUUsQ0FBQ1MsS0FBN0QsRUFBb0VPLE1BQXBFLEdBQTJFLEtBQUdjLElBQTlFLENBaEJrQixDQWlCbEI7O0FBQ0FiLFFBQUFBLE1BQU0sQ0FBQ3VCLElBQVAsQ0FBWTFDLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCc0IsR0FBMUM7QUFDQWxCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVo7QUFDQUQsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFvQjFCLG9CQUFvQixDQUFDc0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCc0IsR0FBbEQ7QUFDQTtBQUNIO0FBQ0o7QUFDSjtBQXpESSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9vemCrueuseWIl+ihqFxyXG5jb25zdCBFbWFpbF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL0VtYWlsX0xvY2FsX1ZhcmlhYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgRW1haWxfSW5mb3JtYXRpb246e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICB9LC8v6YKu5Lu25L+h5oGv6aG16Z2iXHJcbiAgICAgICAgRW1haWxfVGl0bGU6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sLy/pgq7ku7bmoIfpophcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBPcGVuX0VtYWlsOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdmFyIFRoaXNfVGl0bGU9dGhpcy5FbWFpbF9UaXRsZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuICAgICAgICBXZUNoYXQuTG9hZGluZ19FbWFpbCgpO1xyXG4gICAgICAgIFxyXG5cclxuICAgICAgICBmb3IodmFyIGk9MDtpPEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsLmxlbmd0aDtpKyspe1xyXG4gICAgICAgICAgICB2YXIgVGl0bGU9RW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfVGl0bGU7XHJcblxyXG4gICAgICAgICAgICBpZihUaGlzX1RpdGxlPT09VGl0bGUpe1xyXG4gICAgICAgICAgICAgICAgLy/lvZPliY3ngrnlh7vnmoTpgq7ku7ZcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN6YKu5Lu25YaF5a655Li6Me+8mlwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldKTtcclxuICAgICAgICAgICAgICAgIC8v5Li65b2T5YmN6YKu5Lu25paw5bu66IqC54K5XHJcbiAgICAgICAgICAgICAgICB2YXIgTmV3X0VtYWlsX0luZm9ybWF0aW9uID0gY2MuaW5zdGFudGlhdGUodGhpcy5FbWFpbF9JbmZvcm1hdGlvbik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LnBhcmVudC5wYXJlbnQuYWRkQ2hpbGQoTmV3X0VtYWlsX0luZm9ybWF0aW9uKTtcclxuICAgICAgICAgICAgICAgIC8v6K6+572u6IqC54K55Y2z6YKu5Lu25L+h5oGv55WM6Z2i55qE5L2N572uXHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIC8vIGlmKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZT09PWZhbHNlKU5ld19FbWFpbF9JbmZvcm1hdGlvbi5EZXRlcm1pbmUuQnV0dG9uLmludGVyYWN0YWJsZSA9IGZhbHNlO1xyXG4gICAgICAgICAgICAgICAgLy/ovb3lhaXpgq7ku7bkv6Hmga9cclxuICAgICAgICAgICAgICAgIHZhciBUaW1lPW5ldyBEYXRlKHBhcnNlSW50KEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLlRpbWUpKS50b0xvY2FsZVN0cmluZygpLnJlcGxhY2UoLzpcXGR7MSwyfSQvLCcgJyk7XHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uZ2V0Q2hpbGRCeU5hbWUoXCJFbWFpbF9UaXRsZVwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0VtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlO1xyXG4gICAgICAgICAgICAgICAgTmV3X0VtYWlsX0luZm9ybWF0aW9uLmdldENoaWxkQnlOYW1lKFwiRW1haWxfQ29udGVudFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0VtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX0NvbnRlbnQ7XHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uZ2V0Q2hpbGRCeU5hbWUoXCJEaWFtb25kXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfRGlhbW9uZDtcclxuICAgICAgICAgICAgICAgIE5ld19FbWFpbF9JbmZvcm1hdGlvbi5nZXRDaGlsZEJ5TmFtZShcIkdvbGRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9Hb2xkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0VtYWlsX0luZm9ybWF0aW9uLmdldENoaWxkQnlOYW1lKFwiQ29tcGFzc2lvblwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK0VtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX0NvbXBhc3Npb247XHJcbiAgICAgICAgICAgICAgICBOZXdfRW1haWxfSW5mb3JtYXRpb24uZ2V0Q2hpbGRCeU5hbWUoXCJUaW1lXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGltZTtcclxuICAgICAgICAgICAgICAgIC8v5bCG6YKu5Lu26K6+5Li65bey6K+7XHJcbiAgICAgICAgICAgICAgICBXZUNoYXQuUmVhZChFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5faWQpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLlt7LlsIbpgq7ku7borr7kuLrlt7Lor7tcIik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIumCruS7tmlkOlwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLl9pZCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgXHJcblxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Accept.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'be864f5ltdAVaIxUzh5vevO', 'Accept');
// resources/script/Email/Accept.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Accept_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //成功接受提示信息
    Already_Accepted_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已接受过提示信息
    No_Awards_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //没有奖励提示信息
    Email_Title: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //邮件标题
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  Accept: function Accept() {
    var self = this;
    var This_Title = this.Email_Title.getComponent(cc.Label).string;
    WeChat.Loading_Email();

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var Title = Email_Local_Variable.Email[i].Email_Title;

      if (This_Title === Title) {
        //当前点击的邮件
        console.log("当前邮件内容为2：", Email_Local_Variable.Email[i]);

        if (Email_Local_Variable.Email[i].Enclosure === false) {
          var Tip = cc.instantiate(this.No_Awards_Box);
          this.Canvas.addChild(Tip); //设置提示框位置

          Tip.setPosition(0, 0);
        } //是否已经接受过奖励
        else {
            if (Email_Local_Variable.Email[i].Accept === false) {
              //未曾接受奖励
              console.log("接受奖励");
              var Tip = cc.instantiate(this.Accept_Box);
              this.Canvas.addChild(Tip); //设置提示框位置

              Tip.setPosition(0, 0); //奖励参数设置

              var id = Email_Local_Variable.Email[i]._id;
              var Gold = Number(Email_Local_Variable.Email[i].Email_Gold);
              var Diamond = Number(Email_Local_Variable.Email[i].Email_Diamond);
              var Compassion = Number(Email_Local_Variable.Email[i].Email_Compassion); //接受奖励

              console.log("已经接受奖励", "金币：", Gold, "钻石：", Diamond, "体力：", Compassion);
              WeChat.Accept(id, Gold, Diamond, Compassion);
            } //已接受过奖励
            else {
                //弹出提示框
                var Tip = cc.instantiate(this.Already_Accepted_Box);
                this.Canvas.addChild(Tip); //设置提示框位置

                Tip.setPosition(0, 0);
              }
          }

        break;
      }
    }
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxBY2NlcHQuanMiXSwibmFtZXMiOlsiRW1haWxfTG9jYWxfVmFyaWFibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJBY2NlcHRfQm94IiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQWxyZWFkeV9BY2NlcHRlZF9Cb3giLCJOb19Bd2FyZHNfQm94IiwiRW1haWxfVGl0bGUiLCJMYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJBY2NlcHQiLCJzZWxmIiwiVGhpc19UaXRsZSIsImdldENvbXBvbmVudCIsInN0cmluZyIsIldlQ2hhdCIsIkxvYWRpbmdfRW1haWwiLCJpIiwiRW1haWwiLCJsZW5ndGgiLCJUaXRsZSIsImNvbnNvbGUiLCJsb2ciLCJFbmNsb3N1cmUiLCJUaXAiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJpZCIsIl9pZCIsIkdvbGQiLCJOdW1iZXIiLCJFbWFpbF9Hb2xkIiwiRGlhbW9uZCIsIkVtYWlsX0RpYW1vbmQiLCJDb21wYXNzaW9uIiwiRW1haWxfQ29tcGFzc2lvbiIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBTUEsb0JBQW9CLEdBQUdDLE9BQU8sQ0FBQyx3Q0FBRCxDQUFwQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLFVBQVUsRUFBQztBQUNQLGlCQUFRLElBREQ7QUFFUEMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRkQ7QUFHUEMsTUFBQUEsV0FBVyxFQUFDO0FBSEwsS0FESDtBQUtOO0FBQ0ZDLElBQUFBLG9CQUFvQixFQUFDO0FBQ2pCLGlCQUFRLElBRFM7QUFFakJILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDTSxNQUZTO0FBR2pCQyxNQUFBQSxXQUFXLEVBQUM7QUFISyxLQU5iO0FBVU47QUFDRkUsSUFBQUEsYUFBYSxFQUFDO0FBQ1YsaUJBQVEsSUFERTtBQUVWSixNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGRTtBQUdWQyxNQUFBQSxXQUFXLEVBQUM7QUFIRixLQVhOO0FBZU47QUFDRkcsSUFBQUEsV0FBVyxFQUFDO0FBQ1IsaUJBQVEsSUFEQTtBQUVSTCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csS0FGQTtBQUdSSixNQUFBQSxXQUFXLEVBQUM7QUFISixLQWhCSjtBQW9CTjtBQUNGSyxJQUFBQSxNQUFNLEVBQUM7QUFDSCxpQkFBUSxJQURMO0FBRUhQLE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDYSxJQUZMO0FBR1pOLE1BQUFBLFdBQVcsRUFBQztBQUhBO0FBckJDLEdBSFA7QUErQkw7QUFFQTtBQUNBTyxFQUFBQSxNQUFNLEVBQUUsa0JBQVU7QUFDZCxRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBLFFBQUlDLFVBQVUsR0FBQyxLQUFLTixXQUFMLENBQWlCTyxZQUFqQixDQUE4QmpCLEVBQUUsQ0FBQ1csS0FBakMsRUFBd0NPLE1BQXZEO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0MsYUFBUDs7QUFHQSxTQUFJLElBQUlDLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQ3ZCLG9CQUFvQixDQUFDd0IsS0FBckIsQ0FBMkJDLE1BQXpDLEVBQWdERixDQUFDLEVBQWpELEVBQW9EO0FBQ2hELFVBQUlHLEtBQUssR0FBQzFCLG9CQUFvQixDQUFDd0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCWCxXQUF4Qzs7QUFDQSxVQUFHTSxVQUFVLEtBQUdRLEtBQWhCLEVBQXNCO0FBQ2xCO0FBQ0FDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFBd0I1QixvQkFBb0IsQ0FBQ3dCLEtBQXJCLENBQTJCRCxDQUEzQixDQUF4Qjs7QUFFQSxZQUFHdkIsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJNLFNBQTlCLEtBQTBDLEtBQTdDLEVBQW1EO0FBQy9DLGNBQUlDLEdBQUcsR0FBRzVCLEVBQUUsQ0FBQzZCLFdBQUgsQ0FBZSxLQUFLcEIsYUFBcEIsQ0FBVjtBQUNJLGVBQUtHLE1BQUwsQ0FBWWtCLFFBQVosQ0FBcUJGLEdBQXJCLEVBRjJDLENBRzNDOztBQUNBQSxVQUFBQSxHQUFHLENBQUNHLFdBQUosQ0FBZ0IsQ0FBaEIsRUFBa0IsQ0FBbEI7QUFDUCxTQUxELENBTUE7QUFOQSxhQU9HO0FBQ0MsZ0JBQUdqQyxvQkFBb0IsQ0FBQ3dCLEtBQXJCLENBQTJCRCxDQUEzQixFQUE4QlAsTUFBOUIsS0FBdUMsS0FBMUMsRUFBZ0Q7QUFDNUM7QUFDQVcsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBLGtCQUFJRSxHQUFHLEdBQUc1QixFQUFFLENBQUM2QixXQUFILENBQWUsS0FBS3pCLFVBQXBCLENBQVY7QUFDQSxtQkFBS1EsTUFBTCxDQUFZa0IsUUFBWixDQUFxQkYsR0FBckIsRUFKNEMsQ0FLNUM7O0FBQ0FBLGNBQUFBLEdBQUcsQ0FBQ0csV0FBSixDQUFnQixDQUFoQixFQUFrQixDQUFsQixFQU40QyxDQU81Qzs7QUFDQSxrQkFBSUMsRUFBRSxHQUFHbEMsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJZLEdBQXZDO0FBQ0Esa0JBQUlDLElBQUksR0FBR0MsTUFBTSxDQUFDckMsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJlLFVBQS9CLENBQWpCO0FBQ0Esa0JBQUlDLE9BQU8sR0FBR0YsTUFBTSxDQUFDckMsb0JBQW9CLENBQUN3QixLQUFyQixDQUEyQkQsQ0FBM0IsRUFBOEJpQixhQUEvQixDQUFwQjtBQUNBLGtCQUFJQyxVQUFVLEdBQUdKLE1BQU0sQ0FBQ3JDLG9CQUFvQixDQUFDd0IsS0FBckIsQ0FBMkJELENBQTNCLEVBQThCbUIsZ0JBQS9CLENBQXZCLENBWDRDLENBWTVDOztBQUNBZixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXFCLEtBQXJCLEVBQTJCUSxJQUEzQixFQUFnQyxLQUFoQyxFQUFzQ0csT0FBdEMsRUFBOEMsS0FBOUMsRUFBb0RFLFVBQXBEO0FBQ0FwQixjQUFBQSxNQUFNLENBQUNMLE1BQVAsQ0FBY2tCLEVBQWQsRUFBaUJFLElBQWpCLEVBQXNCRyxPQUF0QixFQUE4QkUsVUFBOUI7QUFHSCxhQWpCRCxDQWtCQTtBQWxCQSxpQkFtQk07QUFDRjtBQUNBLG9CQUFJWCxHQUFHLEdBQUc1QixFQUFFLENBQUM2QixXQUFILENBQWUsS0FBS3JCLG9CQUFwQixDQUFWO0FBQ0EscUJBQUtJLE1BQUwsQ0FBWWtCLFFBQVosQ0FBcUJGLEdBQXJCLEVBSEUsQ0FJRjs7QUFDQUEsZ0JBQUFBLEdBQUcsQ0FBQ0csV0FBSixDQUFnQixDQUFoQixFQUFrQixDQUFsQjtBQUNIO0FBQ0w7O0FBQ0Q7QUFDRjtBQUNKO0FBQ0osR0FwRkk7QUFxRkxVLEVBQUFBLEtBckZLLG1CQXFGSSxDQUVSLENBdkZJLENBeUZMOztBQXpGSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9vemCrueuseWIl+ihqFxyXG5jb25zdCBFbWFpbF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL0VtYWlsX0xvY2FsX1ZhcmlhYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgQWNjZXB0X0JveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5QcmVmYWIsXHJcbiAgICAgICAgICAgIHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSwvL+aIkOWKn+aOpeWPl+aPkOekuuS/oeaBr1xyXG4gICAgICAgIEFscmVhZHlfQWNjZXB0ZWRfQm94OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLlByZWZhYixcclxuICAgICAgICAgICAgc2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICB9LC8v5bey5o6l5Y+X6L+H5o+Q56S65L+h5oGvXHJcbiAgICAgICAgTm9fQXdhcmRzX0JveDp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCxcclxuICAgICAgICAgICAgdHlwZTpjYy5QcmVmYWIsXHJcbiAgICAgICAgICAgIHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSwvL+ayoeacieWlluWKseaPkOekuuS/oeaBr1xyXG4gICAgICAgIEVtYWlsX1RpdGxlOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkxhYmVsLFxyXG4gICAgICAgICAgICBzZXJpYWx6YWJsZTp0cnVlLFxyXG4gICAgICAgIH0sLy/pgq7ku7bmoIfpophcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcbiAgICBBY2NlcHQ6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIHZhciBUaGlzX1RpdGxlPXRoaXMuRW1haWxfVGl0bGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfRW1haWwoKTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbC5sZW5ndGg7aSsrKXtcclxuICAgICAgICAgICAgdmFyIFRpdGxlPUVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlO1xyXG4gICAgICAgICAgICBpZihUaGlzX1RpdGxlPT09VGl0bGUpe1xyXG4gICAgICAgICAgICAgICAgLy/lvZPliY3ngrnlh7vnmoTpgq7ku7ZcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5b2T5YmN6YKu5Lu25YaF5a655Li6Mu+8mlwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW5jbG9zdXJlPT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgICAgICAgIHZhciBUaXAgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLk5vX0F3YXJkc19Cb3gpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5hZGRDaGlsZChUaXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+iuvue9ruaPkOekuuahhuS9jee9rlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXAuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8v5piv5ZCm5bey57uP5o6l5Y+X6L+H5aWW5YqxXHJcbiAgICAgICAgICAgICAgIGVsc2V7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uQWNjZXB0PT09ZmFsc2Upe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+acquabvuaOpeWPl+WlluWKsVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaOpeWPl+WlluWKsVwiKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFRpcCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQWNjZXB0X0JveCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQ2FudmFzLmFkZENoaWxkKFRpcCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v6K6+572u5o+Q56S65qGG5L2N572uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFRpcC5zZXRQb3NpdGlvbigwLDApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+WlluWKseWPguaVsOiuvue9rlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaWQgPSBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5faWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBHb2xkID0gTnVtYmVyKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX0dvbGQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgRGlhbW9uZCA9IE51bWJlcihFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9EaWFtb25kKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIENvbXBhc3Npb24gPSBOdW1iZXIoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfQ29tcGFzc2lvbik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8v5o6l5Y+X5aWW5YqxXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5bey57uP5o6l5Y+X5aWW5YqxXCIsXCLph5HluIHvvJpcIixHb2xkLFwi6ZK755+z77yaXCIsRGlhbW9uZCxcIuS9k+WKm++8mlwiLENvbXBhc3Npb24pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBXZUNoYXQuQWNjZXB0KGlkLEdvbGQsRGlhbW9uZCxDb21wYXNzaW9uKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAvL+W3suaOpeWPl+i/h+WlluWKsVxyXG4gICAgICAgICAgICAgICAgICAgIGVsc2UgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy/lvLnlh7rmj5DnpLrmoYZcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIFRpcCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQWxyZWFkeV9BY2NlcHRlZF9Cb3gpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5hZGRDaGlsZChUaXApO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+iuvue9ruaPkOekuuahhuS9jee9rlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBUaXAuc2V0UG9zaXRpb24oMCwwKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH0gXHJcbiAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Read_All.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bc8ddeepjtFgqAinaVbR+PX', 'Read_All');
// resources/script/Email/Read_All.js

"use strict";

//下载邮箱列表
var _require = require('../Local_Variible/Email_Local_Variable'),
    Email = _require.Email;

var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {},
  Read_All: function Read_All() {
    //获取邮件列表
    WeChat.Loading_Email(); //将未读修改为已读

    WeChat.Read_All();
    console.log("邮件信息表", Email_Local_Variable.Email);
    cc.director.loadScene("Email");
  },
  start: function start() {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxSZWFkX0FsbC5qcyJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiRW1haWwiLCJFbWFpbF9Mb2NhbF9WYXJpYWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiUmVhZF9BbGwiLCJXZUNoYXQiLCJMb2FkaW5nX0VtYWlsIiwiY29uc29sZSIsImxvZyIsImRpcmVjdG9yIiwibG9hZFNjZW5lIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7ZUFDa0JBLE9BQU8sQ0FBQyx3Q0FBRDtJQUFqQkMsaUJBQUFBOztBQUNSLElBQU1DLG9CQUFvQixHQUFHRixPQUFPLENBQUMsd0NBQUQsQ0FBcEM7O0FBQ0FHLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBS0xDLEVBQUFBLFFBQVEsRUFBQyxvQkFBVTtBQUNmO0FBQ0FDLElBQUFBLE1BQU0sQ0FBQ0MsYUFBUCxHQUZlLENBR2Y7O0FBQ0FELElBQUFBLE1BQU0sQ0FBQ0QsUUFBUDtBQUVBRyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CVCxvQkFBb0IsQ0FBQ0QsS0FBekM7QUFDQUUsSUFBQUEsRUFBRSxDQUFDUyxRQUFILENBQVlDLFNBQVosQ0FBc0IsT0FBdEI7QUFDSCxHQWJJO0FBZUxDLEVBQUFBLEtBZkssbUJBZUksQ0FFUjtBQWpCSSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9vemCrueuseWIl+ihqFxyXG5jb25zdCB7IEVtYWlsIH0gPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jb25zdCBFbWFpbF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL0VtYWlsX0xvY2FsX1ZhcmlhYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG4gICAgUmVhZF9BbGw6ZnVuY3Rpb24oKXtcclxuICAgICAgICAvL+iOt+WPlumCruS7tuWIl+ihqFxyXG4gICAgICAgIFdlQ2hhdC5Mb2FkaW5nX0VtYWlsKCk7XHJcbiAgICAgICAgLy/lsIbmnKror7vkv67mlLnkuLrlt7Lor7tcclxuICAgICAgICBXZUNoYXQuUmVhZF9BbGwoKTtcclxuICAgICAgICBcclxuICAgICAgICBjb25zb2xlLmxvZyhcIumCruS7tuS/oeaBr+ihqFwiLEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsKTtcclxuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJFbWFpbFwiKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Email/Loading_Email.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bd112igWp1I7pLIVcdeazws', 'Loading_Email');
// resources/script/Email/Loading_Email.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Email_Read: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已读邮件框
    Email: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //未读邮件框
    Email_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //邮箱框
    No_Read_Number: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //未读邮件计数
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    //获取邮件列表
    Email_Local_Variable.Email = null;
    WeChat.Loading_Email();
    console.log("邮件信息表", Email_Local_Variable.Email);
    this._Is_Loading = true;
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Email_Local_Variable.Email != null) {
      this.Loading_Email();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Email_Type").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Email: function Loading_Email() {
    var No_Read_Number = 0;
    var self = this; //循环输出邮件框

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var New_Email_Label = null; //根据是否已读决定背景(邮件框类型)

      if (Email_Local_Variable.Email[i].Is_Read === true) {
        //新建已读邮件节点
        New_Email_Label = cc.instantiate(this.Email_Read); //加入为子节点

        this.Email_View.addChild(New_Email_Label);
        console.log(New_Email_Label, "第", i + 1, "封邮件");
        console.log("Email_Local_Variable.Email[i].Enclosure:", i, Email_Local_Variable.Email[i].Enclosure);
        console.log("Email_Local_Variable.Email[i].Email_Title:", i, Email_Local_Variable.Email[i].Email_Title);
        console.log("已读");
        console.log("Email_Local_Variable.Email[i].Is_Read:", i, Email_Local_Variable.Email[i].Is_Read); //根据是否有附件决定图标类型

        if (Email_Local_Variable.Email[i].Enclosure === true) //若有附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift2.png?sign=639a28a6a90a604f8cac84ea2eb59eae&t=1610714079");else //若无附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift.png?sign=ca9885f77ec4a7f7b3ffbc83cde81935&t=1610714025");
      } else {
        No_Read_Number++; //新建未读邮件节点

        New_Email_Label = cc.instantiate(this.Email); //加入为子节点

        this.Email_View.addChild(New_Email_Label);
        console.log(New_Email_Label, "第", i + 1, "封邮件");
        console.log("Email_Local_Variable.Email[i].Enclosure:", i, Email_Local_Variable.Email[i].Enclosure);
        console.log("Email_Local_Variable.Email[i].Email_Title:", i, Email_Local_Variable.Email[i].Email_Title);
        console.log("未读");
        console.log("Email_Local_Variable.Email[i].Is_Read:", i, Email_Local_Variable.Email[i].Is_Read);
        if (Email_Local_Variable.Email[i].Enclosure === true) //若有附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift2.png?sign=639a28a6a90a604f8cac84ea2eb59eae&t=1610714079");else //若无附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift.png?sign=ca9885f77ec4a7f7b3ffbc83cde81935&t=1610714025");
      }

      New_Email_Label.getChildByName("Email_Title").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Title;
      New_Email_Label.getChildByName("Email_Label").getChildByName("Email_Content").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Content;
      console.log("New_Email_Label.Email_Type:", New_Email_Label.Email_Type);
    }

    console.log("共", No_Read_Number, "封未读邮件");
    var No_Read_Number_Label = cc.instantiate(this.No_Read_Number);
    this.Canvas.addChild(No_Read_Number_Label);
    No_Read_Number_Label.setPosition(0, 360);
    No_Read_Number_Label.getComponent(cc.Label).string = "" + No_Read_Number + "封未读邮件";
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEVtYWlsXFxMb2FkaW5nX0VtYWlsLmpzIl0sIm5hbWVzIjpbIkVtYWlsX0xvY2FsX1ZhcmlhYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiRW1haWxfUmVhZCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkVtYWlsIiwiRW1haWxfVmlldyIsIk5vZGUiLCJOb19SZWFkX051bWJlciIsIkNhbnZhcyIsIl9Jc19Mb2FkaW5nIiwib25Mb2FkIiwiV2VDaGF0IiwiTG9hZGluZ19FbWFpbCIsImNvbnNvbGUiLCJsb2ciLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiTG9hZGluZ19JbWFnZSIsInNlbGYiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJnZXRDaGlsZEJ5TmFtZSIsImdldENvbXBvbmVudCIsIlNwcml0ZSIsInNwcml0ZUZyYW1lIiwiaSIsImxlbmd0aCIsIk5ld19FbWFpbF9MYWJlbCIsIklzX1JlYWQiLCJpbnN0YW50aWF0ZSIsImFkZENoaWxkIiwiRW5jbG9zdXJlIiwiRW1haWxfVGl0bGUiLCJMYWJlbCIsInN0cmluZyIsIkVtYWlsX0NvbnRlbnQiLCJFbWFpbF9UeXBlIiwiTm9fUmVhZF9OdW1iZXJfTGFiZWwiLCJzZXRQb3NpdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQU1BLG9CQUFvQixHQUFHQyxPQUFPLENBQUMsd0NBQUQsQ0FBcEM7O0FBQ0FDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxVQUFVLEVBQUU7QUFDWCxpQkFBUyxJQURFO0FBRVhDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZFO0FBR1hDLE1BQUFBLFdBQVcsRUFBRTtBQUhGLEtBREQ7QUFLUjtBQUNIQyxJQUFBQSxLQUFLLEVBQUU7QUFDTixpQkFBUyxJQURIO0FBRU5ILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZIO0FBR05DLE1BQUFBLFdBQVcsRUFBRTtBQUhQLEtBTkk7QUFVUjtBQUNIRSxJQUFBQSxVQUFVLEVBQUU7QUFDWCxpQkFBUyxJQURFO0FBRVhKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVSxJQUZFO0FBR1hILE1BQUFBLFdBQVcsRUFBRTtBQUhGLEtBWEQ7QUFlUjtBQUNISSxJQUFBQSxjQUFjLEVBQUU7QUFDZixpQkFBUyxJQURNO0FBRWZOLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZNO0FBR2ZDLE1BQUFBLFdBQVcsRUFBRTtBQUhFLEtBaEJMO0FBb0JSO0FBQ0hLLElBQUFBLE1BQU0sRUFBRTtBQUNQLGlCQUFTLElBREY7QUFFUFAsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNVLElBRkY7QUFHUEgsTUFBQUEsV0FBVyxFQUFFO0FBSE4sS0FyQkc7QUEwQlhNLElBQUFBLFdBQVcsRUFBRTtBQTFCRixHQUhKO0FBK0JSQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQWhCLElBQUFBLG9CQUFvQixDQUFDVSxLQUFyQixHQUE2QixJQUE3QjtBQUNBTyxJQUFBQSxNQUFNLENBQUNDLGFBQVA7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQnBCLG9CQUFvQixDQUFDVSxLQUExQztBQUNBLFNBQUtLLFdBQUwsR0FBaUIsSUFBakI7QUFDQSxHQXJDTztBQXNDUjtBQUVBO0FBRUFNLEVBQUFBLEtBMUNRLG1CQTBDQSxDQUVQLENBNUNPO0FBNkNSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQixRQUFHLEtBQUtSLFdBQUwsSUFBa0JmLG9CQUFvQixDQUFDVSxLQUFyQixJQUE4QixJQUFuRCxFQUF3RDtBQUN0RCxXQUFLUSxhQUFMO0FBQ0EsV0FBS0gsV0FBTCxHQUFpQixLQUFqQjtBQUNEO0FBQ0QsR0FsRE87QUFtRFJTLEVBQUFBLGFBbkRRLHlCQW1ETUMsSUFuRE4sRUFtRFlDLFVBbkRaLEVBbUR3QjtBQUMvQixRQUFJQyxJQUFJLEdBQUdELFVBQVg7QUFDQXhCLElBQUFBLEVBQUUsQ0FBQzBCLE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBRUgsSUFEUztBQUVkcEIsTUFBQUEsSUFBSSxFQUFFO0FBRlEsS0FBZixFQUdHLFVBQVN3QixHQUFULEVBQWNDLE9BQWQsRUFBdUJDLElBQXZCLEVBQTZCO0FBQy9CLFVBQUlDLEtBQUssR0FBRyxJQUFJaEMsRUFBRSxDQUFDaUMsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBWjs7QUFDQSxVQUFJRCxHQUFKLEVBQVM7QUFDUlosUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFvQlcsR0FBcEI7QUFDQTs7QUFDRE4sTUFBQUEsSUFBSSxDQUFDVyxjQUFMLENBQW9CLFlBQXBCLEVBQWtDQyxZQUFsQyxDQUErQ25DLEVBQUUsQ0FBQ29DLE1BQWxELEVBQTBEQyxXQUExRCxHQUF3RUwsS0FBeEU7QUFFQSxLQVZEO0FBV0EsR0FoRU87QUFpRVJoQixFQUFBQSxhQWpFUSwyQkFpRVE7QUFDZixRQUFJTCxjQUFjLEdBQUcsQ0FBckI7QUFDQSxRQUFJWSxJQUFJLEdBQUcsSUFBWCxDQUZlLENBR2Y7O0FBQ0EsU0FBSyxJQUFJZSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHeEMsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCK0IsTUFBL0MsRUFBdURELENBQUMsRUFBeEQsRUFBNEQ7QUFDM0QsVUFBSUUsZUFBZSxHQUFHLElBQXRCLENBRDJELENBRzNEOztBQUNBLFVBQUkxQyxvQkFBb0IsQ0FBQ1UsS0FBckIsQ0FBMkI4QixDQUEzQixFQUE4QkcsT0FBOUIsS0FBMEMsSUFBOUMsRUFBb0Q7QUFDbkQ7QUFDQUQsUUFBQUEsZUFBZSxHQUFHeEMsRUFBRSxDQUFDMEMsV0FBSCxDQUFlLEtBQUt0QyxVQUFwQixDQUFsQixDQUZtRCxDQUduRDs7QUFDQSxhQUFLSyxVQUFMLENBQWdCa0MsUUFBaEIsQ0FBeUJILGVBQXpCO0FBQ0F2QixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXNCLGVBQVosRUFBNkIsR0FBN0IsRUFBa0NGLENBQUMsR0FBRyxDQUF0QyxFQUF5QyxLQUF6QztBQUNBckIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMENBQVosRUFBd0RvQixDQUF4RCxFQUEyRHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTSxTQUF6RjtBQUNBM0IsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNENBQVosRUFBMERvQixDQUExRCxFQUE2RHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTyxXQUEzRjtBQUNBNUIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUNBRCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFzRG9CLENBQXRELEVBQXlEeEMsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJHLE9BQXZGLEVBVG1ELENBVW5EOztBQUNBLFlBQUkzQyxvQkFBb0IsQ0FBQ1UsS0FBckIsQ0FBMkI4QixDQUEzQixFQUE4Qk0sU0FBOUIsS0FBNEMsSUFBaEQsRUFDQztBQUNBLGVBQUt0QixhQUFMLENBQW1Ca0IsZUFBbkIsRUFDQyxvSUFERCxFQUZELEtBTUM7QUFDQSxlQUFLbEIsYUFBTCxDQUFtQmtCLGVBQW5CLEVBQ0MsbUlBREQ7QUFHRCxPQXJCRCxNQXFCTztBQUNON0IsUUFBQUEsY0FBYyxHQURSLENBRU47O0FBQ0E2QixRQUFBQSxlQUFlLEdBQUd4QyxFQUFFLENBQUMwQyxXQUFILENBQWUsS0FBS2xDLEtBQXBCLENBQWxCLENBSE0sQ0FJTjs7QUFDQSxhQUFLQyxVQUFMLENBQWdCa0MsUUFBaEIsQ0FBeUJILGVBQXpCO0FBQ0F2QixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXNCLGVBQVosRUFBNkIsR0FBN0IsRUFBa0NGLENBQUMsR0FBRyxDQUF0QyxFQUF5QyxLQUF6QztBQUNBckIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksMENBQVosRUFBd0RvQixDQUF4RCxFQUEyRHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTSxTQUF6RjtBQUNBM0IsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNENBQVosRUFBMERvQixDQUExRCxFQUE2RHhDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTyxXQUEzRjtBQUNBNUIsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUNBRCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3Q0FBWixFQUFzRG9CLENBQXRELEVBQXlEeEMsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJHLE9BQXZGO0FBRUEsWUFBSTNDLG9CQUFvQixDQUFDVSxLQUFyQixDQUEyQjhCLENBQTNCLEVBQThCTSxTQUE5QixLQUE0QyxJQUFoRCxFQUNDO0FBQ0EsZUFBS3RCLGFBQUwsQ0FBbUJrQixlQUFuQixFQUNDLG9JQURELEVBRkQsS0FNQztBQUNBLGVBQUtsQixhQUFMLENBQW1Ca0IsZUFBbkIsRUFDQyxtSUFERDtBQUdEOztBQUVEQSxNQUFBQSxlQUFlLENBQUNOLGNBQWhCLENBQStCLGFBQS9CLEVBQThDQyxZQUE5QyxDQUEyRG5DLEVBQUUsQ0FBQzhDLEtBQTlELEVBQXFFQyxNQUFyRSxHQUE4RSxLQUFLakQsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJPLFdBQWpIO0FBQ0FMLE1BQUFBLGVBQWUsQ0FBQ04sY0FBaEIsQ0FBK0IsYUFBL0IsRUFBOENBLGNBQTlDLENBQTZELGVBQTdELEVBQThFQyxZQUE5RSxDQUEyRm5DLEVBQUUsQ0FBQzhDLEtBQTlGLEVBQXFHQyxNQUFyRyxHQUE4RyxLQUFLakQsb0JBQW9CLENBQUNVLEtBQXJCLENBQTJCOEIsQ0FBM0IsRUFBOEJVLGFBQWpKO0FBQ0EvQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ3NCLGVBQWUsQ0FBQ1MsVUFBM0Q7QUFDQTs7QUFDRGhDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEdBQVosRUFBaUJQLGNBQWpCLEVBQWlDLE9BQWpDO0FBQ0EsUUFBSXVDLG9CQUFvQixHQUFHbEQsRUFBRSxDQUFDMEMsV0FBSCxDQUFlLEtBQUsvQixjQUFwQixDQUEzQjtBQUNBLFNBQUtDLE1BQUwsQ0FBWStCLFFBQVosQ0FBcUJPLG9CQUFyQjtBQUNBQSxJQUFBQSxvQkFBb0IsQ0FBQ0MsV0FBckIsQ0FBaUMsQ0FBakMsRUFBb0MsR0FBcEM7QUFDQUQsSUFBQUEsb0JBQW9CLENBQUNmLFlBQXJCLENBQWtDbkMsRUFBRSxDQUFDOEMsS0FBckMsRUFBNENDLE1BQTVDLEdBQXFELEtBQUtwQyxjQUFMLEdBQXNCLE9BQTNFO0FBQ0E7QUEvSE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/kuIvovb3pgq7nrrHliJfooahcclxuY29uc3QgRW1haWxfTG9jYWxfVmFyaWFibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRFbWFpbF9SZWFkOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+W3suivu+mCruS7tuahhlxyXG5cdFx0RW1haWw6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v5pyq6K+76YKu5Lu25qGGXHJcblx0XHRFbWFpbF9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/pgq7nrrHmoYZcclxuXHRcdE5vX1JlYWRfTnVtYmVyOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+acquivu+mCruS7tuiuoeaVsFxyXG5cdFx0Q2FudmFzOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblx0b25Mb2FkOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v6I635Y+W6YKu5Lu25YiX6KGoXHJcblx0XHRFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbCA9IG51bGw7XHJcblx0XHRXZUNoYXQuTG9hZGluZ19FbWFpbCgpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLpgq7ku7bkv6Hmga/ooahcIiwgRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwpO1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz10cnVlO1xyXG5cdH0sXHJcblx0Ly8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cdC8vIG9uTG9hZCAoKSB7fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0aWYodGhpcy5fSXNfTG9hZGluZyYmRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWwgIT0gbnVsbCl7XHJcblx0XHRcdFx0dGhpcy5Mb2FkaW5nX0VtYWlsKCk7XHJcblx0XHRcdFx0dGhpcy5fSXNfTG9hZGluZz1mYWxzZTtcclxuXHRcdH1cclxuXHR9LFxyXG5cdExvYWRpbmdfSW1hZ2Uoc2VsZiwgSW1hZ2VfUGF0aCkge1xyXG5cdFx0bGV0IF91cmwgPSBJbWFnZV9QYXRoO1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6IF91cmwsXHJcblx0XHRcdHR5cGU6ICdqcGcnXHJcblx0XHR9LCBmdW5jdGlvbihlcnIsIHRleHR1cmUsIHRlc3QpIHtcclxuXHRcdFx0dmFyIGZyYW1lID0gbmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRpZiAoZXJyKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIiwgZXJyKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRzZWxmLmdldENoaWxkQnlOYW1lKFwiRW1haWxfVHlwZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IGZyYW1lO1xyXG5cclxuXHRcdH0pXHJcblx0fSxcclxuXHRMb2FkaW5nX0VtYWlsKCkge1xyXG5cdFx0dmFyIE5vX1JlYWRfTnVtYmVyID0gMDtcclxuXHRcdHZhciBzZWxmID0gdGhpcztcclxuXHRcdC8v5b6q546v6L6T5Ye66YKu5Lu25qGGXHJcblx0XHRmb3IgKHZhciBpID0gMDsgaSA8IEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsLmxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdHZhciBOZXdfRW1haWxfTGFiZWwgPSBudWxsO1xyXG5cclxuXHRcdFx0Ly/moLnmja7mmK/lkKblt7Lor7vlhrPlrprog4zmma8o6YKu5Lu25qGG57G75Z6LKVxyXG5cdFx0XHRpZiAoRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uSXNfUmVhZCA9PT0gdHJ1ZSkge1xyXG5cdFx0XHRcdC8v5paw5bu65bey6K+76YKu5Lu26IqC54K5XHJcblx0XHRcdFx0TmV3X0VtYWlsX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5FbWFpbF9SZWFkKTtcclxuXHRcdFx0XHQvL+WKoOWFpeS4uuWtkOiKgueCuVxyXG5cdFx0XHRcdHRoaXMuRW1haWxfVmlldy5hZGRDaGlsZChOZXdfRW1haWxfTGFiZWwpO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKE5ld19FbWFpbF9MYWJlbCwgXCLnrKxcIiwgaSArIDEsIFwi5bCB6YKu5Lu2XCIpO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwiRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW5jbG9zdXJlOlwiLCBpLCBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbmNsb3N1cmUpO1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwiRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfVGl0bGU6XCIsIGksIEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIuW3suivu1wiKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIkVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLklzX1JlYWQ6XCIsIGksIEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLklzX1JlYWQpO1xyXG5cdFx0XHRcdC8v5qC55o2u5piv5ZCm5pyJ6ZmE5Lu25Yaz5a6a5Zu+5qCH57G75Z6LXHJcblx0XHRcdFx0aWYgKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZSA9PT0gdHJ1ZSlcclxuXHRcdFx0XHRcdC8v6Iul5pyJ6ZmE5Lu2XHJcblx0XHRcdFx0XHR0aGlzLkxvYWRpbmdfSW1hZ2UoTmV3X0VtYWlsX0xhYmVsLFxyXG5cdFx0XHRcdFx0XHRcImh0dHBzOi8vN2E2My16Y3gtNmdiZ2R4ZHkyNTQ4MTZiMC0xMzA0MzQyOTQ3LnRjYi5xY2xvdWQubGEvaW1hZ2UvVGlwcy9HaWZ0Mi5wbmc/c2lnbj02MzlhMjhhNmE5MGE2MDRmOGNhYzg0ZWEyZWI1OWVhZSZ0PTE2MTA3MTQwNzlcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHQvL+iLpeaXoOmZhOS7tlxyXG5cdFx0XHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19FbWFpbF9MYWJlbCxcclxuXHRcdFx0XHRcdFx0XCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL2ltYWdlL1RpcHMvR2lmdC5wbmc/c2lnbj1jYTk4ODVmNzdlYzRhN2Y3YjNmZmJjODNjZGU4MTkzNSZ0PTE2MTA3MTQwMjVcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHROb19SZWFkX051bWJlcisrO1xyXG5cdFx0XHRcdC8v5paw5bu65pyq6K+76YKu5Lu26IqC54K5XHJcblx0XHRcdFx0TmV3X0VtYWlsX0xhYmVsID0gY2MuaW5zdGFudGlhdGUodGhpcy5FbWFpbCk7XHJcblx0XHRcdFx0Ly/liqDlhaXkuLrlrZDoioLngrlcclxuXHRcdFx0XHR0aGlzLkVtYWlsX1ZpZXcuYWRkQ2hpbGQoTmV3X0VtYWlsX0xhYmVsKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhOZXdfRW1haWxfTGFiZWwsIFwi56ysXCIsIGkgKyAxLCBcIuWwgemCruS7tlwiKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIkVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZTpcIiwgaSwgRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW5jbG9zdXJlKTtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIkVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVtYWlsX1RpdGxlOlwiLCBpLCBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9UaXRsZSk7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLmnKror7tcIik7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCJFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5Jc19SZWFkOlwiLCBpLCBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5Jc19SZWFkKTtcclxuXHJcblx0XHRcdFx0aWYgKEVtYWlsX0xvY2FsX1ZhcmlhYmxlLkVtYWlsW2ldLkVuY2xvc3VyZSA9PT0gdHJ1ZSlcclxuXHRcdFx0XHRcdC8v6Iul5pyJ6ZmE5Lu2XHJcblx0XHRcdFx0XHR0aGlzLkxvYWRpbmdfSW1hZ2UoTmV3X0VtYWlsX0xhYmVsLFxyXG5cdFx0XHRcdFx0XHRcImh0dHBzOi8vN2E2My16Y3gtNmdiZ2R4ZHkyNTQ4MTZiMC0xMzA0MzQyOTQ3LnRjYi5xY2xvdWQubGEvaW1hZ2UvVGlwcy9HaWZ0Mi5wbmc/c2lnbj02MzlhMjhhNmE5MGE2MDRmOGNhYzg0ZWEyZWI1OWVhZSZ0PTE2MTA3MTQwNzlcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0XHRlbHNlXHJcblx0XHRcdFx0XHQvL+iLpeaXoOmZhOS7tlxyXG5cdFx0XHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19FbWFpbF9MYWJlbCxcclxuXHRcdFx0XHRcdFx0XCJodHRwczovLzdhNjMtemN4LTZnYmdkeGR5MjU0ODE2YjAtMTMwNDM0Mjk0Ny50Y2IucWNsb3VkLmxhL2ltYWdlL1RpcHMvR2lmdC5wbmc/c2lnbj1jYTk4ODVmNzdlYzRhN2Y3YjNmZmJjODNjZGU4MTkzNSZ0PTE2MTA3MTQwMjVcIlxyXG5cdFx0XHRcdFx0KTtcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0TmV3X0VtYWlsX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiRW1haWxfVGl0bGVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgRW1haWxfTG9jYWxfVmFyaWFibGUuRW1haWxbaV0uRW1haWxfVGl0bGU7XHJcblx0XHRcdE5ld19FbWFpbF9MYWJlbC5nZXRDaGlsZEJ5TmFtZShcIkVtYWlsX0xhYmVsXCIpLmdldENoaWxkQnlOYW1lKFwiRW1haWxfQ29udGVudFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBFbWFpbF9Mb2NhbF9WYXJpYWJsZS5FbWFpbFtpXS5FbWFpbF9Db250ZW50O1xyXG5cdFx0XHRjb25zb2xlLmxvZyhcIk5ld19FbWFpbF9MYWJlbC5FbWFpbF9UeXBlOlwiLCBOZXdfRW1haWxfTGFiZWwuRW1haWxfVHlwZSk7XHJcblx0XHR9XHJcblx0XHRjb25zb2xlLmxvZyhcIuWFsVwiLCBOb19SZWFkX051bWJlciwgXCLlsIHmnKror7vpgq7ku7ZcIik7XHJcblx0XHR2YXIgTm9fUmVhZF9OdW1iZXJfTGFiZWwgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLk5vX1JlYWRfTnVtYmVyKTtcclxuXHRcdHRoaXMuQ2FudmFzLmFkZENoaWxkKE5vX1JlYWRfTnVtYmVyX0xhYmVsKTtcclxuXHRcdE5vX1JlYWRfTnVtYmVyX0xhYmVsLnNldFBvc2l0aW9uKDAsIDM2MCk7XHJcblx0XHROb19SZWFkX051bWJlcl9MYWJlbC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IFwiXCIgKyBOb19SZWFkX051bWJlciArIFwi5bCB5pyq6K+76YKu5Lu2XCI7XHJcblx0fVxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Waterpipe_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '85c4fRDZ2lP6YFLrKdOCnzk', 'Waterpipe_Action');
// resources/script/Game_Coming/Waterpipe_Action.js

"use strict";

//水管移动逻辑
var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Move_Speed: 0,
    //水平移动速度
    x: 0,
    //x坐标
    y: 0,
    //y坐标
    Move_Distance: 0,
    //移动的距离
    Is_Move: false,
    //是否垂直移动
    Is_Up: true //是否向上移动 ，如果为否，就会向下移动

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager(); //改变碰撞体积

    manager.enabled = true; //manager.enabledDebugDraw = true;

    this.Is_Move = Game_Difficulty_Local_Varible.Is_Difficulty; //如果游戏难度为最难，则则不能上下移动

    if (Math.random() > 0.5) {
      this.Is_Up = false; //决定上下移动还是左右移动
    }
  },
  start: function start() {},
  update: function update(dt) {
    this.node.x -= 5 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 2; //水平移动水管

    if (this.node.x < -600) {
      //如果水管已出屏幕，分数加一，毁灭掉水管
      Game_Local_Varible.Fraction += 1;
      this.node.destroy();
    }

    if (this.Is_Move == true && this.node.x < 0) {
      //如果水管能够上下移动，添加水管的上下移动距离
      this.Move_Distance = 50;
      this.Is_Move = false;
    }

    if (this.Move_Distance > 0 && this.Is_Up == true) {
      //使水管上下移动
      this.node.y += 5;
      this.Move_Distance -= 5;
    } else if (this.Move_Distance > 0 && this.Is_Up == false) {
      this.node.y -= 5;
      this.Move_Distance -= 5;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxXYXRlcnBpcGVfQWN0aW9uLmpzIl0sIm5hbWVzIjpbIkdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsIkdhbWVfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiTW92ZV9TcGVlZCIsIngiLCJ5IiwiTW92ZV9EaXN0YW5jZSIsIklzX01vdmUiLCJJc19VcCIsIm9uTG9hZCIsIm1hbmFnZXIiLCJkaXJlY3RvciIsImdldENvbGxpc2lvbk1hbmFnZXIiLCJlbmFibGVkIiwiSXNfRGlmZmljdWx0eSIsIk1hdGgiLCJyYW5kb20iLCJzdGFydCIsInVwZGF0ZSIsImR0Iiwibm9kZSIsIkRpZmZpY3VsdHlfUmF0aW8iLCJGcmFjdGlvbiIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSw2QkFBNkIsR0FBR0MsT0FBTyxDQUFDLCtCQUFELENBQTNDOztBQUNBLElBQUlDLGtCQUFrQixHQUFHRCxPQUFPLENBQUMsb0JBQUQsQ0FBaEM7O0FBRUFFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxVQUFVLEVBQUUsQ0FERDtBQUNJO0FBQ2ZDLElBQUFBLENBQUMsRUFBRSxDQUZRO0FBRUw7QUFDTkMsSUFBQUEsQ0FBQyxFQUFFLENBSFE7QUFHTDtBQUNOQyxJQUFBQSxhQUFhLEVBQUUsQ0FKSjtBQUlPO0FBQ2xCQyxJQUFBQSxPQUFPLEVBQUUsS0FMRTtBQUtLO0FBQ2hCQyxJQUFBQSxLQUFLLEVBQUUsSUFOSSxDQU1FOztBQU5GLEdBSEo7QUFZUjtBQUNBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEIsUUFBSUMsT0FBTyxHQUFHWCxFQUFFLENBQUNZLFFBQUgsQ0FBWUMsbUJBQVosRUFBZCxDQURrQixDQUMrQjs7QUFDakRGLElBQUFBLE9BQU8sQ0FBQ0csT0FBUixHQUFrQixJQUFsQixDQUZrQixDQUdsQjs7QUFDQSxTQUFLTixPQUFMLEdBQWVYLDZCQUE2QixDQUFDa0IsYUFBN0MsQ0FKa0IsQ0FJMEM7O0FBQzVELFFBQUlDLElBQUksQ0FBQ0MsTUFBTCxLQUFnQixHQUFwQixFQUF5QjtBQUN4QixXQUFLUixLQUFMLEdBQWEsS0FBYixDQUR3QixDQUNKO0FBQ3BCO0FBQ0QsR0FyQk87QUF3QlJTLEVBQUFBLEtBQUssRUFBRSxpQkFBVyxDQUFFLENBeEJaO0FBeUJSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQixTQUFLQyxJQUFMLENBQVVoQixDQUFWLElBQWdCLElBQUlSLDZCQUE2QixDQUFDeUIsZ0JBQTlCLEdBQWlELENBQXJFLENBRG9CLENBQ3FEOztBQUN6RSxRQUFJLEtBQUtELElBQUwsQ0FBVWhCLENBQVYsR0FBYyxDQUFDLEdBQW5CLEVBQXdCO0FBQUU7QUFDekJOLE1BQUFBLGtCQUFrQixDQUFDd0IsUUFBbkIsSUFBK0IsQ0FBL0I7QUFDQSxXQUFLRixJQUFMLENBQVVHLE9BQVY7QUFDQTs7QUFDRCxRQUFJLEtBQUtoQixPQUFMLElBQWdCLElBQWhCLElBQXdCLEtBQUthLElBQUwsQ0FBVWhCLENBQVYsR0FBYyxDQUExQyxFQUE2QztBQUFFO0FBQzlDLFdBQUtFLGFBQUwsR0FBcUIsRUFBckI7QUFDQSxXQUFLQyxPQUFMLEdBQWUsS0FBZjtBQUNBOztBQUNELFFBQUksS0FBS0QsYUFBTCxHQUFxQixDQUFyQixJQUEwQixLQUFLRSxLQUFMLElBQWMsSUFBNUMsRUFBa0Q7QUFBRTtBQUNuRCxXQUFLWSxJQUFMLENBQVVmLENBQVYsSUFBZSxDQUFmO0FBQ0EsV0FBS0MsYUFBTCxJQUFzQixDQUF0QjtBQUNBLEtBSEQsTUFHTyxJQUFJLEtBQUtBLGFBQUwsR0FBcUIsQ0FBckIsSUFBMEIsS0FBS0UsS0FBTCxJQUFjLEtBQTVDLEVBQW1EO0FBQ3pELFdBQUtZLElBQUwsQ0FBVWYsQ0FBVixJQUFlLENBQWY7QUFDQSxXQUFLQyxhQUFMLElBQXNCLENBQXRCO0FBQ0E7QUFDRDtBQTFDTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+awtOeuoeenu+WKqOmAu+i+kVxyXG52YXIgR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCdHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZScpO1xyXG52YXIgR2FtZV9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnR2FtZV9Mb2NhbF9WYXJpYmxlJyk7XHJcblxyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRNb3ZlX1NwZWVkOiAwLCAvL+awtOW5s+enu+WKqOmAn+W6plxyXG5cdFx0eDogMCwgLy945Z2Q5qCHXHJcblx0XHR5OiAwLCAvL3nlnZDmoIdcclxuXHRcdE1vdmVfRGlzdGFuY2U6IDAsIC8v56e75Yqo55qE6Led56a7XHJcblx0XHRJc19Nb3ZlOiBmYWxzZSwgLy/mmK/lkKblnoLnm7Tnp7vliqhcclxuXHRcdElzX1VwOiB0cnVlLCAvL+aYr+WQpuWQkeS4iuenu+WKqCDvvIzlpoLmnpzkuLrlkKbvvIzlsLHkvJrlkJHkuIvnp7vliqhcclxuXHR9LFxyXG5cclxuXHQvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIG1hbmFnZXIgPSBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCk7IC8v5pS55Y+Y56Kw5pKe5L2T56evXHJcblx0XHRtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0Ly9tYW5hZ2VyLmVuYWJsZWREZWJ1Z0RyYXcgPSB0cnVlO1xyXG5cdFx0dGhpcy5Jc19Nb3ZlID0gR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuSXNfRGlmZmljdWx0eTsgLy/lpoLmnpzmuLjmiI/pmr7luqbkuLrmnIDpmr7vvIzliJnliJnkuI3og73kuIrkuIvnp7vliqhcclxuXHRcdGlmIChNYXRoLnJhbmRvbSgpID4gMC41KSB7XHJcblx0XHRcdHRoaXMuSXNfVXAgPSBmYWxzZTsgLy/lhrPlrprkuIrkuIvnp7vliqjov5jmmK/lt6blj7Pnp7vliqhcclxuXHRcdH1cclxuXHR9LFxyXG5cclxuXHJcblx0c3RhcnQ6IGZ1bmN0aW9uKCkge30sXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0dGhpcy5ub2RlLnggLT0gKDUgKyBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5EaWZmaWN1bHR5X1JhdGlvICogMik7IC8v5rC05bmz56e75Yqo5rC0566hXHJcblx0XHRpZiAodGhpcy5ub2RlLnggPCAtNjAwKSB7IC8v5aaC5p6c5rC0566h5bey5Ye65bGP5bmV77yM5YiG5pWw5Yqg5LiA77yM5q+B54Gt5o6J5rC0566hXHJcblx0XHRcdEdhbWVfTG9jYWxfVmFyaWJsZS5GcmFjdGlvbiArPSAxO1xyXG5cdFx0XHR0aGlzLm5vZGUuZGVzdHJveSgpO1xyXG5cdFx0fVxyXG5cdFx0aWYgKHRoaXMuSXNfTW92ZSA9PSB0cnVlICYmIHRoaXMubm9kZS54IDwgMCkgeyAvL+WmguaenOawtOeuoeiDveWkn+S4iuS4i+enu+WKqO+8jOa3u+WKoOawtOeuoeeahOS4iuS4i+enu+WKqOi3neemu1xyXG5cdFx0XHR0aGlzLk1vdmVfRGlzdGFuY2UgPSA1MDtcclxuXHRcdFx0dGhpcy5Jc19Nb3ZlID0gZmFsc2U7XHJcblx0XHR9XHJcblx0XHRpZiAodGhpcy5Nb3ZlX0Rpc3RhbmNlID4gMCAmJiB0aGlzLklzX1VwID09IHRydWUpIHsgLy/kvb/msLTnrqHkuIrkuIvnp7vliqhcclxuXHRcdFx0dGhpcy5ub2RlLnkgKz0gNTtcclxuXHRcdFx0dGhpcy5Nb3ZlX0Rpc3RhbmNlIC09IDU7XHJcblx0XHR9IGVsc2UgaWYgKHRoaXMuTW92ZV9EaXN0YW5jZSA+IDAgJiYgdGhpcy5Jc19VcCA9PSBmYWxzZSkge1xyXG5cdFx0XHR0aGlzLm5vZGUueSAtPSA1O1xyXG5cdFx0XHR0aGlzLk1vdmVfRGlzdGFuY2UgLT0gNTtcclxuXHRcdH1cclxuXHR9LFxyXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Loading_Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'af79b95NVZMY7RSD43KGbtm', 'Loading_Game');
// resources/script/Game_Start/Loading_Game.js

"use strict";

//加载游戏资源
cc.Class({
  "extends": cc.Component,
  properties: {
    Admin_Button: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  onLoad: function onLoad() {
    //是否为管理员
    console.log("管理员的值为", Global_Variable.Is_Admin);
  },
  start: function start() {},
  update: function update(dt) {
    this.Admin_Button.active = Global_Variable.Is_Admin;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXExvYWRpbmdfR2FtZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkFkbWluX0J1dHRvbiIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJvbkxvYWQiLCJjb25zb2xlIiwibG9nIiwiR2xvYmFsX1ZhcmlhYmxlIiwiSXNfQWRtaW4iLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiYWN0aXZlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBRVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxJQUZJO0FBR2JDLE1BQUFBLFdBQVcsRUFBRTtBQUhBO0FBREgsR0FGSjtBQVVSQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQUMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWixFQUFxQkMsZUFBZSxDQUFDQyxRQUFyQztBQUVBLEdBZE87QUFnQlJDLEVBQUFBLEtBQUssRUFBRSxpQkFBVyxDQUFFLENBaEJaO0FBa0JSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQixTQUFLWCxZQUFMLENBQWtCWSxNQUFsQixHQUF5QkwsZUFBZSxDQUFDQyxRQUF6QztBQUNBO0FBcEJPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5Yqg6L295ri45oiP6LWE5rqQXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0QWRtaW5fQnV0dG9uOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHR9LFxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Ly/mmK/lkKbkuLrnrqHnkIblkZhcclxuXHRcdGNvbnNvbGUubG9nKFwi566h55CG5ZGY55qE5YC85Li6XCIsR2xvYmFsX1ZhcmlhYmxlLklzX0FkbWluKTtcclxuXHRcdFxyXG5cdH0sXHJcblxyXG5cdHN0YXJ0OiBmdW5jdGlvbigpIHt9LFxyXG5cclxuXHR1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblx0XHR0aGlzLkFkbWluX0J1dHRvbi5hY3RpdmU9R2xvYmFsX1ZhcmlhYmxlLklzX0FkbWluO1xyXG5cdH0sXHJcbn0pO1xuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Gold_Show_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8b8b2T/IZ1FAabnNpC4GbPK', 'Gold_Show_Action');
// resources/script/Game_Coming/Gold_Show_Action.js

"use strict";

//金币显示框运动逻辑
var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Gold_Show: {
      //金币显示框
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    console.log("Game_Local_Varible.Gold=" + Game_Local_Varible.Gold);
    this.Gold_Show.string = Game_Local_Varible.Gold; //改变金币显示数
  },
  start: function start() {},
  update: function update(dt) {
    this.Gold_Show.string = Game_Local_Varible.Gold; //改变金币显示数
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxHb2xkX1Nob3dfQWN0aW9uLmpzIl0sIm5hbWVzIjpbIkdhbWVfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkdvbGRfU2hvdyIsInR5cGUiLCJMYWJlbCIsInNlcmlhbHphYmxlIiwib25Mb2FkIiwiY29uc29sZSIsImxvZyIsIkdvbGQiLCJzdHJpbmciLCJzdGFydCIsInVwZGF0ZSIsImR0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsa0JBQWtCLEdBQUdDLE9BQU8sQ0FBQyxvQkFBRCxDQUFoQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ2RDLElBQUFBLFNBQVMsRUFBQztBQUFHO0FBQ1osaUJBQVEsSUFEQztBQUVUQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sS0FGQztBQUdUQyxNQUFBQSxXQUFXLEVBQUM7QUFISDtBQURJLEdBSFA7QUFZTDtBQUVBQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDckJDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDZCQUEyQlosa0JBQWtCLENBQUNhLElBQTFEO0FBQ0EsU0FBS1AsU0FBTCxDQUFlUSxNQUFmLEdBQXlCZCxrQkFBa0IsQ0FBQ2EsSUFBNUMsQ0FGcUIsQ0FFK0I7QUFDcEQsR0FqQk87QUFtQkxFLEVBQUFBLEtBbkJLLG1CQW1CSSxDQUNSLENBcEJJO0FBc0JMQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUN2QixTQUFLWCxTQUFMLENBQWVRLE1BQWYsR0FBeUJkLGtCQUFrQixDQUFDYSxJQUE1QyxDQUR1QixDQUMyQjtBQUNsRDtBQXhCTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+mHkeW4geaYvuekuuahhui/kOWKqOmAu+i+kVxyXG52YXIgR2FtZV9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnR2FtZV9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblx0XHRHb2xkX1Nob3c6eyAgLy/ph5HluIHmmL7npLrmoYZcclxuXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbigpIHsgIFxyXG5cdFx0Y29uc29sZS5sb2coXCJHYW1lX0xvY2FsX1ZhcmlibGUuR29sZD1cIitHYW1lX0xvY2FsX1ZhcmlibGUuR29sZClcclxuXHRcdHRoaXMuR29sZF9TaG93LnN0cmluZyA9IChHYW1lX0xvY2FsX1ZhcmlibGUuR29sZCk7ICAvL+aUueWPmOmHkeW4geaYvuekuuaVsFxyXG5cdH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgfSxcclxuXHJcbiAgICB1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblx0XHR0aGlzLkdvbGRfU2hvdy5zdHJpbmcgPSAoR2FtZV9Mb2NhbF9WYXJpYmxlLkdvbGQpOy8v5pS55Y+Y6YeR5biB5pi+56S65pWwXHJcblx0fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Login/NewScript.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b181dbQZkBL17qJeHr7Wncz', 'NewScript');
// resources/script/Game_Login/NewScript.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {// foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfTG9naW5cXE5ld1NjcmlwdC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsQ0FDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFmUSxHQUhQO0FBcUJMO0FBRUE7QUFFQUMsRUFBQUEsS0F6QkssbUJBeUJJLENBRVIsQ0EzQkksQ0E2Qkw7O0FBN0JLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Coming/Bird_Action.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'a5d13OmP/tDJbQItrMrcI7P', 'Bird_Action');
// resources/script/Game_Coming/Bird_Action.js

"use strict";

//控制小鸟的运动情况
var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    birdwingAudio: {
      "default": null,
      type: cc.AudioClip
    },
    birddieAudio: {
      "default": null,
      type: cc.AudioClip
    },
    _V_Index: 0,
    //小鸟垂直速度
    _Is_Sart: true,
    //游戏是否进行
    Jump_Up_Acc: 0,
    //上升速度
    Jump_Down_Acc: 0
  },
  onLoad: function onLoad() {
    //开启小鸟的碰撞属性
    var manager = cc.director.getCollisionManager(); //manager.enabledDebugDraw = true;

    manager.enabled = true; //监听屏幕是否被点击

    this.node.parent.on(cc.Node.EventType.TOUCH_START, this.onTouchMove, this);
  },
  onDestroy: function onDestroy() {// 取消键盘输入监听
  },
  start: function start() {},
  update: function update(dt) {
    //如果游戏开始，是的小鸟开始掉落
    if (this._Is_Sart) {
      //随着时间的增长，增加下降速度。
      this._V_Index -= this.Jump_Down_Acc * dt;
    } //通过改变小鸟坐标的形式，使得小鸟移动


    this.node.y += this._V_Index * dt;
  },
  onTouchMove: function onTouchMove(event) {
    //如果屏幕被点击，给予小鸟一个向上的加速度
    this._V_Index = this.Jump_Up_Acc * 20;
    cc.audioEngine.playEffect(this.birdwingAudio, false, 0.2);
  },
  onCollisionEnter: function onCollisionEnter(other, self) {
    //如果发生碰撞，调用函数
    console.log("other.name = ", other.node.name, other.node.group, other.node.groupIndex);

    if (other.node.groupIndex === 1) {
      // 与障碍物相撞
      cc.audioEngine.playEffect(this.birddieAudio, false, 0.1);
      this._Is_Sart = false;
      this._V_Index = 3000;
      cc.audioEngine.stopMusic(); //使得小鸟向上飞出屏幕
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfQ29taW5nXFxCaXJkX0FjdGlvbi5qcyJdLCJuYW1lcyI6WyJHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImJpcmR3aW5nQXVkaW8iLCJ0eXBlIiwiQXVkaW9DbGlwIiwiYmlyZGRpZUF1ZGlvIiwiX1ZfSW5kZXgiLCJfSXNfU2FydCIsIkp1bXBfVXBfQWNjIiwiSnVtcF9Eb3duX0FjYyIsIm9uTG9hZCIsIm1hbmFnZXIiLCJkaXJlY3RvciIsImdldENvbGxpc2lvbk1hbmFnZXIiLCJlbmFibGVkIiwibm9kZSIsInBhcmVudCIsIm9uIiwiTm9kZSIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwib25Ub3VjaE1vdmUiLCJvbkRlc3Ryb3kiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwieSIsImV2ZW50IiwiYXVkaW9FbmdpbmUiLCJwbGF5RWZmZWN0Iiwib25Db2xsaXNpb25FbnRlciIsIm90aGVyIiwic2VsZiIsImNvbnNvbGUiLCJsb2ciLCJuYW1lIiwiZ3JvdXAiLCJncm91cEluZGV4Iiwic3RvcE11c2ljIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0EsSUFBSUEsNkJBQTZCLEdBQUdDLE9BQU8sQ0FBQywrQkFBRCxDQUEzQzs7QUFFQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFHUixhQUFTRCxFQUFFLENBQUNFLFNBSEo7QUFJUkMsRUFBQUEsVUFBVSxFQUFFO0FBRVhDLElBQUFBLGFBQWEsRUFBRTtBQUNMLGlCQUFTLElBREo7QUFFTEMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRkosS0FGSjtBQU9YQyxJQUFBQSxZQUFZLEVBQUU7QUFDSixpQkFBUyxJQURMO0FBRUpGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZMLEtBUEg7QUFZWEUsSUFBQUEsUUFBUSxFQUFFLENBWkM7QUFZRTtBQUNiQyxJQUFBQSxRQUFRLEVBQUUsSUFiQztBQWFLO0FBQ2hCQyxJQUFBQSxXQUFXLEVBQUUsQ0FkRjtBQWNLO0FBQ2hCQyxJQUFBQSxhQUFhLEVBQUU7QUFmSixHQUpKO0FBdUJSQyxFQUFBQSxNQUFNLEVBQUUsa0JBQVc7QUFDbEI7QUFDQSxRQUFJQyxPQUFPLEdBQUdiLEVBQUUsQ0FBQ2MsUUFBSCxDQUFZQyxtQkFBWixFQUFkLENBRmtCLENBR2xCOztBQUNBRixJQUFBQSxPQUFPLENBQUNHLE9BQVIsR0FBa0IsSUFBbEIsQ0FKa0IsQ0FLbEI7O0FBQ0EsU0FBS0MsSUFBTCxDQUFVQyxNQUFWLENBQWlCQyxFQUFqQixDQUFvQm5CLEVBQUUsQ0FBQ29CLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsV0FBdEMsRUFBbUQsS0FBS0MsV0FBeEQsRUFBcUUsSUFBckU7QUFFQSxHQS9CTztBQWlDUkMsRUFBQUEsU0FqQ1EsdUJBaUNJLENBQ1g7QUFFQSxHQXBDTztBQXNDUkMsRUFBQUEsS0F0Q1EsbUJBc0NBLENBRVAsQ0F4Q087QUEwQ1JDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhO0FBQ3BCO0FBQ0EsUUFBSSxLQUFLbEIsUUFBVCxFQUFtQjtBQUNsQjtBQUNBLFdBQUtELFFBQUwsSUFBaUIsS0FBS0csYUFBTCxHQUFxQmdCLEVBQXRDO0FBQ0EsS0FMbUIsQ0FNcEI7OztBQUNBLFNBQUtWLElBQUwsQ0FBVVcsQ0FBVixJQUFlLEtBQUtwQixRQUFMLEdBQWdCbUIsRUFBL0I7QUFFQSxHQW5ETztBQW9EUkosRUFBQUEsV0FwRFEsdUJBb0RJTSxLQXBESixFQW9EVztBQUNsQjtBQUNBLFNBQUtyQixRQUFMLEdBQWdCLEtBQUtFLFdBQUwsR0FBbUIsRUFBbkM7QUFDQVYsSUFBQUEsRUFBRSxDQUFDOEIsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUszQixhQUEvQixFQUE4QyxLQUE5QyxFQUFvRCxHQUFwRDtBQUNBLEdBeERPO0FBMERSNEIsRUFBQUEsZ0JBQWdCLEVBQUUsMEJBQVNDLEtBQVQsRUFBZ0JDLElBQWhCLEVBQXNCO0FBQ3ZDO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFBNkJILEtBQUssQ0FBQ2hCLElBQU4sQ0FBV29CLElBQXhDLEVBQThDSixLQUFLLENBQUNoQixJQUFOLENBQVdxQixLQUF6RCxFQUFnRUwsS0FBSyxDQUFDaEIsSUFBTixDQUFXc0IsVUFBM0U7O0FBQ0EsUUFBSU4sS0FBSyxDQUFDaEIsSUFBTixDQUFXc0IsVUFBWCxLQUEwQixDQUE5QixFQUFpQztBQUFFO0FBQ2xDdkMsTUFBQUEsRUFBRSxDQUFDOEIsV0FBSCxDQUFlQyxVQUFmLENBQTBCLEtBQUt4QixZQUEvQixFQUE2QyxLQUE3QyxFQUFtRCxHQUFuRDtBQUNBLFdBQUtFLFFBQUwsR0FBZ0IsS0FBaEI7QUFDQSxXQUFLRCxRQUFMLEdBQWdCLElBQWhCO0FBQ0FSLE1BQUFBLEVBQUUsQ0FBQzhCLFdBQUgsQ0FBZVUsU0FBZixHQUpnQyxDQUtoQztBQUNBO0FBQ0Q7QUFwRU8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/mjqfliLblsI/puJ/nmoTov5Dliqjmg4XlhrVcclxudmFyIEdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUnKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuXHJcblxyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHRwcm9wZXJ0aWVzOiB7XHJcblxyXG5cdFx0YmlyZHdpbmdBdWRpbzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXBcclxuXHRcdH0sXHJcblx0XHRcclxuXHRcdGJpcmRkaWVBdWRpbzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXBcclxuICAgICAgICB9LFxyXG5cclxuXHRcdF9WX0luZGV4OiAwLCAvL+Wwj+m4n+WeguebtOmAn+W6plxyXG5cdFx0X0lzX1NhcnQ6IHRydWUsIC8v5ri45oiP5piv5ZCm6L+b6KGMXHJcblx0XHRKdW1wX1VwX0FjYzogMCwgLy/kuIrljYfpgJ/luqZcclxuXHRcdEp1bXBfRG93bl9BY2M6IDAsXHJcblx0fSxcclxuXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHQvL+W8gOWQr+Wwj+m4n+eahOeisOaSnuWxnuaAp1xyXG5cdFx0dmFyIG1hbmFnZXIgPSBjYy5kaXJlY3Rvci5nZXRDb2xsaXNpb25NYW5hZ2VyKCk7XHJcblx0XHQvL21hbmFnZXIuZW5hYmxlZERlYnVnRHJhdyA9IHRydWU7XHJcblx0XHRtYW5hZ2VyLmVuYWJsZWQgPSB0cnVlO1xyXG5cdFx0Ly/nm5HlkKzlsY/luZXmmK/lkKbooqvngrnlh7tcclxuXHRcdHRoaXMubm9kZS5wYXJlbnQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMub25Ub3VjaE1vdmUsIHRoaXMpO1xyXG5cclxuXHR9LFxyXG5cclxuXHRvbkRlc3Ryb3koKSB7XHJcblx0XHQvLyDlj5bmtojplK7nm5jovpPlhaXnm5HlkKxcclxuXHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHtcclxuXHRcdC8v5aaC5p6c5ri45oiP5byA5aeL77yM5piv55qE5bCP6bif5byA5aeL5o6J6JC9XHJcblx0XHRpZiAodGhpcy5fSXNfU2FydCkge1xyXG5cdFx0XHQvL+maj+edgOaXtumXtOeahOWinumVv++8jOWinuWKoOS4i+mZjemAn+W6puOAglxyXG5cdFx0XHR0aGlzLl9WX0luZGV4IC09IHRoaXMuSnVtcF9Eb3duX0FjYyAqIGR0O1xyXG5cdFx0fVxyXG5cdFx0Ly/pgJrov4fmlLnlj5jlsI/puJ/lnZDmoIfnmoTlvaLlvI/vvIzkvb/lvpflsI/puJ/np7vliqhcclxuXHRcdHRoaXMubm9kZS55ICs9IHRoaXMuX1ZfSW5kZXggKiBkdDtcclxuXHJcblx0fSxcclxuXHRvblRvdWNoTW92ZShldmVudCkge1xyXG5cdFx0Ly/lpoLmnpzlsY/luZXooqvngrnlh7vvvIznu5nkuojlsI/puJ/kuIDkuKrlkJHkuIrnmoTliqDpgJ/luqZcclxuXHRcdHRoaXMuX1ZfSW5kZXggPSB0aGlzLkp1bXBfVXBfQWNjICogMjA7XHJcblx0XHRjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuYmlyZHdpbmdBdWRpbywgZmFsc2UsMC4yKTtcclxuXHR9LFxyXG5cclxuXHRvbkNvbGxpc2lvbkVudGVyOiBmdW5jdGlvbihvdGhlciwgc2VsZikge1xyXG5cdFx0Ly/lpoLmnpzlj5HnlJ/norDmkp7vvIzosIPnlKjlh73mlbBcclxuXHRcdGNvbnNvbGUubG9nKFwib3RoZXIubmFtZSA9IFwiLCBvdGhlci5ub2RlLm5hbWUsIG90aGVyLm5vZGUuZ3JvdXAsIG90aGVyLm5vZGUuZ3JvdXBJbmRleCk7XHJcblx0XHRpZiAob3RoZXIubm9kZS5ncm91cEluZGV4ID09PSAxKSB7IC8vIOS4jumanOeijeeJqeebuOaSnlxyXG5cdFx0XHRjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KHRoaXMuYmlyZGRpZUF1ZGlvLCBmYWxzZSwwLjEpO1xyXG5cdFx0XHR0aGlzLl9Jc19TYXJ0ID0gZmFsc2U7XHJcblx0XHRcdHRoaXMuX1ZfSW5kZXggPSAzMDAwO1xyXG5cdFx0XHRjYy5hdWRpb0VuZ2luZS5zdG9wTXVzaWMoKTtcclxuXHRcdFx0Ly/kvb/lvpflsI/puJ/lkJHkuIrpo57lh7rlsY/luZVcclxuXHRcdH1cclxuXHR9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Loading_Bird_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9bd7fHKWGxApoF1mzQgBvJr', 'Loading_Bird_Image');
// resources/script/Game_Start/Loading_Bird_Image.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXExvYWRpbmdfQmlyZF9JbWFnZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUUsRUFIUDtBQU9MO0FBRUE7QUFFQUMsRUFBQUEsS0FYSyxtQkFXSSxDQUVSLENBYkksQ0FlTDs7QUFmSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Game_Start/Change_Difficult.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3313dWvxnZAQ4hjAepWc3E+', 'Change_Difficult');
// resources/script/Game_Start/Change_Difficult.js

"use strict";

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible'); //改变游戏难度


cc.Class({
  "extends": cc.Component,
  properties: {
    Difficulty: "" //声明游戏难度

  },
  start: function start() {},
  // update (dt) {},
  on_btn_click: function on_btn_click() {
    //根据不同的游戏难度，调整难度系数
    if (this.Difficulty == 'Easy') {
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 0.5;
      Game_Difficulty_Local_Varible.Is_Difficulty = false;
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 1;
    } else if (this.Difficulty == 'Mid') {
      Game_Difficulty_Local_Varible.Is_Difficulty = false;
    } else if (this.Difficulty == 'Difficulty') {
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 1;
      Game_Difficulty_Local_Varible.Is_Difficulty = true;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdhbWVfU3RhcnRcXENoYW5nZV9EaWZmaWN1bHQuanMiXSwibmFtZXMiOlsiR2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJEaWZmaWN1bHR5Iiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJEaWZmaWN1bHR5X1JhdGlvIiwiSXNfRGlmZmljdWx0eSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSw2QkFBNkIsR0FBR0MsT0FBTyxDQUFDLCtCQUFELENBQTNDLEVBQ0E7OztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsVUFBVSxFQUFFLEVBREQsQ0FDSzs7QUFETCxHQUhKO0FBT1JDLEVBQUFBLEtBUFEsbUJBT0EsQ0FHUCxDQVZPO0FBWVI7QUFDQUMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQUU7QUFDMUIsUUFBSSxLQUFLRixVQUFMLElBQW1CLE1BQXZCLEVBQStCO0FBQzlCTixNQUFBQSw2QkFBNkIsQ0FBQ1MsZ0JBQTlCLEdBQWlELEdBQWpEO0FBRUFULE1BQUFBLDZCQUE2QixDQUFDVSxhQUE5QixHQUE4QyxLQUE5QztBQUNBVixNQUFBQSw2QkFBNkIsQ0FBQ1MsZ0JBQTlCLEdBQWlELENBQWpEO0FBQ0EsS0FMRCxNQUtPLElBQUksS0FBS0gsVUFBTCxJQUFtQixLQUF2QixFQUE4QjtBQUVwQ04sTUFBQUEsNkJBQTZCLENBQUNVLGFBQTlCLEdBQThDLEtBQTlDO0FBQ0EsS0FITSxNQUdBLElBQUksS0FBS0osVUFBTCxJQUFtQixZQUF2QixFQUFxQztBQUMzQ04sTUFBQUEsNkJBQTZCLENBQUNTLGdCQUE5QixHQUFpRCxDQUFqRDtBQUVBVCxNQUFBQSw2QkFBNkIsQ0FBQ1UsYUFBOUIsR0FBOEMsSUFBOUM7QUFDQTtBQUNEO0FBM0JPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbInZhciBHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJ0dhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlJyk7XHJcbi8v5pS55Y+Y5ri45oiP6Zq+5bqmXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdERpZmZpY3VsdHk6IFwiXCIsIC8v5aOw5piO5ri45oiP6Zq+5bqmXHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cclxuXHR9LFxyXG5cclxuXHQvLyB1cGRhdGUgKGR0KSB7fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkgeyAvL+agueaNruS4jeWQjOeahOa4uOaIj+mavuW6pu+8jOiwg+aVtOmavuW6puezu+aVsFxyXG5cdFx0aWYgKHRoaXMuRGlmZmljdWx0eSA9PSAnRWFzeScpIHtcclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbyA9IDAuNTtcclxuXHJcblx0XHRcdEdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlLklzX0RpZmZpY3VsdHkgPSBmYWxzZTtcclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuRGlmZmljdWx0eV9SYXRpbyA9IDE7XHJcblx0XHR9IGVsc2UgaWYgKHRoaXMuRGlmZmljdWx0eSA9PSAnTWlkJykge1xyXG5cclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuSXNfRGlmZmljdWx0eSA9IGZhbHNlO1xyXG5cdFx0fSBlbHNlIGlmICh0aGlzLkRpZmZpY3VsdHkgPT0gJ0RpZmZpY3VsdHknKSB7XHJcblx0XHRcdEdhbWVfRGlmZmljdWx0eV9Mb2NhbF9WYXJpYmxlLkRpZmZpY3VsdHlfUmF0aW8gPSAxO1xyXG5cclxuXHRcdFx0R2FtZV9EaWZmaWN1bHR5X0xvY2FsX1ZhcmlibGUuSXNfRGlmZmljdWx0eSA9IHRydWU7XHJcblx0XHR9XHJcblx0fVxyXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Loading_Base_Resouce.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'bcc9eKPWABDFafMeuT5G5RM', 'Loading_Base_Resouce');
// resources/script/Global_Function/Loading_Base_Resouce.js

"use strict";

//加载基础资源
cc.Class({
  "extends": cc.Component,
  properties: {
    Diamond_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //导入钻石
    Gold_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //导入金币
    Compassion_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //导入爱心

  },
  onLoad: function onLoad() {
    WeChat.Loading_Resources();
  },
  start: function start() {},
  //
  update: function update(dt) {
    //加载基础资源
    // this.schedule(function() { // 计时器将每隔 1s 执行一次。
    // 	WeChat.Loading_Resources();
    // }, 1);
    //更新界面上的基础资源
    if (Global_Variable.Gold != null) {
      this.Gold_Show.string = Global_Variable.Gold;
      this.Diamond_Show.string = Global_Variable.Diamond;
      this.Compassion_Show.string = Global_Variable.Compassion;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcTG9hZGluZ19CYXNlX1Jlc291Y2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJEaWFtb25kX1Nob3ciLCJ0eXBlIiwiTGFiZWwiLCJzZXJpYWx6YWJsZSIsIkdvbGRfU2hvdyIsIkNvbXBhc3Npb25fU2hvdyIsIm9uTG9hZCIsIldlQ2hhdCIsIkxvYWRpbmdfUmVzb3VyY2VzIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIkdsb2JhbF9WYXJpYWJsZSIsIkdvbGQiLCJzdHJpbmciLCJEaWFtb25kIiwiQ29tcGFzc2lvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUVSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsWUFBWSxFQUFFO0FBQ2IsaUJBQVMsSUFESTtBQUViQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGSTtBQUdiQyxNQUFBQSxXQUFXLEVBQUU7QUFIQSxLQURIO0FBS1I7QUFDSEMsSUFBQUEsU0FBUyxFQUFFO0FBQ1YsaUJBQVMsSUFEQztBQUVWSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sS0FGQztBQUdWQyxNQUFBQSxXQUFXLEVBQUU7QUFISCxLQU5BO0FBVVI7QUFDSEUsSUFBQUEsZUFBZSxFQUFFO0FBQ2hCLGlCQUFTLElBRE87QUFFaEJKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxLQUZPO0FBR2hCQyxNQUFBQSxXQUFXLEVBQUU7QUFIRyxLQVhOLENBZVQ7O0FBZlMsR0FGSjtBQW9CUkcsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCQyxJQUFBQSxNQUFNLENBQUNDLGlCQUFQO0FBQ0EsR0F0Qk87QUF3QlJDLEVBQUFBLEtBQUssRUFBRSxpQkFBVyxDQUFFLENBeEJaO0FBeUJSO0FBQ0FDLEVBQUFBLE1BQU0sRUFBRSxnQkFBU0MsRUFBVCxFQUFhO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFHQyxlQUFlLENBQUNDLElBQWhCLElBQXNCLElBQXpCLEVBQThCO0FBQzdCLFdBQUtULFNBQUwsQ0FBZVUsTUFBZixHQUF3QkYsZUFBZSxDQUFDQyxJQUF4QztBQUNBLFdBQUtiLFlBQUwsQ0FBa0JjLE1BQWxCLEdBQTJCRixlQUFlLENBQUNHLE9BQTNDO0FBQ0EsV0FBS1YsZUFBTCxDQUFxQlMsTUFBckIsR0FBOEJGLGVBQWUsQ0FBQ0ksVUFBOUM7QUFDQTtBQUNEO0FBckNPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5Yqg6L295Z+656GA6LWE5rqQXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0RGlhbW9uZF9TaG93OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v5a+85YWl6ZK755+zXHJcblx0XHRHb2xkX1Nob3c6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/lr7zlhaXph5HluIFcclxuXHRcdENvbXBhc3Npb25fU2hvdzoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5MYWJlbCxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9IC8v5a+85YWl54ix5b+DXHJcblx0fSxcclxuXHJcblx0b25Mb2FkOiBmdW5jdGlvbigpIHtcclxuXHRcdFdlQ2hhdC5Mb2FkaW5nX1Jlc291cmNlcygpO1xyXG5cdH0sXHJcblxyXG5cdHN0YXJ0OiBmdW5jdGlvbigpIHt9LFxyXG5cdC8vXHJcblx0dXBkYXRlOiBmdW5jdGlvbihkdCkge1xyXG5cdFx0Ly/liqDovb3ln7rnoYDotYTmupBcclxuXHRcdC8vIHRoaXMuc2NoZWR1bGUoZnVuY3Rpb24oKSB7IC8vIOiuoeaXtuWZqOWwhuavj+malCAxcyDmiafooYzkuIDmrKHjgIJcclxuXHRcdC8vIFx0V2VDaGF0LkxvYWRpbmdfUmVzb3VyY2VzKCk7XHJcblx0XHQvLyB9LCAxKTtcclxuXHRcdC8v5pu05paw55WM6Z2i5LiK55qE5Z+656GA6LWE5rqQXHJcblx0XHRpZihHbG9iYWxfVmFyaWFibGUuR29sZCE9bnVsbCl7XHJcblx0XHRcdHRoaXMuR29sZF9TaG93LnN0cmluZyA9IEdsb2JhbF9WYXJpYWJsZS5Hb2xkO1xyXG5cdFx0XHR0aGlzLkRpYW1vbmRfU2hvdy5zdHJpbmcgPSBHbG9iYWxfVmFyaWFibGUuRGlhbW9uZDtcclxuXHRcdFx0dGhpcy5Db21wYXNzaW9uX1Nob3cuc3RyaW5nID0gR2xvYmFsX1ZhcmlhYmxlLkNvbXBhc3Npb247XHJcblx0XHR9XHJcblx0fSxcclxufSk7XHJcblxyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Change_Bird_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'aaa92aSi/ZKjb7X8Ef7fnO9', 'Change_Bird_Image');
// resources/script/Global_Function/Change_Bird_Image.js

"use strict";

//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    condition: false,
    Character_Image_Array: [],
    i: 0
  },
  start: function start() {},
  update: function update(dt) {
    this.node.getComponent(cc.Sprite).spriteFrame = Global_Variable.Character_Image1; // if (!this.condition) {
    // 	//想要执行的方法   
    // 	this.Character_Image_Array = new Array();
    // 	if (Global_Variable.Character_Image1 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image1);
    // 	if (Global_Variable.Character_Image2 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image2);
    // 	if (Global_Variable.Character_Image3 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image3);
    // 	if (Global_Variable.Character_Image4 != null)
    // 		this.Character_Image_Array.push(Global_Variable.Character_Image4);
    // 	if(this.Character_Image_Array.length==4){
    // 		this.condition = true;	
    // 	}
    // };
    // if(this.condition) {
    // 	this.schedule(function() { // 计时器将每隔 1s 执行一次。
    // 		if (this.Character_Image_Array[this.i] != null) {
    // 			this.node.getComponent(cc.Sprite).spriteFrame = this.Character_Image_Array[this.i];
    // 			this.i+=1;
    // 			if (this.i == 3) {
    // 				this.i = 0;
    // 			}
    // 		}
    // 	},3);
    // };
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcQ2hhbmdlX0JpcmRfSW1hZ2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJjb25kaXRpb24iLCJDaGFyYWN0ZXJfSW1hZ2VfQXJyYXkiLCJpIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIm5vZGUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsIkdsb2JhbF9WYXJpYWJsZSIsIkNoYXJhY3Rlcl9JbWFnZTEiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsU0FBUyxFQUFFLEtBREE7QUFFWEMsSUFBQUEscUJBQXFCLEVBQUMsRUFGWDtBQUdYQyxJQUFBQSxDQUFDLEVBQUc7QUFITyxHQUhKO0FBU1JDLEVBQUFBLEtBVFEsbUJBU0EsQ0FFUCxDQVhPO0FBYVJDLEVBQUFBLE1BYlEsa0JBYURDLEVBYkMsRUFhRztBQUNWLFNBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QlgsRUFBRSxDQUFDWSxNQUExQixFQUFrQ0MsV0FBbEMsR0FBZ0RDLGVBQWUsQ0FBQ0MsZ0JBQWhFLENBRFUsQ0FFVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0M7QUF6Q00sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdGNvbmRpdGlvbjogZmFsc2UsXHJcblx0XHRDaGFyYWN0ZXJfSW1hZ2VfQXJyYXk6W10sXHJcblx0XHRpIDogMCxcclxuXHRcdFxyXG5cdH0sXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZShkdCkge1xyXG5cdFx0dGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTE7XHJcblx0XHQvLyBpZiAoIXRoaXMuY29uZGl0aW9uKSB7XHJcblx0XHQvLyBcdC8v5oOz6KaB5omn6KGM55qE5pa55rOVICAgXHJcblx0XHQvLyBcdHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5ID0gbmV3IEFycmF5KCk7XHJcblx0XHQvLyBcdGlmIChHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlMSAhPSBudWxsKVxyXG5cdFx0Ly8gXHRcdHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5LnB1c2goR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTEpO1xyXG5cdFx0Ly8gXHRpZiAoR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTIgIT0gbnVsbClcclxuXHRcdC8vIFx0XHR0aGlzLkNoYXJhY3Rlcl9JbWFnZV9BcnJheS5wdXNoKEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2UyKTtcclxuXHRcdC8vIFx0aWYgKEdsb2JhbF9WYXJpYWJsZS5DaGFyYWN0ZXJfSW1hZ2UzICE9IG51bGwpXHJcblx0XHQvLyBcdFx0dGhpcy5DaGFyYWN0ZXJfSW1hZ2VfQXJyYXkucHVzaChHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlMyk7XHJcblx0XHQvLyBcdGlmIChHbG9iYWxfVmFyaWFibGUuQ2hhcmFjdGVyX0ltYWdlNCAhPSBudWxsKVxyXG5cdFx0Ly8gXHRcdHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5LnB1c2goR2xvYmFsX1ZhcmlhYmxlLkNoYXJhY3Rlcl9JbWFnZTQpO1xyXG5cdFx0Ly8gXHRpZih0aGlzLkNoYXJhY3Rlcl9JbWFnZV9BcnJheS5sZW5ndGg9PTQpe1xyXG5cdFx0Ly8gXHRcdHRoaXMuY29uZGl0aW9uID0gdHJ1ZTtcdFxyXG5cdFx0Ly8gXHR9XHJcblx0XHQvLyB9O1xyXG5cdFx0Ly8gaWYodGhpcy5jb25kaXRpb24pIHtcclxuXHRcdC8vIFx0dGhpcy5zY2hlZHVsZShmdW5jdGlvbigpIHsgLy8g6K6h5pe25Zmo5bCG5q+P6ZqUIDFzIOaJp+ihjOS4gOasoeOAglxyXG5cdFx0Ly8gXHRcdGlmICh0aGlzLkNoYXJhY3Rlcl9JbWFnZV9BcnJheVt0aGlzLmldICE9IG51bGwpIHtcclxuXHRcdC8vIFx0XHRcdHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IHRoaXMuQ2hhcmFjdGVyX0ltYWdlX0FycmF5W3RoaXMuaV07XHJcblx0XHQvLyBcdFx0XHR0aGlzLmkrPTE7XHJcblx0XHQvLyBcdFx0XHRpZiAodGhpcy5pID09IDMpIHtcclxuXHRcdC8vIFx0XHRcdFx0dGhpcy5pID0gMDtcclxuXHRcdC8vIFx0XHRcdH1cclxuXHRcdC8vIFx0XHR9XHJcblx0XHQvLyBcdH0sMyk7XHJcblx0XHQvLyB9O1xyXG5cdFx0fSxcclxuXHRcdFxyXG5cdH0pOyJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Close_Box.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '15c871m3upP+ITBKtGQ2KX7', 'Close_Box');
// resources/script/Global_Function/Close_Box.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  Close: function Close() {
    this.Canvas.destroy();
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcQ2xvc2VfQm94LmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQ2FudmFzIiwidHlwZSIsIk5vZGUiLCJzZXJpYWx6YWJsZSIsIkNsb3NlIiwiZGVzdHJveSIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVIQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sSUFGTDtBQUdaQyxNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQURDLEdBSFA7QUFXTDtBQUVBO0FBQ0FDLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUNaLFNBQUtKLE1BQUwsQ0FBWUssT0FBWjtBQUNILEdBaEJJO0FBaUJMQyxFQUFBQSxLQWpCSyxtQkFpQkksQ0FFUixDQW5CSSxDQXFCTDs7QUFyQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIENhbnZhczp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcclxuXHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIC8vIG9uTG9hZCAoKSB7fSxcclxuICAgIENsb3NlOmZ1bmN0aW9uKCl7XHJcbiAgICAgICAgdGhpcy5DYW52YXMuZGVzdHJveSgpO1xyXG4gICAgfSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Jump_Scene.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd2897L4SatGvI7ZZ+eiw+yr', 'Jump_Scene');
// resources/script/Global_Function/Jump_Scene.js

"use strict";

//界面跳转
cc.Class({
  "extends": cc.Component,
  properties: {
    scene: ""
  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    cc.director.loadScene(this.scene);
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcSnVtcF9TY2VuZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInNjZW5lIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJkaXJlY3RvciIsImxvYWRTY2VuZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNSLGFBQVNELEVBQUUsQ0FBQ0UsU0FESjtBQUdSQyxFQUFBQSxVQUFVLEVBQUU7QUFDWEMsSUFBQUEsS0FBSyxFQUFFO0FBREksR0FISjtBQU9SQyxFQUFBQSxLQVBRLG1CQU9BLENBRVAsQ0FUTztBQVVSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEJOLElBQUFBLEVBQUUsQ0FBQ08sUUFBSCxDQUFZQyxTQUFaLENBQXNCLEtBQUtKLEtBQTNCO0FBQ0E7QUFaTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+eVjOmdoui3s+i9rFxyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRzY2VuZTogXCJcIixcclxuXHR9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHJcblx0fSxcclxuXHRvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG5cdFx0Y2MuZGlyZWN0b3IubG9hZFNjZW5lKHRoaXMuc2NlbmUpO1xyXG5cdH1cclxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/User_Have_Character_Local_Varible.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ee59bZAOEhJU4jQjub2Eosx', 'User_Have_Character_Local_Varible');
// resources/script/Local_Variible/User_Have_Character_Local_Varible.js

"use strict";

module.exports = {
  User_Have_Character: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIlVzZXJfSGF2ZV9DaGFyYWN0ZXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQjtBQUVoQkMsRUFBQUEsbUJBQW1CLEVBQUU7QUFGTCxDQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSB7XHJcblxyXG5cdFVzZXJfSGF2ZV9DaGFyYWN0ZXI6IG51bGwsXHJcbn07Il19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Cloud_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd8c801US0ZKWIP4fZ/YWxXG', 'Cloud_Image');
// resources/script/Global_Function/Cloud_Image.js

"use strict";

//改变图片
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    //图片所在路径
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //图片要加载的组件

  },
  // onLoad () {},
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge; //下载图片

    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcQ2xvdWRfSW1hZ2UuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJJYW1nZSIsIkJHU3ByaXRlIiwidHlwZSIsIlNwcml0ZSIsInNlcmlhbHphYmxlIiwib25Mb2FkIiwic2VsZiIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBQ1hDLElBQUFBLEtBQUssRUFBRSxFQURJO0FBQ0Q7QUFDVkMsSUFBQUEsUUFBUSxFQUFFO0FBQ1QsaUJBQVMsSUFEQTtBQUVUQyxNQUFBQSxJQUFJLEVBQUVOLEVBQUUsQ0FBQ08sTUFGQTtBQUdUQyxNQUFBQSxXQUFXLEVBQUU7QUFISixLQUZDLENBTVI7O0FBTlEsR0FISjtBQVlSO0FBRUFDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVztBQUNsQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBLFFBQUlDLElBQUksR0FBR0QsSUFBSSxDQUFDTixLQUFoQixDQUZrQixDQUdsQjs7QUFDQUosSUFBQUEsRUFBRSxDQUFDWSxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUVILElBRFM7QUFFZEwsTUFBQUEsSUFBSSxFQUFFO0FBRlEsS0FBZixFQUdHLFVBQVNTLEdBQVQsRUFBY0MsT0FBZCxFQUF1QkMsSUFBdkIsRUFBNkI7QUFDL0IsVUFBSUMsS0FBSyxHQUFHLElBQUlsQixFQUFFLENBQUNtQixXQUFQLENBQW1CSCxPQUFuQixDQUFaOztBQUNBLFVBQUlELEdBQUosRUFBUztBQUNSSyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW9CTixHQUFwQjtBQUNBOztBQUNETCxNQUFBQSxJQUFJLENBQUNMLFFBQUwsQ0FBY2lCLFlBQWQsQ0FBMkJ0QixFQUFFLENBQUNPLE1BQTlCLEVBQXNDZ0IsV0FBdEMsR0FBb0RMLEtBQXBEO0FBQ0EsS0FURDtBQVVBLEdBNUJPO0FBOEJSTSxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYSxDQUFFO0FBOUJmLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5pS55Y+Y5Zu+54mHXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdElhbWdlOiBcIlwiLC8v5Zu+54mH5omA5Zyo6Lev5b6EXHJcblx0XHRCR1Nwcml0ZToge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5TcHJpdGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/lm77niYfopoHliqDovb3nmoTnu4Tku7ZcclxuXHR9LFxyXG5cclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblxyXG5cdG9uTG9hZDogZnVuY3Rpb24oKSB7XHJcblx0XHR2YXIgc2VsZiA9IHRoaXM7XHJcblx0XHRsZXQgX3VybCA9IHNlbGYuSWFtZ2U7XHJcblx0XHQvL+S4i+i9veWbvueJh1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6IF91cmwsXHJcblx0XHRcdHR5cGU6ICdqcGcnXHJcblx0XHR9LCBmdW5jdGlvbihlcnIsIHRleHR1cmUsIHRlc3QpIHtcclxuXHRcdFx0dmFyIGZyYW1lID0gbmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRpZiAoZXJyKSB7XHJcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIiwgZXJyKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRzZWxmLkJHU3ByaXRlLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID0gZnJhbWU7XHJcblx0XHR9KVxyXG5cdH0sXHJcblxyXG5cdHVwZGF0ZTogZnVuY3Rpb24oZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Jump_DIfficulty.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'c82b5K7GGNOQZ4B65REBXaa', 'Jump_DIfficulty');
// resources/script/Local_Variible/Jump_DIfficulty.js

"use strict";

//跳转难度界面
cc.Class({
  "extends": cc.Component,
  properties: {
    Choose_Difficulty: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //难度框		
    Jump_Jump: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //点击图片

  },
  onLoad: function onLoad() {
    this.Choose_Difficulty.node.active = false; // 初始化跳跃动作  

    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchMove, this);
  },
  onDestroy: function onDestroy() {// 取消键盘输入监听
  },
  start: function start() {},
  update: function update(dt) {},
  onTouchMove: function onTouchMove(event) {
    //管理Jump图片
    this.Jump_Jump.node.active = false; //打开难度选择框

    this.Choose_Difficulty.node.active = true;
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxKdW1wX0RJZmZpY3VsdHkuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJDaG9vc2VfRGlmZmljdWx0eSIsInR5cGUiLCJTcHJpdGUiLCJzZXJpYWx6YWJsZSIsIkp1bXBfSnVtcCIsIm9uTG9hZCIsIm5vZGUiLCJhY3RpdmUiLCJvbiIsIk5vZGUiLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsIm9uVG91Y2hNb3ZlIiwib25EZXN0cm95Iiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsImV2ZW50Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBRVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxpQkFBaUIsRUFBRTtBQUNsQixpQkFBUyxJQURTO0FBRWxCQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGUztBQUdsQkMsTUFBQUEsV0FBVyxFQUFFO0FBSEssS0FEUjtBQUtSO0FBQ0hDLElBQUFBLFNBQVMsRUFBRTtBQUNWLGlCQUFTLElBREM7QUFFVkgsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLE1BRkM7QUFHVkMsTUFBQUEsV0FBVyxFQUFFO0FBSEgsS0FOQSxDQVVSOztBQVZRLEdBRko7QUFlUkUsRUFBQUEsTUFBTSxFQUFFLGtCQUFXO0FBQ2xCLFNBQUtMLGlCQUFMLENBQXVCTSxJQUF2QixDQUE0QkMsTUFBNUIsR0FBcUMsS0FBckMsQ0FEa0IsQ0FFbEI7O0FBQ0EsU0FBS0QsSUFBTCxDQUFVRSxFQUFWLENBQWFaLEVBQUUsQ0FBQ2EsSUFBSCxDQUFRQyxTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxLQUFLQyxXQUFqRCxFQUE4RCxJQUE5RDtBQUNBLEdBbkJPO0FBcUJSQyxFQUFBQSxTQXJCUSx1QkFxQkksQ0FDWDtBQUVBLEdBeEJPO0FBMEJSQyxFQUFBQSxLQTFCUSxtQkEwQkEsQ0FFUCxDQTVCTztBQThCUkMsRUFBQUEsTUFBTSxFQUFFLGdCQUFTQyxFQUFULEVBQWEsQ0FFcEIsQ0FoQ087QUFpQ1JKLEVBQUFBLFdBakNRLHVCQWlDSUssS0FqQ0osRUFpQ1c7QUFDbEI7QUFDQSxTQUFLYixTQUFMLENBQWVFLElBQWYsQ0FBb0JDLE1BQXBCLEdBQTZCLEtBQTdCLENBRmtCLENBR2xCOztBQUNBLFNBQUtQLGlCQUFMLENBQXVCTSxJQUF2QixDQUE0QkMsTUFBNUIsR0FBcUMsSUFBckM7QUFDQTtBQXRDTyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+i3s+i9rOmavuW6pueVjOmdolxyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdENob29zZV9EaWZmaWN1bHR5OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlNwcml0ZSxcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+mavuW6puahhlx0XHRcclxuXHRcdEp1bXBfSnVtcDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5TcHJpdGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/ngrnlh7vlm77niYdcclxuXHR9LFxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dGhpcy5DaG9vc2VfRGlmZmljdWx0eS5ub2RlLmFjdGl2ZSA9IGZhbHNlO1xyXG5cdFx0Ly8g5Yid5aeL5YyW6Lez6LeD5Yqo5L2cICBcclxuXHRcdHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoTW92ZSwgdGhpcyk7XHJcblx0fSxcclxuXHJcblx0b25EZXN0cm95KCkge1xyXG5cdFx0Ly8g5Y+W5raI6ZSu55uY6L6T5YWl55uR5ZCsXHJcblxyXG5cdH0sXHJcblxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cclxuXHR1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblxyXG5cdH0sXHJcblx0b25Ub3VjaE1vdmUoZXZlbnQpIHtcclxuXHRcdC8v566h55CGSnVtcOWbvueJh1xyXG5cdFx0dGhpcy5KdW1wX0p1bXAubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuXHRcdC8v5omT5byA6Zq+5bqm6YCJ5oup5qGGXHJcblx0XHR0aGlzLkNob29zZV9EaWZmaWN1bHR5Lm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuXHR9LFxyXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Global_Function/Global_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ca194AYdxJFRJI8ZInLl158', 'Global_Variable');
// resources/script/Global_Function/Global_Variable.js

"use strict";

window.Global_Variable = {
  User_Information: null,
  openid: null,
  Gold: 0,
  Diamond: 0,
  Compassion: 0,
  User_Head_Image: null,
  User_Name: null,
  Best_Score: 0,
  Is_Admin: false,
  Is_Closured: null,
  Restores_Compassion_Time: new Date(),
  Character_Image1: null,
  Character_Image2: null,
  Character_Image3: null,
  Character_Image4: null,
  Unsealing_Time: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEdsb2JhbF9GdW5jdGlvblxcR2xvYmFsX1ZhcmlhYmxlLmpzIl0sIm5hbWVzIjpbIndpbmRvdyIsIkdsb2JhbF9WYXJpYWJsZSIsIlVzZXJfSW5mb3JtYXRpb24iLCJvcGVuaWQiLCJHb2xkIiwiRGlhbW9uZCIsIkNvbXBhc3Npb24iLCJVc2VyX0hlYWRfSW1hZ2UiLCJVc2VyX05hbWUiLCJCZXN0X1Njb3JlIiwiSXNfQWRtaW4iLCJJc19DbG9zdXJlZCIsIlJlc3RvcmVzX0NvbXBhc3Npb25fVGltZSIsIkRhdGUiLCJDaGFyYWN0ZXJfSW1hZ2UxIiwiQ2hhcmFjdGVyX0ltYWdlMiIsIkNoYXJhY3Rlcl9JbWFnZTMiLCJDaGFyYWN0ZXJfSW1hZ2U0IiwiVW5zZWFsaW5nX1RpbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsZUFBUCxHQUF5QjtBQUN4QkMsRUFBQUEsZ0JBQWdCLEVBQUUsSUFETTtBQUV4QkMsRUFBQUEsTUFBTSxFQUFFLElBRmdCO0FBR3hCQyxFQUFBQSxJQUFJLEVBQUUsQ0FIa0I7QUFJeEJDLEVBQUFBLE9BQU8sRUFBRSxDQUplO0FBS3hCQyxFQUFBQSxVQUFVLEVBQUUsQ0FMWTtBQU14QkMsRUFBQUEsZUFBZSxFQUFFLElBTk87QUFPeEJDLEVBQUFBLFNBQVMsRUFBRSxJQVBhO0FBUXhCQyxFQUFBQSxVQUFVLEVBQUUsQ0FSWTtBQVN4QkMsRUFBQUEsUUFBUSxFQUFDLEtBVGU7QUFVeEJDLEVBQUFBLFdBQVcsRUFBQyxJQVZZO0FBV3hCQyxFQUFBQSx3QkFBd0IsRUFBRSxJQUFJQyxJQUFKLEVBWEY7QUFZeEJDLEVBQUFBLGdCQUFnQixFQUFFLElBWk07QUFheEJDLEVBQUFBLGdCQUFnQixFQUFFLElBYk07QUFjeEJDLEVBQUFBLGdCQUFnQixFQUFFLElBZE07QUFleEJDLEVBQUFBLGdCQUFnQixFQUFFLElBZk07QUFnQnhCQyxFQUFBQSxjQUFjLEVBQUU7QUFoQlEsQ0FBekIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIndpbmRvdy5HbG9iYWxfVmFyaWFibGUgPSB7XHJcblx0VXNlcl9JbmZvcm1hdGlvbjogbnVsbCxcclxuXHRvcGVuaWQ6IG51bGwsXHJcblx0R29sZDogMCxcclxuXHREaWFtb25kOiAwLFxyXG5cdENvbXBhc3Npb246IDAsXHJcblx0VXNlcl9IZWFkX0ltYWdlOiBudWxsLFxyXG5cdFVzZXJfTmFtZTogbnVsbCxcclxuXHRCZXN0X1Njb3JlOiAwLFxyXG5cdElzX0FkbWluOmZhbHNlLFxyXG5cdElzX0Nsb3N1cmVkOm51bGwsXHJcblx0UmVzdG9yZXNfQ29tcGFzc2lvbl9UaW1lOiBuZXcgRGF0ZSgpLFxyXG5cdENoYXJhY3Rlcl9JbWFnZTE6IG51bGwsXHJcblx0Q2hhcmFjdGVyX0ltYWdlMjogbnVsbCxcclxuXHRDaGFyYWN0ZXJfSW1hZ2UzOiBudWxsLFxyXG5cdENoYXJhY3Rlcl9JbWFnZTQ6IG51bGwsXHJcblx0VW5zZWFsaW5nX1RpbWU6IG51bGwsXHJcbn07XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Shop_Character_Local_Varible.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '95dc8tLtclIw7KfpV2l/Vde', 'Shop_Character_Local_Varible');
// resources/script/Local_Variible/Shop_Character_Local_Varible.js

"use strict";

module.exports = {
  Shop_Character_User: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydHMiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFFaEJDLEVBQUFBLG1CQUFtQixFQUFFO0FBRkwsQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0ge1xyXG5cclxuXHRTaG9wX0NoYXJhY3Rlcl9Vc2VyOiBudWxsLFxyXG59OyJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Game_Difficulty_Local_Varible.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '77c6fU8RvVPS5w1VUEQmtm9', 'Game_Difficulty_Local_Varible');
// resources/script/Local_Variible/Game_Difficulty_Local_Varible.js

"use strict";

//游戏难度系数的局部变量
module.exports = {
  //游戏难度系数
  Difficulty_Ratio: 1,
  //是否是困难模式
  Is_Difficulty: false
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxHYW1lX0RpZmZpY3VsdHlfTG9jYWxfVmFyaWJsZS5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiRGlmZmljdWx0eV9SYXRpbyIsIklzX0RpZmZpY3VsdHkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2hCO0FBQ0FDLEVBQUFBLGdCQUFnQixFQUFFLENBRkY7QUFHaEI7QUFDQUMsRUFBQUEsYUFBYSxFQUFFO0FBSkMsQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5ri45oiP6Zq+5bqm57O75pWw55qE5bGA6YOo5Y+Y6YePXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG5cdC8v5ri45oiP6Zq+5bqm57O75pWwXHJcblx0RGlmZmljdWx0eV9SYXRpbzogMSxcclxuXHQvL+aYr+WQpuaYr+WbsOmavuaooeW8j1xyXG5cdElzX0RpZmZpY3VsdHk6IGZhbHNlLFxyXG59O1xuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Rank_Local_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e2ff38hiklMJL+3U5NoiQoC', 'Rank_Local_Variable');
// resources/script/Local_Variible/Rank_Local_Variable.js

"use strict";

module.exports = {
  //�������������Ϣ
  Word_Rank_User: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxSYW5rX0xvY2FsX1ZhcmlhYmxlLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydHMiLCJXb3JkX1JhbmtfVXNlciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2hCO0FBQ0FDLEVBQUFBLGNBQWMsRUFBRTtBQUZBLENBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHtcclxuXHQvL++/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/ve+/vc+iXHJcblx0V29yZF9SYW5rX1VzZXI6IG51bGwsXHJcbn07XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Report_Local_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7185fkTCFtDqJAe6Gxt7FSE', 'Report_Local_Variable');
// resources/script/Local_Variible/Report_Local_Variable.js

"use strict";

//举报         
module.exports = {
  //举报列表
  openid: "",
  User_Name: ""
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxSZXBvcnRfTG9jYWxfVmFyaWFibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIm9wZW5pZCIsIlVzZXJfTmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDaEI7QUFDQUMsRUFBQUEsTUFBTSxFQUFDLEVBRlM7QUFHaEJDLEVBQUFBLFNBQVMsRUFBQztBQUhNLENBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4vuaKpSAgICAgICAgIFxubW9kdWxlLmV4cG9ydHMgPSB7XG5cdC8v5Li+5oql5YiX6KGoXG5cdG9wZW5pZDpcIlwiLFxuXHRVc2VyX05hbWU6XCJcIlxufTsiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Email_Local_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'feb84qEhSBF+IQuP+G7nHvX', 'Email_Local_Variable');
// resources/script/Local_Variible/Email_Local_Variable.js

"use strict";

//邮箱的局部变量
module.exports = {
  //邮箱接收者
  Email: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxFbWFpbF9Mb2NhbF9WYXJpYWJsZS5qcyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiRW1haWwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQUEsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2I7QUFDSEMsRUFBQUEsS0FBSyxFQUFFO0FBRlMsQ0FBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v6YKu566x55qE5bGA6YOo5Y+Y6YePXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG4gICAgLy/pgq7nrrHmjqXmlLbogIVcclxuXHRFbWFpbDogbnVsbCxcclxufTsiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Report_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3150aaPeV1AHaJmpWEz0VCd', 'Report_User');
// resources/script/Rank/Report_User.js

"use strict";

//弹出举报框
var Report_Local_Variable = require('Report_Local_Variable');

var Rank_Local_Varible = require('Rank_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Report_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //举报框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //玩家框节点
    Report_Rank: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //被举报玩家

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建举报信息框
    var New_Report_Label = cc.instantiate(this.Report_Label);
    this.Canvas.parent.parent.parent.addChild(New_Report_Label);
    New_Report_Label.setPosition(0, 0); //载入信息

    console.log("被举报人的名次", this.Report_Rank.getComponent(cc.Label).string);
    var Rank_Number = Number(this.Report_Rank.getComponent(cc.Label).string) - 1;
    console.log("被举报人的openid", Report_Local_Variable.openid);
    Report_Local_Variable.openid = Rank_Local_Varible.Word_Rank_User[Rank_Number].openid;
    Report_Local_Variable.User_Name = Rank_Local_Varible.Word_Rank_User[Rank_Number].User_Name;
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXFJlcG9ydF9Vc2VyLmpzIl0sIm5hbWVzIjpbIlJlcG9ydF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJSYW5rX0xvY2FsX1ZhcmlibGUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIlJlcG9ydF9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkNhbnZhcyIsIk5vZGUiLCJSZXBvcnRfUmFuayIsIkxhYmVsIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJOZXdfUmVwb3J0X0xhYmVsIiwiaW5zdGFudGlhdGUiLCJwYXJlbnQiLCJhZGRDaGlsZCIsInNldFBvc2l0aW9uIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInN0cmluZyIsIlJhbmtfTnVtYmVyIiwiTnVtYmVyIiwib3BlbmlkIiwiV29yZF9SYW5rX1VzZXIiLCJVc2VyX05hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxxQkFBcUIsR0FBR0MsT0FBTyxDQUFDLHVCQUFELENBQW5DOztBQUNBLElBQUlDLGtCQUFrQixHQUFHRCxPQUFPLENBQUMscUJBQUQsQ0FBaEM7O0FBRUFFLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZJO0FBR2JDLE1BQUFBLFdBQVcsRUFBRTtBQUhBLEtBREg7QUFLUjtBQUNIQyxJQUFBQSxNQUFNLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxJQUZGO0FBR1BGLE1BQUFBLFdBQVcsRUFBRTtBQUhOLEtBTkc7QUFVUjtBQUNIRyxJQUFBQSxXQUFXLEVBQUU7QUFDWixpQkFBUyxJQURHO0FBRVpMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDVyxLQUZHO0FBR1pKLE1BQUFBLFdBQVcsRUFBRTtBQUhELEtBWEYsQ0FlUjs7QUFmUSxHQUhKO0FBcUJSSyxFQUFBQSxLQXJCUSxtQkFxQkEsQ0FFUCxDQXZCTztBQXdCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUdkLEVBQUUsQ0FBQ2UsV0FBSCxDQUFlLEtBQUtYLFlBQXBCLENBQXZCO0FBQ0EsU0FBS0ksTUFBTCxDQUFZUSxNQUFaLENBQW1CQSxNQUFuQixDQUEwQkEsTUFBMUIsQ0FBaUNDLFFBQWpDLENBQTBDSCxnQkFBMUM7QUFDQUEsSUFBQUEsZ0JBQWdCLENBQUNJLFdBQWpCLENBQTZCLENBQTdCLEVBQWdDLENBQWhDLEVBSndCLENBS3hCOztBQUNBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaLEVBQXVCLEtBQUtWLFdBQUwsQ0FBaUJXLFlBQWpCLENBQThCckIsRUFBRSxDQUFDVyxLQUFqQyxFQUF3Q1csTUFBL0Q7QUFDQSxRQUFJQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQyxLQUFLZCxXQUFMLENBQWlCVyxZQUFqQixDQUE4QnJCLEVBQUUsQ0FBQ1csS0FBakMsRUFBd0NXLE1BQXpDLENBQU4sR0FBeUQsQ0FBM0U7QUFDQUgsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksYUFBWixFQUEyQnZCLHFCQUFxQixDQUFDNEIsTUFBakQ7QUFDQTVCLElBQUFBLHFCQUFxQixDQUFDNEIsTUFBdEIsR0FBK0IxQixrQkFBa0IsQ0FBQzJCLGNBQW5CLENBQWtDSCxXQUFsQyxFQUErQ0UsTUFBOUU7QUFDQTVCLElBQUFBLHFCQUFxQixDQUFDOEIsU0FBdEIsR0FBa0M1QixrQkFBa0IsQ0FBQzJCLGNBQW5CLENBQWtDSCxXQUFsQyxFQUErQ0ksU0FBakY7QUFDQSxHQW5DTyxDQW9DUjs7QUFwQ1EsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lvLnlh7rkuL7miqXmoYZcclxudmFyIFJlcG9ydF9Mb2NhbF9WYXJpYWJsZSA9IHJlcXVpcmUoJ1JlcG9ydF9Mb2NhbF9WYXJpYWJsZScpO1xyXG52YXIgUmFua19Mb2NhbF9WYXJpYmxlID0gcmVxdWlyZSgnUmFua19Mb2NhbF9WYXJpYWJsZScpO1xyXG5cclxuY2MuQ2xhc3Moe1xyXG5cdGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0UmVwb3J0X0xhYmVsOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLlByZWZhYixcclxuXHRcdFx0c2VyaWFsemFibGU6IHRydWUsXHJcblx0XHR9LCAvL+S4vuaKpeahhlxyXG5cdFx0Q2FudmFzOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/njqnlrrbmoYboioLngrlcclxuXHRcdFJlcG9ydF9SYW5rOiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLkxhYmVsLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v6KKr5Li+5oql546p5a62XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v5Yib5bu65Li+5oql5L+h5oGv5qGGXHJcblx0XHR2YXIgTmV3X1JlcG9ydF9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuUmVwb3J0X0xhYmVsKTtcclxuXHRcdHRoaXMuQ2FudmFzLnBhcmVudC5wYXJlbnQucGFyZW50LmFkZENoaWxkKE5ld19SZXBvcnRfTGFiZWwpO1xyXG5cdFx0TmV3X1JlcG9ydF9MYWJlbC5zZXRQb3NpdGlvbigwLCAwKTtcclxuXHRcdC8v6L295YWl5L+h5oGvXHJcblx0XHRjb25zb2xlLmxvZyhcIuiiq+S4vuaKpeS6uueahOWQjeasoVwiLCB0aGlzLlJlcG9ydF9SYW5rLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKTtcclxuXHRcdHZhciBSYW5rX051bWJlciA9IE51bWJlcih0aGlzLlJlcG9ydF9SYW5rLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nKSAtIDE7XHJcblx0XHRjb25zb2xlLmxvZyhcIuiiq+S4vuaKpeS6uueahG9wZW5pZFwiLCBSZXBvcnRfTG9jYWxfVmFyaWFibGUub3BlbmlkKTtcclxuXHRcdFJlcG9ydF9Mb2NhbF9WYXJpYWJsZS5vcGVuaWQgPSBSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXJbUmFua19OdW1iZXJdLm9wZW5pZDtcclxuXHRcdFJlcG9ydF9Mb2NhbF9WYXJpYWJsZS5Vc2VyX05hbWUgPSBSYW5rX0xvY2FsX1ZhcmlibGUuV29yZF9SYW5rX1VzZXJbUmFua19OdW1iZXJdLlVzZXJfTmFtZTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Local_Variible/Account_Management_Local_Variable.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fcaa05Eja5EDING8XS/HnT8', 'Account_Management_Local_Variable');
// resources/script/Local_Variible/Account_Management_Local_Variable.js

"use strict";

//游戏难度系数的局部变量
module.exports = {
  //全部玩家角色表
  All_Users_Information: null,
  Report_User_List: null,
  Reported_Users_Information: null
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXExvY2FsX1ZhcmlpYmxlXFxBY2NvdW50X01hbmFnZW1lbnRfTG9jYWxfVmFyaWFibGUuanMiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsIkFsbF9Vc2Vyc19JbmZvcm1hdGlvbiIsIlJlcG9ydF9Vc2VyX0xpc3QiLCJSZXBvcnRlZF9Vc2Vyc19JbmZvcm1hdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxNQUFNLENBQUNDLE9BQVAsR0FBaUI7QUFDaEI7QUFDQUMsRUFBQUEscUJBQXFCLEVBQUUsSUFGUDtBQUdoQkMsRUFBQUEsZ0JBQWdCLEVBQUMsSUFIRDtBQUloQkMsRUFBQUEsMEJBQTBCLEVBQUM7QUFKWCxDQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/muLjmiI/pmr7luqbns7vmlbDnmoTlsYDpg6jlj5jph49cclxubW9kdWxlLmV4cG9ydHMgPSB7XHJcblx0Ly/lhajpg6jnjqnlrrbop5LoibLooahcclxuXHRBbGxfVXNlcnNfSW5mb3JtYXRpb246IG51bGwsXHJcblx0UmVwb3J0X1VzZXJfTGlzdDpudWxsLFxyXG5cdFJlcG9ydGVkX1VzZXJzX0luZm9ybWF0aW9uOm51bGwsXHJcblxyXG5cdFxyXG59O1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/My_Rank.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e4df5WVfNREMp/E8B3qtIDN', 'My_Rank');
// resources/script/Rank/My_Rank.js

"use strict";

//加载自己的成绩信息
cc.Class({
  "extends": cc.Component,
  properties: {
    User_Heading_Image: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //使用者头像
    User_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //使用者名字		
    Best_Scroe_Text: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  //加载自己的信息
  onLoad: function onLoad() {
    this.Loading_Image(this, Global_Variable.User_Head_Image);
    this.User_Name.string = Global_Variable.User_Name;
    this.Best_Scroe_Text.string = Global_Variable.Best_Score + "分";
  },
  start: function start() {},
  // update (dt) {},
  //加载图片
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.User_Heading_Image.getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXE15X1JhbmsuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJVc2VyX0hlYWRpbmdfSW1hZ2UiLCJ0eXBlIiwiU3ByaXRlIiwic2VyaWFsemFibGUiLCJVc2VyX05hbWUiLCJMYWJlbCIsIkJlc3RfU2Nyb2VfVGV4dCIsIm9uTG9hZCIsIkxvYWRpbmdfSW1hZ2UiLCJHbG9iYWxfVmFyaWFibGUiLCJVc2VyX0hlYWRfSW1hZ2UiLCJzdHJpbmciLCJCZXN0X1Njb3JlIiwic3RhcnQiLCJzZWxmIiwiSW1hZ2VfUGF0aCIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENvbXBvbmVudCIsInNwcml0ZUZyYW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNkQyxJQUFBQSxrQkFBa0IsRUFBQztBQUVoQixpQkFBUSxJQUZRO0FBR2hCQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFIUTtBQUloQkMsTUFBQUEsV0FBVyxFQUFDO0FBSkksS0FETDtBQU1aO0FBQ0ZDLElBQUFBLFNBQVMsRUFBQztBQUNSLGlCQUFRLElBREE7QUFFUEgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRkQ7QUFHUEYsTUFBQUEsV0FBVyxFQUFDO0FBSEwsS0FQSTtBQVdaO0FBQ0ZHLElBQUFBLGVBQWUsRUFBQztBQUNiLGlCQUFRLElBREs7QUFFYkwsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRks7QUFHYkYsTUFBQUEsV0FBVyxFQUFDO0FBSEM7QUFaRixHQUhQO0FBc0JSO0FBQ0lJLEVBQUFBLE1BQU0sRUFBRSxrQkFBVTtBQUNwQixTQUFLQyxhQUFMLENBQW1CLElBQW5CLEVBQXdCQyxlQUFlLENBQUNDLGVBQXhDO0FBQ0EsU0FBS04sU0FBTCxDQUFlTyxNQUFmLEdBQXNCRixlQUFlLENBQUNMLFNBQXRDO0FBQ0EsU0FBS0UsZUFBTCxDQUFxQkssTUFBckIsR0FBNEJGLGVBQWUsQ0FBQ0csVUFBaEIsR0FBMkIsR0FBdkQ7QUFFQSxHQTVCTTtBQThCTEMsRUFBQUEsS0E5QkssbUJBOEJJLENBRVIsQ0FoQ0k7QUFrQ0w7QUFDSDtBQUNBTCxFQUFBQSxhQXBDUSx5QkFvQ01NLElBcENOLEVBb0NXQyxVQXBDWCxFQW9Dc0I7QUFDM0IsUUFBSUMsSUFBSSxHQUFDRCxVQUFUO0FBQ0FuQixJQUFBQSxFQUFFLENBQUNxQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZGYsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVNtQixHQUFULEVBQWFDLE9BQWIsRUFBcUJDLElBQXJCLEVBQTBCO0FBQzNCLFVBQUlDLEtBQUssR0FBQyxJQUFJM0IsRUFBRSxDQUFDNEIsV0FBUCxDQUFtQkgsT0FBbkIsQ0FBVjs7QUFDQSxVQUFHRCxHQUFILEVBQU87QUFDTkssUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFtQk4sR0FBbkI7QUFDQTs7QUFDRE4sTUFBQUEsSUFBSSxDQUFDZCxrQkFBTCxDQUF3QjJCLFlBQXhCLENBQXFDL0IsRUFBRSxDQUFDTSxNQUF4QyxFQUFnRDBCLFdBQWhELEdBQTRETCxLQUE1RDtBQUVBLEtBVkQ7QUFXRjtBQWpETyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+WKoOi9veiHquW3seeahOaIkOe7qeS/oeaBr1xyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cdFx0VXNlcl9IZWFkaW5nX0ltYWdlOntcclxuXHJcblx0XHRcdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHRcdFx0dHlwZTpjYy5TcHJpdGUsXHJcblx0XHRcdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSwvL+S9v+eUqOiAheWktOWDj1xyXG5cdFx0VXNlcl9OYW1lOntcclxuXHRcdFx0XHRkZWZhdWx0Om51bGwsIFxyXG5cdFx0XHRcdFx0dHlwZTpjYy5MYWJlbCxcclxuXHRcdFx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcblx0XHR9LC8v5L2/55So6ICF5ZCN5a2XXHRcdFxyXG5cdFx0QmVzdF9TY3JvZV9UZXh0OntcclxuXHRcdFx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdFx0XHR0eXBlOmNjLkxhYmVsLFxyXG5cdFx0XHRcdFx0c2VyaWFsemFibGU6dHJ1ZSxcclxuXHRcdH0sXHJcbiAgICB9LFxyXG5cclxuXHQvL+WKoOi9veiHquW3seeahOS/oeaBr1xyXG4gICAgIG9uTG9hZDogZnVuY3Rpb24oKXtcclxuXHRcdCB0aGlzLkxvYWRpbmdfSW1hZ2UodGhpcyxHbG9iYWxfVmFyaWFibGUuVXNlcl9IZWFkX0ltYWdlKTtcclxuXHRcdCB0aGlzLlVzZXJfTmFtZS5zdHJpbmc9R2xvYmFsX1ZhcmlhYmxlLlVzZXJfTmFtZTtcclxuXHRcdCB0aGlzLkJlc3RfU2Nyb2VfVGV4dC5zdHJpbmc9R2xvYmFsX1ZhcmlhYmxlLkJlc3RfU2NvcmUrXCLliIZcIjtcclxuXHRcdCBcclxuXHQgfSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxuXHQvL+WKoOi9veWbvueJh1xyXG5cdExvYWRpbmdfSW1hZ2Uoc2VsZixJbWFnZV9QYXRoKXtcclxuXHRcdFx0XHRsZXQgX3VybD1JbWFnZV9QYXRoO1xyXG5cdFx0XHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0XHRcdHVybDpfdXJsLFxyXG5cdFx0XHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0XHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XHJcblx0XHRcdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xyXG5cdFx0XHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xyXG5cdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0c2VsZi5Vc2VyX0hlYWRpbmdfSW1hZ2UuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuc3ByaXRlRnJhbWU9ZnJhbWU7XHJcblx0XHRcdFx0XHRcclxuXHRcdFx0XHR9KVxyXG5cdH1cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Role/Change_Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '62d69Q/mPZMR7Ofo7rz8dcr', 'Change_Character');
// resources/script/Role/Change_Character.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    console.log("角色ID为", this.Canvas.getChildByName("Character_Id").getComponent(cc.Label).string);
    var Current_id = this.node.getChildByName("Character_Id").getComponent(cc.Label).string;
    WeChat.Updating_Current_Character_id(Current_id);
    this.Canvas.destroy();
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJvbGVcXENoYW5nZV9DaGFyYWN0ZXIuanMiXSwibmFtZXMiOlsiU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIkNhbnZhcyIsInR5cGUiLCJOb2RlIiwic2VyaWFsemFibGUiLCJvbl9idG5fY2xpY2siLCJjb25zb2xlIiwibG9nIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIkN1cnJlbnRfaWQiLCJub2RlIiwiV2VDaGF0IiwiVXBkYXRpbmdfQ3VycmVudF9DaGFyYWN0ZXJfaWQiLCJkZXN0cm95IiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUEsNEJBQTRCLEdBQUdDLE9BQU8sQ0FBQyxnREFBRCxDQUExQzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ2RDLElBQUFBLE1BQU0sRUFBQztBQUNHLGlCQUFRLElBRFg7QUFFR0MsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLElBRlg7QUFHTkMsTUFBQUEsV0FBVyxFQUFDO0FBSE47QUFETyxHQUhQO0FBV0w7QUFFQUMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBRXJCQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaLEVBQW9CLEtBQUtOLE1BQUwsQ0FBWU8sY0FBWixDQUEyQixjQUEzQixFQUEyQ0MsWUFBM0MsQ0FBd0RaLEVBQUUsQ0FBQ2EsS0FBM0QsRUFBa0VDLE1BQXRGO0FBQ04sUUFBSUMsVUFBVSxHQUFDLEtBQUtDLElBQUwsQ0FBVUwsY0FBVixDQUF5QixjQUF6QixFQUF5Q0MsWUFBekMsQ0FBc0RaLEVBQUUsQ0FBQ2EsS0FBekQsRUFBZ0VDLE1BQS9FO0FBQ01HLElBQUFBLE1BQU0sQ0FBQ0MsNkJBQVAsQ0FBcUNILFVBQXJDO0FBQ04sU0FBS1gsTUFBTCxDQUFZZSxPQUFaO0FBRUcsR0FwQkk7QUFxQkxDLEVBQUFBLE1BckJLLGtCQXFCR0MsRUFyQkgsRUFxQk8sQ0FBRTtBQXJCVCxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcblx0XHRDYW52YXM6e1xuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcbiAgICAgICAgICAgIHR5cGU6Y2MuTm9kZSxcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuICAgICAgIFxyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi6KeS6ImySUTkuLpcIix0aGlzLkNhbnZhcy5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9JZFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyk7XHJcblx0XHR2YXIgQ3VycmVudF9pZD10aGlzLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfSWRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LlVwZGF0aW5nX0N1cnJlbnRfQ2hhcmFjdGVyX2lkKEN1cnJlbnRfaWQpO1xyXG5cdFx0dGhpcy5DYW52YXMuZGVzdHJveSgpO1xyXG5cclxuICAgIH0sXHJcbiAgICB1cGRhdGUgKGR0KSB7fSxcclxuXHJcblxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Report_Cancel.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b83b6vn//NP5JtzLaVI6saD', 'Report_Cancel');
// resources/script/Rank/Report_Cancel.js

"use strict";

//取消会议记录
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXFJlcG9ydF9DYW5jZWwuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsIm5vZGUiLCJkZXN0cm95Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBTUw7QUFFQTtBQUVBQyxFQUFBQSxLQVZLLG1CQVVJLENBRVIsQ0FaSTtBQWFSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEIsU0FBS0MsSUFBTCxDQUFVQyxPQUFWO0FBQ0EsR0FmTyxDQWdCTDs7QUFoQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/lj5bmtojkvJrorq7orrDlvZVcclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHRcclxuICAgIH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdHRoaXMubm9kZS5kZXN0cm95KCk7XHJcblx0fVxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Rank/Report_Confirm.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '3838dtwztxF5oSVGAKVfDFZ', 'Report_Confirm');
// resources/script/Rank/Report_Confirm.js

"use strict";

//确定举报
var Report_Local_Variable = require('Report_Local_Variable'); //const Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');


cc.Class({
  "extends": cc.Component,
  properties: {
    Report_Content: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //举报框

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //载入举报人的信息
    console.log("点到了吗??");
    var Reported_User_Openid = Report_Local_Variable.openid;
    var Reported_User_Name = Report_Local_Variable.User_Name;
    var Report_Text = this.Report_Content.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "关于对" + Reported_User_Name + "的举报";
    var Content = "系统已收到您的举报，请等待处理			举报原因：" + Report_Text;
    WeChat.Email_Report_And_Appeal(Time, Title, Content);
    console.log("被举报人OPENID", Reported_User_Openid, "举报内容为", Report_Text); //上传举报信息

    WeChat.Uploading_Reported_Information(Report_Local_Variable.openid, Report_Text);
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJhbmtcXFJlcG9ydF9Db25maXJtLmpzIl0sIm5hbWVzIjpbIlJlcG9ydF9Mb2NhbF9WYXJpYWJsZSIsInJlcXVpcmUiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIlJlcG9ydF9Db250ZW50IiwidHlwZSIsIkxhYmVsIiwic2VyaWFsemFibGUiLCJzdGFydCIsIm9uX2J0bl9jbGljayIsImNvbnNvbGUiLCJsb2ciLCJSZXBvcnRlZF9Vc2VyX09wZW5pZCIsIm9wZW5pZCIsIlJlcG9ydGVkX1VzZXJfTmFtZSIsIlVzZXJfTmFtZSIsIlJlcG9ydF9UZXh0IiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiVGltZSIsInBhcnNlSW50IiwiRGF0ZSIsImdldFRpbWUiLCJUaXRsZSIsIkNvbnRlbnQiLCJXZUNoYXQiLCJFbWFpbF9SZXBvcnRfQW5kX0FwcGVhbCIsIlVwbG9hZGluZ19SZXBvcnRlZF9JbmZvcm1hdGlvbiIsIm5vZGUiLCJkZXN0cm95Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRUEsSUFBSUEscUJBQXFCLEdBQUdDLE9BQU8sQ0FBQyx1QkFBRCxDQUFuQyxFQUNBOzs7QUFDQUMsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDUixhQUFTRCxFQUFFLENBQUNFLFNBREo7QUFHUkMsRUFBQUEsVUFBVSxFQUFFO0FBRVhDLElBQUFBLGNBQWMsRUFBRTtBQUNmLGlCQUFTLElBRE07QUFFZkMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNLEtBRk07QUFHZkMsTUFBQUEsV0FBVyxFQUFFO0FBSEUsS0FGTCxDQU1UOztBQU5TLEdBSEo7QUFZUjtBQUVBO0FBQ0FDLEVBQUFBLEtBZlEsbUJBZUEsQ0FFUCxDQWpCTztBQWtCUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0FDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDQSxRQUFJQyxvQkFBb0IsR0FBR2QscUJBQXFCLENBQUNlLE1BQWpEO0FBQ0EsUUFBSUMsa0JBQWtCLEdBQUdoQixxQkFBcUIsQ0FBQ2lCLFNBQS9DO0FBQ0EsUUFBSUMsV0FBVyxHQUFHLEtBQUtaLGNBQUwsQ0FBb0JhLFlBQXBCLENBQWlDakIsRUFBRSxDQUFDTSxLQUFwQyxFQUEyQ1ksTUFBN0QsQ0FMd0IsQ0FPdEI7O0FBQ0YsUUFBSUMsSUFBSSxHQUFHQyxRQUFRLENBQUMsSUFBSUMsSUFBSixHQUFXQyxPQUFYLEVBQUQsQ0FBbkI7QUFDQSxRQUFJQyxLQUFLLEdBQUcsUUFBTVQsa0JBQU4sR0FBeUIsS0FBckM7QUFDQSxRQUFJVSxPQUFPLEdBQUUsNEJBQTBCUixXQUF2QztBQUNBUyxJQUFBQSxNQUFNLENBQUNDLHVCQUFQLENBQStCUCxJQUEvQixFQUFvQ0ksS0FBcEMsRUFBMENDLE9BQTFDO0FBQ0FkLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVosRUFBMEJDLG9CQUExQixFQUFnRCxPQUFoRCxFQUF5REksV0FBekQsRUFad0IsQ0FheEI7O0FBQ0FTLElBQUFBLE1BQU0sQ0FBQ0UsOEJBQVAsQ0FBc0M3QixxQkFBcUIsQ0FBQ2UsTUFBNUQsRUFBb0VHLFdBQXBFO0FBQ0EsU0FBS1ksSUFBTCxDQUFVQyxPQUFWO0FBQ0EsR0FsQ08sQ0FtQ1I7O0FBbkNRLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v56Gu5a6a5Li+5oqlXHJcblxyXG52YXIgUmVwb3J0X0xvY2FsX1ZhcmlhYmxlID0gcmVxdWlyZSgnUmVwb3J0X0xvY2FsX1ZhcmlhYmxlJyk7XHJcbi8vY29uc3QgRW1haWxfTG9jYWxfVmFyaWFibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9FbWFpbF9Mb2NhbF9WYXJpYWJsZScpO1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblxyXG5cdFx0UmVwb3J0X0NvbnRlbnQ6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwvL+S4vuaKpeahhlxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHQvLyBvbkxvYWQgKCkge30sXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v6L295YWl5Li+5oql5Lq655qE5L+h5oGvXHJcblx0XHRjb25zb2xlLmxvZyhcIueCueWIsOS6huWQlz8/XCIpO1xyXG5cdFx0dmFyIFJlcG9ydGVkX1VzZXJfT3BlbmlkID0gUmVwb3J0X0xvY2FsX1ZhcmlhYmxlLm9wZW5pZDtcclxuXHRcdHZhciBSZXBvcnRlZF9Vc2VyX05hbWUgPSBSZXBvcnRfTG9jYWxfVmFyaWFibGUuVXNlcl9OYW1lO1xyXG5cdFx0dmFyIFJlcG9ydF9UZXh0ID0gdGhpcy5SZXBvcnRfQ29udGVudC5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZztcclxuXHJcblx0XHQgIC8v6I635Y+W5pe26Ze05oizXHJcblx0XHRsZXQgVGltZSA9IHBhcnNlSW50KG5ldyBEYXRlKCkuZ2V0VGltZSgpKTtcclxuXHRcdHZhciBUaXRsZSA9IFwi5YWz5LqO5a+5XCIrUmVwb3J0ZWRfVXNlcl9OYW1lK1wi55qE5Li+5oqlXCI7XHJcblx0XHR2YXIgQ29udGVudCA9XCLns7vnu5/lt7LmlLbliLDmgqjnmoTkuL7miqXvvIzor7fnrYnlvoXlpITnkIZcdFx0XHTkuL7miqXljp/lm6DvvJpcIitSZXBvcnRfVGV4dDtcclxuXHRcdFdlQ2hhdC5FbWFpbF9SZXBvcnRfQW5kX0FwcGVhbChUaW1lLFRpdGxlLENvbnRlbnQpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLooqvkuL7miqXkurpPUEVOSURcIiwgUmVwb3J0ZWRfVXNlcl9PcGVuaWQsIFwi5Li+5oql5YaF5a655Li6XCIsIFJlcG9ydF9UZXh0KTtcclxuXHRcdC8v5LiK5Lyg5Li+5oql5L+h5oGvXHJcblx0XHRXZUNoYXQuVXBsb2FkaW5nX1JlcG9ydGVkX0luZm9ybWF0aW9uKFJlcG9ydF9Mb2NhbF9WYXJpYWJsZS5vcGVuaWQsIFJlcG9ydF9UZXh0KTtcclxuXHRcdHRoaXMubm9kZS5kZXN0cm95KCk7XHJcblx0fVxyXG5cdC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Role/Loading_Role.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '70024YCCxVGfLoGElakA4f/', 'Loading_Role');
// resources/script/Role/Loading_Role.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var User_Have_Character_Local_Varible = require('../Local_Variible/User_Have_Character_Local_Varible');

var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Character_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var self = this;
    User_Have_Character_Local_Varible.User_Have_Character = null;
    WeChat.Loading_Character();
    this._Is_Loading == true;
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && User_Have_Character_Local_Varible.User_Have_Character != null) {
      this.Loading_Character();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("sprite").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Character: function Loading_Character() {
    //遍历User_Character_Information的表
    for (var i = 0; i < User_Have_Character_Local_Varible.User_Have_Character.length; i++) {
      //User_Character_Information放的是只有2个记录的小表(User_Have_Character)的信息
      var User_Character_Information = User_Have_Character_Local_Varible.User_Have_Character[i]; //User_Character_Number放的是Character的序号

      var User_Character_Number = User_Have_Character_Local_Varible.User_Have_Character[i].Character_Id; //判断用户是否有该小鸟
      //Global_Variable.openid是当前用户的openid

      if (Global_Variable.openid == User_Character_Information.openid) {
        // console.log("角色长度",User_Have_Character_Local_Varible.User_Have_Character.length);
        for (var j = 0; j < Shop_Character_Local_Varible.Shop_Character_User.length; j++) {
          if (User_Character_Number == Shop_Character_Local_Varible.Shop_Character_User[j].Character_Id) {
            var New_Character_Label = cc.instantiate(this.Character_Label);
            this.Character_View.addChild(New_Character_Label);
            this.Loading_Image(New_Character_Label, Shop_Character_Local_Varible.Shop_Character_User[j].Character_Head_Image);
            New_Character_Label.getChildByName("Character_Name").getComponent(cc.Label).string = "" + Shop_Character_Local_Varible.Shop_Character_User[j].Character_Name;
          }
        }
      }
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFJvbGVcXExvYWRpbmdfUm9sZS5qcyJdLCJuYW1lcyI6WyJVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQ2hhcmFjdGVyX0xhYmVsIiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQ2hhcmFjdGVyX1ZpZXciLCJOb2RlIiwiX0lzX0xvYWRpbmciLCJvbkxvYWQiLCJzZWxmIiwiVXNlcl9IYXZlX0NoYXJhY3RlciIsIldlQ2hhdCIsIkxvYWRpbmdfQ2hhcmFjdGVyIiwic3RhcnQiLCJ1cGRhdGUiLCJkdCIsIkxvYWRpbmdfSW1hZ2UiLCJJbWFnZV9QYXRoIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJjb25zb2xlIiwibG9nIiwiZ2V0Q2hpbGRCeU5hbWUiLCJnZXRDb21wb25lbnQiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsImkiLCJsZW5ndGgiLCJVc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbiIsIlVzZXJfQ2hhcmFjdGVyX051bWJlciIsIkNoYXJhY3Rlcl9JZCIsIkdsb2JhbF9WYXJpYWJsZSIsIm9wZW5pZCIsImoiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIiwiTmV3X0NoYXJhY3Rlcl9MYWJlbCIsImluc3RhbnRpYXRlIiwiYWRkQ2hpbGQiLCJDaGFyYWN0ZXJfSGVhZF9JbWFnZSIsIkxhYmVsIiwic3RyaW5nIiwiQ2hhcmFjdGVyX05hbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUEsaUNBQWlDLEdBQUdDLE9BQU8sQ0FBQyxxREFBRCxDQUFqRDs7QUFDQSxJQUFJQyw0QkFBNEIsR0FBR0QsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBRSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUVMQyxFQUFBQSxVQUFVLEVBQUU7QUFDZEMsSUFBQUEsZUFBZSxFQUFDO0FBQ2YsaUJBQVEsSUFETztBQUVmQyxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ00sTUFGTztBQUdmQyxNQUFBQSxXQUFXLEVBQUM7QUFIRyxLQURGO0FBTWRDLElBQUFBLGNBQWMsRUFBQztBQUNkLGlCQUFRLElBRE07QUFFZEgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLElBRk07QUFHZEYsTUFBQUEsV0FBVyxFQUFDO0FBSEUsS0FORDtBQVdmRyxJQUFBQSxXQUFXLEVBQUM7QUFYRyxHQUZQO0FBZ0JMO0FBRUNDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVTtBQUNyQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBZixJQUFBQSxpQ0FBaUMsQ0FBQ2dCLG1CQUFsQyxHQUFzRCxJQUF0RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLGlCQUFQO0FBQ0EsU0FBS0wsV0FBTCxJQUFrQixJQUFsQjtBQUNDLEdBdkJNO0FBeUJMTSxFQUFBQSxLQXpCSyxtQkF5QkksQ0FFUixDQTNCSTtBQTZCTEMsRUFBQUEsTUFBTSxFQUFDLGdCQUFVQyxFQUFWLEVBQWM7QUFDdkIsUUFBRyxLQUFLUixXQUFMLElBQWtCYixpQ0FBaUMsQ0FBQ2dCLG1CQUFsQyxJQUF1RCxJQUE1RSxFQUFpRjtBQUNoRixXQUFLRSxpQkFBTDtBQUNBLFdBQUtMLFdBQUwsR0FBaUIsS0FBakI7QUFDQTtBQUNELEdBbENPO0FBbUNSUyxFQUFBQSxhQW5DUSx5QkFtQ01QLElBbkNOLEVBbUNXUSxVQW5DWCxFQW1Dc0I7QUFDN0IsUUFBSUMsSUFBSSxHQUFDRCxVQUFUO0FBQ0FwQixJQUFBQSxFQUFFLENBQUNzQixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZGhCLE1BQUFBLElBQUksRUFBQztBQUZTLEtBQWYsRUFHRSxVQUFTb0IsR0FBVCxFQUFhQyxPQUFiLEVBQXFCQyxJQUFyQixFQUEwQjtBQUMzQixVQUFJQyxLQUFLLEdBQUMsSUFBSTVCLEVBQUUsQ0FBQzZCLFdBQVAsQ0FBbUJILE9BQW5CLENBQVY7O0FBQ0EsVUFBR0QsR0FBSCxFQUFPO0FBQ05LLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBbUJOLEdBQW5CO0FBQ0E7O0FBQ0RiLE1BQUFBLElBQUksQ0FBQ29CLGNBQUwsQ0FBb0IsUUFBcEIsRUFBOEJDLFlBQTlCLENBQTJDakMsRUFBRSxDQUFDa0MsTUFBOUMsRUFBc0RDLFdBQXRELEdBQWtFUCxLQUFsRTtBQUVBLEtBVkQ7QUFXRCxHQWhEUTtBQWlEUmIsRUFBQUEsaUJBakRRLCtCQWlEVztBQUNsQjtBQUNBLFNBQUksSUFBSXFCLENBQUMsR0FBQyxDQUFWLEVBQVlBLENBQUMsR0FBQ3ZDLGlDQUFpQyxDQUFDZ0IsbUJBQWxDLENBQXNEd0IsTUFBcEUsRUFBMkVELENBQUMsRUFBNUUsRUFBK0U7QUFDOUU7QUFDQSxVQUFJRSwwQkFBMEIsR0FBQ3pDLGlDQUFpQyxDQUFDZ0IsbUJBQWxDLENBQXNEdUIsQ0FBdEQsQ0FBL0IsQ0FGOEUsQ0FHOUU7O0FBQ0EsVUFBSUcscUJBQXFCLEdBQUMxQyxpQ0FBaUMsQ0FBQ2dCLG1CQUFsQyxDQUFzRHVCLENBQXRELEVBQXlESSxZQUFuRixDQUo4RSxDQUs5RTtBQUNHOztBQUNBLFVBQUdDLGVBQWUsQ0FBQ0MsTUFBaEIsSUFBd0JKLDBCQUEwQixDQUFDSSxNQUF0RCxFQUE2RDtBQUMvRDtBQUNBLGFBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDNUMsNEJBQTRCLENBQUM2QyxtQkFBN0IsQ0FBaURQLE1BQS9ELEVBQXNFTSxDQUFDLEVBQXZFLEVBQTBFO0FBQ3pFLGNBQUdKLHFCQUFxQixJQUFFeEMsNEJBQTRCLENBQUM2QyxtQkFBN0IsQ0FBaURELENBQWpELEVBQW9ESCxZQUE5RSxFQUEyRjtBQUMxRixnQkFBSUssbUJBQW1CLEdBQUM3QyxFQUFFLENBQUM4QyxXQUFILENBQWUsS0FBSzFDLGVBQXBCLENBQXhCO0FBQ0EsaUJBQUtJLGNBQUwsQ0FBb0J1QyxRQUFwQixDQUE2QkYsbUJBQTdCO0FBQ0EsaUJBQUsxQixhQUFMLENBQW1CMEIsbUJBQW5CLEVBQXVDOUMsNEJBQTRCLENBQUM2QyxtQkFBN0IsQ0FBaURELENBQWpELEVBQW9ESyxvQkFBM0Y7QUFDTUgsWUFBQUEsbUJBQW1CLENBQUNiLGNBQXBCLENBQW1DLGdCQUFuQyxFQUFxREMsWUFBckQsQ0FBa0VqQyxFQUFFLENBQUNpRCxLQUFyRSxFQUE0RUMsTUFBNUUsR0FBbUYsS0FBR25ELDRCQUE0QixDQUFDNkMsbUJBQTdCLENBQWlERCxDQUFqRCxFQUFvRFEsY0FBMUk7QUFDTjtBQUVEO0FBRUU7QUFFSjtBQUNEO0FBekVPLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5jb25zdCBVc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9Vc2VyX0hhdmVfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHRcdENoYXJhY3Rlcl9MYWJlbDp7XHJcblx0XHRcdGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSxcclxuXHRcdENoYXJhY3Rlcl9WaWV3OntcclxuXHRcdFx0ZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTp0cnVlLFxyXG5cdFx0fSxcclxuXHRfSXNfTG9hZGluZzp0cnVlLFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAgb25Mb2FkOiBmdW5jdGlvbigpe1xyXG5cdFx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdFx0VXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlVzZXJfSGF2ZV9DaGFyYWN0ZXI9bnVsbDtcclxuXHRcdFdlQ2hhdC5Mb2FkaW5nX0NoYXJhY3RlcigpO1xyXG5cdFx0dGhpcy5fSXNfTG9hZGluZz09dHJ1ZTsgXHJcblx0IH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgdXBkYXRlOmZ1bmN0aW9uIChkdCkge1xyXG5cdFx0aWYodGhpcy5fSXNfTG9hZGluZyYmVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlVzZXJfSGF2ZV9DaGFyYWN0ZXIhPW51bGwpe1xyXG5cdFx0XHR0aGlzLkxvYWRpbmdfQ2hhcmFjdGVyKCk7XHJcblx0XHRcdHRoaXMuX0lzX0xvYWRpbmc9ZmFsc2U7XHJcblx0XHR9XHJcblx0fSxcclxuXHRMb2FkaW5nX0ltYWdlKHNlbGYsSW1hZ2VfUGF0aCl7XHJcblx0XHRsZXQgX3VybD1JbWFnZV9QYXRoO1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6X3VybCxcclxuXHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdH1cclxuXHRcdFx0c2VsZi5nZXRDaGlsZEJ5TmFtZShcInNwcml0ZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcclxuXHRcdFx0XHJcblx0XHR9KVxyXG59LFxyXG5cdExvYWRpbmdfQ2hhcmFjdGVyKCl7XHJcblx0XHQvL+mBjeWOhlVzZXJfQ2hhcmFjdGVyX0luZm9ybWF0aW9u55qE6KGoXHJcblx0XHRmb3IodmFyIGk9MDtpPFVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5Vc2VyX0hhdmVfQ2hhcmFjdGVyLmxlbmd0aDtpKyspe1x0XHRcclxuXHRcdFx0Ly9Vc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbuaUvueahOaYr+WPquaciTLkuKrorrDlvZXnmoTlsI/ooagoVXNlcl9IYXZlX0NoYXJhY3RlcinnmoTkv6Hmga9cclxuXHRcdFx0dmFyIFVzZXJfQ2hhcmFjdGVyX0luZm9ybWF0aW9uPVVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5Vc2VyX0hhdmVfQ2hhcmFjdGVyW2ldO1xyXG5cdFx0XHQvL1VzZXJfQ2hhcmFjdGVyX051bWJlcuaUvueahOaYr0NoYXJhY3RlcueahOW6j+WPt1xyXG5cdFx0XHR2YXIgVXNlcl9DaGFyYWN0ZXJfTnVtYmVyPVVzZXJfSGF2ZV9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5Vc2VyX0hhdmVfQ2hhcmFjdGVyW2ldLkNoYXJhY3Rlcl9JZDtcclxuXHRcdFx0Ly/liKTmlq3nlKjmiLfmmK/lkKbmnInor6XlsI/puJ9cclxuXHRcdCAgICAvL0dsb2JhbF9WYXJpYWJsZS5vcGVuaWTmmK/lvZPliY3nlKjmiLfnmoRvcGVuaWRcclxuXHRcdCAgICBpZihHbG9iYWxfVmFyaWFibGUub3BlbmlkPT1Vc2VyX0NoYXJhY3Rlcl9JbmZvcm1hdGlvbi5vcGVuaWQpe1xyXG5cdFx0XHRcdC8vIGNvbnNvbGUubG9nKFwi6KeS6Imy6ZW/5bqmXCIsVXNlcl9IYXZlX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlVzZXJfSGF2ZV9DaGFyYWN0ZXIubGVuZ3RoKTtcclxuXHRcdFx0XHRmb3IodmFyIGo9MDtqPFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuU2hvcF9DaGFyYWN0ZXJfVXNlci5sZW5ndGg7aisrKXtcclxuXHRcdFx0XHRcdGlmKFVzZXJfQ2hhcmFjdGVyX051bWJlcj09U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2pdLkNoYXJhY3Rlcl9JZCl7XHJcblx0XHRcdFx0XHRcdHZhciBOZXdfQ2hhcmFjdGVyX0xhYmVsPWNjLmluc3RhbnRpYXRlKHRoaXMuQ2hhcmFjdGVyX0xhYmVsKTtcclxuXHRcdFx0XHRcdFx0dGhpcy5DaGFyYWN0ZXJfVmlldy5hZGRDaGlsZChOZXdfQ2hhcmFjdGVyX0xhYmVsKTtcclxuXHRcdFx0XHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19DaGFyYWN0ZXJfTGFiZWwsU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2pdLkNoYXJhY3Rlcl9IZWFkX0ltYWdlKTtcclxuXHRcdCAgICAgICAgXHRcdE5ld19DaGFyYWN0ZXJfTGFiZWwuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfTmFtZVwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUuU2hvcF9DaGFyYWN0ZXJfVXNlcltqXS5DaGFyYWN0ZXJfTmFtZTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFxyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHRcclxuXHRcdCAgICB9XHJcblx0XHQgICBcclxuXHRcdH1cclxuXHR9XHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Loading_Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2926dRot1ZOEaidacXaL7Yi', 'Loading_Character');
// resources/script/Shop/Loading_Character.js

"use strict";

//下载角色
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Shop_Character_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Shop_Character_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var self = this;
    Shop_Character_Local_Varible.Shop_Character_User = null;
    this._Is_Loading = true;
    WeChat.Loading_Shop_Character(); //Shop_Character_Local_Varible.Shop_Character_User.length
  },
  start: function start() {},
  update: function update(dt) {
    //直到加载出角色
    if (this._Is_Loading && Shop_Character_Local_Varible.Shop_Character_User != null) {
      this.Loading_Character();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("sprite").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Character: function Loading_Character() {
    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var New_Shop_Character_Label = cc.instantiate(this.Shop_Character_Label);
      this.Shop_Character_View.addChild(New_Shop_Character_Label);
      this.Loading_Image(New_Shop_Character_Label, Shop_Character_Local_Varible.Shop_Character_User[i].Character_Head_Image);
      New_Shop_Character_Label.getChildByName("Character_Name").getComponent(cc.Label).string = "" + Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXExvYWRpbmdfQ2hhcmFjdGVyLmpzIl0sIm5hbWVzIjpbIlNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUiLCJyZXF1aXJlIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJTaG9wX0NoYXJhY3Rlcl9MYWJlbCIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIlNob3BfQ2hhcmFjdGVyX1ZpZXciLCJOb2RlIiwiX0lzX0xvYWRpbmciLCJvbkxvYWQiLCJzZWxmIiwiU2hvcF9DaGFyYWN0ZXJfVXNlciIsIldlQ2hhdCIsIkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIiLCJzdGFydCIsInVwZGF0ZSIsImR0IiwiTG9hZGluZ19DaGFyYWN0ZXIiLCJMb2FkaW5nX0ltYWdlIiwiSW1hZ2VfUGF0aCIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwiY29uc29sZSIsImxvZyIsImdldENoaWxkQnlOYW1lIiwiZ2V0Q29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJpIiwibGVuZ3RoIiwiTmV3X1Nob3BfQ2hhcmFjdGVyX0xhYmVsIiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsIkNoYXJhY3Rlcl9IZWFkX0ltYWdlIiwiTGFiZWwiLCJzdHJpbmciLCJDaGFyYWN0ZXJfTmFtZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQU1BLDRCQUE0QixHQUFHQyxPQUFPLENBQUMsZ0RBQUQsQ0FBNUM7O0FBRUFDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBRVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxvQkFBb0IsRUFBRTtBQUNyQixpQkFBUyxJQURZO0FBRXJCQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ00sTUFGWTtBQUdyQkMsTUFBQUEsV0FBVyxFQUFFO0FBSFEsS0FEWDtBQU1YQyxJQUFBQSxtQkFBbUIsRUFBRTtBQUNwQixpQkFBUyxJQURXO0FBRXBCSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ1MsSUFGVztBQUdwQkYsTUFBQUEsV0FBVyxFQUFFO0FBSE8sS0FOVjtBQVdYRyxJQUFBQSxXQUFXLEVBQUU7QUFYRixHQUZKO0FBZ0JSO0FBRUFDLEVBQUFBLE1BQU0sRUFBRSxrQkFBVztBQUNsQixRQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUNBZCxJQUFBQSw0QkFBNEIsQ0FBQ2UsbUJBQTdCLEdBQW1ELElBQW5EO0FBQ0EsU0FBS0gsV0FBTCxHQUFtQixJQUFuQjtBQUNBSSxJQUFBQSxNQUFNLENBQUNDLHNCQUFQLEdBSmtCLENBS2xCO0FBQ0EsR0F4Qk87QUEwQlJDLEVBQUFBLEtBMUJRLG1CQTBCQSxDQUVQLENBNUJPO0FBOEJSQyxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYTtBQUNwQjtBQUNBLFFBQUksS0FBS1IsV0FBTCxJQUFvQlosNEJBQTRCLENBQUNlLG1CQUE3QixJQUFvRCxJQUE1RSxFQUFrRjtBQUNqRixXQUFLTSxpQkFBTDtBQUNBLFdBQUtULFdBQUwsR0FBbUIsS0FBbkI7QUFDQTtBQUNELEdBcENPO0FBcUNSVSxFQUFBQSxhQXJDUSx5QkFxQ01SLElBckNOLEVBcUNZUyxVQXJDWixFQXFDd0I7QUFDL0IsUUFBSUMsSUFBSSxHQUFHRCxVQUFYO0FBQ0FyQixJQUFBQSxFQUFFLENBQUN1QixNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUVILElBRFM7QUFFZGpCLE1BQUFBLElBQUksRUFBRTtBQUZRLEtBQWYsRUFHRyxVQUFTcUIsR0FBVCxFQUFjQyxPQUFkLEVBQXVCQyxJQUF2QixFQUE2QjtBQUMvQixVQUFJQyxLQUFLLEdBQUcsSUFBSTdCLEVBQUUsQ0FBQzhCLFdBQVAsQ0FBbUJILE9BQW5CLENBQVo7O0FBQ0EsVUFBSUQsR0FBSixFQUFTO0FBQ1JLLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVosRUFBb0JOLEdBQXBCO0FBQ0E7O0FBQ0RkLE1BQUFBLElBQUksQ0FBQ3FCLGNBQUwsQ0FBb0IsUUFBcEIsRUFBOEJDLFlBQTlCLENBQTJDbEMsRUFBRSxDQUFDbUMsTUFBOUMsRUFBc0RDLFdBQXRELEdBQW9FUCxLQUFwRTtBQUVBLEtBVkQ7QUFXQSxHQWxETztBQW1EUlYsRUFBQUEsaUJBbkRRLCtCQW1EVztBQUNsQixTQUFLLElBQUlrQixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHdkMsNEJBQTRCLENBQUNlLG1CQUE3QixDQUFpRHlCLE1BQXJFLEVBQTZFRCxDQUFDLEVBQTlFLEVBQWtGO0FBQ2pGLFVBQUlFLHdCQUF3QixHQUFHdkMsRUFBRSxDQUFDd0MsV0FBSCxDQUFlLEtBQUtwQyxvQkFBcEIsQ0FBL0I7QUFDQSxXQUFLSSxtQkFBTCxDQUF5QmlDLFFBQXpCLENBQWtDRix3QkFBbEM7QUFDQSxXQUFLbkIsYUFBTCxDQUFtQm1CLHdCQUFuQixFQUE2Q3pDLDRCQUE0QixDQUFDZSxtQkFBN0IsQ0FBaUR3QixDQUFqRCxFQUFvREssb0JBQWpHO0FBQ0FILE1BQUFBLHdCQUF3QixDQUFDTixjQUF6QixDQUF3QyxnQkFBeEMsRUFBMERDLFlBQTFELENBQXVFbEMsRUFBRSxDQUFDMkMsS0FBMUUsRUFBaUZDLE1BQWpGLEdBQTBGLEtBQ3pGOUMsNEJBQTRCLENBQUNlLG1CQUE3QixDQUFpRHdCLENBQWpELEVBQW9EUSxjQURyRDtBQUVBO0FBQ0Q7QUEzRE8sQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/kuIvovb3op5LoibJcclxuY29uc3QgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZSA9IHJlcXVpcmUoJy4uL0xvY2FsX1ZhcmlpYmxlL1Nob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUnKTtcclxuXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblx0cHJvcGVydGllczoge1xyXG5cdFx0U2hvcF9DaGFyYWN0ZXJfTGFiZWw6IHtcclxuXHRcdFx0ZGVmYXVsdDogbnVsbCxcclxuXHRcdFx0dHlwZTogY2MuUHJlZmFiLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sXHJcblx0XHRTaG9wX0NoYXJhY3Rlcl9WaWV3OiB7XHJcblx0XHRcdGRlZmF1bHQ6IG51bGwsXHJcblx0XHRcdHR5cGU6IGNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSxcclxuXHRcdF9Jc19Mb2FkaW5nOiB0cnVlLFxyXG5cdH0sXHJcblxyXG5cdC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuXHRvbkxvYWQ6IGZ1bmN0aW9uKCkge1xyXG5cdFx0dmFyIHNlbGYgPSB0aGlzO1xyXG5cdFx0U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyID0gbnVsbDtcclxuXHRcdHRoaXMuX0lzX0xvYWRpbmcgPSB0cnVlO1xyXG5cdFx0V2VDaGF0LkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIoKTtcclxuXHRcdC8vU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyLmxlbmd0aFxyXG5cdH0sXHJcblxyXG5cdHN0YXJ0KCkge1xyXG5cclxuXHR9LFxyXG5cclxuXHR1cGRhdGU6IGZ1bmN0aW9uKGR0KSB7XHJcblx0XHQvL+ebtOWIsOWKoOi9veWHuuinkuiJslxyXG5cdFx0aWYgKHRoaXMuX0lzX0xvYWRpbmcgJiYgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyICE9IG51bGwpIHtcclxuXHRcdFx0dGhpcy5Mb2FkaW5nX0NoYXJhY3RlcigpO1xyXG5cdFx0XHR0aGlzLl9Jc19Mb2FkaW5nID0gZmFsc2U7XHJcblx0XHR9XHJcblx0fSxcclxuXHRMb2FkaW5nX0ltYWdlKHNlbGYsIEltYWdlX1BhdGgpIHtcclxuXHRcdGxldCBfdXJsID0gSW1hZ2VfUGF0aDtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0dXJsOiBfdXJsLFxyXG5cdFx0XHR0eXBlOiAnanBnJ1xyXG5cdFx0fSwgZnVuY3Rpb24oZXJyLCB0ZXh0dXJlLCB0ZXN0KSB7XHJcblx0XHRcdHZhciBmcmFtZSA9IG5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0aWYgKGVycikge1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwi5Zu+54mH6ZSZ6K+vXCIsIGVycik7XHJcblx0XHRcdH1cclxuXHRcdFx0c2VsZi5nZXRDaGlsZEJ5TmFtZShcInNwcml0ZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZSA9IGZyYW1lO1xyXG5cclxuXHRcdH0pXHJcblx0fSxcclxuXHRMb2FkaW5nX0NoYXJhY3Rlcigpe1xyXG5cdFx0Zm9yICh2YXIgaSA9IDA7IGkgPCBTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXIubGVuZ3RoOyBpKyspIHtcclxuXHRcdFx0dmFyIE5ld19TaG9wX0NoYXJhY3Rlcl9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuU2hvcF9DaGFyYWN0ZXJfTGFiZWwpO1xyXG5cdFx0XHR0aGlzLlNob3BfQ2hhcmFjdGVyX1ZpZXcuYWRkQ2hpbGQoTmV3X1Nob3BfQ2hhcmFjdGVyX0xhYmVsKTtcclxuXHRcdFx0dGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19TaG9wX0NoYXJhY3Rlcl9MYWJlbCwgU2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2ldLkNoYXJhY3Rlcl9IZWFkX0ltYWdlKTtcclxuXHRcdFx0TmV3X1Nob3BfQ2hhcmFjdGVyX0xhYmVsLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICtcclxuXHRcdFx0XHRTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXJbaV0uQ2hhcmFjdGVyX05hbWU7XHJcblx0XHR9XHJcblx0fVxyXG5cclxufSk7XG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Appeal_User.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '566674OTJxDC6nbV9VVDq+a', 'Appeal_User');
// resources/script/Account_Management/Appeal_User.js

"use strict";

//弹出申诉框
cc.Class({
  "extends": cc.Component,
  properties: {
    Appeal_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //申诉框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    } //玩家框节点

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建申诉信息框
    var New_Appeal_Label = cc.instantiate(this.Appeal_Label);
    this.Canvas.addChild(New_Appeal_Label);
    New_Appeal_Label.setPosition(0, 0);
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQXBwZWFsX1VzZXIuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJBcHBlYWxfTGFiZWwiLCJ0eXBlIiwiUHJlZmFiIiwic2VyaWFsemFibGUiLCJDYW52YXMiLCJOb2RlIiwic3RhcnQiLCJvbl9idG5fY2xpY2siLCJOZXdfQXBwZWFsX0xhYmVsIiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsInNldFBvc2l0aW9uIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxZQUFZLEVBQUU7QUFDYixpQkFBUyxJQURJO0FBRWJDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTSxNQUZJO0FBR2JDLE1BQUFBLFdBQVcsRUFBRTtBQUhBLEtBREg7QUFLUjtBQUNIQyxJQUFBQSxNQUFNLEVBQUU7QUFDUCxpQkFBUyxJQURGO0FBRVBILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDUyxJQUZGO0FBR1BGLE1BQUFBLFdBQVcsRUFBRTtBQUhOLEtBTkcsQ0FVUjs7QUFWUSxHQUhKO0FBZ0JSRyxFQUFBQSxLQWhCUSxtQkFnQkEsQ0FFUCxDQWxCTztBQW1CUkMsRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3hCO0FBQ0EsUUFBSUMsZ0JBQWdCLEdBQUdaLEVBQUUsQ0FBQ2EsV0FBSCxDQUFlLEtBQUtULFlBQXBCLENBQXZCO0FBQ0EsU0FBS0ksTUFBTCxDQUFZTSxRQUFaLENBQXFCRixnQkFBckI7QUFDQUEsSUFBQUEsZ0JBQWdCLENBQUNHLFdBQWpCLENBQTZCLENBQTdCLEVBQWdDLENBQWhDO0FBQ0EsR0F4Qk8sQ0F5QlI7O0FBekJRLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8v5by55Ye655Sz6K+J5qGGXHJcbmNjLkNsYXNzKHtcclxuXHRleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG5cdHByb3BlcnRpZXM6IHtcclxuXHRcdEFwcGVhbF9MYWJlbDoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOiB0cnVlLFxyXG5cdFx0fSwgLy/nlLPor4nmoYZcclxuXHRcdENhbnZhczoge1xyXG5cdFx0XHRkZWZhdWx0OiBudWxsLFxyXG5cdFx0XHR0eXBlOiBjYy5Ob2RlLFxyXG5cdFx0XHRzZXJpYWx6YWJsZTogdHJ1ZSxcclxuXHRcdH0sIC8v546p5a625qGG6IqC54K5XHJcblx0fSxcclxuXHJcblx0c3RhcnQoKSB7XHJcblxyXG5cdH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdC8v5Yib5bu655Sz6K+J5L+h5oGv5qGGXHJcblx0XHR2YXIgTmV3X0FwcGVhbF9MYWJlbCA9IGNjLmluc3RhbnRpYXRlKHRoaXMuQXBwZWFsX0xhYmVsKTtcclxuXHRcdHRoaXMuQ2FudmFzLmFkZENoaWxkKE5ld19BcHBlYWxfTGFiZWwpO1xyXG5cdFx0TmV3X0FwcGVhbF9MYWJlbC5zZXRQb3NpdGlvbigwLCAwKTtcclxuXHR9XHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Account_Management/Appeal_Cancel.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '5108eBGdSVFdZFrNGvedr3Z', 'Appeal_Cancel');
// resources/script/Account_Management/Appeal_Cancel.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXEFjY291bnRfTWFuYWdlbWVudFxcQXBwZWFsX0NhbmNlbC5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsInN0YXJ0Iiwib25fYnRuX2NsaWNrIiwibm9kZSIsImRlc3Ryb3kiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBTUw7QUFFQTtBQUVBQyxFQUFBQSxLQVZLLG1CQVVJLENBRVIsQ0FaSTtBQWFSQyxFQUFBQSxZQUFZLEVBQUUsd0JBQVc7QUFDeEIsU0FBS0MsSUFBTCxDQUFVQyxPQUFWO0FBQ0EsR0FmTyxDQWdCTDs7QUFoQkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHRcclxuICAgIH0sXHJcblx0b25fYnRuX2NsaWNrOiBmdW5jdGlvbigpIHtcclxuXHRcdHRoaXMubm9kZS5kZXN0cm95KCk7XHJcblx0fVxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Character_Information.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2288aR73xZMqrncTej+w8ez', 'Character_Information');
// resources/script/Shop/Character_Information.js

"use strict";

//显示角色信息
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Buy_Character_Background: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    var self = this;
    var This_Name = this.Character_Name.getComponent(cc.Label).string;
    WeChat.Loading_Shop_Character();

    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var List_Name = Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;

      if (This_Name === List_Name) {
        //当前点击的角色
        var This_information = Shop_Character_Local_Varible.Shop_Character_User[i];
        var New_Buy_Character_Background = cc.instantiate(this.Buy_Character_Background);
        this.Canvas.parent.parent.parent.addChild(New_Buy_Character_Background);
        New_Buy_Character_Background.setPosition(0, -300);
        console.log("图片地址为", This_information);
        this.Loading_Image(New_Buy_Character_Background, This_information.Character_Head_Image);
        New_Buy_Character_Background.getChildByName("Character_Name").getComponent(cc.Label).string = "" + This_information.Character_Name;
        New_Buy_Character_Background.getChildByName("Character_Synopsis").getComponent(cc.Label).string = "" + This_information.Character_Synopsis;
        New_Buy_Character_Background.getChildByName("Bounce_Power_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Jump_Speed;
        New_Buy_Character_Background.getChildByName("Weight_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fall_Speed;
        New_Buy_Character_Background.getChildByName("Speed_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fly_Speed;
        New_Buy_Character_Background.getChildByName("Skill_Name_Label").getComponent(cc.Label).string = "" + This_information.Skill_Name;
        New_Buy_Character_Background.getChildByName("Skill_Effect_Label").getComponent(cc.Label).string = "" + This_information.Skill_Synopsis;
        New_Buy_Character_Background.getChildByName("Price_Label").getComponent(cc.Label).string = "" + This_information.Character_Price;
        New_Buy_Character_Background.getChildByName("Character_Id").getComponent(cc.Label).string = "" + This_information.Character_Id;
        New_Buy_Character_Background.getChildByName("Background1").getComponent(cc.Sprite).fillRange = This_information.Character_Jump_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background2").getComponent(cc.Sprite).fillRange = This_information.Character_Fall_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background3").getComponent(cc.Sprite).fillRange = This_information.Character_Fly_Speed / 100;
        break;
      }
    }
  },
  update: function update(dt) {},
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Character_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXENoYXJhY3Rlcl9JbmZvcm1hdGlvbi5qcyJdLCJuYW1lcyI6WyJTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwiQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kIiwidHlwZSIsIlByZWZhYiIsInNlcmlhbHphYmxlIiwiQ2hhcmFjdGVyX05hbWUiLCJMYWJlbCIsIkNhbnZhcyIsIk5vZGUiLCJvbl9idG5fY2xpY2siLCJzZWxmIiwiVGhpc19OYW1lIiwiZ2V0Q29tcG9uZW50Iiwic3RyaW5nIiwiV2VDaGF0IiwiTG9hZGluZ19TaG9wX0NoYXJhY3RlciIsImkiLCJTaG9wX0NoYXJhY3Rlcl9Vc2VyIiwibGVuZ3RoIiwiTGlzdF9OYW1lIiwiVGhpc19pbmZvcm1hdGlvbiIsIk5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQiLCJpbnN0YW50aWF0ZSIsInBhcmVudCIsImFkZENoaWxkIiwic2V0UG9zaXRpb24iLCJjb25zb2xlIiwibG9nIiwiTG9hZGluZ19JbWFnZSIsIkNoYXJhY3Rlcl9IZWFkX0ltYWdlIiwiZ2V0Q2hpbGRCeU5hbWUiLCJDaGFyYWN0ZXJfU3lub3BzaXMiLCJDaGFyYWN0ZXJfSnVtcF9TcGVlZCIsIkNoYXJhY3Rlcl9GYWxsX1NwZWVkIiwiQ2hhcmFjdGVyX0ZseV9TcGVlZCIsIlNraWxsX05hbWUiLCJTa2lsbF9TeW5vcHNpcyIsIkNoYXJhY3Rlcl9QcmljZSIsIkNoYXJhY3Rlcl9JZCIsIlNwcml0ZSIsImZpbGxSYW5nZSIsInVwZGF0ZSIsImR0IiwiSW1hZ2VfUGF0aCIsIl91cmwiLCJsb2FkZXIiLCJsb2FkIiwidXJsIiwiZXJyIiwidGV4dHVyZSIsInRlc3QiLCJmcmFtZSIsIlNwcml0ZUZyYW1lIiwic3ByaXRlRnJhbWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSw0QkFBNEIsR0FBR0MsT0FBTyxDQUFDLGdEQUFELENBQTFDOztBQUNBQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsd0JBQXdCLEVBQUM7QUFDckIsaUJBQVEsSUFEYTtBQUU5QkMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRnNCO0FBRzlCQyxNQUFBQSxXQUFXLEVBQUM7QUFIa0IsS0FEakI7QUFNUkMsSUFBQUEsY0FBYyxFQUFDO0FBQ1gsaUJBQVEsSUFERztBQUVwQkgsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNTLEtBRlk7QUFHcEJGLE1BQUFBLFdBQVcsRUFBQztBQUhRLEtBTlA7QUFXUkcsSUFBQUEsTUFBTSxFQUFDO0FBQ0gsaUJBQVEsSUFETDtBQUVITCxNQUFBQSxJQUFJLEVBQUNMLEVBQUUsQ0FBQ1csSUFGTDtBQUdaSixNQUFBQSxXQUFXLEVBQUM7QUFIQTtBQVhDLEdBSFA7QUFxQkw7QUFFQUssRUFBQUEsWUFBWSxFQUFFLHdCQUFXO0FBQ3JCLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsU0FBUyxHQUFDLEtBQUtOLGNBQUwsQ0FBb0JPLFlBQXBCLENBQWlDZixFQUFFLENBQUNTLEtBQXBDLEVBQTJDTyxNQUF6RDtBQUNBQyxJQUFBQSxNQUFNLENBQUNDLHNCQUFQOztBQUdBLFNBQUksSUFBSUMsQ0FBQyxHQUFDLENBQVYsRUFBWUEsQ0FBQyxHQUFDckIsNEJBQTRCLENBQUNzQixtQkFBN0IsQ0FBaURDLE1BQS9ELEVBQXNFRixDQUFDLEVBQXZFLEVBQTBFO0FBQ3RFLFVBQUlHLFNBQVMsR0FBQ3hCLDRCQUE0QixDQUFDc0IsbUJBQTdCLENBQWlERCxDQUFqRCxFQUFvRFgsY0FBbEU7O0FBRUEsVUFBR00sU0FBUyxLQUFHUSxTQUFmLEVBQXlCO0FBQ3JCO0FBQ0EsWUFBSUMsZ0JBQWdCLEdBQUN6Qiw0QkFBNEIsQ0FBQ3NCLG1CQUE3QixDQUFpREQsQ0FBakQsQ0FBckI7QUFFQSxZQUFJSyw0QkFBNEIsR0FBR3hCLEVBQUUsQ0FBQ3lCLFdBQUgsQ0FBZSxLQUFLckIsd0JBQXBCLENBQW5DO0FBQ0EsYUFBS00sTUFBTCxDQUFZZ0IsTUFBWixDQUFtQkEsTUFBbkIsQ0FBMEJBLE1BQTFCLENBQWlDQyxRQUFqQyxDQUEwQ0gsNEJBQTFDO0FBQ0FBLFFBQUFBLDRCQUE0QixDQUFDSSxXQUE3QixDQUF5QyxDQUF6QyxFQUEyQyxDQUFDLEdBQTVDO0FBQ0FDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVosRUFBb0JQLGdCQUFwQjtBQUVBLGFBQUtRLGFBQUwsQ0FBbUJQLDRCQUFuQixFQUFnREQsZ0JBQWdCLENBQUNTLG9CQUFqRTtBQUNBUixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsZ0JBQTVDLEVBQThEbEIsWUFBOUQsQ0FBMkVmLEVBQUUsQ0FBQ1MsS0FBOUUsRUFBcUZPLE1BQXJGLEdBQTRGLEtBQUdPLGdCQUFnQixDQUFDZixjQUFoSDtBQUNBZ0IsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ1csa0JBQXBIO0FBQ0FWLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QywyQkFBNUMsRUFBeUVsQixZQUF6RSxDQUFzRmYsRUFBRSxDQUFDUyxLQUF6RixFQUFnR08sTUFBaEcsR0FBdUcsS0FBR08sZ0JBQWdCLENBQUNZLG9CQUEzSDtBQUNBWCxRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMscUJBQTVDLEVBQW1FbEIsWUFBbkUsQ0FBZ0ZmLEVBQUUsQ0FBQ1MsS0FBbkYsRUFBMEZPLE1BQTFGLEdBQWlHLEtBQUdPLGdCQUFnQixDQUFDYSxvQkFBckg7QUFDQVosUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLG9CQUE1QyxFQUFrRWxCLFlBQWxFLENBQStFZixFQUFFLENBQUNTLEtBQWxGLEVBQXlGTyxNQUF6RixHQUFnRyxLQUFHTyxnQkFBZ0IsQ0FBQ2MsbUJBQXBIO0FBQ0FiLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxrQkFBNUMsRUFBZ0VsQixZQUFoRSxDQUE2RWYsRUFBRSxDQUFDUyxLQUFoRixFQUF1Rk8sTUFBdkYsR0FBOEYsS0FBR08sZ0JBQWdCLENBQUNlLFVBQWxIO0FBQ0FkLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxvQkFBNUMsRUFBa0VsQixZQUFsRSxDQUErRWYsRUFBRSxDQUFDUyxLQUFsRixFQUF5Rk8sTUFBekYsR0FBZ0csS0FBR08sZ0JBQWdCLENBQUNnQixjQUFwSDtBQUNBZixRQUFBQSw0QkFBNEIsQ0FBQ1MsY0FBN0IsQ0FBNEMsYUFBNUMsRUFBMkRsQixZQUEzRCxDQUF3RWYsRUFBRSxDQUFDUyxLQUEzRSxFQUFrRk8sTUFBbEYsR0FBeUYsS0FBR08sZ0JBQWdCLENBQUNpQixlQUE3RztBQUNBaEIsUUFBQUEsNEJBQTRCLENBQUNTLGNBQTdCLENBQTRDLGNBQTVDLEVBQTREbEIsWUFBNUQsQ0FBeUVmLEVBQUUsQ0FBQ1MsS0FBNUUsRUFBbUZPLE1BQW5GLEdBQTBGLEtBQUdPLGdCQUFnQixDQUFDa0IsWUFBOUc7QUFDQWpCLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxhQUE1QyxFQUEyRGxCLFlBQTNELENBQXdFZixFQUFFLENBQUMwQyxNQUEzRSxFQUFtRkMsU0FBbkYsR0FBNkZwQixnQkFBZ0IsQ0FBQ1ksb0JBQWpCLEdBQXNDLEdBQW5JO0FBQ0FYLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxhQUE1QyxFQUEyRGxCLFlBQTNELENBQXdFZixFQUFFLENBQUMwQyxNQUEzRSxFQUFtRkMsU0FBbkYsR0FBNkZwQixnQkFBZ0IsQ0FBQ2Esb0JBQWpCLEdBQXNDLEdBQW5JO0FBQ0FaLFFBQUFBLDRCQUE0QixDQUFDUyxjQUE3QixDQUE0QyxhQUE1QyxFQUEyRGxCLFlBQTNELENBQXdFZixFQUFFLENBQUMwQyxNQUEzRSxFQUFtRkMsU0FBbkYsR0FBNkZwQixnQkFBZ0IsQ0FBQ2MsbUJBQWpCLEdBQXFDLEdBQWxJO0FBQ0E7QUFDSDtBQUNKO0FBQ0osR0F6REk7QUEwRExPLEVBQUFBLE1BMURLLGtCQTBER0MsRUExREgsRUEwRE8sQ0FBRSxDQTFEVDtBQTJETmQsRUFBQUEsYUEzRE0seUJBMkRRbEIsSUEzRFIsRUEyRGFpQyxVQTNEYixFQTJEd0I7QUFDL0IsUUFBSUMsSUFBSSxHQUFDRCxVQUFUO0FBQ0E5QyxJQUFBQSxFQUFFLENBQUNnRCxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZDFDLE1BQUFBLElBQUksRUFBQztBQUZTLEtBQWYsRUFHRSxVQUFTOEMsR0FBVCxFQUFhQyxPQUFiLEVBQXFCQyxJQUFyQixFQUEwQjtBQUMzQixVQUFJQyxLQUFLLEdBQUMsSUFBSXRELEVBQUUsQ0FBQ3VELFdBQVAsQ0FBbUJILE9BQW5CLENBQVY7O0FBQ0EsVUFBR0QsR0FBSCxFQUFPO0FBQ050QixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CcUIsR0FBbkI7QUFDQTs7QUFDRHRDLE1BQUFBLElBQUksQ0FBQ29CLGNBQUwsQ0FBb0IsaUJBQXBCLEVBQXVDbEIsWUFBdkMsQ0FBb0RmLEVBQUUsQ0FBQzBDLE1BQXZELEVBQStEYyxXQUEvRCxHQUEyRUYsS0FBM0U7QUFFQSxLQVZEO0FBV0Q7QUF4RVEsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy/mmL7npLrop5LoibLkv6Hmga9cclxudmFyIFNob3BfQ2hhcmFjdGVyX0xvY2FsX1ZhcmlibGUgPSByZXF1aXJlKCcuLi9Mb2NhbF9WYXJpaWJsZS9TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlJyk7XHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLCBcclxuXHRcdFx0dHlwZTpjYy5QcmVmYWIsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDaGFyYWN0ZXJfTmFtZTp7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6bnVsbCwgXHJcblx0XHRcdHR5cGU6Y2MuTGFiZWwsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBDYW52YXM6e1xyXG4gICAgICAgICAgICBkZWZhdWx0Om51bGwsIFxyXG4gICAgICAgICAgICB0eXBlOmNjLk5vZGUsXHJcblx0XHRcdHNlcmlhbHphYmxlOnRydWUsXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbl9idG5fY2xpY2s6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgVGhpc19OYW1lPXRoaXMuQ2hhcmFjdGVyX05hbWUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc7XHJcbiAgICAgICAgV2VDaGF0LkxvYWRpbmdfU2hvcF9DaGFyYWN0ZXIoKTtcclxuICAgICAgICBcclxuXHJcbiAgICAgICAgZm9yKHZhciBpPTA7aTxTaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXIubGVuZ3RoO2krKyl7XHJcbiAgICAgICAgICAgIHZhciBMaXN0X05hbWU9U2hvcF9DaGFyYWN0ZXJfTG9jYWxfVmFyaWJsZS5TaG9wX0NoYXJhY3Rlcl9Vc2VyW2ldLkNoYXJhY3Rlcl9OYW1lO1xyXG5cclxuICAgICAgICAgICAgaWYoVGhpc19OYW1lPT09TGlzdF9OYW1lKXtcclxuICAgICAgICAgICAgICAgIC8v5b2T5YmN54K55Ye755qE6KeS6ImyXHJcbiAgICAgICAgICAgICAgICB2YXIgVGhpc19pbmZvcm1hdGlvbj1TaG9wX0NoYXJhY3Rlcl9Mb2NhbF9WYXJpYmxlLlNob3BfQ2hhcmFjdGVyX1VzZXJbaV07XHJcblxyXG4gICAgICAgICAgICAgICAgdmFyIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLkJ1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkNhbnZhcy5wYXJlbnQucGFyZW50LnBhcmVudC5hZGRDaGlsZChOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kKTtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuc2V0UG9zaXRpb24oMCwtMzAwKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5Zu+54mH5Zyw5Z2A5Li6XCIsVGhpc19pbmZvcm1hdGlvbik7XHJcblxyXG4gICAgICAgICAgICAgICAgdGhpcy5Mb2FkaW5nX0ltYWdlKE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQsVGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSGVhZF9JbWFnZSk7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQ2hhcmFjdGVyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9TeW5vcHNpc1wiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX1N5bm9wc2lzO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJvdW5jZV9Qb3dlcl9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9KdW1wX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIldlaWdodF9OdW1iZXJfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GYWxsX1NwZWVkO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNwZWVkX051bWJlcl9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0ZseV9TcGVlZDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJTa2lsbF9OYW1lX0xhYmVsXCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nPVwiXCIrVGhpc19pbmZvcm1hdGlvbi5Ta2lsbF9OYW1lO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIlNraWxsX0VmZmVjdF9MYWJlbFwiKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZz1cIlwiK1RoaXNfaW5mb3JtYXRpb24uU2tpbGxfU3lub3BzaXM7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiUHJpY2VfTGFiZWxcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9QcmljZTtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJDaGFyYWN0ZXJfSWRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmc9XCJcIitUaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9JZDtcclxuICAgICAgICAgICAgICAgIE5ld19CdXlfQ2hhcmFjdGVyX0JhY2tncm91bmQuZ2V0Q2hpbGRCeU5hbWUoXCJCYWNrZ3JvdW5kMVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5maWxsUmFuZ2U9VGhpc19pbmZvcm1hdGlvbi5DaGFyYWN0ZXJfSnVtcF9TcGVlZC8xMDA7XHJcbiAgICAgICAgICAgICAgICBOZXdfQnV5X0NoYXJhY3Rlcl9CYWNrZ3JvdW5kLmdldENoaWxkQnlOYW1lKFwiQmFja2dyb3VuZDJcIikuZ2V0Q29tcG9uZW50KGNjLlNwcml0ZSkuZmlsbFJhbmdlPVRoaXNfaW5mb3JtYXRpb24uQ2hhcmFjdGVyX0ZhbGxfU3BlZWQvMTAwO1xyXG4gICAgICAgICAgICAgICAgTmV3X0J1eV9DaGFyYWN0ZXJfQmFja2dyb3VuZC5nZXRDaGlsZEJ5TmFtZShcIkJhY2tncm91bmQzXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLmZpbGxSYW5nZT1UaGlzX2luZm9ybWF0aW9uLkNoYXJhY3Rlcl9GbHlfU3BlZWQvMTAwO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdXBkYXRlIChkdCkge30sXHJcbiAgXHRMb2FkaW5nX0ltYWdlKHNlbGYsSW1hZ2VfUGF0aCl7XHJcblx0XHRsZXQgX3VybD1JbWFnZV9QYXRoO1xyXG5cdFx0Y2MubG9hZGVyLmxvYWQoe1xyXG5cdFx0XHR1cmw6X3VybCxcclxuXHRcdFx0dHlwZTonanBnJ1xyXG5cdFx0fSxmdW5jdGlvbihlcnIsdGV4dHVyZSx0ZXN0KXtcclxuXHRcdFx0dmFyIGZyYW1lPW5ldyBjYy5TcHJpdGVGcmFtZSh0ZXh0dXJlKTtcclxuXHRcdFx0aWYoZXJyKXtcclxuXHRcdFx0XHRjb25zb2xlLmxvZyhcIuWbvueJh+mUmeivr1wiLGVycik7XHJcblx0XHRcdH1cclxuXHRcdFx0c2VsZi5nZXRDaGlsZEJ5TmFtZShcIkNoYXJhY3Rlcl9JbWFnZVwiKS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcclxuXHRcdFx0XHJcblx0XHR9KVxyXG59XHJcblxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/resources/script/Shop/Character.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'e5a1fZvLqBJ2a3/lkwWzySk', 'Character');
// resources/script/Shop/Character.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    buy: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Canvas_Sprite: {
      "default": null,
      type: cc.Canvas,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  onClickAlert: function onClickAlert() {
    var anode = cc.instantiate(this.buy);
    this.Canvas_Sprite.node.addChild(anode);
    anode.setPosition(540, 0); //  node = node.getComponent('BuyCharacter');
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xccmVzb3VyY2VzXFxzY3JpcHRcXFNob3BcXENoYXJhY3Rlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImJ1eSIsInR5cGUiLCJQcmVmYWIiLCJzZXJpYWx6YWJsZSIsIkNhbnZhc19TcHJpdGUiLCJDYW52YXMiLCJzdGFydCIsIm9uQ2xpY2tBbGVydCIsImFub2RlIiwiaW5zdGFudGlhdGUiLCJub2RlIiwiYWRkQ2hpbGQiLCJzZXRQb3NpdGlvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1JDLElBQUFBLEdBQUcsRUFBQztBQUNBLGlCQUFRLElBRFI7QUFFQUMsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNLE1BRlI7QUFHQUMsTUFBQUEsV0FBVyxFQUFDO0FBSFosS0FESTtBQU1SQyxJQUFBQSxhQUFhLEVBQUM7QUFDVixpQkFBUSxJQURFO0FBRVZILE1BQUFBLElBQUksRUFBQ0wsRUFBRSxDQUFDUyxNQUZFO0FBR1ZGLE1BQUFBLFdBQVcsRUFBQztBQUhGO0FBTk4sR0FIUDtBQWdCTDtBQUVBO0FBRUFHLEVBQUFBLEtBcEJLLG1CQW9CSSxDQUVSLENBdEJJO0FBdUJKQyxFQUFBQSxZQUFZLEVBQUMsd0JBQVU7QUFDbkIsUUFBSUMsS0FBSyxHQUFHWixFQUFFLENBQUNhLFdBQUgsQ0FBZSxLQUFLVCxHQUFwQixDQUFaO0FBQ0EsU0FBS0ksYUFBTCxDQUFtQk0sSUFBbkIsQ0FBd0JDLFFBQXhCLENBQWlDSCxLQUFqQztBQUNBQSxJQUFBQSxLQUFLLENBQUNJLFdBQU4sQ0FBa0IsR0FBbEIsRUFBc0IsQ0FBdEIsRUFIbUIsQ0FJcEI7QUFDRixHQTVCRyxDQTZCTDs7QUE3QkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7ICAgXHJcbiAgICAgICAgYnV5OntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLlByZWZhYixcclxuICAgICAgICAgICAgc2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICAgfSxcclxuICAgICAgICBDYW52YXNfU3ByaXRlOntcclxuICAgICAgICAgICAgZGVmYXVsdDpudWxsLFxyXG4gICAgICAgICAgICB0eXBlOmNjLkNhbnZhcyxcclxuICAgICAgICAgICAgc2VyaWFsemFibGU6dHJ1ZSxcclxuICAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgLy8gb25Mb2FkICgpIHt9LCBcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgIG9uQ2xpY2tBbGVydDpmdW5jdGlvbigpe1xyXG4gICAgICAgICB2YXIgYW5vZGUgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmJ1eSk7ICBcclxuICAgICAgICAgdGhpcy5DYW52YXNfU3ByaXRlLm5vZGUuYWRkQ2hpbGQoYW5vZGUpO1xyXG4gICAgICAgICBhbm9kZS5zZXRQb3NpdGlvbig1NDAsMCk7XHJcbiAgICAgICAgLy8gIG5vZGUgPSBub2RlLmdldENvbXBvbmVudCgnQnV5Q2hhcmFjdGVyJyk7XHJcbiAgICAgfVxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------
