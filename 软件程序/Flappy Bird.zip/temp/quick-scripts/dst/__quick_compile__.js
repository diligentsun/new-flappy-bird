
(function () {
var scripts = [{"deps":{"./assets/Script/Jump_Scene1":1,"./assets/cloud/cloud":2,"./assets/Script/Buy_Character":3,"./assets/Script/FriendsListData":4,"./assets/Script/FriendsView":5,"./assets/Script/Cloud_Image1":6,"./assets/Script/People":7,"./assets/resources/script/Account_Management/Handle_Reported_User":8,"./assets/resources/script/Closure/Tip":10,"./assets/resources/script/Friends/Show_Friends":13,"./assets/resources/script/Game_Login/WX_Login":14,"./assets/resources/script/Game_Start/Change_Map":15,"./assets/resources/script/Game_Over/Grade_Show":16,"./assets/resources/script/Local_Variible/Game_Local_Varible":17,"./assets/resources/script/Rank/Loading_Rank":18,"./assets/resources/script/Account_Management/Loading_All_Users":21,"./assets/resources/script/Account_Management/Closure_Account":22,"./assets/resources/script/Account_Management/Loading_All_Reported_User":23,"./assets/resources/script/Closure/Tip_Close":24,"./assets/resources/script/Account_Management/Appeal_Confirm":25,"./assets/resources/script/Account_Management/Cancel_Closure":26,"./assets/resources/script/Closure/Closure_Tips":27,"./assets/resources/script/Account_Management/Loading_Reported_Users ":28,"./assets/resources/script/Email/Email_Waring":30,"./assets/resources/script/Game_Coming/Gold_Action":31,"./assets/resources/script/Game_Coming/Waterpipe_Action":36,"./assets/resources/script/Game_Start/Loading_Game":37,"./assets/resources/script/Game_Coming/Gold_Show_Action":38,"./assets/resources/script/Game_Login/NewScript":39,"./assets/resources/script/Game_Coming/Bird_Action":40,"./assets/resources/script/Game_Start/Loading_Bird_Image":41,"./assets/resources/script/Game_Start/Change_Difficult":42,"./assets/resources/script/Global_Function/Loading_Base_Resouce":43,"./assets/resources/script/Global_Function/Change_Bird_Image":44,"./assets/resources/script/Global_Function/Close_Box":45,"./assets/resources/script/Global_Function/Jump_Scene":46,"./assets/resources/script/Local_Variible/User_Have_Character_Local_Varible":47,"./assets/resources/script/Global_Function/Cloud_Image":48,"./assets/resources/script/Local_Variible/Jump_DIfficulty":49,"./assets/resources/script/Global_Function/Global_Variable":50,"./assets/resources/script/Local_Variible/Shop_Character_Local_Varible":51,"./assets/resources/script/Local_Variible/Game_Difficulty_Local_Varible":52,"./assets/resources/script/Local_Variible/Rank_Local_Variable":53,"./assets/resources/script/Local_Variible/Report_Local_Variable":54,"./assets/resources/script/Local_Variible/Email_Local_Variable":55,"./assets/resources/script/Local_Variible/Account_Management_Local_Variable":57,"./assets/resources/script/Rank/My_Rank":58,"./assets/resources/script/Rank/Report_Cancel":60,"./assets/resources/script/Rank/Report_Confirm":61,"./assets/resources/script/Account_Management/Appeal_User":64,"./assets/resources/script/Account_Management/Appeal_Cancel":65,"./assets/resources/script/Shop/Character":67,"./assets/resources/script/Rank/Report_User":56,"./assets/resources/script/Global_Function/Global_WeChat":9,"./assets/resources/script/Game_Coming/Game":12,"./assets/resources/script/Email/Awards":11,"./assets/resources/script/Role/Have_Character_Information":19,"./assets/resources/script/Shop/Buy_Character_Sure":20,"./assets/resources/script/Email/Email_Information":32,"./assets/resources/script/Email/Delete_Read":29,"./assets/resources/script/Email/Accept":33,"./assets/resources/script/Email/Read_All":34,"./assets/resources/script/Role/Change_Character":59,"./assets/resources/script/Email/Loading_Email":35,"./assets/resources/script/Role/Loading_Role":62,"./assets/resources/script/Shop/Character_Information":66,"./assets/resources/script/Shop/Loading_Character":63},"path":"preview-scripts/__qc_index__.js"},{"deps":{},"path":"preview-scripts/assets/Script/Jump_Scene1.js"},{"deps":{},"path":"preview-scripts/assets/cloud/cloud.js"},{"deps":{},"path":"preview-scripts/assets/Script/Buy_Character.js"},{"deps":{},"path":"preview-scripts/assets/Script/FriendsListData.js"},{"deps":{},"path":"preview-scripts/assets/Script/FriendsView.js"},{"deps":{},"path":"preview-scripts/assets/Script/Cloud_Image1.js"},{"deps":{},"path":"preview-scripts/assets/Script/People.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Account_Management/Handle_Reported_User.js"},{"deps":{"User_Have_Character_Local_Varible":47,"Rank_Local_Variable":53,"Shop_Character_Local_Varible":51,"Email_Local_Variable":55,"Account_Management_Local_Variable":57},"path":"preview-scripts/assets/resources/script/Global_Function/Global_WeChat.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Closure/Tip.js"},{"deps":{"../Local_Variible/Email_Local_Variable":55},"path":"preview-scripts/assets/resources/script/Email/Awards.js"},{"deps":{"Game_Local_Varible":17,"Game_Difficulty_Local_Varible":52},"path":"preview-scripts/assets/resources/script/Game_Coming/Game.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Friends/Show_Friends.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Game_Login/WX_Login.js"},{"deps":{"Game_Local_Varible":17},"path":"preview-scripts/assets/resources/script/Game_Start/Change_Map.js"},{"deps":{"Game_Local_Varible":17,"Game_Difficulty_Local_Varible":52},"path":"preview-scripts/assets/resources/script/Game_Over/Grade_Show.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Game_Local_Varible.js"},{"deps":{"Rank_Local_Variable":53},"path":"preview-scripts/assets/resources/script/Rank/Loading_Rank.js"},{"deps":{"../Local_Variible/Shop_Character_Local_Varible":51},"path":"preview-scripts/assets/resources/script/Role/Have_Character_Information.js"},{"deps":{"../Local_Variible/Shop_Character_Local_Varible":51,"../Local_Variible/User_Have_Character_Local_Varible":47},"path":"preview-scripts/assets/resources/script/Shop/Buy_Character_Sure.js"},{"deps":{"Account_Management_Local_Variable":57},"path":"preview-scripts/assets/resources/script/Account_Management/Loading_All_Users.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Account_Management/Closure_Account.js"},{"deps":{"Account_Management_Local_Variable":57},"path":"preview-scripts/assets/resources/script/Account_Management/Loading_All_Reported_User.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Closure/Tip_Close.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Account_Management/Appeal_Confirm.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Account_Management/Cancel_Closure.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Closure/Closure_Tips.js"},{"deps":{"Account_Management_Local_Variable":57},"path":"preview-scripts/assets/resources/script/Account_Management/Loading_Reported_Users .js"},{"deps":{"../Local_Variible/Email_Local_Variable":55},"path":"preview-scripts/assets/resources/script/Email/Delete_Read.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Email/Email_Waring.js"},{"deps":{"Game_Local_Varible":17,"Game_Difficulty_Local_Varible":52},"path":"preview-scripts/assets/resources/script/Game_Coming/Gold_Action.js"},{"deps":{"../Local_Variible/Email_Local_Variable":55},"path":"preview-scripts/assets/resources/script/Email/Email_Information.js"},{"deps":{"../Local_Variible/Email_Local_Variable":55},"path":"preview-scripts/assets/resources/script/Email/Accept.js"},{"deps":{"../Local_Variible/Email_Local_Variable":55},"path":"preview-scripts/assets/resources/script/Email/Read_All.js"},{"deps":{"../Local_Variible/Email_Local_Variable":55},"path":"preview-scripts/assets/resources/script/Email/Loading_Email.js"},{"deps":{"Game_Difficulty_Local_Varible":52,"Game_Local_Varible":17},"path":"preview-scripts/assets/resources/script/Game_Coming/Waterpipe_Action.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Game_Start/Loading_Game.js"},{"deps":{"Game_Local_Varible":17},"path":"preview-scripts/assets/resources/script/Game_Coming/Gold_Show_Action.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Game_Login/NewScript.js"},{"deps":{"Game_Difficulty_Local_Varible":52},"path":"preview-scripts/assets/resources/script/Game_Coming/Bird_Action.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Game_Start/Loading_Bird_Image.js"},{"deps":{"Game_Difficulty_Local_Varible":52},"path":"preview-scripts/assets/resources/script/Game_Start/Change_Difficult.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Global_Function/Loading_Base_Resouce.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Global_Function/Change_Bird_Image.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Global_Function/Close_Box.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Global_Function/Jump_Scene.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/User_Have_Character_Local_Varible.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Global_Function/Cloud_Image.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Jump_DIfficulty.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Global_Function/Global_Variable.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Shop_Character_Local_Varible.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Game_Difficulty_Local_Varible.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Rank_Local_Variable.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Report_Local_Variable.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Email_Local_Variable.js"},{"deps":{"Rank_Local_Variable":53,"Report_Local_Variable":54},"path":"preview-scripts/assets/resources/script/Rank/Report_User.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Local_Variible/Account_Management_Local_Variable.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Rank/My_Rank.js"},{"deps":{"../Local_Variible/Shop_Character_Local_Varible":51},"path":"preview-scripts/assets/resources/script/Role/Change_Character.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Rank/Report_Cancel.js"},{"deps":{"Report_Local_Variable":54},"path":"preview-scripts/assets/resources/script/Rank/Report_Confirm.js"},{"deps":{"../Local_Variible/User_Have_Character_Local_Varible":47,"../Local_Variible/Shop_Character_Local_Varible":51},"path":"preview-scripts/assets/resources/script/Role/Loading_Role.js"},{"deps":{"../Local_Variible/Shop_Character_Local_Varible":51},"path":"preview-scripts/assets/resources/script/Shop/Loading_Character.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Account_Management/Appeal_User.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Account_Management/Appeal_Cancel.js"},{"deps":{"../Local_Variible/Shop_Character_Local_Varible":51},"path":"preview-scripts/assets/resources/script/Shop/Character_Information.js"},{"deps":{},"path":"preview-scripts/assets/resources/script/Shop/Character.js"}];
var entries = ["preview-scripts/__qc_index__.js"];
var bundleScript = 'preview-scripts/__qc_bundle__.js';

/**
 * Notice: This file can not use ES6 (for IE 11)
 */
var modules = {};
var name2path = {};

// Will generated by module.js plugin
// var scripts = ${scripts};
// var entries = ${entries};
// var bundleScript = ${bundleScript};

if (typeof global === 'undefined') {
    window.global = window;
}

var isJSB = typeof jsb !== 'undefined';

function getXMLHttpRequest () {
    return window.XMLHttpRequest ? new window.XMLHttpRequest() : new ActiveXObject('MSXML2.XMLHTTP');
}

function downloadText(url, callback) {
    if (isJSB) {
        var result = jsb.fileUtils.getStringFromFile(url);
        callback(null, result);
        return;
    }

    var xhr = getXMLHttpRequest(),
        errInfo = 'Load text file failed: ' + url;
    xhr.open('GET', url, true);
    if (xhr.overrideMimeType) xhr.overrideMimeType('text\/plain; charset=utf-8');
    xhr.onload = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 0) {
                callback(null, xhr.responseText);
            }
            else {
                callback({status:xhr.status, errorMessage:errInfo + ', status: ' + xhr.status});
            }
        }
        else {
            callback({status:xhr.status, errorMessage:errInfo + '(wrong readyState)'});
        }
    };
    xhr.onerror = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(error)'});
    };
    xhr.ontimeout = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(time out)'});
    };
    xhr.send(null);
};

function loadScript (src, cb) {
    if (typeof require !== 'undefined') {
        require(src);
        return cb();
    }

    // var timer = 'load ' + src;
    // console.time(timer);

    var scriptElement = document.createElement('script');

    function done() {
        // console.timeEnd(timer);
        // deallocation immediate whatever
        scriptElement.remove();
    }

    scriptElement.onload = function () {
        done();
        cb();
    };
    scriptElement.onerror = function () {
        done();
        var error = 'Failed to load ' + src;
        console.error(error);
        cb(new Error(error));
    };
    scriptElement.setAttribute('type','text/javascript');
    scriptElement.setAttribute('charset', 'utf-8');
    scriptElement.setAttribute('src', src);

    document.head.appendChild(scriptElement);
}

function loadScripts (srcs, cb) {
    var n = srcs.length;

    srcs.forEach(function (src) {
        loadScript(src, function () {
            n--;
            if (n === 0) {
                cb();
            }
        });
    })
}

function formatPath (path) {
    let destPath = window.__quick_compile_project__.destPath;
    if (destPath) {
        let prefix = 'preview-scripts';
        if (destPath[destPath.length - 1] === '/') {
            prefix += '/';
        }
        path = path.replace(prefix, destPath);
    }
    return path;
}

window.__quick_compile_project__ = {
    destPath: '',

    registerModule: function (path, module) {
        path = formatPath(path);
        modules[path].module = module;
    },

    registerModuleFunc: function (path, func) {
        path = formatPath(path);
        modules[path].func = func;

        var sections = path.split('/');
        var name = sections[sections.length - 1];
        name = name.replace(/\.(?:js|ts|json)$/i, '');
        name2path[name] = path;
    },

    require: function (request, path) {
        var m, requestScript;

        path = formatPath(path);
        if (path) {
            m = modules[path];
            if (!m) {
                console.warn('Can not find module for path : ' + path);
                return null;
            }
        }

        if (m) {
            let depIndex = m.deps[request];
            // dependence script was excluded
            if (depIndex === -1) {
                return null;
            }
            else {
                requestScript = scripts[ m.deps[request] ];
            }
        }
        
        let requestPath = '';
        if (!requestScript) {
            // search from name2path when request is a dynamic module name
            if (/^[\w- .]*$/.test(request)) {
                requestPath = name2path[request];
            }

            if (!requestPath) {
                if (CC_JSB) {
                    return require(request);
                }
                else {
                    console.warn('Can not find deps [' + request + '] for path : ' + path);
                    return null;
                }
            }
        }
        else {
            requestPath = formatPath(requestScript.path);
        }

        let requestModule = modules[requestPath];
        if (!requestModule) {
            console.warn('Can not find request module for path : ' + requestPath);
            return null;
        }

        if (!requestModule.module && requestModule.func) {
            requestModule.func();
        }

        if (!requestModule.module) {
            console.warn('Can not find requestModule.module for path : ' + path);
            return null;
        }

        return requestModule.module.exports;
    },

    run: function () {
        entries.forEach(function (entry) {
            entry = formatPath(entry);
            var module = modules[entry];
            if (!module.module) {
                module.func();
            }
        });
    },

    load: function (cb) {
        var self = this;

        var srcs = scripts.map(function (script) {
            var path = formatPath(script.path);
            modules[path] = script;

            if (script.mtime) {
                path += ("?mtime=" + script.mtime);
            }
            return path;
        });

        console.time && console.time('load __quick_compile_project__');
        // jsb can not analysis sourcemap, so keep separate files.
        if (bundleScript && !isJSB) {
            downloadText(formatPath(bundleScript), function (err, bundleSource) {
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                if (err) {
                    console.error(err);
                    return;
                }

                let evalTime = 'eval __quick_compile_project__ : ' + srcs.length + ' files';
                console.time && console.time(evalTime);
                var sources = bundleSource.split('\n//------QC-SOURCE-SPLIT------\n');
                for (var i = 0; i < sources.length; i++) {
                    if (sources[i]) {
                        window.eval(sources[i]);
                        // not sure why new Function cannot set breakpoints precisely
                        // new Function(sources[i])()
                    }
                }
                self.run();
                console.timeEnd && console.timeEnd(evalTime);
                cb();
            })
        }
        else {
            loadScripts(srcs, function () {
                self.run();
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                cb();
            });
        }
    }
};

// Polyfill for IE 11
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function () {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
})();
    