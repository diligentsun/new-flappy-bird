
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Buy_Character');
require('./assets/Script/Cloud_Image1');
require('./assets/Script/FriendsListData');
require('./assets/Script/FriendsView');
require('./assets/Script/Jump_Scene1');
require('./assets/Script/People');
require('./assets/cloud/cloud');
require('./assets/resources/script/Account_Management/Appeal_Cancel');
require('./assets/resources/script/Account_Management/Appeal_Confirm');
require('./assets/resources/script/Account_Management/Appeal_User');
require('./assets/resources/script/Account_Management/Cancel_Closure');
require('./assets/resources/script/Account_Management/Closure_Account');
require('./assets/resources/script/Account_Management/Handle_Reported_User');
require('./assets/resources/script/Account_Management/Loading_All_Reported_User');
require('./assets/resources/script/Account_Management/Loading_All_Users');
require('./assets/resources/script/Account_Management/Loading_Reported_Users ');
require('./assets/resources/script/Closure/Closure_Tips');
require('./assets/resources/script/Closure/Tip');
require('./assets/resources/script/Closure/Tip_Close');
require('./assets/resources/script/Email/Accept');
require('./assets/resources/script/Email/Awards');
require('./assets/resources/script/Email/Delete_Read');
require('./assets/resources/script/Email/Email_Information');
require('./assets/resources/script/Email/Email_Waring');
require('./assets/resources/script/Email/Loading_Email');
require('./assets/resources/script/Email/Read_All');
require('./assets/resources/script/Friends/Show_Friends');
require('./assets/resources/script/Game_Coming/Bird_Action');
require('./assets/resources/script/Game_Coming/Game');
require('./assets/resources/script/Game_Coming/Gold_Action');
require('./assets/resources/script/Game_Coming/Gold_Show_Action');
require('./assets/resources/script/Game_Coming/Waterpipe_Action');
require('./assets/resources/script/Game_Login/NewScript');
require('./assets/resources/script/Game_Login/WX_Login');
require('./assets/resources/script/Game_Over/Grade_Show');
require('./assets/resources/script/Game_Start/Change_Difficult');
require('./assets/resources/script/Game_Start/Change_Map');
require('./assets/resources/script/Game_Start/Loading_Bird_Image');
require('./assets/resources/script/Game_Start/Loading_Game');
require('./assets/resources/script/Global_Function/Change_Bird_Image');
require('./assets/resources/script/Global_Function/Close_Box');
require('./assets/resources/script/Global_Function/Cloud_Image');
require('./assets/resources/script/Global_Function/Global_Variable');
require('./assets/resources/script/Global_Function/Global_WeChat');
require('./assets/resources/script/Global_Function/Jump_Scene');
require('./assets/resources/script/Global_Function/Loading_Base_Resouce');
require('./assets/resources/script/Local_Variible/Account_Management_Local_Variable');
require('./assets/resources/script/Local_Variible/Email_Local_Variable');
require('./assets/resources/script/Local_Variible/Game_Difficulty_Local_Varible');
require('./assets/resources/script/Local_Variible/Game_Local_Varible');
require('./assets/resources/script/Local_Variible/Jump_DIfficulty');
require('./assets/resources/script/Local_Variible/Rank_Local_Variable');
require('./assets/resources/script/Local_Variible/Report_Local_Variable');
require('./assets/resources/script/Local_Variible/Shop_Character_Local_Varible');
require('./assets/resources/script/Local_Variible/User_Have_Character_Local_Varible');
require('./assets/resources/script/Rank/Loading_Rank');
require('./assets/resources/script/Rank/My_Rank');
require('./assets/resources/script/Rank/Report_Cancel');
require('./assets/resources/script/Rank/Report_Confirm');
require('./assets/resources/script/Rank/Report_User');
require('./assets/resources/script/Role/Change_Character');
require('./assets/resources/script/Role/Have_Character_Information');
require('./assets/resources/script/Role/Loading_Role');
require('./assets/resources/script/Shop/Buy_Character_Sure');
require('./assets/resources/script/Shop/Character');
require('./assets/resources/script/Shop/Character_Information');
require('./assets/resources/script/Shop/Loading_Character');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();