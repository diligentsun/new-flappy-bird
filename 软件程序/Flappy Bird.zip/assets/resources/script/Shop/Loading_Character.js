//下载角色
const Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
	extends: cc.Component,
	properties: {
		Shop_Character_Label: {
			default: null,
			type: cc.Prefab,
			serialzable: true,
		},
		Shop_Character_View: {
			default: null,
			type: cc.Node,
			serialzable: true,
		},
		_Is_Loading: true,
	},

	// LIFE-CYCLE CALLBACKS:

	onLoad: function() {
		var self = this;
		Shop_Character_Local_Varible.Shop_Character_User = null;
		this._Is_Loading = true;
		WeChat.Loading_Shop_Character();
		//Shop_Character_Local_Varible.Shop_Character_User.length
	},

	start() {

	},

	update: function(dt) {
		//直到加载出角色
		if (this._Is_Loading && Shop_Character_Local_Varible.Shop_Character_User != null) {
			this.Loading_Character();
			this._Is_Loading = false;
		}
	},
	Loading_Image(self, Image_Path) {
		let _url = Image_Path;
		cc.loader.load({
			url: _url,
			type: 'jpg'
		}, function(err, texture, test) {
			var frame = new cc.SpriteFrame(texture);
			if (err) {
				console.log("图片错误", err);
			}
			self.getChildByName("sprite").getComponent(cc.Sprite).spriteFrame = frame;

		})
	},
	Loading_Character(){
		for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
			var New_Shop_Character_Label = cc.instantiate(this.Shop_Character_Label);
			this.Shop_Character_View.addChild(New_Shop_Character_Label);
			this.Loading_Image(New_Shop_Character_Label, Shop_Character_Local_Varible.Shop_Character_User[i].Character_Head_Image);
			New_Shop_Character_Label.getChildByName("Character_Name").getComponent(cc.Label).string = "" +
				Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;
		}
	}

});
