
cc.Class({
    extends: cc.Component,

    properties: {   
        buy:{
            default:null,
            type:cc.Prefab,
            serialzable:true,
         },
        Canvas_Sprite:{
            default:null,
            type:cc.Canvas,
            serialzable:true,
         },
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}, 

    start () {
        
    },
     onClickAlert:function(){
         var anode = cc.instantiate(this.buy);  
         this.Canvas_Sprite.node.addChild(anode);
         anode.setPosition(540,0);
        //  node = node.getComponent('BuyCharacter');
     }
    // update (dt) {},
});
