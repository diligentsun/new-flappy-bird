cc.Class({
	extends: cc.Component,

	properties: {
	},


	onLoad: function() {
		//调用微信登录函数，登录游戏
		wx.login({
			success: function(res) {
				if (res.code) {
					console.log("登录成功，获取到code", res.code);
				}
				var button = wx.createUserInfoButton({
					type: 'text',
					text: '开始游戏',
					style: {
						left: wx.getSystemInfoSync().screenWidth / 2 - 60,
						top: wx.getSystemInfoSync().screenHeight / 2 - 60,
						width: 120,
						height: 40,
						lineHeight: 40,
						backgroundColor: '#00aa00',
						color: '#ffffff',
						textAlign: 'center',
						fontSize: 16,
						borderRadius: 90,
					}
				});
				button.hide();
				button.show();
				button.onTap((res) => {
					console.log(res);

					if (res.errMsg === "getUserInfo:ok") {
						console.log("已经授权");
						//获取注册信息
						console.log(res.userInfo);
						WeChat.onRegisterUser(res.userInfo);
						button.destroy();
						//cc.director.loadScene("Game_Start");
					}else {
						console.log("没有授权");
					}
				});
			}
		});
	},

	start() {
		
	},
	
	

	// update (dt) {},
});
