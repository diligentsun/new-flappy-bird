//改变地图难度
var Game_Local_Varible = require('Game_Local_Varible');
cc.Class({
	extends: cc.Component,

	properties: {
		BGSprite: {
			default: null,
			type: cc.Sprite,
			serialzable: true,
		},
	},


	// onLoad () {},

	onLoad: function() {},
	update: function(dt) {},


	on_btn_click: function() {
		//改变背景
		var frame = this.node.getComponent(cc.Sprite).spriteFrame;
		//改变地图变量
		Game_Local_Varible.Current_Map = frame;
		if(Game_Local_Varible.Current_Map!=null){
			this.BGSprite.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
		}else{
			cc.loader.load({
				url: "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Map/Map_Desert.jpg?sign=1ff843bf81f16ee3d008efbd49344610&t=1608450857",
				type: 'jpg'
			}, function(err, texture, test) {
				var frame = new cc.SpriteFrame(texture);
				if (err) {
					console.log("图片错误", err);
				}
				this.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
			})
		}
		
		console.log("Current_Map.typeof=" + Game_Local_Varible.Current_Map);
	}
});
