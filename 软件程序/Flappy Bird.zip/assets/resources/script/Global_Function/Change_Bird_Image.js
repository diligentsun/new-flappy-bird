//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
	extends: cc.Component,

	properties: {
		condition: false,
		Character_Image_Array:[],
		i : 0,
		
	},
	start() {

	},

	update(dt) {
		this.node.getComponent(cc.Sprite).spriteFrame = Global_Variable.Character_Image1;
		// if (!this.condition) {
		// 	//想要执行的方法   
		// 	this.Character_Image_Array = new Array();
		// 	if (Global_Variable.Character_Image1 != null)
		// 		this.Character_Image_Array.push(Global_Variable.Character_Image1);
		// 	if (Global_Variable.Character_Image2 != null)
		// 		this.Character_Image_Array.push(Global_Variable.Character_Image2);
		// 	if (Global_Variable.Character_Image3 != null)
		// 		this.Character_Image_Array.push(Global_Variable.Character_Image3);
		// 	if (Global_Variable.Character_Image4 != null)
		// 		this.Character_Image_Array.push(Global_Variable.Character_Image4);
		// 	if(this.Character_Image_Array.length==4){
		// 		this.condition = true;	
		// 	}
		// };
		// if(this.condition) {
		// 	this.schedule(function() { // 计时器将每隔 1s 执行一次。
		// 		if (this.Character_Image_Array[this.i] != null) {
		// 			this.node.getComponent(cc.Sprite).spriteFrame = this.Character_Image_Array[this.i];
		// 			this.i+=1;
		// 			if (this.i == 3) {
		// 				this.i = 0;
		// 			}
		// 		}
		// 	},3);
		// };
		},
		
	});