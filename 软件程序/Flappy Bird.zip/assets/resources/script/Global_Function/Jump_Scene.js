//界面跳转
cc.Class({
	extends: cc.Component,

	properties: {
		scene: "",
	},

	start() {

	},
	on_btn_click: function() {
		cc.director.loadScene(this.scene);
	}
});
