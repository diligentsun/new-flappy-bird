//全局变量
var Rank_Local_Varible = require('Rank_Local_Variable');
var Shop_Character_Local_Variable=require('Shop_Character_Local_Varible');
var User_Have_Character_Local_Varible=require('User_Have_Character_Local_Varible');
var Email_Local_Variable = require('Email_Local_Variable');
var Account_Management_Local_Variable=require('Account_Management_Local_Variable');
window.WeChat = {};
//微信登录注册调用
WeChat.onRegisterUser = function(_userinfo) {
	wx.cloud.init({
		env: "zcx-6gbgdxdy254816b0"
	})
	console.log(_userinfo);
	wx.cloud.callFunction({
		//调用云函数
		name: "login",
		//传入的参数，玩家信息
		data: {
			userinfo: _userinfo,
		},
		success(res) {
			console.log("登录注册成功回调", res);
			Global_Variable.Is_Closured = res.result.Is_Closured;
			Global_Variable.Unsealing_Time = res.result.data[0].Unsealing_Time;
			Global_Variable.openid = res.result.data[0].openid;
			console.log("!res.result.Is_Closured的值为",!res.result.Is_Closured);
			console.log("Global_Variable.Unsealing_Time",Global_Variable.Unsealing_Time);
			if(!res.result.Is_Closured){
				cc.director.loadScene("Game_Start");
			}else{
				cc.director.loadScene("Closure");
			}
			
		},
		fail() {
			Global_Variable.Is_Closured = true;
			console.log("程序出错", console.error);
		}
	})
}
//加载资源
WeChat.Loading_Resources = function() {
	wx.cloud.init({
		env: "zcx-6gbgdxdy254816b0"
	})
	wx.cloud.callFunction({
		//调用云函数
		name: "Loading_Resources",
		success(res) {
			//将值赋给全局变量
			console.log("获取成功回调", res);
			Global_Variable.openid = res.result.openid;
			Global_Variable.Gold = res.result.Gold;
			Global_Variable.Diamond = res.result.Diamond;
			Global_Variable.Compassion = res.result.Compassion;
			Global_Variable.User_Head_Image = res.result.User_Head_Image;
			Global_Variable.Best_Score = res.result.Best_Score;
			Global_Variable.User_Name = res.result.User_Name;
			Global_Variable.Current_Character_Id=res.result.Current_Character_Id;
			Global_Variable.Is_Admin=res.result.Is_Admin;
			WeChat.Loading_Bird_Image(Global_Variable.Current_Character_Id);
		},
		fail() {
			console.log("获取基础物资出错", console.error);
			//失败了重新赋值
			WeChat.Loading_Resources();
		}
	})
}
//游戏结算
WeChat.Game_Settlement = function(_Add_Gold, _Score) {
	wx.cloud.init({
		env: "zcx-6gbgdxdy254816b0"
	})
	wx.cloud.callFunction({
		//调用云函数
		name: "Game_Settlement",
		//传入参数，包括增加的金币数量，分数
		data: {
			Add_Gold: _Add_Gold,
			Score: _Score,
		},

		success(res) {

			console.log("获取成功回调", res);
			Global_Variable.Gold = res.result.Gold;
			Global_Variable.Diamond = res.result.Diamond;
			Global_Variable.Compassion = res.result.Compassion;
		},
		fail() {
			console.log("获取基础物资出错", console.error);
			WeChat.Loading_Resources();
		}
	})
}
//加载世界排名
WeChat.Loading_World_Rank = function() {
	wx.cloud.init({
		env: "zcx-6gbgdxdy254816b0"
	})
	wx.cloud.callFunction({
		//调用云函数		
		name: "Loading_World_Rank",

		success(res) {

			console.log("下载世界排名成功回调", res);
			Rank_Local_Varible.Word_Rank_User = res.result.User_Information.data;
			console.log("Rank_Local_Varible为", Rank_Local_Varible.Word_Rank_User[0].openid);
		},
		fail() {
			console.log("下载世界排名出错", console.error);
			WeChat.Loading_Resources();
		}
	})
}

//上传举报、申诉列表
WeChat.Uploading_Reported_Information = function(_Openid, _Report_Content) {

	wx.cloud.init({
		env: "zcx-6gbgdxdy254816b0"
	})
	wx.cloud.callFunction({
		//调用云函数
		name: "Uploading_Reported_Information",
		data: {
			Reported_Openid: _Openid,
			Report_Content: _Report_Content,
		},

		success(res) {
			console.log("举报成功回调", res);
		},
		fail() {
			console.log("举报出错回调", console.error);
		}
	})
}

WeChat.Loading_Character=function () {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Character",
		

		success(res){		
			console.log("获取角色信息成功",res);
			Shop_Character_Local_Variable.Shop_Character_User=res.result.Character_Information.data;
			User_Have_Character_Local_Varible.User_Have_Character=res.result.User_Have_Character_Information.data;
		},
		fail(){
			console.log("获取角色信息失败",console.error);
			WeChat.Loading_Resources();
		}
	})
}

WeChat.Loading_Shop_Character=function(){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Shop",
		

		success(res){		
			console.log("获取商店信息成功",res);
			Shop_Character_Local_Variable.Shop_Character_User=res.result.Character_Information.data;
			User_Have_Character_Local_Varible.User_Have_Character=res.result.User_Have_Character_Information.data;
		},
		fail(){
			console.log("获取商店信息失败",console.error);
			WeChat.Loading_Resources();
		}
	})
}


//商店购买跟新
WeChat.Buy_Character_Update=function (_Update_Gold,_Update_Character) {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Shop_Buy",
		
		data:{
			Update_Gold:_Update_Gold,
			Update_Character:_Update_Character,
		},
		
		success(res){		
			console.log("商店获取成功回调",res);
		},
		fail(){
			console.log("商店获回调出错",console.error);
			WeChat.Loading_Resources();
		}
	})
}

WeChat.Loading_Bird_Image=function (Character_Id) {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Loading_Bird_Image",
		
		data:{
			Character_Id:Character_Id,
		},
		
		success(res){		
			console.log("角色图像获取成功回调",res);
			
			cc.loader.load({
				url:res.result.Character_Image1,
				type:'jpg'
			},function(err,texture,test){
				var frame=new cc.SpriteFrame(texture);
				if(err){
					console.log("图片错误",err);
				}
				Global_Variable.Character_Image1=frame;
			});
			cc.loader.load({
				url:res.result.Character_Image2,
				type:'jpg'
			},function(err,texture,test){
				var frame=new cc.SpriteFrame(texture);
				if(err){
					console.log("图片错误",err);
				}
				Global_Variable.Character_Image2=frame;
			});
			cc.loader.load({
				url:res.result.Character_Image3,
				type:'jpg'
			},function(err,texture,test){
				var frame=new cc.SpriteFrame(texture);
				if(err){
					console.log("图片错误",err);
				}
				Global_Variable.Character_Image3=frame;
			});
			cc.loader.load({
				url:res.result.Character_Image4,
				type:'jpg'
			},function(err,texture,test){
				var frame=new cc.SpriteFrame(texture);
				if(err){
					console.log("图片错误",err);
				}
				Global_Variable.Character_Image4=frame;
			})
		},
		
		fail(){
			console.log("角色图像回调出错",console.error);
		}
	})
}

WeChat.Updating_Current_Character_id=function (Character_Id) {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Updating_Current_Character_id",
		
		data:{
			Character_Id:Character_Id,
		},
		
		success(res){		
			console.log("修改当前角色成功回调",res);
			WeChat.Loading_Bird_Image(Character_Id);
		},
		
		fail(){
			console.log("修改当前角色失败",console.error);
			WeChat.Loading_Bird_Image(Character_Id);
		}
	})
}

//加载个人邮箱
WeChat.Loading_Email=function(){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Loading_Email",
		success(res){
			Email_Local_Variable.Email=res.result.User_Email_Information.data;
			console.log("获取邮件信息成功",res);
			console.log("邮件信息表",Email_Local_Variable.Email);
		},
		fail(){
			console.log("获取邮件信息失败",console.error);
			WeChat.Loading_Resources();
		}
		
	})
}
//加载全部邮箱
WeChat.Loading_All_Email=function(){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Loading_All_Email",
		success(res){
			Email_Local_Variable.Email=res.result.User_Email_Information.data;
			console.log("获取邮件信息成功",res);
			console.log("邮件信息表",Email_Local_Variable.Email);
		},
		fail(){
			console.log("获取邮件信息失败",console.error);
			WeChat.Loading_Resources();
		}
		
	})
}
//已读全部邮件
WeChat.Read_All=function () {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Read_All",
		success(res){		
			console.log("已读邮件成功回调",res);
		},
		
		fail(){
			console.log("已读邮件失败",console.error);
		}
	})
}
//删除已读邮件
WeChat.Delete_Read=function () {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Delete_Read",
		success(res){		
			console.log("删除已读邮件成功回调",res);
		},
		
		fail(){
			console.log("删除已读邮件失败",console.error);
		}
	})
}
//已读单个邮件
WeChat.Read=function(_id){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Read",
		data:{
			_id:_id,
		},
		success(res){		
			console.log("已读邮件成功回调",res);
		},
		
		fail(){
			console.log("已读邮件失败",console.error);
		}
	})
}
//接受奖励
WeChat.Accept=function(_id,_Add_Gold,_Add_Diamond,_Add_Compassion){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Accept",
		data:{
			_id:_id,
			Add_Gold:_Add_Gold,
			Add_Diamond:_Add_Diamond,
			Add_Compassion:_Add_Compassion,
		},
		success(res){		
			console.log("接受奖励成功回调",res);
			Global_Variable.Gold = res.result.Gold;
			Global_Variable.Diamond = res.result.Diamond;
			Global_Variable.Compassion = res.result.Compassion;
		},
		
		fail(){
			console.log("获取基础物资出错", console.error);
			WeChat.Loading_Resources();
		}
	})
}
//发放奖励
WeChat.Awards_Email=function(Time,Title,Content,Gold,Diamond,Compassion,Enclosure){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Awards",
		data:{
			Time:Time,
			Email_Title:Title,
			Email_Content:Content,
			Email_Gold:Gold,
			Email_Diamond:Diamond,
			Email_Compassion:Compassion,
			Enclosure:Enclosure,
		},
		success(res){		
			console.log("发放奖励成功回调",res);
		},
		
		fail(){
			console.log("发放奖励失败", console.error);
		}
	})
}

WeChat.Loading_All_User=function () {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Loading_All_User",
		
		success(res){		
			console.log("下载全部账号信息成功回调",res);
			Account_Management_Local_Variable.All_Users_Information=res.result.All_Users_Information.data;
			console.log("查看全部账号",Account_Management_Local_Variable.All_Users_Information);
		},
		
		fail(){
			console.log("下载全部账号信息失败",console.error);
			WeChat.Loading_All_User();
		}
	})
}

WeChat.Loading_Report_User=function (_openid) {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Loading_Report_User",
		
		data:{
			openid:_openid,
		},
		
		success(res){		
			console.log("下载举报人信息成功回调",res);
			Account_Management_Local_Variable.Report_User_List=res.result.Report_User_List.data;
			console.log("查看所有举报人信息",Account_Management_Local_Variable.Report_User_List);
		},
		
		fail(){
			console.log("下载所有举报人信息失败",console.error);
			WeChat.Loading_Report_User(_openid);
		}
	})
}

WeChat.Loading_Reporterd_User=function () {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Loading_All_Reported_Users",
		success(res){
			console.log("下载被举报人信息成功回调",res);
			Account_Management_Local_Variable.Reported_Users_Information=res.result.Reported_Information.list;
			console.log("查看被举报人信息",Account_Management_Local_Variable.Reported_Users_Information);
		},
		fail(){
			console.log("下载所有被举报人信息失败",console.error);
			WeChat.Loading_Reporterd_User();
		}
	})
}

WeChat.Email_Report_And_Appeal=function (Time,Title,Content) {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Email_Report",
		data:{
			Time:Time,
			Email_Title:Title,
			Email_Content:Content
		},
		success(res){
			console.log("举报邮件成功回调",res);
		},
		fail(){
			console.log("举报邮件发送失败",console.error);;
		}
	})
}

WeChat.Email_Warning=function (Time,Title,Content,open_id) {
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Email_Warning",
		data:{
			Time:Time,
			Email_Title:Title,
			Email_Content:Content,
			open_id:open_id
		},
		success(res){
			console.log("警告邮件成功回调",res);
		},
		fail(){
			console.log("警告邮件发送失败",console.error);;
		}
	})
}

WeChat.Handle_Reported_User=function(_openid){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Handle_Reported_User",
		data:{
			openid:_openid
		},
		success(res){
			console.log("处理被举报人成功回调",res);
		},
		fail(){
			console.log("处理被举报人失败",console.error);
		}
	})
}

WeChat.Closure_Account = function(Openid,Input){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Closure_Account",
		data:{
			Reported_Openid:Openid,
			Closure_Time:Input,
		},
		success(res){
			console.log("封停账号成功回调",res);
		},
		fail(){
			console.log("封停账号失败",console.error);
		}
	})
}

WeChat.Cancel_Closure = function(Openid){
	wx.cloud.init({env:"zcx-6gbgdxdy254816b0"})
	wx.cloud.callFunction({
		//调用云函数
		//传入的参数
		name:"Cancel_Closure",
		data:{
			Reported_Openid:Openid,
		},
		success(res){
			console.log("解除封停账号成功回调",res);
		},
		fail(){
			console.log("解除封停账号失败",console.error);
		}
	})
}