

cc.Class({
    extends: cc.Component,

    properties: {
        Canvas:{
            default:null, 
            type:cc.Node,
			serialzable:true,
        }
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    Close:function(){
        this.Canvas.destroy();
    },
    start () {

    },

    // update (dt) {},
});
