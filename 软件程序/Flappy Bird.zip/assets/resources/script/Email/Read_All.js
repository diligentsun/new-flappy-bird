//下载邮箱列表
const { Email } = require('../Local_Variible/Email_Local_Variable');
const Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');
cc.Class({
    extends: cc.Component,

    properties: {
    },
    Read_All:function(){
        //获取邮件列表
        WeChat.Loading_Email();
        //将未读修改为已读
        WeChat.Read_All();
        
        console.log("邮件信息表",Email_Local_Variable.Email);
        cc.director.loadScene("Email");
    },

    start () {

    },
});
