
cc.Class({
    extends: cc.Component,

    properties: {
       OPENID_Label:{
            default: null,
            type: cc.Label,
            serialzable: true,
       }
    },

    Warning:function(){
        var open_id=this.OPENID_Label.getComponent(cc.Label).string;
        //获取时间戳
		let Time = parseInt(new Date().getTime());
		var Title = "账号异常警告";
		var Content ="您的账号可能存在异常，如核实有违规行为，系统将对您作出惩罚";
		WeChat.Email_Warning(Time,Title,Content,open_id);
    },

    start () {

    },

    // update (dt) {},
});
