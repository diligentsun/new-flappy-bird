//下载邮箱列表
const Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');
cc.Class({
    extends: cc.Component,

    properties: {
      
    },

    Delete_Read: function(){
        
         //删除已读邮件
         WeChat.Delete_Read();
          //获取邮件列表
         WeChat.Loading_Email();
         console.log("邮件信息表",Email_Local_Variable.Email);
         cc.director.loadScene("Email");
    },

    start () {

    },

    // update (dt) {},
});
