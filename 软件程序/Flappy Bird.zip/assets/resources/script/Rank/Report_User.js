//弹出举报框
var Report_Local_Variable = require('Report_Local_Variable');
var Rank_Local_Varible = require('Rank_Local_Variable');

cc.Class({
	extends: cc.Component,

	properties: {
		Report_Label: {
			default: null,
			type: cc.Prefab,
			serialzable: true,
		}, //举报框
		Canvas: {
			default: null,
			type: cc.Node,
			serialzable: true,
		}, //玩家框节点
		Report_Rank: {
			default: null,
			type: cc.Label,
			serialzable: true,
		}, //被举报玩家
	},

	start() {

	},
	on_btn_click: function() {
		//创建举报信息框
		var New_Report_Label = cc.instantiate(this.Report_Label);
		this.Canvas.parent.parent.parent.addChild(New_Report_Label);
		New_Report_Label.setPosition(0, 0);
		//载入信息
		console.log("被举报人的名次", this.Report_Rank.getComponent(cc.Label).string);
		var Rank_Number = Number(this.Report_Rank.getComponent(cc.Label).string) - 1;
		console.log("被举报人的openid", Report_Local_Variable.openid);
		Report_Local_Variable.openid = Rank_Local_Varible.Word_Rank_User[Rank_Number].openid;
		Report_Local_Variable.User_Name = Rank_Local_Varible.Word_Rank_User[Rank_Number].User_Name;
	}
	// update (dt) {},
});
