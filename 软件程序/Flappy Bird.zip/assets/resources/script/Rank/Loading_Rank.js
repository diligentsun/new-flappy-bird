//下载世界排名列表
var Rank_Local_Varible = require('Rank_Local_Variable');
cc.Class({
    extends: cc.Component,

    properties: {
    Rank_User_Label:{
     			default:null, 
     			type:cc.Prefab,
     			serialzable:true,
     },//玩家框
	 Rank_View:{
	 			default:null, 
	 			type:cc.Node,
	 			serialzable:true,
	 },//排名框
	 _Is_Loading:true,
    },


    onLoad:function () {
		var self = this;
		Rank_Local_Varible.Word_Rank_User=null;
		this._Is_Loading=true;
		WeChat.Loading_World_Rank();
		console.log(Rank_Local_Varible.Word_Rank_User);
		
	},

    start () {
    },

    update:function (dt) {
		//Rank_Local_Varible.Word_Rank_User.length
		//循环输出玩家框
		if(this._Is_Loading&&Rank_Local_Varible.Word_Rank_User){
			for(var i=0;i<Rank_Local_Varible.Word_Rank_User.length;i++){
				console.log("正在加载中");
				var New_Rank_User_Label = cc.instantiate(this.Rank_User_Label);
				this.Rank_View.addChild(New_Rank_User_Label);
				this.Loading_Image(New_Rank_User_Label,Rank_Local_Varible.Word_Rank_User[i].Head_Iamge);
				New_Rank_User_Label.getChildByName("Game_Rank_Show").getComponent(cc.Label).string=""+(i+1);
				New_Rank_User_Label.getChildByName("User_Name").getComponent(cc.Label).string=""+Rank_Local_Varible.Word_Rank_User[i].User_Name;
				New_Rank_User_Label.getChildByName("Best_Score_Text").getComponent(cc.Label).string=""+Rank_Local_Varible.Word_Rank_User[i].Best_Score+"分";
				
			}
			this._Is_Loading=false
		}
	},
	
	Loading_Image(self,Image_Path){
				let _url=Image_Path;
				cc.loader.load({
					url:_url,
					type:'jpg'
				},function(err,texture,test){
					var frame=new cc.SpriteFrame(texture);
					if(err){
						console.log("图片错误",err);
					}
					self.getChildByName("Head_Image_Mask").getChildByName("Head_Image").getComponent(cc.Sprite).spriteFrame=frame;
					
				})
	}
});
