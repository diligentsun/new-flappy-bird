//取消会议记录
cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
	
    },
	on_btn_click: function() {
		this.node.destroy();
	}
    // update (dt) {},
});
