//加载自己的成绩信息
cc.Class({
    extends: cc.Component,

    properties: {
		User_Heading_Image:{

					default:null, 
					type:cc.Sprite,
					serialzable:true,
		},//使用者头像
		User_Name:{
				default:null, 
					type:cc.Label,
					serialzable:true,
		},//使用者名字		
		Best_Scroe_Text:{
					default:null, 
					type:cc.Label,
					serialzable:true,
		},
    },

	//加载自己的信息
     onLoad: function(){
		 this.Loading_Image(this,Global_Variable.User_Head_Image);
		 this.User_Name.string=Global_Variable.User_Name;
		 this.Best_Scroe_Text.string=Global_Variable.Best_Score+"分";
		 
	 },

    start () {

    },

    // update (dt) {},
	//加载图片
	Loading_Image(self,Image_Path){
				let _url=Image_Path;
				cc.loader.load({
					url:_url,
					type:'jpg'
				},function(err,texture,test){
					var frame=new cc.SpriteFrame(texture);
					if(err){
						console.log("图片错误",err);
					}
					self.User_Heading_Image.getComponent(cc.Sprite).spriteFrame=frame;
					
				})
	}
});
