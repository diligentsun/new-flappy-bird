cc.Class({
    extends: cc.Component,

    properties: {
        tip:{
            default: null,
			type: cc.Node,
			serialzable: true,
        }
    },


    start () {
	
    },
	on_btn_click: function() {
		this.tip.destroy();
	}
});
