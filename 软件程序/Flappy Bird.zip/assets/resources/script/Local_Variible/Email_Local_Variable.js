//邮箱的局部变量
module.exports = {
    //邮箱接收者
	Email: null,
};