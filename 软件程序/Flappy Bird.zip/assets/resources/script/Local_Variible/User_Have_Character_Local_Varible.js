module.exports = {

	User_Have_Character: null,
};