module.exports = {

	Shop_Character_User: null,
};