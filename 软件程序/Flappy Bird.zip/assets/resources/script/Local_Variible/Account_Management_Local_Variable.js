//游戏难度系数的局部变量
module.exports = {
	//全部玩家角色表
	All_Users_Information: null,
	Report_User_List:null,
	Reported_Users_Information:null,

	
};
