//游戏难度系数的局部变量
module.exports = {
	//游戏难度系数
	Difficulty_Ratio: 1,
	//是否是困难模式
	Is_Difficulty: false,
};
