//游戏界面的局部变量
module.exports = {
	//分数统计
	Fraction: 0,
	//获得金币
	Gold: 0,
	//当前地图
	Current_Map: {
		default: null,
		type: cc.SpriteFrame,
		serialzable: true,
	},
};
