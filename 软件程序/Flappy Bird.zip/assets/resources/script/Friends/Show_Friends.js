//加载好友
cc.Class({
	extends: cc.Component,

	properties: {
		WXSubContextView: cc.SubContextView,
		_Is_Loading:true,
		
	},


	onLoad: function() {
		console.log("显示排行榜");
		//获取时间戳
		let updateTime = parseInt(new Date().getTime() / 1000);
		let getArr = new Array(); //声明向开放数据域传递的变量
		let openDataContext = wx.getOpenDataContext(); //声明开发数据域
		let setArr = [{
			key: "score",
			value: String(Global_Variable.Best_Score)
		}];
		getArr.push("score"); //将score压入开放数据域

		//向开发数据域声明获取好友
		openDataContext.postMessage({
			type: "GET",
			data: getArr,
			timer: updateTime
		})

		//将自己的成绩送入开放数据域
		console.log(setArr);
		openDataContext.postMessage({
			type: "SET",
			data: setArr,
			timer: updateTime
		})
		console.log("设置的信息为", setArr);
		//显示开放数据域
		this.SubContextView = null;
		this._Is_Loading=true;
		this.SubContextView = this.WXSubContextView.getComponent(cc.SubContextView);
		console.log("加载好友框中");
		this.SubContextView.enabled = true;
		this.SubContextView.active = true;
		console.log("加载好友框中");
		this.SubContextView.update();
		console.log("特别正常");
	},

	start() {

	},

	update:function(dt) {
		//加载好友框
	},
	

});
