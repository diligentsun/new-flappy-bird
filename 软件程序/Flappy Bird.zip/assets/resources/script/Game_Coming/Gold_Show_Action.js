//金币显示框运动逻辑
var Game_Local_Varible = require('Game_Local_Varible');
cc.Class({
    extends: cc.Component,

    properties: {
		Gold_Show:{  //金币显示框
			default:null, 
			type:cc.Label,
			serialzable:true,
		},
		
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function() {  
		console.log("Game_Local_Varible.Gold="+Game_Local_Varible.Gold)
		this.Gold_Show.string = (Game_Local_Varible.Gold);  //改变金币显示数
	},

    start () {
    },

    update: function(dt) {
		this.Gold_Show.string = (Game_Local_Varible.Gold);//改变金币显示数
	},
});
