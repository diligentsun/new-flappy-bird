//控制小鸟的运动情况
var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({


	extends: cc.Component,
	properties: {

		birdwingAudio: {
            default: null,
            type: cc.AudioClip
		},
		
		birddieAudio: {
            default: null,
            type: cc.AudioClip
        },

		_V_Index: 0, //小鸟垂直速度
		_Is_Sart: true, //游戏是否进行
		Jump_Up_Acc: 0, //上升速度
		Jump_Down_Acc: 0,
	},


	onLoad: function() {
		//开启小鸟的碰撞属性
		var manager = cc.director.getCollisionManager();
		//manager.enabledDebugDraw = true;
		manager.enabled = true;
		//监听屏幕是否被点击
		this.node.parent.on(cc.Node.EventType.TOUCH_START, this.onTouchMove, this);

	},

	onDestroy() {
		// 取消键盘输入监听

	},

	start() {

	},

	update: function(dt) {
		//如果游戏开始，是的小鸟开始掉落
		if (this._Is_Sart) {
			//随着时间的增长，增加下降速度。
			this._V_Index -= this.Jump_Down_Acc * dt;
		}
		//通过改变小鸟坐标的形式，使得小鸟移动
		this.node.y += this._V_Index * dt;

	},
	onTouchMove(event) {
		//如果屏幕被点击，给予小鸟一个向上的加速度
		this._V_Index = this.Jump_Up_Acc * 20;
		cc.audioEngine.playEffect(this.birdwingAudio, false,0.2);
	},

	onCollisionEnter: function(other, self) {
		//如果发生碰撞，调用函数
		console.log("other.name = ", other.node.name, other.node.group, other.node.groupIndex);
		if (other.node.groupIndex === 1) { // 与障碍物相撞
			cc.audioEngine.playEffect(this.birddieAudio, false,0.1);
			this._Is_Sart = false;
			this._V_Index = 3000;
			cc.audioEngine.stopMusic();
			//使得小鸟向上飞出屏幕
		}
	},
});
