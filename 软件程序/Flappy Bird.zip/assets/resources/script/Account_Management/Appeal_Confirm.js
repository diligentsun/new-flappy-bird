cc.Class({
	extends: cc.Component,

	properties: {

		Appeal_Content: {
			default: null,
			type: cc.Label,
			serialzable: true,
		},//举报框
	},

	// LIFE-CYCLE CALLBACKS:

	// onLoad () {},
	start() {

	},
	on_btn_click: function() {
		//载入申诉人的信息
		console.log("点到了吗??");
		var Appeal_Text = this.Appeal_Content.getComponent(cc.Label).string;

		  //获取时间戳
		let Time = parseInt(new Date().getTime());
		var Title = "关于对账号的申诉";
		var Content ="系统已收到您的申诉，请等待处理			申诉原因："+Appeal_Text;
		WeChat.Email_Report_And_Appeal(Time,Title,Content);
		console.log("申诉内容为", Appeal_Text);
		//上传举报信息
		WeChat.Uploading_Reported_Information(Global_Variable.openid,Appeal_Text);
		this.node.destroy();
	}
	// update (dt) {},
});
