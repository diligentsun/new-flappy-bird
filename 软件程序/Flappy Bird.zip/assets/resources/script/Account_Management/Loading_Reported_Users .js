var Account_Management_Local_Variable = require('Account_Management_Local_Variable');
cc.Class({
	extends: cc.Component,

	properties: {
		Account_Label: {
			default: null,
			type: cc.Prefab,
			serialzable: true,
		}, //账号管理预制体
		Account_Managent_View: {
			default: null,
			type: cc.Node,
			serialzable: true,
		}, //排名框
		Report_Information_Label: {
			default: null,
			type: cc.Prefab,
			serialzable: true,
		},
		_Is_Loading: true,
	},

	// LIFE-CYCLE CALLBACKS:

	onLoad: function() {
		Account_Management_Local_Variable.Reported_Users_Information = null;
		this._Is_Loading = true;
		WeChat.Loading_Reporterd_User();
		console.log("被举报人信息个数", Account_Management_Local_Variable.Reported_Users_Information.length);

	},

	start() {

	},

	update: function(dt) {
		if (this._Is_Loading && Account_Management_Local_Variable.Reported_Users_Information != null) {
			this.Loading_Reported_Users();
			this._Is_Loading = false;
		}
	},
	Loading_Reported_Users() {
		for (var i = 0; i < Account_Management_Local_Variable.Reported_Users_Information.length; i++) {
			console.log("1");
			var New_Account_Label = cc.instantiate(this.Account_Label);
			New_Account_Label.getChildByName("Account_Management_Label").getChildByName("User_Id_Label").getChildByName(
				"User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Reported_Users_Information[
				i].openid;
			New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Account_Status_Label").getChildByName(
				"Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.Reported_Users_Information[
				i].User_state;
			New_Account_Label.getChildByName("Account_Management_Label").getChildByName(
				"Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(
				cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].Reported_Count;
			var openidlist = Account_Management_Local_Variable.Reported_Users_Information[i].openidlist;
			New_Account_Label.height = 500 + openidlist.length * 200;
			this.Account_Managent_View.addChild(New_Account_Label);
			for (var j = 0; j < openidlist.length; j++) {
				console.log("查看openidlist", openidlist[j]);
				var New_Report_Information_Label = cc.instantiate(this.Report_Information_Label);
				New_Account_Label.addChild(New_Report_Information_Label);
				New_Report_Information_Label.getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label)
					.string = "" + openidlist[j].Reported_Openid;
				New_Report_Information_Label.getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(
					cc.Label).string = "" + openidlist[j].Report_Time.toString();
				New_Report_Information_Label.getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName(
					"Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + openidlist[j].Report_Reason;
			}

		}
	}
});
