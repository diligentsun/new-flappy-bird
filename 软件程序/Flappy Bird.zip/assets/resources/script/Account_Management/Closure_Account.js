//封停账号
cc.Class({
	extends: cc.Component,

	properties: {
		Account_Label:{
			default: null,
			type: cc.Node,
			serialzable: true,
		},
		User_Id_Show: {
			default: null,
			type: cc.Label,
			serialzable: true,
		},
		Input_Show: {
			default: null,
			type: cc.Label,
			serialzable: true,
		},
		
	},

	// LIFE-CYCLE CALLBACKS:

	// onLoad () {},

	start() {

	},
	on_btn_click: function() {
		var Openid=this.User_Id_Show.getComponent(cc.Label).string;
		var Input=Number(this.Input_Show.getComponent(cc.Label).string);
		if (!isNaN(Input)){
		WeChat.Closure_Account(Openid,Input);
		WeChat.Handle_Reported_User(Openid);
		this.Account_Label.destroy();
		}
	}

	// update (dt) {},
});
