//弹出申诉框
cc.Class({
	extends: cc.Component,

	properties: {
		Appeal_Label: {
			default: null,
			type: cc.Prefab,
			serialzable: true,
		}, //申诉框
		Canvas: {
			default: null,
			type: cc.Node,
			serialzable: true,
		}, //玩家框节点
	},

	start() {

	},
	on_btn_click: function() {
		//创建申诉信息框
		var New_Appeal_Label = cc.instantiate(this.Appeal_Label);
		this.Canvas.addChild(New_Appeal_Label);
		New_Appeal_Label.setPosition(0, 0);
	}
	// update (dt) {},
});
