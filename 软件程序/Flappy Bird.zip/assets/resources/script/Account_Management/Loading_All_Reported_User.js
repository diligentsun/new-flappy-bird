var Account_Management_Local_Variable=require('Account_Management_Local_Variable');

cc.Class({
	extends: cc.Component,

	properties: {
		Uid_Show:{
			default:null, 
			type:cc.Label,
			serialzable:true,
		},//Openid
		Report_Information_Label:{
			default:null,
			type:cc.Prefab,
			serialzable:true,
		},
		Account_Label:{
			default:null,
			type:cc.Node,
			serialzable:true,
		},
		
	},

	// LIFE-CYCLE CALLBACKS:

	// onLoad () {},

	start() {

	},

	// update (dt) {},
	on_btn_click: function() {
		var Openid=this.Uid_Show.getComponent(cc.Label).string;
		WeChat.Loading_Report_User(Openid);
		console.log("下拉举报");
		WeChat.Loading_All_User();
		console.log("输出账号个数",Account_Management_Local_Variable.Report_User_List.length);
		for(var i=0;i<Account_Management_Local_Variable.Report_User_List.length;i++){	
			console.log("1");
			var New_Report_Information_Label=cc.instantiate(this.Report_Information_Label);
			this.Account_Label.addChild(New_Report_Information_Label);
			New_Report_Information_Label.getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string=""+Account_Management_Local_Variable.Report_User_List[i].Report_Openid;
			New_Report_Information_Label.getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string=""+Account_Management_Local_Variable.Report_User_List[i].Report_Time.toString();
			New_Report_Information_Label.getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string=""+Account_Management_Local_Variable.Report_User_List[i].Report_Reason;
		}
	}
});
