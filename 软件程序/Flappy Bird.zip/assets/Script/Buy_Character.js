
var Alert = {
     
    btnOK:null,
    btnCancel:null,
    content:null,
    btnOKCallBack:null,
}

cc.Class({
    extends: cc.Component,

    properties: {
       Tip:cc.Label,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}, 

    start () {

    },
    show:function(){
        this.node.active = true 
    },
    hide:function(){
        this.node.active = false
    },
    onClickCancle:function(){
        this.hide()
    },
    onClickConfirm:function(){
        this.hide()
    },
    setTip:function(string){
        this.Tip.String = string
    }
    // update (dt) {},
});
