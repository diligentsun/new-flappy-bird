// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
       Iamge: "",
	   BGSprite:{
		  default:null,
		  type:cc.Sprite,
		  serialzable:true,
	   },
    },


    // onLoad () {},

    onLoad:function() {
		var self = this;
		let _url=self.Iamge;
		cc.loader.load({
			url:_url,
			type:'jpg'
		},function(err,texture,test){
			var frame=new cc.SpriteFrame(texture);
			if(err){
				console.log("图片错误",err);
			}
			self.BGSprite.getComponent(cc.Sprite).spriteFrame=frame;
			
		})
},

    update: function(dt) {},
});
