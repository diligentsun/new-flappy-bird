
var Alert = {
     
    btnOK:null,
    btnCancel:null,
    content:null,
    btnOKCallBack:null,
}

cc.Class({
    extends: cc.Component,

    properties: {
        alert:cc.Prefab,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {}, 

    start () {

    },
     onClickAlert:function(){
         var node = cc.instantiate(this.alert);
         this.node.addChild(node);
         node = node.getComponent('ReportAlert');
         node.setTip('确定举报该好友吗？');
     }
    // update (dt) {},
});
