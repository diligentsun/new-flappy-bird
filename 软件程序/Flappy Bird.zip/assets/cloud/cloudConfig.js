(function () {
  window.cc_cloud_commonConfig = {
    platform: "tencent",
    tencent: {
      env: "cocos-cocos-tcb-test-09dsa-61249",
      appSign: "com.cocos.test",
      appSecret: {
        appAccessKeyId: "1",
        appAccessKey: "693a06e3e6aba325154ba45b3c4bb34d"
      }
    },
  };
})()