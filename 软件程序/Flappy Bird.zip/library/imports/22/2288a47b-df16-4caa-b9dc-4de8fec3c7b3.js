"use strict";
cc._RF.push(module, '2288aR73xZMqrncTej+w8ez', 'Character_Information');
// resources/script/Shop/Character_Information.js

"use strict";

//显示角色信息
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Buy_Character_Background: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Name: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    var self = this;
    var This_Name = this.Character_Name.getComponent(cc.Label).string;
    WeChat.Loading_Shop_Character();

    for (var i = 0; i < Shop_Character_Local_Varible.Shop_Character_User.length; i++) {
      var List_Name = Shop_Character_Local_Varible.Shop_Character_User[i].Character_Name;

      if (This_Name === List_Name) {
        //当前点击的角色
        var This_information = Shop_Character_Local_Varible.Shop_Character_User[i];
        var New_Buy_Character_Background = cc.instantiate(this.Buy_Character_Background);
        this.Canvas.parent.parent.parent.addChild(New_Buy_Character_Background);
        New_Buy_Character_Background.setPosition(0, -300);
        console.log("图片地址为", This_information);
        this.Loading_Image(New_Buy_Character_Background, This_information.Character_Head_Image);
        New_Buy_Character_Background.getChildByName("Character_Name").getComponent(cc.Label).string = "" + This_information.Character_Name;
        New_Buy_Character_Background.getChildByName("Character_Synopsis").getComponent(cc.Label).string = "" + This_information.Character_Synopsis;
        New_Buy_Character_Background.getChildByName("Bounce_Power_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Jump_Speed;
        New_Buy_Character_Background.getChildByName("Weight_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fall_Speed;
        New_Buy_Character_Background.getChildByName("Speed_Number_Label").getComponent(cc.Label).string = "" + This_information.Character_Fly_Speed;
        New_Buy_Character_Background.getChildByName("Skill_Name_Label").getComponent(cc.Label).string = "" + This_information.Skill_Name;
        New_Buy_Character_Background.getChildByName("Skill_Effect_Label").getComponent(cc.Label).string = "" + This_information.Skill_Synopsis;
        New_Buy_Character_Background.getChildByName("Price_Label").getComponent(cc.Label).string = "" + This_information.Character_Price;
        New_Buy_Character_Background.getChildByName("Character_Id").getComponent(cc.Label).string = "" + This_information.Character_Id;
        New_Buy_Character_Background.getChildByName("Background1").getComponent(cc.Sprite).fillRange = This_information.Character_Jump_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background2").getComponent(cc.Sprite).fillRange = This_information.Character_Fall_Speed / 100;
        New_Buy_Character_Background.getChildByName("Background3").getComponent(cc.Sprite).fillRange = This_information.Character_Fly_Speed / 100;
        break;
      }
    }
  },
  update: function update(dt) {},
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Character_Image").getComponent(cc.Sprite).spriteFrame = frame;
    });
  }
});

cc._RF.pop();