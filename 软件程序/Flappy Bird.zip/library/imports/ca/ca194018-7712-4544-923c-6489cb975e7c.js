"use strict";
cc._RF.push(module, 'ca194AYdxJFRJI8ZInLl158', 'Global_Variable');
// resources/script/Global_Function/Global_Variable.js

"use strict";

window.Global_Variable = {
  User_Information: null,
  openid: null,
  Gold: 0,
  Diamond: 0,
  Compassion: 0,
  User_Head_Image: null,
  User_Name: null,
  Best_Score: 0,
  Is_Admin: false,
  Is_Closured: null,
  Restores_Compassion_Time: new Date(),
  Character_Image1: null,
  Character_Image2: null,
  Character_Image3: null,
  Character_Image4: null,
  Unsealing_Time: null
};

cc._RF.pop();