"use strict";
cc._RF.push(module, '15c871m3upP+ITBKtGQ2KX7', 'Close_Box');
// resources/script/Global_Function/Close_Box.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  Close: function Close() {
    this.Canvas.destroy();
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();