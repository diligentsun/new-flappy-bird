"use strict";
cc._RF.push(module, '92d67ihDSlIL5FHV3xxiZud', 'Tip');
// resources/script/Closure/Tip.js

"use strict";

//弹出提示框
cc.Class({
  "extends": cc.Component,
  properties: {
    Tip: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //提示框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    } //玩家框节点

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建申诉信息框
    var New_Tip = cc.instantiate(this.Tip);
    this.Canvas.parent.addChild(New_Tip);
    New_Tip.setPosition(0, 0);
  } // update (dt) {},

});

cc._RF.pop();