"use strict";
cc._RF.push(module, '62d69Q/mPZMR7Ofo7rz8dcr', 'Change_Character');
// resources/script/Role/Change_Character.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    console.log("角色ID为", this.Canvas.getChildByName("Character_Id").getComponent(cc.Label).string);
    var Current_id = this.node.getChildByName("Character_Id").getComponent(cc.Label).string;
    WeChat.Updating_Current_Character_id(Current_id);
    this.Canvas.destroy();
  },
  update: function update(dt) {}
});

cc._RF.pop();