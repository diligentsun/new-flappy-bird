"use strict";
cc._RF.push(module, 'bd112igWp1I7pLIVcdeazws', 'Loading_Email');
// resources/script/Email/Loading_Email.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Email_Read: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已读邮件框
    Email: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //未读邮件框
    Email_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //邮箱框
    No_Read_Number: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //未读邮件计数
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  onLoad: function onLoad() {
    //获取邮件列表
    Email_Local_Variable.Email = null;
    WeChat.Loading_Email();
    console.log("邮件信息表", Email_Local_Variable.Email);
    this._Is_Loading = true;
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Email_Local_Variable.Email != null) {
      this.Loading_Email();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("Email_Type").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Email: function Loading_Email() {
    var No_Read_Number = 0;
    var self = this; //循环输出邮件框

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var New_Email_Label = null; //根据是否已读决定背景(邮件框类型)

      if (Email_Local_Variable.Email[i].Is_Read === true) {
        //新建已读邮件节点
        New_Email_Label = cc.instantiate(this.Email_Read); //加入为子节点

        this.Email_View.addChild(New_Email_Label);
        console.log(New_Email_Label, "第", i + 1, "封邮件");
        console.log("Email_Local_Variable.Email[i].Enclosure:", i, Email_Local_Variable.Email[i].Enclosure);
        console.log("Email_Local_Variable.Email[i].Email_Title:", i, Email_Local_Variable.Email[i].Email_Title);
        console.log("已读");
        console.log("Email_Local_Variable.Email[i].Is_Read:", i, Email_Local_Variable.Email[i].Is_Read); //根据是否有附件决定图标类型

        if (Email_Local_Variable.Email[i].Enclosure === true) //若有附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift2.png?sign=639a28a6a90a604f8cac84ea2eb59eae&t=1610714079");else //若无附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift.png?sign=ca9885f77ec4a7f7b3ffbc83cde81935&t=1610714025");
      } else {
        No_Read_Number++; //新建未读邮件节点

        New_Email_Label = cc.instantiate(this.Email); //加入为子节点

        this.Email_View.addChild(New_Email_Label);
        console.log(New_Email_Label, "第", i + 1, "封邮件");
        console.log("Email_Local_Variable.Email[i].Enclosure:", i, Email_Local_Variable.Email[i].Enclosure);
        console.log("Email_Local_Variable.Email[i].Email_Title:", i, Email_Local_Variable.Email[i].Email_Title);
        console.log("未读");
        console.log("Email_Local_Variable.Email[i].Is_Read:", i, Email_Local_Variable.Email[i].Is_Read);
        if (Email_Local_Variable.Email[i].Enclosure === true) //若有附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift2.png?sign=639a28a6a90a604f8cac84ea2eb59eae&t=1610714079");else //若无附件
          this.Loading_Image(New_Email_Label, "https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/image/Tips/Gift.png?sign=ca9885f77ec4a7f7b3ffbc83cde81935&t=1610714025");
      }

      New_Email_Label.getChildByName("Email_Title").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Title;
      New_Email_Label.getChildByName("Email_Label").getChildByName("Email_Content").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Content;
      console.log("New_Email_Label.Email_Type:", New_Email_Label.Email_Type);
    }

    console.log("共", No_Read_Number, "封未读邮件");
    var No_Read_Number_Label = cc.instantiate(this.No_Read_Number);
    this.Canvas.addChild(No_Read_Number_Label);
    No_Read_Number_Label.setPosition(0, 360);
    No_Read_Number_Label.getComponent(cc.Label).string = "" + No_Read_Number + "封未读邮件";
  }
});

cc._RF.pop();