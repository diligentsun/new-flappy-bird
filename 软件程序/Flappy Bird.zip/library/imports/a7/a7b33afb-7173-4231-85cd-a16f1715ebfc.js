"use strict";
cc._RF.push(module, 'a7b33r7cXNCMYXNoW8XFev8', 'Grade_Show');
// resources/script/Game_Over/Grade_Show.js

"use strict";

//进行游戏结束后的结算
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Grade_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //调入金币显示的Label
    Fraction_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //调入分数显示的Label
    Background: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //调入分数显示的Lab

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    WeChat.Game_Settlement(Math.floor(Game_Local_Varible.Fraction / 4 * Game_Difficulty_Local_Varible.Difficulty_Ratio + Game_Local_Varible.Gold), Game_Local_Varible.Fraction / 2); //将分数传入云数据库中

    this.Grade_Show.string = "一共通过了" + Game_Local_Varible.Fraction / 2 + "根水管\n收获了" + Math.floor(Game_Local_Varible.Fraction / 4 * Game_Difficulty_Local_Varible.Difficulty_Ratio + Game_Local_Varible.Gold) + "枚金币"; //将Label更新

    this.Fraction_Show.string = Game_Local_Varible.Fraction / 2 * Game_Difficulty_Local_Varible.Difficulty_Ratio; //更新前端Label

    this.Background.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
  },
  start: function start() {},
  update: function update(dt) {}
});

cc._RF.pop();