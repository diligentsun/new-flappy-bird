"use strict";
cc._RF.push(module, '2e806coFMhP9JcwsZjNhFiV', 'Awards');
// resources/script/Email/Awards.js

"use strict";

var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Gold_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Diamond_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Compassoion_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Title_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Content_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Success_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //发送成功
    Fail_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已有重复邮件
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  Awards: function Awards() {
    WeChat.Loading_All_Email();
    var Title = this.Title_Label.getComponent(cc.Label).string;

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      if (Title === Email_Local_Variable.Email[i].Email_Title) {
        var Fail = cc.instantiate(this.Fail_Box);
        this.Canvas.addChild(Fail);
        Fail.setPosition(0, 0);
        return;
      }
    } //获取时间戳


    var Time = parseInt(new Date().getTime());
    var Gold = this.Gold_Label.getComponent(cc.Label).string;
    var Diamond = this.Diamond_Label.getComponent(cc.Label).string;
    var Compassion = this.Compassoion_Label.getComponent(cc.Label).string;
    var Content = this.Content_Label.getComponent(cc.Label).string;
    var Enclosure = false;
    if (Gold > 0 || Diamond > 0 || Compassion > 0) Enclosure = true;
    WeChat.Awards_Email(Time, Title, Content, Gold, Diamond, Compassion, Enclosure);
    console.log("已发送", Time, Title, Content, Gold, Diamond, Compassion, Enclosure);
    var Success = cc.instantiate(this.Success_Box);
    this.Canvas.addChild(Success);
    Success.setPosition(0, 0);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();