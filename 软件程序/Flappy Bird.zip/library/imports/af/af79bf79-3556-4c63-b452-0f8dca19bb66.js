"use strict";
cc._RF.push(module, 'af79b95NVZMY7RSD43KGbtm', 'Loading_Game');
// resources/script/Game_Start/Loading_Game.js

"use strict";

//加载游戏资源
cc.Class({
  "extends": cc.Component,
  properties: {
    Admin_Button: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  onLoad: function onLoad() {
    //是否为管理员
    console.log("管理员的值为", Global_Variable.Is_Admin);
  },
  start: function start() {},
  update: function update(dt) {
    this.Admin_Button.active = Global_Variable.Is_Admin;
  }
});

cc._RF.pop();