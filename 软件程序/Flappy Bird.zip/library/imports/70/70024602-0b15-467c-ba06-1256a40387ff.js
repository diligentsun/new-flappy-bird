"use strict";
cc._RF.push(module, '70024YCCxVGfLoGElakA4f/', 'Loading_Role');
// resources/script/Role/Loading_Role.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var User_Have_Character_Local_Varible = require('../Local_Variible/User_Have_Character_Local_Varible');

var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Character_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var self = this;
    User_Have_Character_Local_Varible.User_Have_Character = null;
    WeChat.Loading_Character();
    this._Is_Loading == true;
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && User_Have_Character_Local_Varible.User_Have_Character != null) {
      this.Loading_Character();
      this._Is_Loading = false;
    }
  },
  Loading_Image: function Loading_Image(self, Image_Path) {
    var _url = Image_Path;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.getChildByName("sprite").getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  Loading_Character: function Loading_Character() {
    //遍历User_Character_Information的表
    for (var i = 0; i < User_Have_Character_Local_Varible.User_Have_Character.length; i++) {
      //User_Character_Information放的是只有2个记录的小表(User_Have_Character)的信息
      var User_Character_Information = User_Have_Character_Local_Varible.User_Have_Character[i]; //User_Character_Number放的是Character的序号

      var User_Character_Number = User_Have_Character_Local_Varible.User_Have_Character[i].Character_Id; //判断用户是否有该小鸟
      //Global_Variable.openid是当前用户的openid

      if (Global_Variable.openid == User_Character_Information.openid) {
        // console.log("角色长度",User_Have_Character_Local_Varible.User_Have_Character.length);
        for (var j = 0; j < Shop_Character_Local_Varible.Shop_Character_User.length; j++) {
          if (User_Character_Number == Shop_Character_Local_Varible.Shop_Character_User[j].Character_Id) {
            var New_Character_Label = cc.instantiate(this.Character_Label);
            this.Character_View.addChild(New_Character_Label);
            this.Loading_Image(New_Character_Label, Shop_Character_Local_Varible.Shop_Character_User[j].Character_Head_Image);
            New_Character_Label.getChildByName("Character_Name").getComponent(cc.Label).string = "" + Shop_Character_Local_Varible.Shop_Character_User[j].Character_Name;
          }
        }
      }
    }
  }
});

cc._RF.pop();