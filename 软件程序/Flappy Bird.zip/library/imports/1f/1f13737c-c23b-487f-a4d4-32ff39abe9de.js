"use strict";
cc._RF.push(module, '1f137N8wjtIf6TUMv85q+ne', 'Game');
// resources/script/Game_Coming/Game.js

"use strict";

//控制游戏进程的JS脚本
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Bird: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //载入小鸟
    Background: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //载入背景
    Fraction: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //载入分数统计
    Waterpipe_Up: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入上方水管的预制体
    Waterpipe_Down: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入下方水管的预制体
    Fall_Gold: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //载入金币的预制体
    Is_Start: false,
    //控制游戏是否进行
    time: 0,
    //载入时间
    Time_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //载入倒计的Label
    daojishi: 3 //设置倒计时时间

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  onLoad: function onLoad() {
    Game_Local_Varible.Gold = 0;
    Game_Local_Varible.Fraction = 0;
    this.Bird.node.active = false;
    this.Background.getComponent(cc.Sprite).spriteFrame = Game_Local_Varible.Current_Map;
    cc.loader.load({
      url: 'https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/music/Background_Music.mp3?sign=386a04ae0314e518d75477e111518b42&t=1610622832',
      type: 'mp3'
    }, function (err, data) {
      console.log(data);
      cc.audioEngine.playMusic(data);
    }); //cc.audioEngine.play("https://7a63-zcx-6gbgdxdy254816b0-1304342947.tcb.qcloud.la/music/Background_Music.mp3?sign=386a04ae0314e518d75477e111518b42&t=1610622832", false,0.1);
  },
  start: function start() {
    this.Time_Label.string = 3; //  场景文本框为 显示3

    this.daojishi = 3;

    if (this.daojishi >= 0) {
      this.schedule(function () {
        // 计时器将每隔 1s 执行一次。
        this.DoSomething();

        if (this.daojishi == 0) {
          this.Time_Label.enabled = false;
          this.Is_Start = true;
          this.Bird.node.active = true;
        }
      }, 1);
    }
  },
  update: function update(dt) {
    this.time += 1;
    this.gainScore(); //每隔一段时间生成一个水管

    if (this.time % 100 == 0 && this.Is_Start) {
      this.spawnNewWaterpipe();
    } //如果小鸟飞出了界面，游戏结束，进行跳转。


    if (this.Bird.node.y > 2000) {
      cc.director.loadScene("Game_Over");
    }
  },
  //随机生成新的水管
  spawnNewWaterpipe: function spawnNewWaterpipe() {
    var Waterpipe_Up_randY = Math.random() * 400 + 800 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 200; //随机生成上方水管的坐标

    var Waterpipe_Down_randY = Waterpipe_Up_randY - Math.random() * 200 - 2000 + 200 * Game_Difficulty_Local_Varible.Difficulty_Ratio; //随机生成下方水管的坐标

    var Gold_randY = (Waterpipe_Up_randY + Waterpipe_Down_randY) / 2; //再水管中间生成金币的坐标

    var randX = 700; //生成水管的X坐标
    //生成新的水管和进行，并且把他们加入到画布中

    var New_Waterpipe_Up = cc.instantiate(this.Waterpipe_Up);
    this.node.addChild(New_Waterpipe_Up);
    New_Waterpipe_Up.setPosition(randX, Waterpipe_Up_randY);
    var New_Waterpipe_Down = cc.instantiate(this.Waterpipe_Down);
    this.node.addChild(New_Waterpipe_Down);
    New_Waterpipe_Down.setPosition(randX, Waterpipe_Down_randY);
    var New_Fall_Gold = cc.instantiate(this.Fall_Gold);
    this.node.addChild(New_Fall_Gold);
    New_Fall_Gold.setPosition(randX, Gold_randY);
  },
  gainScore: function gainScore() {
    // 更新 scoreDisplay Label 的文字
    this.Fraction.string = 'Score: ' + Game_Local_Varible.Fraction / 2;
  },
  DoSomething: function DoSomething() {
    // 倒计时算法
    if (this.daojishi >= 1) {
      this.daojishi = this.daojishi - 1;
      this.Time_Label.string = this.daojishi; //场景中文本框显示 
      //cc.log("daojishi=" + this.daojishi);
    }
  }
});

cc._RF.pop();