"use strict";
cc._RF.push(module, 'f95f53B521Flo6ICudvtupm', 'Email_Waring');
// resources/script/Email/Email_Waring.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    OPENID_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  Warning: function Warning() {
    var open_id = this.OPENID_Label.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "账号异常警告";
    var Content = "您的账号可能存在异常，如核实有违规行为，系统将对您作出惩罚";
    WeChat.Email_Warning(Time, Title, Content, open_id);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();