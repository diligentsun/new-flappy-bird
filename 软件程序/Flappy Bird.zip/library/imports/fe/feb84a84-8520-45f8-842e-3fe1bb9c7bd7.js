"use strict";
cc._RF.push(module, 'feb84qEhSBF+IQuP+G7nHvX', 'Email_Local_Variable');
// resources/script/Local_Variible/Email_Local_Variable.js

"use strict";

//邮箱的局部变量
module.exports = {
  //邮箱接收者
  Email: null
};

cc._RF.pop();