"use strict";
cc._RF.push(module, 'c2475IN0ABFuY27U34UTn1M', 'Cancel_Closure');
// resources/script/Account_Management/Cancel_Closure.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    User_Id_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //Openid

  },
  start: function start() {
    WeChat.Cancel_Closure;
  },
  on_btn_click: function on_btn_click() {
    var Openid = this.User_Id_Show.getComponent(cc.Label).string;
    WeChat.Cancel_Closure(Openid);
  } // update (dt) {},

});

cc._RF.pop();