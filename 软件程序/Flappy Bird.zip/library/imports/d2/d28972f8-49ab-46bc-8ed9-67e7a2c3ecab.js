"use strict";
cc._RF.push(module, 'd2897L4SatGvI7ZZ+eiw+yr', 'Jump_Scene');
// resources/script/Global_Function/Jump_Scene.js

"use strict";

//界面跳转
cc.Class({
  "extends": cc.Component,
  properties: {
    scene: ""
  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    cc.director.loadScene(this.scene);
  }
});

cc._RF.pop();