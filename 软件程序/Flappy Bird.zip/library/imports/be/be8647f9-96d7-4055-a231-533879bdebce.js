"use strict";
cc._RF.push(module, 'be864f5ltdAVaIxUzh5vevO', 'Accept');
// resources/script/Email/Accept.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Accept_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //成功接受提示信息
    Already_Accepted_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //已接受过提示信息
    No_Awards_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //没有奖励提示信息
    Email_Title: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //邮件标题
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  Accept: function Accept() {
    var self = this;
    var This_Title = this.Email_Title.getComponent(cc.Label).string;
    WeChat.Loading_Email();

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var Title = Email_Local_Variable.Email[i].Email_Title;

      if (This_Title === Title) {
        //当前点击的邮件
        console.log("当前邮件内容为2：", Email_Local_Variable.Email[i]);

        if (Email_Local_Variable.Email[i].Enclosure === false) {
          var Tip = cc.instantiate(this.No_Awards_Box);
          this.Canvas.addChild(Tip); //设置提示框位置

          Tip.setPosition(0, 0);
        } //是否已经接受过奖励
        else {
            if (Email_Local_Variable.Email[i].Accept === false) {
              //未曾接受奖励
              console.log("接受奖励");
              var Tip = cc.instantiate(this.Accept_Box);
              this.Canvas.addChild(Tip); //设置提示框位置

              Tip.setPosition(0, 0); //奖励参数设置

              var id = Email_Local_Variable.Email[i]._id;
              var Gold = Number(Email_Local_Variable.Email[i].Email_Gold);
              var Diamond = Number(Email_Local_Variable.Email[i].Email_Diamond);
              var Compassion = Number(Email_Local_Variable.Email[i].Email_Compassion); //接受奖励

              console.log("已经接受奖励", "金币：", Gold, "钻石：", Diamond, "体力：", Compassion);
              WeChat.Accept(id, Gold, Diamond, Compassion);
            } //已接受过奖励
            else {
                //弹出提示框
                var Tip = cc.instantiate(this.Already_Accepted_Box);
                this.Canvas.addChild(Tip); //设置提示框位置

                Tip.setPosition(0, 0);
              }
          }

        break;
      }
    }
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();