"use strict";
cc._RF.push(module, '8b8b2T/IZ1FAabnNpC4GbPK', 'Gold_Show_Action');
// resources/script/Game_Coming/Gold_Show_Action.js

"use strict";

//金币显示框运动逻辑
var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Gold_Show: {
      //金币显示框
      "default": null,
      type: cc.Label,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    console.log("Game_Local_Varible.Gold=" + Game_Local_Varible.Gold);
    this.Gold_Show.string = Game_Local_Varible.Gold; //改变金币显示数
  },
  start: function start() {},
  update: function update(dt) {
    this.Gold_Show.string = Game_Local_Varible.Gold; //改变金币显示数
  }
});

cc._RF.pop();