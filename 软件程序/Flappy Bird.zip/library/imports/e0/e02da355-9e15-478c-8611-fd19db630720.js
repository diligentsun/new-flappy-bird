"use strict";
cc._RF.push(module, 'e02daNVnhVHjIYR/RnbYwcg', 'Handle_Reported_User');
// resources/script/Account_Management/Handle_Reported_User.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Openid_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Account_Label: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    WeChat.Handle_Reported_User(this.Openid_Show.getComponent(cc.Label).string);
    this.Account_Label.destroy();
  }
});

cc._RF.pop();