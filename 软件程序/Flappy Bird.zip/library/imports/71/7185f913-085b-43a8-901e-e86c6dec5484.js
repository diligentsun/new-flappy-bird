"use strict";
cc._RF.push(module, '7185fkTCFtDqJAe6Gxt7FSE', 'Report_Local_Variable');
// resources/script/Local_Variible/Report_Local_Variable.js

"use strict";

//举报         
module.exports = {
  //举报列表
  openid: "",
  User_Name: ""
};

cc._RF.pop();