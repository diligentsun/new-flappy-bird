"use strict";
cc._RF.push(module, '5eeabuJZA1Gm6NyqsZ1kn6R', 'Closure_Tips');
// resources/script/Closure/Closure_Tips.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    Closure_Tips_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //封号信息显示

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    //封号提示
    this.Closure_Tips_Show.getComponent(cc.Label).string = "因为违规操作\n你的帐号已经封停\n将在" + Global_Variable.Unsealing_Time + "后\n解封";
  } // update (dt) {},

});

cc._RF.pop();