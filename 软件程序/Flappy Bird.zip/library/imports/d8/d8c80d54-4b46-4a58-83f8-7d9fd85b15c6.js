"use strict";
cc._RF.push(module, 'd8c801US0ZKWIP4fZ/YWxXG', 'Cloud_Image');
// resources/script/Global_Function/Cloud_Image.js

"use strict";

//改变图片
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    //图片所在路径
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //图片要加载的组件

  },
  // onLoad () {},
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge; //下载图片

    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();