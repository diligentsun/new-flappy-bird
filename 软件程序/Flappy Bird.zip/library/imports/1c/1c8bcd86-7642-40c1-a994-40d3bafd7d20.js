"use strict";
cc._RF.push(module, '1c8bc2GdkJAwamUQNO6/X0g', 'Email_Information');
// resources/script/Email/Email_Information.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Email_Information: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //邮件信息页面
    Email_Title: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //邮件标题
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  Open_Email: function Open_Email() {
    var self = this;
    var This_Title = this.Email_Title.getComponent(cc.Label).string;
    WeChat.Loading_Email();

    for (var i = 0; i < Email_Local_Variable.Email.length; i++) {
      var Title = Email_Local_Variable.Email[i].Email_Title;

      if (This_Title === Title) {
        //当前点击的邮件
        console.log("当前邮件内容为1：", Email_Local_Variable.Email[i]); //为当前邮件新建节点

        var New_Email_Information = cc.instantiate(this.Email_Information);
        this.Canvas.parent.parent.parent.parent.addChild(New_Email_Information); //设置节点即邮件信息界面的位置

        New_Email_Information.setPosition(0, 0); // if(Email_Local_Variable.Email[i].Enclosure===false)New_Email_Information.Determine.Button.interactable = false;
        //载入邮件信息

        var Time = new Date(parseInt(Email_Local_Variable.Email[i].Time)).toLocaleString().replace(/:\d{1,2}$/, ' ');
        New_Email_Information.getChildByName("Email_Title").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Title;
        New_Email_Information.getChildByName("Email_Content").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Content;
        New_Email_Information.getChildByName("Diamond").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Diamond;
        New_Email_Information.getChildByName("Gold").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Gold;
        New_Email_Information.getChildByName("Compassion").getComponent(cc.Label).string = "" + Email_Local_Variable.Email[i].Email_Compassion;
        New_Email_Information.getChildByName("Time").getComponent(cc.Label).string = "" + Time; //将邮件设为已读

        WeChat.Read(Email_Local_Variable.Email[i]._id);
        console.log("已将邮件设为已读");
        console.log("邮件id:", Email_Local_Variable.Email[i]._id);
        break;
      }
    }
  }
});

cc._RF.pop();