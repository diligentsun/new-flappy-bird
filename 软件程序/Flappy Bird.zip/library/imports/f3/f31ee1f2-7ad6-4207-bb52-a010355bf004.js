"use strict";
cc._RF.push(module, 'f31eeHyetZCB7tSoBA1W/AE', 'Buy_Character');
// Script/Buy_Character.js

"use strict";

var Alert = {
  btnOK: null,
  btnCancel: null,
  content: null,
  btnOKCallBack: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    Tip: cc.Label
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  show: function show() {
    this.node.active = true;
  },
  hide: function hide() {
    this.node.active = false;
  },
  onClickCancle: function onClickCancle() {
    this.hide();
  },
  onClickConfirm: function onClickConfirm() {
    this.hide();
  },
  setTip: function setTip(string) {
    this.Tip.String = string;
  } // update (dt) {},

});

cc._RF.pop();