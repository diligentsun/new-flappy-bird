"use strict";
cc._RF.push(module, 'ef9d6HOYUVHH5W82LluoCbX', 'Tip_Close');
// resources/script/Closure/Tip_Close.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    tip: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.tip.destroy();
  }
});

cc._RF.pop();