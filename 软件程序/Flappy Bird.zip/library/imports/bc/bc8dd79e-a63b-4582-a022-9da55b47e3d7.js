"use strict";
cc._RF.push(module, 'bc8ddeepjtFgqAinaVbR+PX', 'Read_All');
// resources/script/Email/Read_All.js

"use strict";

//下载邮箱列表
var _require = require('../Local_Variible/Email_Local_Variable'),
    Email = _require.Email;

var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {},
  Read_All: function Read_All() {
    //获取邮件列表
    WeChat.Loading_Email(); //将未读修改为已读

    WeChat.Read_All();
    console.log("邮件信息表", Email_Local_Variable.Email);
    cc.director.loadScene("Email");
  },
  start: function start() {}
});

cc._RF.pop();