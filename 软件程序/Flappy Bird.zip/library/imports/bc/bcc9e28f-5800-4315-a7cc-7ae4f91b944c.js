"use strict";
cc._RF.push(module, 'bcc9eKPWABDFafMeuT5G5RM', 'Loading_Base_Resouce');
// resources/script/Global_Function/Loading_Base_Resouce.js

"use strict";

//加载基础资源
cc.Class({
  "extends": cc.Component,
  properties: {
    Diamond_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //导入钻石
    Gold_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    //导入金币
    Compassion_Show: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //导入爱心

  },
  onLoad: function onLoad() {
    WeChat.Loading_Resources();
  },
  start: function start() {},
  //
  update: function update(dt) {
    //加载基础资源
    // this.schedule(function() { // 计时器将每隔 1s 执行一次。
    // 	WeChat.Loading_Resources();
    // }, 1);
    //更新界面上的基础资源
    if (Global_Variable.Gold != null) {
      this.Gold_Show.string = Global_Variable.Gold;
      this.Diamond_Show.string = Global_Variable.Diamond;
      this.Compassion_Show.string = Global_Variable.Compassion;
    }
  }
});

cc._RF.pop();