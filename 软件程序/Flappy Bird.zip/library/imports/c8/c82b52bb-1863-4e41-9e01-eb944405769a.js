"use strict";
cc._RF.push(module, 'c82b5K7GGNOQZ4B65REBXaa', 'Jump_DIfficulty');
// resources/script/Local_Variible/Jump_DIfficulty.js

"use strict";

//跳转难度界面
cc.Class({
  "extends": cc.Component,
  properties: {
    Choose_Difficulty: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    },
    //难度框		
    Jump_Jump: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    } //点击图片

  },
  onLoad: function onLoad() {
    this.Choose_Difficulty.node.active = false; // 初始化跳跃动作  

    this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchMove, this);
  },
  onDestroy: function onDestroy() {// 取消键盘输入监听
  },
  start: function start() {},
  update: function update(dt) {},
  onTouchMove: function onTouchMove(event) {
    //管理Jump图片
    this.Jump_Jump.node.active = false; //打开难度选择框

    this.Choose_Difficulty.node.active = true;
  }
});

cc._RF.pop();