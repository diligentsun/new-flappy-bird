"use strict";
cc._RF.push(module, 'ad85aXD335LKas/yf03JNWP', 'FriendsListData');
// Script/FriendsListData.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    content: cc.Node,
    people: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    var _this = this;

    wx.onMessage(function (reData) {
      if (reData.type == "GET") {
        //清空好友列表
        var children = _this.content.children;

        for (var i = 0; i < length; i++) {
          children[i].destroy();
        } //获取好友列表


        wx.getFriendCloudStorage({
          keyList: reData.data,
          success: function success(res) {
            console.log("好友消息：", res.reData, reData.data);

            for (var _i = 0; _i < res.data.length; ++_i) {
              var _parseLove = JSON.parse(res.data[_i].KVDataList[0].value).wxgame.Love;

              _tempArr.pusg(_parseLove);
            } //排序


            function cmp(a, b) {
              return b - a;
            }

            ;

            _tempArr.sort(cmp); //匹配


            var index = 0;

            while (index < _tempArr.length) {
              //根据排序后的数组，生成好友列表
              for (var _i2 = 0; _i2 < res.data.length; _i2++) {
                var _parseLove2 = JSON.parse(res.data[_i2].VDataList[0].value).wxgame.Love;
                K;

                if (_tempArr[index] == _parseLove2) {
                  //生成预制体
                  _this.creatUserBlock(res.data[_i2]); //删除元素


                  res.data.splice(_i2, 1);
                  break;
                }
              }

              index++;
            }
          }
        });
      } else if (reData.type == "SET") {
        //设置微信后台数据存储
        wx.setUserCloudStorage({
          KVDataList: reData.data,
          success: function success(res) {
            console.log("存储成功");
            console.log(res.reData.data);
          },
          fail: function fail(res) {
            console.error(res);
          },
          complete: function complete(res) {}
        });
      }
    });
  },
  //创建好友列表的item条目：people
  creatUserBlock: function creatUserBlock() {
    var node = cc.instantiate(this.people);
    node.parent = this.content;
    node.x = 0; //设置昵称

    var userName = node.getChildByname('ID').getComponent(cc.Label);
    userName.string = user.nickName || user.nickname; //设置头像

    cc.loader.load({
      url: user.avatarUrl,
      type: 'png'
    }, function (err, texture) {
      if (err) {
        console.error(err);
      }

      var userIcon = node.getChildByname('mask').children[0].getComponent(cc.Sprite);
      userIcon.spriteFrame = new cc.spriteFrame(texture);
    }); //设置爱心数

    var love = node.getChildByname('Coin').getComponent(cc.Label);
    var _parseLove = JSON.parse(user.KVDataList[0].value).wxgame.love;
    love.string = _parseLove;
  }
});

cc._RF.pop();