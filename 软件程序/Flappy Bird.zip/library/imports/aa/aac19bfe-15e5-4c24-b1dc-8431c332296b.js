"use strict";
cc._RF.push(module, 'aac19v+FeVMJLHchDHDMilr', 'Buy_Character_Sure');
// resources/script/Shop/Buy_Character_Sure.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Shop_Character_Local_Varible = require('../Local_Variible/Shop_Character_Local_Varible');

var User_Have_Character_Local_Varible = require('../Local_Variible/User_Have_Character_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Reminder_Box: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    Character_Id: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Price_Label: {
      "default": null,
      type: cc.Label,
      serialzable: true
    },
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  on_btn_click: function on_btn_click() {
    WeChat.Loading_Shop_Character(); //读取当前点击的角色金币

    var This_Information_Price = this.Price_Label.getComponent(cc.Label).string; //读取当前点击的角色信息

    var This_Information = this.Character_Id.getComponent(cc.Label).string; //读取用户拥有的金币

    var User_Gold = Global_Variable.Gold;
    var New_Reminder_Box = cc.instantiate(this.Reminder_Box);
    this.Canvas.parent.parent.addChild(New_Reminder_Box);
    New_Reminder_Box.setPosition(0, -400);
    var flag = 0;

    for (var i = 0; i < User_Have_Character_Local_Varible.User_Have_Character.length; i++) {
      //读取用户拥有的角色信息
      var User_Character_Information = User_Have_Character_Local_Varible.User_Have_Character[i]; //判断已经拥有角色
      //判断是否是本机用户

      if (This_Information == User_Character_Information.Character_Id && Global_Variable.openid == User_Character_Information.openid) {
        New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "您已拥有该商品";
        flag = 1;
        break; //输出已经拥有
      }
    }

    console.log("小鸟价格", This_Information_Price);
    console.log("用户金币数", User_Gold); //判断用户金币是否购买的起当前小鸟       

    if (User_Gold < This_Information_Price && flag == 0) {
      New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "金币不足购买商品";
    }

    if (User_Gold >= This_Information_Price && flag == 0) {
      New_Reminder_Box.getChildByName("Reminder_Text").getComponent(cc.Label).string = "购买成功该商品";
      User_Gold = User_Gold - This_Information_Price;
      WeChat.Buy_Character_Update(User_Gold, This_Information);
    }
  },
  update: function update(dt) {}
});

cc._RF.pop();