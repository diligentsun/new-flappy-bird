"use strict";
cc._RF.push(module, '35cf1epWixAa5295ytVUj/q', 'People');
// Script/People.js

"use strict";

var Alert = {
  btnOK: null,
  btnCancel: null,
  content: null,
  btnOKCallBack: null
};
cc.Class({
  "extends": cc.Component,
  properties: {
    alert: cc.Prefab
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {}, 
  start: function start() {},
  onClickAlert: function onClickAlert() {
    var node = cc.instantiate(this.alert);
    this.node.addChild(node);
    node = node.getComponent('ReportAlert');
    node.setTip('确定举报该好友吗？');
  } // update (dt) {},

});

cc._RF.pop();