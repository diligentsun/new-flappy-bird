"use strict";
cc._RF.push(module, 'b83b6vn//NP5JtzLaVI6saD', 'Report_Cancel');
// resources/script/Rank/Report_Cancel.js

"use strict";

//取消会议记录
cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();