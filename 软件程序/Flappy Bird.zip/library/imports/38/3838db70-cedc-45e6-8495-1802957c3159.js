"use strict";
cc._RF.push(module, '3838dtwztxF5oSVGAKVfDFZ', 'Report_Confirm');
// resources/script/Rank/Report_Confirm.js

"use strict";

//确定举报
var Report_Local_Variable = require('Report_Local_Variable'); //const Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');


cc.Class({
  "extends": cc.Component,
  properties: {
    Report_Content: {
      "default": null,
      type: cc.Label,
      serialzable: true
    } //举报框

  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //载入举报人的信息
    console.log("点到了吗??");
    var Reported_User_Openid = Report_Local_Variable.openid;
    var Reported_User_Name = Report_Local_Variable.User_Name;
    var Report_Text = this.Report_Content.getComponent(cc.Label).string; //获取时间戳

    var Time = parseInt(new Date().getTime());
    var Title = "关于对" + Reported_User_Name + "的举报";
    var Content = "系统已收到您的举报，请等待处理			举报原因：" + Report_Text;
    WeChat.Email_Report_And_Appeal(Time, Title, Content);
    console.log("被举报人OPENID", Reported_User_Openid, "举报内容为", Report_Text); //上传举报信息

    WeChat.Uploading_Reported_Information(Report_Local_Variable.openid, Report_Text);
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();