"use strict";
cc._RF.push(module, 'fcaa05Eja5EDING8XS/HnT8', 'Account_Management_Local_Variable');
// resources/script/Local_Variible/Account_Management_Local_Variable.js

"use strict";

//游戏难度系数的局部变量
module.exports = {
  //全部玩家角色表
  All_Users_Information: null,
  Report_User_List: null,
  Reported_Users_Information: null
};

cc._RF.pop();