"use strict";
cc._RF.push(module, 'ee59bZAOEhJU4jQjub2Eosx', 'User_Have_Character_Local_Varible');
// resources/script/Local_Variible/User_Have_Character_Local_Varible.js

"use strict";

module.exports = {
  User_Have_Character: null
};

cc._RF.pop();