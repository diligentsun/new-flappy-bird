"use strict";
cc._RF.push(module, '85c4fRDZ2lP6YFLrKdOCnzk', 'Waterpipe_Action');
// resources/script/Game_Coming/Waterpipe_Action.js

"use strict";

//水管移动逻辑
var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

var Game_Local_Varible = require('Game_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    Move_Speed: 0,
    //水平移动速度
    x: 0,
    //x坐标
    y: 0,
    //y坐标
    Move_Distance: 0,
    //移动的距离
    Is_Move: false,
    //是否垂直移动
    Is_Up: true //是否向上移动 ，如果为否，就会向下移动

  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    var manager = cc.director.getCollisionManager(); //改变碰撞体积

    manager.enabled = true; //manager.enabledDebugDraw = true;

    this.Is_Move = Game_Difficulty_Local_Varible.Is_Difficulty; //如果游戏难度为最难，则则不能上下移动

    if (Math.random() > 0.5) {
      this.Is_Up = false; //决定上下移动还是左右移动
    }
  },
  start: function start() {},
  update: function update(dt) {
    this.node.x -= 5 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 2; //水平移动水管

    if (this.node.x < -600) {
      //如果水管已出屏幕，分数加一，毁灭掉水管
      Game_Local_Varible.Fraction += 1;
      this.node.destroy();
    }

    if (this.Is_Move == true && this.node.x < 0) {
      //如果水管能够上下移动，添加水管的上下移动距离
      this.Move_Distance = 50;
      this.Is_Move = false;
    }

    if (this.Move_Distance > 0 && this.Is_Up == true) {
      //使水管上下移动
      this.node.y += 5;
      this.Move_Distance -= 5;
    } else if (this.Move_Distance > 0 && this.Is_Up == false) {
      this.node.y -= 5;
      this.Move_Distance -= 5;
    }
  }
});

cc._RF.pop();