"use strict";
cc._RF.push(module, '85f41MkxtRAJbqu2YeY3nrd', 'Gold_Action');
// resources/script/Game_Coming/Gold_Action.js

"use strict";

//金币运动函数
var Game_Local_Varible = require('Game_Local_Varible');

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible');

cc.Class({
  "extends": cc.Component,
  properties: {
    coinAudio: {
      "default": null,
      type: cc.AudioClip
    },
    Move_Speed: 0,
    //金币的移动速度
    x: 0,
    //金币x坐标
    y: 0,
    //金币y坐标
    Gold_Show: {
      //金币的预制体
      "default": null,
      type: cc.Prefab,
      serialzable: true
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    //打开碰撞属性
    var manager = cc.director.getCollisionManager();
    manager.enabled = true; //manager.enabledDebugDraw = true;
  },
  start: function start() {},
  update: function update(dt) {
    //通过更新金币的x坐标，让金币前进
    this.node.x -= 5 + Game_Difficulty_Local_Varible.Difficulty_Ratio * 2; //如果金币超出界面，毁灭掉金币

    if (this.node.x < -600) {
      this.node.destroy();
    }
  },
  //碰撞判断	
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log("other.name = ", other.node.name, other.node.group, other.node.groupIndex);

    if (other.node.groupIndex === 0) {
      //如果和小鸟碰撞
      var Gold_Show_Label = cc.instantiate(this.Gold_Show); //加入金币显示框

      Game_Local_Varible.Gold += 1;
      this.node.destroy(); //移除该金币

      this.node.parent.addChild(Gold_Show_Label);
      Gold_Show_Label.setPosition(400, 750);
      cc.audioEngine.playEffect(this.coinAudio, false, 0.6);
    }
  }
});

cc._RF.pop();