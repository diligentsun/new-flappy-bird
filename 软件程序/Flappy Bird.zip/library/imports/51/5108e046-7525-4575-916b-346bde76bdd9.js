"use strict";
cc._RF.push(module, '5108eBGdSVFdZFrNGvedr3Z', 'Appeal_Cancel');
// resources/script/Account_Management/Appeal_Cancel.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {},
  on_btn_click: function on_btn_click() {
    this.node.destroy();
  } // update (dt) {},

});

cc._RF.pop();