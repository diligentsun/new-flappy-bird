"use strict";
cc._RF.push(module, '3313dWvxnZAQ4hjAepWc3E+', 'Change_Difficult');
// resources/script/Game_Start/Change_Difficult.js

"use strict";

var Game_Difficulty_Local_Varible = require('Game_Difficulty_Local_Varible'); //改变游戏难度


cc.Class({
  "extends": cc.Component,
  properties: {
    Difficulty: "" //声明游戏难度

  },
  start: function start() {},
  // update (dt) {},
  on_btn_click: function on_btn_click() {
    //根据不同的游戏难度，调整难度系数
    if (this.Difficulty == 'Easy') {
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 0.5;
      Game_Difficulty_Local_Varible.Is_Difficulty = false;
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 1;
    } else if (this.Difficulty == 'Mid') {
      Game_Difficulty_Local_Varible.Is_Difficulty = false;
    } else if (this.Difficulty == 'Difficulty') {
      Game_Difficulty_Local_Varible.Difficulty_Ratio = 1;
      Game_Difficulty_Local_Varible.Is_Difficulty = true;
    }
  }
});

cc._RF.pop();