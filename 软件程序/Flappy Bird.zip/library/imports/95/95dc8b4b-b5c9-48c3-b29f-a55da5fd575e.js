"use strict";
cc._RF.push(module, '95dc8tLtclIw7KfpV2l/Vde', 'Shop_Character_Local_Varible');
// resources/script/Local_Variible/Shop_Character_Local_Varible.js

"use strict";

module.exports = {
  Shop_Character_User: null
};

cc._RF.pop();