"use strict";
cc._RF.push(module, 'fbdaeLWsLlOfJtmSiczS30X', 'Delete_Read');
// resources/script/Email/Delete_Read.js

"use strict";

//下载邮箱列表
var Email_Local_Variable = require('../Local_Variible/Email_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {},
  Delete_Read: function Delete_Read() {
    //删除已读邮件
    WeChat.Delete_Read(); //获取邮件列表

    WeChat.Loading_Email();
    console.log("邮件信息表", Email_Local_Variable.Email);
    cc.director.loadScene("Email");
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();