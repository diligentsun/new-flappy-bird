"use strict";
cc._RF.push(module, '0dac3D7735OkZ6XLHfugRmJ', 'Game_Local_Varible');
// resources/script/Local_Variible/Game_Local_Varible.js

"use strict";

//游戏界面的局部变量
module.exports = {
  //分数统计
  Fraction: 0,
  //获得金币
  Gold: 0,
  //当前地图
  Current_Map: {
    "default": null,
    type: cc.SpriteFrame,
    serialzable: true
  }
};

cc._RF.pop();