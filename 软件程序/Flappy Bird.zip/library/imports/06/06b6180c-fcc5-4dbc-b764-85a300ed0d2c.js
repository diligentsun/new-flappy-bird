"use strict";
cc._RF.push(module, '06b61gM/MVNvLdkhaMA7Q0s', 'FriendsView');
// Script/FriendsView.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    WXSubContextView: {
      "default": null,
      type: cc.Node,
      serializable: true
    }
  },
  start: function start() {
    this.subContextView = this.WXSubContextView.getComponent(cc.WXSubContextView);
  },
  showFriends: function showFriends() {
    console.log("显示好友列表"); //获取时间戳

    var updateTime = new Date().valueOf(); //获取好友列表上对应的信息

    var getArr = new Array();
    getArr.push("love");
    var openDataContext = wx.getOpenDataContext();
    openDataContext.postMessage({
      type: "GET",
      data: getArr,
      time: updateTime
    });
    this.subContextView.enabled = true;
    this.WXSubContextView.active = true;
    this.subContextView.update();
  },
  sendMsgToFriendsListdata: function sendMsgToFriendsListdata() {
    console.log("sendMsg"); //时间戳

    var updateTime = new Date().valueOf();
    var value = JSON.stringfy({
      "wxgame": {
        "love": Math.floor(10000 * Math.random()),
        "update_time": updateTime
      }
    });
    var arr = new Array();
    arr.push({
      key: "love",
      value: _value
    });
    var openDataContext = wx.getOpenDataContext();
    openDataContext.postMessage({
      type: "SET",
      data: arr,
      timer: updateTime
    });
  }
});

cc._RF.pop();