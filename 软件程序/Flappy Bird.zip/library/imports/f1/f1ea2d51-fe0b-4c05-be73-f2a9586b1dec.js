"use strict";
cc._RF.push(module, 'f1ea21R/gtMBb5z8qlYax3s', 'Loading_All_Users');
// resources/script/Account_Management/Loading_All_Users.js

"use strict";

var Account_Management_Local_Variable = require('Account_Management_Local_Variable');

cc.Class({
  "extends": cc.Component,
  properties: {
    Account_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //账号管理预制体
    Account_Managent_View: {
      "default": null,
      type: cc.Node,
      serialzable: true
    },
    //排名框
    _Is_Loading: true
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this._Is_Loading = true;
    Account_Management_Local_Variable.All_Users_Information = null;
    WeChat.Loading_All_User();
    console.log("输出账号个数", Account_Management_Local_Variable.All_Users_Information.length);
  },
  start: function start() {},
  update: function update(dt) {
    if (this._Is_Loading && Account_Management_Local_Variable.All_Users_Information != null) {
      this.Loading_All_User();
      this._Is_Loading = false;
    }
  },
  Loading_All_User: function Loading_All_User() {
    for (var i = 0; i < Account_Management_Local_Variable.All_Users_Information.length; i++) {
      console.log("1");
      var New_Account_Label = cc.instantiate(this.Account_Label);
      this.Account_Managent_View.addChild(New_Account_Label);
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("User_Id_Label").getChildByName("User_Id_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].openid;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Account_Status_Label").getChildByName("Account_Status_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].User_state;
      New_Account_Label.getChildByName("Account_Management_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Label").getChildByName("Cumulative_Number_Of_Reported_Cases_Show").getComponent(cc.Label).string = "" + Account_Management_Local_Variable.All_Users_Information[i].Reported_Count;
    }
  }
});

cc._RF.pop();