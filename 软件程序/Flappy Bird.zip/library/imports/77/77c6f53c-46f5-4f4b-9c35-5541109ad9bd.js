"use strict";
cc._RF.push(module, '77c6fU8RvVPS5w1VUEQmtm9', 'Game_Difficulty_Local_Varible');
// resources/script/Local_Variible/Game_Difficulty_Local_Varible.js

"use strict";

//游戏难度系数的局部变量
module.exports = {
  //游戏难度系数
  Difficulty_Ratio: 1,
  //是否是困难模式
  Is_Difficulty: false
};

cc._RF.pop();