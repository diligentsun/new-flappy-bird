"use strict";
cc._RF.push(module, '566674OTJxDC6nbV9VVDq+a', 'Appeal_User');
// resources/script/Account_Management/Appeal_User.js

"use strict";

//弹出申诉框
cc.Class({
  "extends": cc.Component,
  properties: {
    Appeal_Label: {
      "default": null,
      type: cc.Prefab,
      serialzable: true
    },
    //申诉框
    Canvas: {
      "default": null,
      type: cc.Node,
      serialzable: true
    } //玩家框节点

  },
  start: function start() {},
  on_btn_click: function on_btn_click() {
    //创建申诉信息框
    var New_Appeal_Label = cc.instantiate(this.Appeal_Label);
    this.Canvas.addChild(New_Appeal_Label);
    New_Appeal_Label.setPosition(0, 0);
  } // update (dt) {},

});

cc._RF.pop();