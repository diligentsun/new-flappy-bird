let moduleMap = {
'assets/internal/index.js' () { return require('assets/internal/index.js') },
'assets/main/index.js' () { return require('assets/main/index.js') },
'assets/internal/config.27aeb.js' () { return require('assets/internal/config.27aeb.js'); },
'assets/internal/import/02/0275e94c-56a7-410f-bd1a-fc7483f7d14a.7871f.js' () { return require('assets/internal/import/02/0275e94c-56a7-410f-bd1a-fc7483f7d14a.7871f.js'); },
'assets/internal/import/14/144c3297-af63-49e8-b8ef-1cfa29b3be28.8a866.js' () { return require('assets/internal/import/14/144c3297-af63-49e8-b8ef-1cfa29b3be28.8a866.js'); },
'assets/internal/import/28/2874f8dd-416c-4440-81b7-555975426e93.20630.js' () { return require('assets/internal/import/28/2874f8dd-416c-4440-81b7-555975426e93.20630.js'); },
'assets/internal/import/2a/2a296057-247c-4a1c-bbeb-0548b6c98650.9314f.js' () { return require('assets/internal/import/2a/2a296057-247c-4a1c-bbeb-0548b6c98650.9314f.js'); },
'assets/internal/import/2a/2a7c0036-e0b3-4fe1-8998-89a54b8a2bec.95fe9.js' () { return require('assets/internal/import/2a/2a7c0036-e0b3-4fe1-8998-89a54b8a2bec.95fe9.js'); },
'assets/internal/import/30/30682f87-9f0d-4f17-8a44-72863791461b.15c3b.js' () { return require('assets/internal/import/30/30682f87-9f0d-4f17-8a44-72863791461b.15c3b.js'); },
'assets/internal/import/3a/3a7bb79f-32fd-422e-ada2-96f518fed422.75131.js' () { return require('assets/internal/import/3a/3a7bb79f-32fd-422e-ada2-96f518fed422.75131.js'); },
'assets/internal/import/46/466d4f9b-e5f4-4ea8-85d5-3c6e9a65658a.5b6af.js' () { return require('assets/internal/import/46/466d4f9b-e5f4-4ea8-85d5-3c6e9a65658a.5b6af.js'); },
'assets/internal/import/6d/6d91e591-4ce0-465c-809f-610ec95019c6.ed67b.js' () { return require('assets/internal/import/6d/6d91e591-4ce0-465c-809f-610ec95019c6.ed67b.js'); },
'assets/internal/import/6f/6f801092-0c37-4f30-89ef-c8d960825b36.85108.js' () { return require('assets/internal/import/6f/6f801092-0c37-4f30-89ef-c8d960825b36.85108.js'); },
'assets/internal/import/a1/a153945d-2511-4c14-be7b-05d242f47d57.ec423.js' () { return require('assets/internal/import/a1/a153945d-2511-4c14-be7b-05d242f47d57.ec423.js'); },
'assets/internal/import/c0/c0040c95-c57f-49cd-9cbc-12316b73d0d4.7bc0d.js' () { return require('assets/internal/import/c0/c0040c95-c57f-49cd-9cbc-12316b73d0d4.7bc0d.js'); },
'assets/internal/import/cf/cf7e0bb8-a81c-44a9-ad79-d28d43991032.0953e.js' () { return require('assets/internal/import/cf/cf7e0bb8-a81c-44a9-ad79-d28d43991032.0953e.js'); },
'assets/internal/import/e0/e02d87d4-e599-4d16-8001-e14891ac6506.fd1a0.js' () { return require('assets/internal/import/e0/e02d87d4-e599-4d16-8001-e14891ac6506.fd1a0.js'); },
'assets/internal/import/ec/eca5d2f2-8ef6-41c2-bbe6-f9c79d09c432.380a4.js' () { return require('assets/internal/import/ec/eca5d2f2-8ef6-41c2-bbe6-f9c79d09c432.380a4.js'); },
'assets/internal/import/f1/f18742d7-56d2-4eb5-ae49-2d9d710b37c8.fe018.js' () { return require('assets/internal/import/f1/f18742d7-56d2-4eb5-ae49-2d9d710b37c8.fe018.js'); },
'assets/main/config.fea8a.js' () { return require('assets/main/config.fea8a.js'); },
'assets/main/import/13/133c5f30-106e-494c-b127-732d823bd90f.7871f.js' () { return require('assets/main/import/13/133c5f30-106e-494c-b127-732d823bd90f.7871f.js'); },
'assets/main/import/1b/1bf3d5fb-b42d-4811-9f9e-c72714d62c40.7871f.js' () { return require('assets/main/import/1b/1bf3d5fb-b42d-4811-9f9e-c72714d62c40.7871f.js'); },
'assets/main/import/22/224942e5-5035-46e4-a307-1f7fc204c047.30d3e.js' () { return require('assets/main/import/22/224942e5-5035-46e4-a307-1f7fc204c047.30d3e.js'); },
'assets/main/import/57/57a22b32-f6b6-4bf5-a3ad-cd55ebee110f.6be08.js' () { return require('assets/main/import/57/57a22b32-f6b6-4bf5-a3ad-cd55ebee110f.6be08.js'); },
'assets/main/import/a2/a23235d1-15db-4b95-8439-a2e005bfff91.43d76.js' () { return require('assets/main/import/a2/a23235d1-15db-4b95-8439-a2e005bfff91.43d76.js'); },
'assets/main/import/b4/b4b298ad-1b61-4b90-9b2d-8591587bdbda.7871f.js' () { return require('assets/main/import/b4/b4b298ad-1b61-4b90-9b2d-8591587bdbda.7871f.js'); },
'assets/main/import/b4/b4f939c2-ec54-4738-a8c0-23f3e68b563f.41791.js' () { return require('assets/main/import/b4/b4f939c2-ec54-4738-a8c0-23f3e68b563f.41791.js'); },
'assets/main/import/bd/bd8a2296-d5da-4206-bc5c-1d7043dead4b.7871f.js' () { return require('assets/main/import/bd/bd8a2296-d5da-4206-bc5c-1d7043dead4b.7871f.js'); },
'assets/main/import/c7/c7f39b7d-40d5-434f-82a2-922eb6c0a7d0.de8ee.js' () { return require('assets/main/import/c7/c7f39b7d-40d5-434f-82a2-922eb6c0a7d0.de8ee.js'); },
'assets/main/import/ed/edd215b9-2796-4a05-aaf5-81f96c9281ce.7871f.js' () { return require('assets/main/import/ed/edd215b9-2796-4a05-aaf5-81f96c9281ce.7871f.js'); },
'assets/main/import/f1/f110c42e-968b-4c24-9da4-2ea461304024.5da53.js' () { return require('assets/main/import/f1/f110c42e-968b-4c24-9da4-2ea461304024.5da53.js'); },
'assets/main/import/f6/f67c9e01-de99-41b0-9737-908a57422909.81f70.js' () { return require('assets/main/import/f6/f67c9e01-de99-41b0-9737-908a57422909.81f70.js'); },
'assets/main/import/ff/ff0e91c7-55c6-4086-a39f-cb6e457b8c3b.68f7d.js' () { return require('assets/main/import/ff/ff0e91c7-55c6-4086-a39f-cb6e457b8c3b.68f7d.js'); },
// tail

};

window.__cocos_require__ = function (moduleName) {
    let func = moduleMap[moduleName];
    if (!func) {
        throw new Error(`cannot find module ${moduleName}`);
    }
    return func();
};