let moduleMap = {
'src/assets/cloud/cloudConfig.js' () { return require('src/assets/cloud/cloudConfig.js') },
'src/assets/cloud/tcbjs/adapter.js' () { return require('src/assets/cloud/tcbjs/adapter.js') },
'src/assets/cloud/tcbjs/tcbjs.js' () { return require('src/assets/cloud/tcbjs/tcbjs.js') },
'assets/internal/index.js' () { return require('assets/internal/index.js') },
'assets/resources/index.js' () { return require('assets/resources/index.js') },
'assets/start-scene/index.js' () { return require('assets/start-scene/index.js') },
// tail
};

window.__cocos_require__ = function (moduleName) {
    let func = moduleMap[moduleName];
    if (!func) {
        throw new Error(`cannot find module ${moduleName}`);
    }
    return func();
};