
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Cloud_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd8c801US0ZKWIP4fZ/YWxXG', 'Cloud_Image');
// Script/Cloud_Image.js

"use strict";

//加载图片
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDbG91ZF9JbWFnZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIklhbWdlIiwiQkdTcHJpdGUiLCJ0eXBlIiwiU3ByaXRlIiwic2VyaWFsemFibGUiLCJvbkxvYWQiLCJzZWxmIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJjb25zb2xlIiwibG9nIiwiZ2V0Q29tcG9uZW50Iiwic3ByaXRlRnJhbWUiLCJ1cGRhdGUiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDVEMsSUFBQUEsS0FBSyxFQUFFLEVBREU7QUFFWkMsSUFBQUEsUUFBUSxFQUFDO0FBQ1QsaUJBQVEsSUFEQztBQUVUQyxNQUFBQSxJQUFJLEVBQUNOLEVBQUUsQ0FBQ08sTUFGQztBQUdUQyxNQUFBQSxXQUFXLEVBQUM7QUFISDtBQUZHLEdBSFA7QUFhTEMsRUFBQUEsTUFBTSxFQUFDLGtCQUFXO0FBQ3BCLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsSUFBSSxHQUFDRCxJQUFJLENBQUNOLEtBQWQ7QUFDQUosSUFBQUEsRUFBRSxDQUFDWSxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZEwsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVNTLEdBQVQsRUFBYUMsT0FBYixFQUFxQkMsSUFBckIsRUFBMEI7QUFDM0IsVUFBSUMsS0FBSyxHQUFDLElBQUlsQixFQUFFLENBQUNtQixXQUFQLENBQW1CSCxPQUFuQixDQUFWOztBQUNBLFVBQUdELEdBQUgsRUFBTztBQUNOSyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CTixHQUFuQjtBQUNBOztBQUNETCxNQUFBQSxJQUFJLENBQUNMLFFBQUwsQ0FBY2lCLFlBQWQsQ0FBMkJ0QixFQUFFLENBQUNPLE1BQTlCLEVBQXNDZ0IsV0FBdEMsR0FBa0RMLEtBQWxEO0FBRUEsS0FWRDtBQVdELEdBM0JRO0FBNkJMTSxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYSxDQUFFO0FBN0JsQixDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+WKoOi9veWbvueJh1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICBJYW1nZTogXCJcIixcclxuXHQgICBCR1Nwcml0ZTp7XG5cdFx0ICBkZWZhdWx0Om51bGwsXG5cdFx0ICB0eXBlOmNjLlNwcml0ZSxcblx0XHQgIHNlcmlhbHphYmxlOnRydWUsXG5cdCAgIH0sXG4gICAgfSxcblxuXG4gICAgb25Mb2FkOmZ1bmN0aW9uKCkge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRsZXQgX3VybD1zZWxmLklhbWdlO1xuXHRcdGNjLmxvYWRlci5sb2FkKHtcblx0XHRcdHVybDpfdXJsLFxuXHRcdFx0dHlwZTonanBnJ1xuXHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XG5cdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xuXHRcdFx0aWYoZXJyKXtcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xuXHRcdFx0fVxuXHRcdFx0c2VsZi5CR1Nwcml0ZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcblx0XHRcdFxuXHRcdH0pXG59LFxuXG4gICAgdXBkYXRlOiBmdW5jdGlvbihkdCkge30sXHJcblx0XG59KTtcbiJdfQ==