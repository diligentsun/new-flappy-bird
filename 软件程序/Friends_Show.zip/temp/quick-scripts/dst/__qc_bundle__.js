
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/Cloud_Image');
require('./assets/Script/Loading_Friends');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Cloud_Image.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd8c801US0ZKWIP4fZ/YWxXG', 'Cloud_Image');
// Script/Cloud_Image.js

"use strict";

//加载图片
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDbG91ZF9JbWFnZS5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsIklhbWdlIiwiQkdTcHJpdGUiLCJ0eXBlIiwiU3ByaXRlIiwic2VyaWFsemFibGUiLCJvbkxvYWQiLCJzZWxmIiwiX3VybCIsImxvYWRlciIsImxvYWQiLCJ1cmwiLCJlcnIiLCJ0ZXh0dXJlIiwidGVzdCIsImZyYW1lIiwiU3ByaXRlRnJhbWUiLCJjb25zb2xlIiwibG9nIiwiZ2V0Q29tcG9uZW50Iiwic3ByaXRlRnJhbWUiLCJ1cGRhdGUiLCJkdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDVEMsSUFBQUEsS0FBSyxFQUFFLEVBREU7QUFFWkMsSUFBQUEsUUFBUSxFQUFDO0FBQ1QsaUJBQVEsSUFEQztBQUVUQyxNQUFBQSxJQUFJLEVBQUNOLEVBQUUsQ0FBQ08sTUFGQztBQUdUQyxNQUFBQSxXQUFXLEVBQUM7QUFISDtBQUZHLEdBSFA7QUFhTEMsRUFBQUEsTUFBTSxFQUFDLGtCQUFXO0FBQ3BCLFFBQUlDLElBQUksR0FBRyxJQUFYO0FBQ0EsUUFBSUMsSUFBSSxHQUFDRCxJQUFJLENBQUNOLEtBQWQ7QUFDQUosSUFBQUEsRUFBRSxDQUFDWSxNQUFILENBQVVDLElBQVYsQ0FBZTtBQUNkQyxNQUFBQSxHQUFHLEVBQUNILElBRFU7QUFFZEwsTUFBQUEsSUFBSSxFQUFDO0FBRlMsS0FBZixFQUdFLFVBQVNTLEdBQVQsRUFBYUMsT0FBYixFQUFxQkMsSUFBckIsRUFBMEI7QUFDM0IsVUFBSUMsS0FBSyxHQUFDLElBQUlsQixFQUFFLENBQUNtQixXQUFQLENBQW1CSCxPQUFuQixDQUFWOztBQUNBLFVBQUdELEdBQUgsRUFBTztBQUNOSyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaLEVBQW1CTixHQUFuQjtBQUNBOztBQUNETCxNQUFBQSxJQUFJLENBQUNMLFFBQUwsQ0FBY2lCLFlBQWQsQ0FBMkJ0QixFQUFFLENBQUNPLE1BQTlCLEVBQXNDZ0IsV0FBdEMsR0FBa0RMLEtBQWxEO0FBRUEsS0FWRDtBQVdELEdBM0JRO0FBNkJMTSxFQUFBQSxNQUFNLEVBQUUsZ0JBQVNDLEVBQVQsRUFBYSxDQUFFO0FBN0JsQixDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+WKoOi9veWbvueJh1xuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICBJYW1nZTogXCJcIixcclxuXHQgICBCR1Nwcml0ZTp7XG5cdFx0ICBkZWZhdWx0Om51bGwsXG5cdFx0ICB0eXBlOmNjLlNwcml0ZSxcblx0XHQgIHNlcmlhbHphYmxlOnRydWUsXG5cdCAgIH0sXG4gICAgfSxcblxuXG4gICAgb25Mb2FkOmZ1bmN0aW9uKCkge1xuXHRcdHZhciBzZWxmID0gdGhpcztcblx0XHRsZXQgX3VybD1zZWxmLklhbWdlO1xuXHRcdGNjLmxvYWRlci5sb2FkKHtcblx0XHRcdHVybDpfdXJsLFxuXHRcdFx0dHlwZTonanBnJ1xuXHRcdH0sZnVuY3Rpb24oZXJyLHRleHR1cmUsdGVzdCl7XG5cdFx0XHR2YXIgZnJhbWU9bmV3IGNjLlNwcml0ZUZyYW1lKHRleHR1cmUpO1xuXHRcdFx0aWYoZXJyKXtcblx0XHRcdFx0Y29uc29sZS5sb2coXCLlm77niYfplJnor69cIixlcnIpO1xuXHRcdFx0fVxuXHRcdFx0c2VsZi5CR1Nwcml0ZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKS5zcHJpdGVGcmFtZT1mcmFtZTtcblx0XHRcdFxuXHRcdH0pXG59LFxuXG4gICAgdXBkYXRlOiBmdW5jdGlvbihkdCkge30sXHJcblx0XG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Loading_Friends.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'db76bxjOYpOvLoHND/u41oj', 'Loading_Friends');
// Script/Loading_Friends.js

"use strict";

//下载好友信息
cc.Class({
  "extends": cc.Component,
  properties: {
    Friend_Show_Label: cc.Node,
    Friend_Show: cc.Prefab
  },
  // onLoad () {},
  start: function start() {
    var _this = this;

    console.log("该子域被调用显示了"); //接收主域信息

    wx.onMessage(function (reDate) {
      console.log(reDate); //如果为get，更新关系域中存储的信息。

      if (reDate.type == "GET") {
        console.log("good");
        var children = _this.Friend_Show_Label.children;
        var length = children.length; //清空列表

        for (var i = 0; i < length; i++) {
          children[i].destroy();
        }

        console.log("good");
        wx.getFriendCloudStorage({
          keyList: reDate.data,
          success: function success(res) {
            console.log("好友信息：", res.data, reDate.data);
            var _tempArr = []; //将好友信息载入_tempArr中

            for (var _i = 0; _i < res.data.length; ++_i) {
              console.log("score为", res.data[_i].KVDataList[0].value);

              var _parseScore = Number(res.data[_i].KVDataList[0].value);

              _tempArr.push(_parseScore);
            } //排序


            _tempArr.sort(function (a, b) {
              return b - a;
            }); //匹配


            var index = 0;

            while (index < _tempArr.length) {
              //根据排序后的数值生成排行榜数据
              for (var _i2 = 0; _i2 < res.data.length; ++_i2) {
                var _parseScore2 = Number(res.data[_i2].KVDataList[0].value);

                if (_tempArr[index] == _parseScore2) {
                  _this.Create_User_Block(res.data[_i2], index);

                  res.data.splice(_i2, 1);
                  break;
                }
              }

              index++;
            }
          }
        });
      } else if (reDate.type == "SET") {
        //接收信息，更新子域中存储的信息
        wx.setUserCloudStorage({
          KVDataList: reDate.data,
          success: function success(res) {
            console.log("存储成功");
            console.log(res, reDate.data);
          },
          fail: function fail(res) {
            console.log("存储失败");
            console.error(res);
          },
          complete: function complete(res) {
            console.log("存储程序运行了");
          }
        });
      }
    });
  },
  //对好友框进行渲染
  Create_User_Block: function Create_User_Block(user, index) {
    var New_Friend_Show = cc.instantiate(this.Friend_Show);
    this.Friend_Show_Label.addChild(New_Friend_Show); //设置昵称

    console.log("设置昵称");
    New_Friend_Show.getChildByName("User_Name").getComponent(cc.Label).string = user.nickname || user.nickName; //设置分数

    console.log("设置分数");
    console.log("此时的user为", user.KVDataList[0].value);
    New_Friend_Show.getChildByName("Best_Score_Text").getComponent(cc.Label).string = "" + user.KVDataList[0].value + "分";
    New_Friend_Show.getChildByName("Game_Rank_Show").getComponent(cc.Label).string = "" + (1 + index); //设置头像

    console.log("设置头像");
    cc.loader.load({
      url: user.avatarUrl,
      type: 'png'
    }, function (err, texture) {
      if (err) {
        console.error(err);
      }

      New_Friend_Show.getChildByName("Head_Image_Mask").getChildByName("Head_Image").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
    });
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxMb2FkaW5nX0ZyaWVuZHMuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJGcmllbmRfU2hvd19MYWJlbCIsIk5vZGUiLCJGcmllbmRfU2hvdyIsIlByZWZhYiIsInN0YXJ0IiwiY29uc29sZSIsImxvZyIsInd4Iiwib25NZXNzYWdlIiwicmVEYXRlIiwidHlwZSIsImNoaWxkcmVuIiwibGVuZ3RoIiwiaSIsImRlc3Ryb3kiLCJnZXRGcmllbmRDbG91ZFN0b3JhZ2UiLCJrZXlMaXN0IiwiZGF0YSIsInN1Y2Nlc3MiLCJyZXMiLCJfdGVtcEFyciIsIktWRGF0YUxpc3QiLCJ2YWx1ZSIsIl9wYXJzZVNjb3JlIiwiTnVtYmVyIiwicHVzaCIsInNvcnQiLCJhIiwiYiIsImluZGV4IiwiQ3JlYXRlX1VzZXJfQmxvY2siLCJzcGxpY2UiLCJzZXRVc2VyQ2xvdWRTdG9yYWdlIiwiZmFpbCIsImVycm9yIiwiY29tcGxldGUiLCJ1c2VyIiwiTmV3X0ZyaWVuZF9TaG93IiwiaW5zdGFudGlhdGUiLCJhZGRDaGlsZCIsImdldENoaWxkQnlOYW1lIiwiZ2V0Q29tcG9uZW50IiwiTGFiZWwiLCJzdHJpbmciLCJuaWNrbmFtZSIsIm5pY2tOYW1lIiwibG9hZGVyIiwibG9hZCIsInVybCIsImF2YXRhclVybCIsImVyciIsInRleHR1cmUiLCJTcHJpdGUiLCJzcHJpdGVGcmFtZSIsIlNwcml0ZUZyYW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0FBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ1IsYUFBU0QsRUFBRSxDQUFDRSxTQURKO0FBR1JDLEVBQUFBLFVBQVUsRUFBRTtBQUNYQyxJQUFBQSxpQkFBaUIsRUFBRUosRUFBRSxDQUFDSyxJQURYO0FBRVhDLElBQUFBLFdBQVcsRUFBRU4sRUFBRSxDQUFDTztBQUZMLEdBSEo7QUFRUjtBQUVBQyxFQUFBQSxLQVZRLG1CQVVBO0FBQUE7O0FBQ1BDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosRUFETyxDQUVQOztBQUNBQyxJQUFBQSxFQUFFLENBQUNDLFNBQUgsQ0FBYSxVQUFBQyxNQUFNLEVBQUk7QUFDdEJKLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZRyxNQUFaLEVBRHNCLENBRXRCOztBQUNBLFVBQUlBLE1BQU0sQ0FBQ0MsSUFBUCxJQUFlLEtBQW5CLEVBQTBCO0FBQ3pCTCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0EsWUFBSUssUUFBUSxHQUFHLEtBQUksQ0FBQ1gsaUJBQUwsQ0FBdUJXLFFBQXRDO0FBQ0EsWUFBSUMsTUFBTSxHQUFHRCxRQUFRLENBQUNDLE1BQXRCLENBSHlCLENBSXpCOztBQUNBLGFBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0QsTUFBcEIsRUFBNEJDLENBQUMsRUFBN0IsRUFBaUM7QUFDaENGLFVBQUFBLFFBQVEsQ0FBQ0UsQ0FBRCxDQUFSLENBQVlDLE9BQVo7QUFDQTs7QUFDRFQsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBQyxRQUFBQSxFQUFFLENBQUNRLHFCQUFILENBQXlCO0FBQ3hCQyxVQUFBQSxPQUFPLEVBQUVQLE1BQU0sQ0FBQ1EsSUFEUTtBQUV4QkMsVUFBQUEsT0FBTyxFQUFFLGlCQUFBQyxHQUFHLEVBQUk7QUFDZmQsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWixFQUFxQmEsR0FBRyxDQUFDRixJQUF6QixFQUErQlIsTUFBTSxDQUFDUSxJQUF0QztBQUNBLGdCQUFJRyxRQUFRLEdBQUcsRUFBZixDQUZlLENBR2Y7O0FBQ0EsaUJBQUssSUFBSVAsRUFBQyxHQUFHLENBQWIsRUFBZ0JBLEVBQUMsR0FBR00sR0FBRyxDQUFDRixJQUFKLENBQVNMLE1BQTdCLEVBQXFDLEVBQUVDLEVBQXZDLEVBQTBDO0FBQ3pDUixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaLEVBQXNCYSxHQUFHLENBQUNGLElBQUosQ0FBU0osRUFBVCxFQUFZUSxVQUFaLENBQXVCLENBQXZCLEVBQTBCQyxLQUFoRDs7QUFDQSxrQkFBSUMsV0FBVyxHQUFHQyxNQUFNLENBQUNMLEdBQUcsQ0FBQ0YsSUFBSixDQUFTSixFQUFULEVBQVlRLFVBQVosQ0FBdUIsQ0FBdkIsRUFBMEJDLEtBQTNCLENBQXhCOztBQUNBRixjQUFBQSxRQUFRLENBQUNLLElBQVQsQ0FBY0YsV0FBZDtBQUNBLGFBUmMsQ0FTZjs7O0FBQ0FILFlBQUFBLFFBQVEsQ0FBQ00sSUFBVCxDQUFjLFVBQUNDLENBQUQsRUFBSUMsQ0FBSixFQUFVO0FBQ3ZCLHFCQUFPQSxDQUFDLEdBQUdELENBQVg7QUFDQSxhQUZELEVBVmUsQ0FhZjs7O0FBQ0EsZ0JBQUlFLEtBQUssR0FBRyxDQUFaOztBQUNBLG1CQUFPQSxLQUFLLEdBQUdULFFBQVEsQ0FBQ1IsTUFBeEIsRUFBZ0M7QUFDL0I7QUFDQSxtQkFBSyxJQUFJQyxHQUFDLEdBQUcsQ0FBYixFQUFnQkEsR0FBQyxHQUFHTSxHQUFHLENBQUNGLElBQUosQ0FBU0wsTUFBN0IsRUFBcUMsRUFBRUMsR0FBdkMsRUFBMEM7QUFDekMsb0JBQUlVLFlBQVcsR0FBR0MsTUFBTSxDQUFDTCxHQUFHLENBQUNGLElBQUosQ0FBU0osR0FBVCxFQUFZUSxVQUFaLENBQXVCLENBQXZCLEVBQTBCQyxLQUEzQixDQUF4Qjs7QUFDQSxvQkFBSUYsUUFBUSxDQUFDUyxLQUFELENBQVIsSUFBbUJOLFlBQXZCLEVBQW9DO0FBQ25DLGtCQUFBLEtBQUksQ0FBQ08saUJBQUwsQ0FBdUJYLEdBQUcsQ0FBQ0YsSUFBSixDQUFTSixHQUFULENBQXZCLEVBQW9DZ0IsS0FBcEM7O0FBQ0FWLGtCQUFBQSxHQUFHLENBQUNGLElBQUosQ0FBU2MsTUFBVCxDQUFnQmxCLEdBQWhCLEVBQW1CLENBQW5CO0FBQ0E7QUFDQTtBQUNEOztBQUNEZ0IsY0FBQUEsS0FBSztBQUNMO0FBQ0Q7QUE3QnVCLFNBQXpCO0FBK0JBLE9BeENELE1Bd0NPLElBQUlwQixNQUFNLENBQUNDLElBQVAsSUFBZSxLQUFuQixFQUEwQjtBQUNoQztBQUNBSCxRQUFBQSxFQUFFLENBQUN5QixtQkFBSCxDQUF1QjtBQUN0QlgsVUFBQUEsVUFBVSxFQUFFWixNQUFNLENBQUNRLElBREc7QUFFdEJDLFVBQUFBLE9BQU8sRUFBRSxpQkFBU0MsR0FBVCxFQUFjO0FBQ3RCZCxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FELFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZYSxHQUFaLEVBQWlCVixNQUFNLENBQUNRLElBQXhCO0FBQ0EsV0FMcUI7QUFNdEJnQixVQUFBQSxJQUFJLEVBQUUsY0FBU2QsR0FBVCxFQUFjO0FBQ25CZCxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FELFlBQUFBLE9BQU8sQ0FBQzZCLEtBQVIsQ0FBY2YsR0FBZDtBQUNBLFdBVHFCO0FBVXRCZ0IsVUFBQUEsUUFWc0Isb0JBVWJoQixHQVZhLEVBVVI7QUFDYmQsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjtBQUNBO0FBWnFCLFNBQXZCO0FBY0E7QUFDRCxLQTVERDtBQTZEQSxHQTFFTztBQTJFUjtBQUNBd0IsRUFBQUEsaUJBQWlCLEVBQUUsMkJBQVNNLElBQVQsRUFBZVAsS0FBZixFQUFzQjtBQUN4QyxRQUFJUSxlQUFlLEdBQUd6QyxFQUFFLENBQUMwQyxXQUFILENBQWUsS0FBS3BDLFdBQXBCLENBQXRCO0FBQ0EsU0FBS0YsaUJBQUwsQ0FBdUJ1QyxRQUF2QixDQUFnQ0YsZUFBaEMsRUFGd0MsQ0FHeEM7O0FBQ0FoQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0ErQixJQUFBQSxlQUFlLENBQUNHLGNBQWhCLENBQStCLFdBQS9CLEVBQTRDQyxZQUE1QyxDQUF5RDdDLEVBQUUsQ0FBQzhDLEtBQTVELEVBQW1FQyxNQUFuRSxHQUE0RVAsSUFBSSxDQUFDUSxRQUFMLElBQWlCUixJQUFJLENBQUNTLFFBQWxHLENBTHdDLENBT3hDOztBQUNBeEMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUNBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxVQUFaLEVBQXdCOEIsSUFBSSxDQUFDZixVQUFMLENBQWdCLENBQWhCLEVBQW1CQyxLQUEzQztBQUNBZSxJQUFBQSxlQUFlLENBQUNHLGNBQWhCLENBQStCLGlCQUEvQixFQUFrREMsWUFBbEQsQ0FBK0Q3QyxFQUFFLENBQUM4QyxLQUFsRSxFQUF5RUMsTUFBekUsR0FBa0YsS0FBS1AsSUFBSSxDQUFDZixVQUFMLENBQWdCLENBQWhCLEVBQW1CQyxLQUF4QixHQUNqRixHQUREO0FBRUFlLElBQUFBLGVBQWUsQ0FBQ0csY0FBaEIsQ0FBK0IsZ0JBQS9CLEVBQWlEQyxZQUFqRCxDQUE4RDdDLEVBQUUsQ0FBQzhDLEtBQWpFLEVBQXdFQyxNQUF4RSxHQUFpRixNQUFNLElBQUlkLEtBQVYsQ0FBakYsQ0Fad0MsQ0FjeEM7O0FBQ0F4QixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0FWLElBQUFBLEVBQUUsQ0FBQ2tELE1BQUgsQ0FBVUMsSUFBVixDQUFlO0FBQ2RDLE1BQUFBLEdBQUcsRUFBRVosSUFBSSxDQUFDYSxTQURJO0FBRWR2QyxNQUFBQSxJQUFJLEVBQUU7QUFGUSxLQUFmLEVBR0csVUFBQ3dDLEdBQUQsRUFBTUMsT0FBTixFQUFrQjtBQUNwQixVQUFJRCxHQUFKLEVBQVM7QUFDUjdDLFFBQUFBLE9BQU8sQ0FBQzZCLEtBQVIsQ0FBY2dCLEdBQWQ7QUFDQTs7QUFDRGIsTUFBQUEsZUFBZSxDQUFDRyxjQUFoQixDQUErQixpQkFBL0IsRUFBa0RBLGNBQWxELENBQWlFLFlBQWpFLEVBQStFQyxZQUEvRSxDQUE0RjdDLEVBQUUsQ0FBQ3dELE1BQS9GLEVBQXVHQyxXQUF2RyxHQUNDLElBQUl6RCxFQUFFLENBQUMwRCxXQUFQLENBQW1CSCxPQUFuQixDQUREO0FBRUEsS0FURDtBQVVBLEdBdEdPLENBdUdSOztBQXZHUSxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvL+S4i+i9veWlveWPi+S/oeaBr1xyXG5jYy5DbGFzcyh7XHJcblx0ZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRwcm9wZXJ0aWVzOiB7XHJcblx0XHRGcmllbmRfU2hvd19MYWJlbDogY2MuTm9kZSxcclxuXHRcdEZyaWVuZF9TaG93OiBjYy5QcmVmYWIsXHJcblx0fSxcclxuXHJcblx0Ly8gb25Mb2FkICgpIHt9LFxyXG5cclxuXHRzdGFydCgpIHtcclxuXHRcdGNvbnNvbGUubG9nKFwi6K+l5a2Q5Z+f6KKr6LCD55So5pi+56S65LqGXCIpO1xyXG5cdFx0Ly/mjqXmlLbkuLvln5/kv6Hmga9cclxuXHRcdHd4Lm9uTWVzc2FnZShyZURhdGUgPT4ge1xyXG5cdFx0XHRjb25zb2xlLmxvZyhyZURhdGUpO1xyXG5cdFx0XHQvL+WmguaenOS4umdldO+8jOabtOaWsOWFs+ezu+Wfn+S4reWtmOWCqOeahOS/oeaBr+OAglxyXG5cdFx0XHRpZiAocmVEYXRlLnR5cGUgPT0gXCJHRVRcIikge1xyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwiZ29vZFwiKTtcclxuXHRcdFx0XHRsZXQgY2hpbGRyZW4gPSB0aGlzLkZyaWVuZF9TaG93X0xhYmVsLmNoaWxkcmVuO1xyXG5cdFx0XHRcdGxldCBsZW5ndGggPSBjaGlsZHJlbi5sZW5ndGg7XHJcblx0XHRcdFx0Ly/muIXnqbrliJfooahcclxuXHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XHJcblx0XHRcdFx0XHRjaGlsZHJlbltpXS5kZXN0cm95KCk7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdGNvbnNvbGUubG9nKFwiZ29vZFwiKTtcclxuXHRcdFx0XHR3eC5nZXRGcmllbmRDbG91ZFN0b3JhZ2Uoe1xyXG5cdFx0XHRcdFx0a2V5TGlzdDogcmVEYXRlLmRhdGEsXHJcblx0XHRcdFx0XHRzdWNjZXNzOiByZXMgPT4ge1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWlveWPi+S/oeaBr++8mlwiLCByZXMuZGF0YSwgcmVEYXRlLmRhdGEpO1xyXG5cdFx0XHRcdFx0XHRsZXQgX3RlbXBBcnIgPSBbXTtcclxuXHRcdFx0XHRcdFx0Ly/lsIblpb3lj4vkv6Hmga/ovb3lhaVfdGVtcEFycuS4rVxyXG5cdFx0XHRcdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHJlcy5kYXRhLmxlbmd0aDsgKytpKSB7XHJcblx0XHRcdFx0XHRcdFx0Y29uc29sZS5sb2coXCJzY29yZeS4ulwiLCByZXMuZGF0YVtpXS5LVkRhdGFMaXN0WzBdLnZhbHVlKTtcclxuXHRcdFx0XHRcdFx0XHRsZXQgX3BhcnNlU2NvcmUgPSBOdW1iZXIocmVzLmRhdGFbaV0uS1ZEYXRhTGlzdFswXS52YWx1ZSk7XHJcblx0XHRcdFx0XHRcdFx0X3RlbXBBcnIucHVzaChfcGFyc2VTY29yZSk7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdFx0Ly/mjpLluo9cclxuXHRcdFx0XHRcdFx0X3RlbXBBcnIuc29ydCgoYSwgYikgPT4ge1xyXG5cdFx0XHRcdFx0XHRcdHJldHVybiBiIC0gYTtcclxuXHRcdFx0XHRcdFx0fSk7XHJcblx0XHRcdFx0XHRcdC8v5Yy56YWNXHJcblx0XHRcdFx0XHRcdGxldCBpbmRleCA9IDA7XHJcblx0XHRcdFx0XHRcdHdoaWxlIChpbmRleCA8IF90ZW1wQXJyLmxlbmd0aCkge1xyXG5cdFx0XHRcdFx0XHRcdC8v5qC55o2u5o6S5bqP5ZCO55qE5pWw5YC855Sf5oiQ5o6S6KGM5qac5pWw5o2uXHJcblx0XHRcdFx0XHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCByZXMuZGF0YS5sZW5ndGg7ICsraSkge1xyXG5cdFx0XHRcdFx0XHRcdFx0bGV0IF9wYXJzZVNjb3JlID0gTnVtYmVyKHJlcy5kYXRhW2ldLktWRGF0YUxpc3RbMF0udmFsdWUpO1xyXG5cdFx0XHRcdFx0XHRcdFx0aWYgKF90ZW1wQXJyW2luZGV4XSA9PSBfcGFyc2VTY29yZSkge1xyXG5cdFx0XHRcdFx0XHRcdFx0XHR0aGlzLkNyZWF0ZV9Vc2VyX0Jsb2NrKHJlcy5kYXRhW2ldLCBpbmRleCk7XHJcblx0XHRcdFx0XHRcdFx0XHRcdHJlcy5kYXRhLnNwbGljZShpLCAxKTtcclxuXHRcdFx0XHRcdFx0XHRcdFx0YnJlYWs7XHJcblx0XHRcdFx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRcdFx0fVxyXG5cdFx0XHRcdFx0XHRcdGluZGV4Kys7XHJcblx0XHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9KVxyXG5cdFx0XHR9IGVsc2UgaWYgKHJlRGF0ZS50eXBlID09IFwiU0VUXCIpIHtcclxuXHRcdFx0XHQvL+aOpeaUtuS/oeaBr++8jOabtOaWsOWtkOWfn+S4reWtmOWCqOeahOS/oeaBr1xyXG5cdFx0XHRcdHd4LnNldFVzZXJDbG91ZFN0b3JhZ2Uoe1xyXG5cdFx0XHRcdFx0S1ZEYXRhTGlzdDogcmVEYXRlLmRhdGEsXHJcblx0XHRcdFx0XHRzdWNjZXNzOiBmdW5jdGlvbihyZXMpIHtcclxuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coXCLlrZjlgqjmiJDlip9cIik7XHJcblx0XHRcdFx0XHRcdGNvbnNvbGUubG9nKHJlcywgcmVEYXRlLmRhdGEpO1xyXG5cdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdGZhaWw6IGZ1bmN0aW9uKHJlcykge1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWtmOWCqOWksei0pVwiKTtcclxuXHRcdFx0XHRcdFx0Y29uc29sZS5lcnJvcihyZXMpO1xyXG5cdFx0XHRcdFx0fSxcclxuXHRcdFx0XHRcdGNvbXBsZXRlKHJlcykge1xyXG5cdFx0XHRcdFx0XHRjb25zb2xlLmxvZyhcIuWtmOWCqOeoi+W6j+i/kOihjOS6hlwiKTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9KTtcclxuXHRcdFx0fVxyXG5cdFx0fSlcclxuXHR9LFxyXG5cdC8v5a+55aW95Y+L5qGG6L+b6KGM5riy5p+TXHJcblx0Q3JlYXRlX1VzZXJfQmxvY2s6IGZ1bmN0aW9uKHVzZXIsIGluZGV4KSB7XHJcblx0XHR2YXIgTmV3X0ZyaWVuZF9TaG93ID0gY2MuaW5zdGFudGlhdGUodGhpcy5GcmllbmRfU2hvdyk7XHJcblx0XHR0aGlzLkZyaWVuZF9TaG93X0xhYmVsLmFkZENoaWxkKE5ld19GcmllbmRfU2hvdyk7XHJcblx0XHQvL+iuvue9ruaYteensFxyXG5cdFx0Y29uc29sZS5sb2coXCLorr7nva7mmLXnp7BcIik7XHJcblx0XHROZXdfRnJpZW5kX1Nob3cuZ2V0Q2hpbGRCeU5hbWUoXCJVc2VyX05hbWVcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSB1c2VyLm5pY2tuYW1lIHx8IHVzZXIubmlja05hbWU7XHJcblxyXG5cdFx0Ly/orr7nva7liIbmlbBcclxuXHRcdGNvbnNvbGUubG9nKFwi6K6+572u5YiG5pWwXCIpO1xyXG5cdFx0Y29uc29sZS5sb2coXCLmraTml7bnmoR1c2Vy5Li6XCIsIHVzZXIuS1ZEYXRhTGlzdFswXS52YWx1ZSk7XHJcblx0XHROZXdfRnJpZW5kX1Nob3cuZ2V0Q2hpbGRCeU5hbWUoXCJCZXN0X1Njb3JlX1RleHRcIikuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSBcIlwiICsgdXNlci5LVkRhdGFMaXN0WzBdLnZhbHVlICtcclxuXHRcdFx0XCLliIZcIjtcclxuXHRcdE5ld19GcmllbmRfU2hvdy5nZXRDaGlsZEJ5TmFtZShcIkdhbWVfUmFua19TaG93XCIpLmdldENvbXBvbmVudChjYy5MYWJlbCkuc3RyaW5nID0gXCJcIiArICgxICsgaW5kZXgpO1xyXG5cclxuXHRcdC8v6K6+572u5aS05YOPXHJcblx0XHRjb25zb2xlLmxvZyhcIuiuvue9ruWktOWDj1wiKTtcclxuXHRcdGNjLmxvYWRlci5sb2FkKHtcclxuXHRcdFx0dXJsOiB1c2VyLmF2YXRhclVybCxcclxuXHRcdFx0dHlwZTogJ3BuZydcclxuXHRcdH0sIChlcnIsIHRleHR1cmUpID0+IHtcclxuXHRcdFx0aWYgKGVycikge1xyXG5cdFx0XHRcdGNvbnNvbGUuZXJyb3IoZXJyKTtcclxuXHRcdFx0fVxyXG5cdFx0XHROZXdfRnJpZW5kX1Nob3cuZ2V0Q2hpbGRCeU5hbWUoXCJIZWFkX0ltYWdlX01hc2tcIikuZ2V0Q2hpbGRCeU5hbWUoXCJIZWFkX0ltYWdlXCIpLmdldENvbXBvbmVudChjYy5TcHJpdGUpLnNwcml0ZUZyYW1lID1cclxuXHRcdFx0XHRuZXcgY2MuU3ByaXRlRnJhbWUodGV4dHVyZSk7XHJcblx0XHR9KVxyXG5cdH0sXHJcblx0Ly8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xuIl19
//------QC-SOURCE-SPLIT------
