
require('./assets/Script/Cloud_Image');
require('./assets/Script/Loading_Friends');
