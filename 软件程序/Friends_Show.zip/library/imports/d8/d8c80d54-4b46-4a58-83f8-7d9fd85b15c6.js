"use strict";
cc._RF.push(module, 'd8c801US0ZKWIP4fZ/YWxXG', 'Cloud_Image');
// Script/Cloud_Image.js

"use strict";

//加载图片
cc.Class({
  "extends": cc.Component,
  properties: {
    Iamge: "",
    BGSprite: {
      "default": null,
      type: cc.Sprite,
      serialzable: true
    }
  },
  onLoad: function onLoad() {
    var self = this;
    var _url = self.Iamge;
    cc.loader.load({
      url: _url,
      type: 'jpg'
    }, function (err, texture, test) {
      var frame = new cc.SpriteFrame(texture);

      if (err) {
        console.log("图片错误", err);
      }

      self.BGSprite.getComponent(cc.Sprite).spriteFrame = frame;
    });
  },
  update: function update(dt) {}
});

cc._RF.pop();