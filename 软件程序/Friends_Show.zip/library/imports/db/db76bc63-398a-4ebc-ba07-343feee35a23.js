"use strict";
cc._RF.push(module, 'db76bxjOYpOvLoHND/u41oj', 'Loading_Friends');
// Script/Loading_Friends.js

"use strict";

//下载好友信息
cc.Class({
  "extends": cc.Component,
  properties: {
    Friend_Show_Label: cc.Node,
    Friend_Show: cc.Prefab
  },
  // onLoad () {},
  start: function start() {
    var _this = this;

    console.log("该子域被调用显示了"); //接收主域信息

    wx.onMessage(function (reDate) {
      console.log(reDate); //如果为get，更新关系域中存储的信息。

      if (reDate.type == "GET") {
        console.log("good");
        var children = _this.Friend_Show_Label.children;
        var length = children.length; //清空列表

        for (var i = 0; i < length; i++) {
          children[i].destroy();
        }

        console.log("good");
        wx.getFriendCloudStorage({
          keyList: reDate.data,
          success: function success(res) {
            console.log("好友信息：", res.data, reDate.data);
            var _tempArr = []; //将好友信息载入_tempArr中

            for (var _i = 0; _i < res.data.length; ++_i) {
              console.log("score为", res.data[_i].KVDataList[0].value);

              var _parseScore = Number(res.data[_i].KVDataList[0].value);

              _tempArr.push(_parseScore);
            } //排序


            _tempArr.sort(function (a, b) {
              return b - a;
            }); //匹配


            var index = 0;

            while (index < _tempArr.length) {
              //根据排序后的数值生成排行榜数据
              for (var _i2 = 0; _i2 < res.data.length; ++_i2) {
                var _parseScore2 = Number(res.data[_i2].KVDataList[0].value);

                if (_tempArr[index] == _parseScore2) {
                  _this.Create_User_Block(res.data[_i2], index);

                  res.data.splice(_i2, 1);
                  break;
                }
              }

              index++;
            }
          }
        });
      } else if (reDate.type == "SET") {
        //接收信息，更新子域中存储的信息
        wx.setUserCloudStorage({
          KVDataList: reDate.data,
          success: function success(res) {
            console.log("存储成功");
            console.log(res, reDate.data);
          },
          fail: function fail(res) {
            console.log("存储失败");
            console.error(res);
          },
          complete: function complete(res) {
            console.log("存储程序运行了");
          }
        });
      }
    });
  },
  //对好友框进行渲染
  Create_User_Block: function Create_User_Block(user, index) {
    var New_Friend_Show = cc.instantiate(this.Friend_Show);
    this.Friend_Show_Label.addChild(New_Friend_Show); //设置昵称

    console.log("设置昵称");
    New_Friend_Show.getChildByName("User_Name").getComponent(cc.Label).string = user.nickname || user.nickName; //设置分数

    console.log("设置分数");
    console.log("此时的user为", user.KVDataList[0].value);
    New_Friend_Show.getChildByName("Best_Score_Text").getComponent(cc.Label).string = "" + user.KVDataList[0].value + "分";
    New_Friend_Show.getChildByName("Game_Rank_Show").getComponent(cc.Label).string = "" + (1 + index); //设置头像

    console.log("设置头像");
    cc.loader.load({
      url: user.avatarUrl,
      type: 'png'
    }, function (err, texture) {
      if (err) {
        console.error(err);
      }

      New_Friend_Show.getChildByName("Head_Image_Mask").getChildByName("Head_Image").getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
    });
  } // update (dt) {},

});

cc._RF.pop();